/**
 * "Never sell air", and "can anyone fake a job or a sale?".
 */
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { fakeNet, newSignature, newWallet, payStubSession, sigInfo, signedEvent, solTransferTx, start } from './helpers.ts';
import type { Running } from './helpers.ts';

async function makeProduct(app: Running, extra: Record<string, unknown> = {}) {
  const res = await app.api('POST', '/api/console/products', {
    title: 'Invoice Chaser Kit',
    description: 'Three reminder email templates and a setup guide.',
    priceDollars: 99,
    ships: ['3 email templates', 'Setup guide (PDF)'],
    doesNotShip: ['Done-for-you setup'],
    ...extra,
  });
  assert.equal(res.status, 201, JSON.stringify(res.json));
  return res.json.product;
}

async function webhook(app: Running, payload: string, header: string) {
  const res = await fetch(app.url + '/api/webhooks/stripe', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Stripe-Signature': header }, body: payload });
  return res.status;
}

test('a product cannot go on sale without a real deliverable — in the API and in the database', async () => {
  const app = await start({}, { stripe: true });
  try {
    await app.login();
    const p = await makeProduct(app);
    assert.equal(p.status, 'draft');
    assert.equal(p.hasDeliverable, false);

    const list = await app.api('POST', `/api/console/products/${p.id}/status`, { status: 'listed' });
    assert.equal(list.status, 409);
    assert.equal(list.json.code, 'NEVER_SELL_AIR');
    assert.equal((await app.api('GET', `/api/public/product/${p.slug}`, undefined, { cookie: null })).status, 404);

    // Even writing straight to the database cannot list it.
    await assert.rejects(app.built.db.query(`UPDATE products SET status = 'listed' WHERE id = $1`, [p.id]), /never_sell_air/);

    // Dangerous or non-web links are not accepted as deliverables.
    for (const value of ['javascript:alert(1)', 'data:text/html,<script>alert(1)</script>', 'file:///etc/passwd', 'not a url']) {
      const res = await app.api('PUT', `/api/console/products/${p.id}`, { title: p.title, description: p.description, priceDollars: 99, deliverableKind: 'link', deliverableValue: value });
      assert.equal(res.status, 400, `"${value}" must be rejected`);
    }

    const withFile = await app.api('PUT', `/api/console/products/${p.id}`, {
      title: p.title,
      description: p.description,
      priceDollars: 99,
      deliverableKind: 'link',
      deliverableValue: 'https://files.example.com/invoice-chaser-kit.zip?sig=secret-download-token',
    });
    assert.equal(withFile.json.product.hasDeliverable, true);
    const listed = await app.api('POST', `/api/console/products/${p.id}/status`, { status: 'listed' });
    assert.equal(listed.json.product.status, 'listed');

    // On sale: the deliverable cannot be stripped out from under buyers.
    const strip = await app.api('PUT', `/api/console/products/${p.id}`, { title: p.title, description: p.description, priceDollars: 99 });
    assert.equal(strip.status, 409);
  } finally {
    await app.close();
  }
});

test('buying by card: server-side price, deliverable revealed only after verified payment', async () => {
  const app = await start({}, { stripe: true });
  try {
    await app.login();
    const p = await makeProduct(app, { deliverableKind: 'link', deliverableValue: 'https://files.example.com/kit.zip?sig=secret-download-token' });
    await app.api('POST', `/api/console/products/${p.id}/status`, { status: 'listed' });

    const pub = await app.api('GET', `/api/public/product/${p.slug}`, undefined, { cookie: null });
    assert.equal(pub.status, 200);
    assert.ok(!JSON.stringify(pub.json).includes('secret-download-token'), 'the product page never contains the deliverable');
    assert.ok(!JSON.stringify(pub.json).includes(p.id));

    const buy = await app.api('POST', `/api/public/product/${p.slug}/checkout`, { priceCents: 1, amount: 0.01 }, { cookie: null });
    assert.equal(buy.status, 200);
    const create = app.stub!.requests.find(r => r.method === 'POST' && r.path === '/v1/checkout/sessions')!;
    assert.equal(create.body['line_items[0][price_data][unit_amount]'], '9900', 'price comes from the server');
    assert.equal(create.body['metadata[flash_kind]'], 'order');

    const token = buy.json.orderToken;
    let order = (await app.api('GET', `/api/public/order/${token}`, undefined, { cookie: null })).json;
    assert.equal(order.status, 'pending');
    assert.equal(order.deliverable, null, 'nothing is delivered before payment');
    // Unpaid orders do not appear as sales.
    assert.equal((await app.api('GET', '/api/console/orders')).json.orders.length, 0);
    assert.equal((await app.api('GET', '/api/console/products')).json.products[0].soldCount, 0);

    const sid = [...app.stub!.sessions.keys()][0];
    payStubSession(app.stub!, sid, 'buyer@example.com');
    const ev = signedEvent('checkout.session.completed', { id: sid, object: 'checkout.session' });
    assert.equal(await webhook(app, ev.payload, ev.header), 200);

    order = (await app.api('GET', `/api/public/order/${token}`, undefined, { cookie: null })).json;
    assert.equal(order.status, 'paid');
    assert.deepEqual(order.deliverable, { kind: 'link', value: 'https://files.example.com/kit.zip?sig=secret-download-token' });

    const product = (await app.api('GET', '/api/console/products')).json.products[0];
    assert.equal(product.soldCount, 1);
    assert.equal(product.revenueCents, 9900);
    const orders = (await app.api('GET', '/api/console/orders')).json.orders;
    assert.equal(orders[0].customerEmail, 'buyer@example.com');
    assert.equal((await app.api('GET', '/api/console/overview')).json.totals.ordersPaid, 1);

    // A wrong or guessed order token reveals nothing.
    assert.equal((await app.api('GET', `/api/public/order/${'z'.repeat(32)}`, undefined, { cookie: null })).status, 404);

    // Refund → the order stops counting.
    const pi = app.stub!.sessions.get(sid).payment_intent;
    const refund = signedEvent('charge.refunded', { id: 'ch_x', object: 'charge', payment_intent: pi, amount_refunded: 9900 });
    await webhook(app, refund.payload, refund.header);
    order = (await app.api('GET', `/api/public/order/${token}`, undefined, { cookie: null })).json;
    assert.equal(order.status, 'refunded');
    assert.equal(order.deliverable, null);
    assert.equal((await app.api('GET', '/api/console/products')).json.products[0].revenueCents, 0);
  } finally {
    await app.close();
  }
});

test('buying with crypto: an underpaid order is not released', async () => {
  const wallet = newWallet();
  const net = fakeNet();
  const app = await start({ SOLANA_RECEIVE_ADDRESS: wallet.address }, { net });
  try {
    await app.login();
    const ch = (await app.api('POST', '/api/console/wallet/challenge', {})).json;
    await app.api('POST', '/api/console/wallet/verify', { signature: wallet.sign(ch.message) });
    const p = await makeProduct(app, { priceDollars: 110.2, deliverableKind: 'text', deliverableValue: 'LICENCE-KEY-123' });
    await app.api('POST', `/api/console/products/${p.id}/status`, { status: 'listed' });

    const q = (await app.api('POST', `/api/public/product/${p.slug}/quote`, { asset: 'SOL' }, { cookie: null })).json;
    assert.equal(q.quote.amount, '1');
    const token = q.orderToken;

    const half = newSignature();
    net.signatures.set(q.quote.reference, [sigInfo(half)]);
    net.transactions.set(half, solTransferTx({ recipient: wallet.address, reference: q.quote.reference, lamports: 500_000_000 }));
    await app.built.db.query('UPDATE sol_quotes SET checked_at = 0');
    let order = (await app.api('GET', `/api/public/order/${token}`, undefined, { cookie: null })).json;
    assert.equal(order.status, 'pending', 'half the price does not buy the product');
    assert.equal(order.deliverable, null);

    // The remainder arrives on a fresh quote for the same order.
    const q2 = (await app.api('POST', `/api/public/product/${p.slug}/quote`, { asset: 'SOL', orderToken: token }, { cookie: null })).json;
    assert.equal(q2.orderToken, token);
    const rest = newSignature();
    net.signatures.set(q2.quote.reference, [sigInfo(rest)]);
    net.transactions.set(rest, solTransferTx({ recipient: wallet.address, reference: q2.quote.reference, lamports: 1_000_000_000 }));
    await app.built.db.query('UPDATE sol_quotes SET checked_at = 0');
    order = (await app.api('GET', `/api/public/order/${token}`, undefined, { cookie: null })).json;
    assert.equal(order.status, 'paid');
    assert.deepEqual(order.deliverable, { kind: 'text', value: 'LICENCE-KEY-123' });
  } finally {
    await app.close();
  }
});

test('draft and archived products cannot be bought', async () => {
  const app = await start({}, { stripe: true });
  try {
    await app.login();
    const p = await makeProduct(app, { deliverableKind: 'text', deliverableValue: 'the goods' });
    assert.equal((await app.api('POST', `/api/public/product/${p.slug}/checkout`, {}, { cookie: null })).status, 404);
    await app.api('POST', `/api/console/products/${p.id}/status`, { status: 'listed' });
    assert.equal((await app.api('POST', `/api/public/product/${p.slug}/checkout`, {}, { cookie: null })).status, 200);
    await app.api('POST', `/api/console/products/${p.id}/status`, { status: 'archived' });
    assert.equal((await app.api('POST', `/api/public/product/${p.slug}/checkout`, {}, { cookie: null })).status, 404);
    assert.equal((await app.api('GET', `/api/public/product/${p.slug}`, undefined, { cookie: null })).status, 404);
  } finally {
    await app.close();
  }
});
