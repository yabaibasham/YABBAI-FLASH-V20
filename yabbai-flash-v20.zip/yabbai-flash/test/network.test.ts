/**
 * The network: links to the other apps, and a sentinel that knocks on them.
 *
 * A link is something the director clicks from a console they trust, and the
 * sentinel is this server making requests on somebody's say-so. So: can a
 * borrowed session repoint a link, can a link be something other than a web
 * address, and can the sentinel be aimed at a private machine?
 */
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { PASSWORD, fakeNet, start } from './helpers.ts';
import type { Running } from './helpers.ts';

const link = (over: Record<string, unknown> = {}) => ({ name: 'Agency site', url: 'https://agency.example.com/', realm: 'Agency', kind: 'site', ...over });
const expireStepUp = (app: Running) => app.built.db.query('UPDATE sessions SET stepup_until = 0');
const stepUp = async (app: Running) => assert.equal((await app.api('POST', '/api/auth/stepup', { password: PASSWORD })).status, 200);
const links = async (app: Running) => (await app.api('GET', '/api/console/network')).json.links as any[];

test('a link is a web address and nothing else: https beyond this machine, no credentials, no scripts', async () => {
  const app = await start();
  try {
    assert.equal((await app.api('GET', '/api/console/network', undefined, { cookie: null })).status, 401);
    assert.equal((await app.api('POST', '/api/console/network', link(), { cookie: null })).status, 401);

    await app.login();
    const made = await app.api('POST', '/api/console/network', link({ note: 'The retainer landing page.' }));
    assert.equal(made.status, 201, JSON.stringify(made.json));
    assert.equal(made.json.link.host, 'agency.example.com');
    assert.equal(made.json.link.state, 'off', 'a link is not watched unless you ask');
    assert.equal(made.json.link.lastStatus, null);
    assert.ok(made.json.link.id.startsWith('link_'));

    for (const [why, body] of [
      ['a script', link({ url: 'javascript:alert(document.cookie)' })],
      ['a data URL', link({ url: 'data:text/html,<script>alert(1)</script>' })],
      ['a file', link({ url: 'file:///etc/passwd' })],
      ['ftp', link({ url: 'ftp://files.example.com/x' })],
      ['plain http on the internet', link({ url: 'http://agency.example.com/' })],
      ['a password inside the address', link({ url: 'https://tom:hunter2@agency.example.com/' })],
      ['not an address', link({ url: 'agency dot example dot com' })],
      ['no name', link({ name: '', url: 'https://a.example.com/' })],
      ['an unknown kind', link({ kind: 'casino', url: 'https://b.example.com/' })],
      ['a realm that is too long', link({ realm: 'r'.repeat(41), url: 'https://c.example.com/' })],
      ['a note that is too long', link({ note: 'n'.repeat(241), url: 'https://d.example.com/' })],
      ['watching this machine', link({ url: 'http://127.0.0.1:7860/', watch: true })],
      ['watching a bare IP', link({ url: 'https://203.0.113.9/', watch: true })],
    ] as Array<[string, Record<string, unknown>]>) {
      const res = await app.api('POST', '/api/console/network', body);
      assert.equal(res.status, 400, `${why} must be refused (got ${res.status})`);
    }
    // An app on this computer is the one place plain http is accepted — as a link, never watched.
    const local = await app.api('POST', '/api/console/network', link({ name: 'YABBAI LOCAL', url: 'http://127.0.0.1:7860/', realm: 'This computer', kind: 'app' }));
    assert.equal(local.status, 201);
    assert.equal(local.json.link.watchable, false);

    const twice = await app.api('POST', '/api/console/network', link({ name: 'Same place again' }));
    assert.equal(twice.status, 409);
    assert.equal(twice.json.code, 'LINK_EXISTS');
    // The database holds the same line: a row that is not a web address cannot exist.
    await assert.rejects(
      () => app.built.db.query(`INSERT INTO network_links (id, name, url, realm, kind, created_at, updated_at) VALUES ('link_x', 'x', 'javascript:alert(1)', 'r', 'site', 1, 1)`),
      /link_is_a_web_address/
    );

    const view = (await app.api('GET', '/api/console/network')).json;
    assert.deepEqual(view.links.map((l: any) => l.name), ['Agency site', 'YABBAI LOCAL'], 'ordered by realm, then name');
    assert.deepEqual(view.realms, ['Agency', 'This computer']);
    // A link carries no figure of any kind.
    assert.ok(!Object.keys(view.links[0]).some(k => /cents|amount|revenue|balance|profit|value|tvl|mrr/i.test(k)));
  } finally {
    await app.close();
  }
});

test('a borrowed session cannot repoint a link: adding and changing need the password, removing does not', async () => {
  const app = await start();
  try {
    await app.login();
    const made = (await app.api('POST', '/api/console/network', link({ url: 'https://agency.example.com/pay/SECRET-TOKEN-123' }))).json.link;

    await expireStepUp(app);
    for (const res of [
      await app.api('POST', '/api/console/network', link({ url: 'https://phish.example.net/' })),
      await app.api('PUT', `/api/console/network/${made.id}`, link({ url: 'https://phish.example.net/login' })),
      await app.api('POST', '/api/console/network/import', { links: [link({ url: 'https://phish.example.net/' })] }),
    ]) {
      assert.equal(res.status, 403);
      assert.equal(res.json.code, 'STEP_UP_REQUIRED');
    }
    assert.deepEqual((await links(app)).map(l => l.url), ['https://agency.example.com/pay/SECRET-TOKEN-123'], 'nothing moved');

    await stepUp(app);
    const moved = await app.api('PUT', `/api/console/network/${made.id}`, link({ name: 'Agency site (new host)', url: 'https://agency.example.org/' }));
    assert.equal(moved.status, 200);
    assert.equal(moved.json.link.host, 'agency.example.org');
    assert.equal((await app.api('PUT', '/api/console/network/link_missing', link())).status, 404);

    // Taking a link away is always allowed.
    await expireStepUp(app);
    assert.equal((await app.api('DELETE', `/api/console/network/${made.id}`)).status, 200);
    assert.equal((await app.api('DELETE', `/api/console/network/${made.id}`)).status, 404);
    assert.deepEqual(await links(app), []);

    // Each change is on the record, by host only: a full address can carry a token.
    const entries = (await app.api('GET', '/api/console/audit')).json.entries.filter((e: any) => e.action.startsWith('network.'));
    assert.deepEqual(entries.map((e: any) => e.action).reverse(), ['network.added', 'network.changed', 'network.removed']);
    assert.equal(entries.find((e: any) => e.action === 'network.changed').detail.from, 'agency.example.com');
    assert.ok(!JSON.stringify(entries).includes('SECRET-TOKEN-123'));
  } finally {
    await app.close();
  }
});

test('import is all-or-nothing, skips what is already there, and has a ceiling', async () => {
  const app = await start();
  try {
    await app.login();
    await app.api('POST', '/api/console/network', link());

    const bad = await app.api('POST', '/api/console/network/import', {
      links: [link({ url: 'https://one.example.com/' }), link({ url: 'https://two.example.com/' }), link({ url: 'javascript:alert(1)' }), link({ url: 'https://four.example.com/' })],
    });
    assert.equal(bad.status, 400);
    assert.match(bad.json.error, /^Row 3: /);
    assert.equal((await links(app)).length, 1, 'a bad row means none of the list is written');

    for (const payload of [{}, { links: 'https://a.example.com' }, { links: [] }, { links: ['https://a.example.com'] }, { links: Array.from({ length: 101 }, (_, i) => link({ url: `https://n${i}.example.com/` })) }]) {
      assert.equal((await app.api('POST', '/api/console/network/import', payload)).status, 400);
    }

    const good = await app.api('POST', '/api/console/network/import', {
      links: [
        link(), // already there
        link({ name: 'Store', url: 'https://store.example.com/', realm: 'Products', kind: 'app', watch: true }),
        link({ name: 'Store again', url: 'https://store.example.com/', realm: 'Products', kind: 'app' }), // repeated inside the list
        link({ name: 'Money map', url: 'https://docs.example.com/money-map', realm: 'Library', kind: 'doc', stage: 'won', id: 'link_admin', lastStatus: 200, state: 'up' }),
      ],
    });
    assert.equal(good.status, 200, JSON.stringify(good.json));
    assert.deepEqual(good.json, { added: 2, skipped: 2 });
    const all = await links(app);
    assert.deepEqual(all.map(l => l.name), ['Agency site', 'Money map', 'Store']);
    const doc = all.find(l => l.name === 'Money map');
    assert.notEqual(doc.id, 'link_admin');
    assert.equal(doc.lastStatus, null, 'an import cannot claim a link was already checked');
    assert.equal(doc.state, 'off');
    assert.equal((await app.api('GET', '/api/console/audit')).json.entries.find((e: any) => e.action === 'network.imported').detail.added, 2);

    // The ceiling counts what is already there.
    await app.built.db.query(
      `INSERT INTO network_links (id, name, url, realm, kind, created_at, updated_at)
       SELECT 'link_fill_' || g, 'Filler ' || g, 'https://fill' || g || '.example.com/', 'Filler', 'site', 1, 1 FROM generate_series(1, 196) AS g`
    );
    const over = await app.api('POST', '/api/console/network/import', { links: [link({ url: 'https://y1.example.com/' }), link({ url: 'https://y2.example.com/' })] });
    assert.equal(over.status, 409);
    assert.equal(over.json.code, 'LINKS_FULL');
    assert.equal((await app.api('POST', '/api/console/network', link({ url: 'https://y1.example.com/' }))).status, 201);
    assert.equal((await app.api('POST', '/api/console/network', link({ url: 'https://y2.example.com/' }))).status, 409);
  } finally {
    await app.close();
  }
});

test('the sentinel knocks with HEAD on public https names only, follows nothing, and keeps a status code', async () => {
  const net = fakeNet();
  const knocks: Array<{ url: string; init: any }> = [];
  const inner = net.fetch;
  const answers: Record<string, number | 'dead'> = {
    'https://status.example.com/': 200,
    'https://signin.example.com/': 401,
    'https://old.example.com/': 404,
    'https://crashed.example.com/': 503,
    'https://gone.example.com/': 'dead',
    'https://moved.example.com/': 302,
  };
  net.fetch = (async (input: any, init?: any) => {
    const url = typeof input === 'string' ? input : input.url;
    if (init?.method !== 'HEAD') return inner(input, init);
    knocks.push({ url, init });
    const a = answers[url];
    if (a === undefined || a === 'dead') throw new TypeError('fetch failed');
    return new Response(null, { status: a, headers: a === 302 ? { Location: 'http://169.254.169.254/latest/meta-data/' } : {} });
  }) as typeof fetch;

  const app = await start({}, { net });
  try {
    await app.login();
    const add = async (name: string, url: string, watch = true) => {
      const res = await app.api('POST', '/api/console/network', link({ name, url, watch, realm: 'Watch', kind: 'app' }));
      assert.equal(res.status, 201, `${name}: ${JSON.stringify(res.json)}`);
      return res.json.link;
    };
    await add('Status page', 'https://status.example.com/');
    await add('Behind a sign-in', 'https://signin.example.com/');
    const old = await add('Old site', 'https://old.example.com/');
    await add('Crashed app', 'https://crashed.example.com/');
    await add('Gone app', 'https://gone.example.com/');
    await add('Moved app', 'https://moved.example.com/');
    await add('Not watched', 'https://quiet.example.com/', false);
    await add('This computer', 'http://127.0.0.1:7860/', false);
    assert.equal((await links(app)).find(l => l.name === 'Status page').state, 'unknown', 'watched but not yet checked is "unknown", never "up"');

    // Someone with database access plants watched links aimed at private machines. The sentinel still refuses.
    const q = app.built.db.query;
    for (const [i, url] of ['https://10.0.0.5/admin', 'https://localhost/x', 'https://[::1]/', 'https://metadata.internal/latest', 'https://2130706433/', 'https://printer.local/', 'http://plain.example.com/'].entries()) {
      await q(`INSERT INTO network_links (id, name, url, realm, kind, watch, created_at, updated_at) VALUES ($1, $2, $3, 'Planted', 'app', TRUE, 1, 1)`, [`link_planted_${i}`, `Planted ${i}`, url]);
    }

    const run = await app.api('POST', '/api/console/network/check', {});
    assert.equal(run.status, 200, JSON.stringify(run.json));
    assert.equal(run.json.result, '6 checked · 3 answering · 3 not answering');
    assert.ok(run.json.sweptAt > 0);

    assert.deepEqual(knocks.map(k => k.url).sort(), Object.keys(answers).sort(), 'only the six public https links that asked to be watched');
    for (const k of knocks) {
      assert.equal(k.init.method, 'HEAD', 'no page is ever requested');
      assert.equal(k.init.redirect, 'manual', 'a redirect is recorded, never followed');
      assert.equal(k.init.body, undefined);
      const headers = Object.keys(k.init.headers ?? {}).map(h => h.toLowerCase());
      assert.ok(!headers.includes('cookie') && !headers.includes('authorization'));
    }
    assert.ok(!net.calls.some(c => c.url.includes('169.254.169.254')), 'the redirect target was not visited');

    const state = Object.fromEntries((await links(app)).map(l => [l.name, l]));
    assert.equal(state['Status page'].state, 'up');
    assert.equal(state['Status page'].lastStatus, 200);
    assert.equal(state['Behind a sign-in'].state, 'up', 'a 401 still proves a server is there');
    assert.equal(state['Moved app'].state, 'up');
    assert.equal(state['Moved app'].lastStatus, 302);
    assert.equal(state['Old site'].state, 'error');
    assert.equal(state['Old site'].lastStatus, 404);
    assert.equal(state['Crashed app'].state, 'error');
    assert.equal(state['Gone app'].state, 'down');
    assert.equal(state['Gone app'].lastStatus, null);
    assert.equal(state['Gone app'].lastError, 'no answer');
    assert.equal(state['Not watched'].state, 'off');
    assert.equal(state['Not watched'].lastCheckedAt, null);
    for (const planted of Object.values(state).filter((l: any) => l.realm === 'Planted') as any[]) {
      assert.equal(planted.watch, false, `${planted.url} is reported as not watched`);
      assert.equal(planted.watchable, false);
      assert.equal(planted.lastCheckedAt, null);
    }

    // What stopped answering is raised without being asked, by name, and nothing more is claimed.
    const o = (await app.api('GET', '/api/console/overview')).json;
    const raised = o.attention.find((a: any) => a.tab === 'network');
    assert.equal(raised.level, 'warn');
    assert.match(raised.text, /^3 linked apps are not answering: /);
    for (const name of ['Old site', 'Crashed app', 'Gone app']) assert.ok(raised.text.includes(name));
    const check = (await app.api('GET', '/api/console/health')).json.checks.find((c: any) => c.id === 'network');
    assert.equal(check.state, 'warn');
    assert.match(check.detail, /15 linked, 6 watched\. Not answering: /);
    assert.equal(o.totals.verifiedAllTimeCents, 0, 'a link answering adds nothing to any figure');

    // Pointing a link somewhere new clears what the old address answered.
    const moved = await app.api('PUT', `/api/console/network/${old.id}`, link({ name: 'Old site', url: 'https://new.example.com/', watch: true, realm: 'Watch', kind: 'app' }));
    assert.equal(moved.json.link.state, 'unknown');
    assert.equal(moved.json.link.lastStatus, null);

    // It is one of the scheduled jobs, and it says what it does.
    const job = (await app.api('GET', '/api/console/autopilot')).json.jobs.find((j: any) => j.id === 'sentinel');
    assert.match(job.does, /HEAD request/);
    assert.ok(job.lastRunAt > 0);
  } finally {
    await app.close();
  }

  // With nothing watched it makes no request at all.
  const quiet = await start({}, { net });
  try {
    knocks.length = 0;
    await quiet.login();
    await quiet.api('POST', '/api/console/network', link());
    const run = await quiet.api('POST', '/api/console/network/check', {});
    assert.equal(run.json.result, 'No links are being watched');
    assert.equal(knocks.length, 0);
    assert.equal((await quiet.api('GET', '/api/console/health')).json.checks.find((c: any) => c.id === 'network').state, 'ok');
  } finally {
    await quiet.close();
  }
});
