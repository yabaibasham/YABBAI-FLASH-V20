/**
 * Test harness.
 *
 * Tests run the real server against a real database (PGlite by default, or a
 * real Postgres when TEST_PG_ADMIN_URL is set) and talk to it over HTTP like a
 * browser would. Stripe is the real SDK pointed at a local stub server; the
 * chain, price feeds and AI provider are a scripted fetch.
 */
import { generateKeyPairSync, randomBytes, sign as cryptoSign } from 'node:crypto';
import http from 'node:http';
import type { AddressInfo } from 'node:net';
import Stripe from 'stripe';
import { createApp } from '../server.ts';
import type { BuiltApp } from '../server.ts';
import { hashPassword } from '../server/auth.ts';
import { base58Encode } from '../server/util.ts';

export const PASSWORD = 'correct horse battery staple 42';
let cachedHash: string | null = null;
export async function passwordHash(): Promise<string> {
  if (!cachedHash) cachedHash = await hashPassword(PASSWORD);
  return cachedHash;
}

export const WEBHOOK_SECRET = 'whsec_test_0123456789abcdef0123456789abcdef';

// ── Stripe stub ───────────────────────────────────────────────────────────
export interface StripeStub {
  port: number;
  sessions: Map<string, any>;
  requests: Array<{ method: string; path: string; body: Record<string, string> }>;
  account: any;
  balance: any;
  payouts: any[];
  failCreate: boolean;
  /** When true, reading the account is refused the way Stripe refuses a restricted key without that permission. */
  accountForbidden: boolean;
  close(): Promise<void>;
}

export async function startStripeStub(livemode = false): Promise<StripeStub> {
  const stub: StripeStub = {
    port: 0,
    sessions: new Map(),
    requests: [],
    account: {
      id: 'acct_stub',
      object: 'account',
      charges_enabled: true,
      payouts_enabled: true,
      details_submitted: true,
      requirements: { currently_due: [], past_due: [], disabled_reason: null },
      external_accounts: { object: 'list', data: [{ object: 'bank_account', bank_name: 'STUB BANK', last4: '4321' }] },
      settings: { payouts: { schedule: { interval: 'daily', delay_days: 2 } } },
    },
    balance: { object: 'balance', livemode, available: [{ amount: 0, currency: 'aud' }], pending: [{ amount: 0, currency: 'aud' }] },
    payouts: [],
    failCreate: false,
    accountForbidden: false,
    close: async () => {},
  };
  let n = 0;
  const server = http.createServer((req, res) => {
    const chunks: Buffer[] = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      const body = Object.fromEntries(new URLSearchParams(raw));
      const url = new URL(req.url ?? '/', 'http://stub');
      stub.requests.push({ method: req.method ?? '', path: url.pathname, body });
      const send = (status: number, data: unknown) => {
        res.writeHead(status, { 'Content-Type': 'application/json', 'Request-Id': `req_${++n}` });
        res.end(JSON.stringify(data));
      };
      if (req.method === 'POST' && url.pathname === '/v1/checkout/sessions') {
        if (stub.failCreate) return send(400, { error: { type: 'invalid_request_error', message: 'Your account cannot currently make live charges.' } });
        const id = `cs_${livemode ? 'live' : 'test'}_${randomBytes(12).toString('hex')}`;
        const session = {
          id,
          object: 'checkout.session',
          livemode,
          mode: body.mode,
          status: 'open',
          payment_status: 'unpaid',
          currency: body['line_items[0][price_data][currency]'],
          amount_total: Number(body['line_items[0][price_data][unit_amount]']),
          client_reference_id: body.client_reference_id,
          metadata: { flash_kind: body['metadata[flash_kind]'], flash_ref: body['metadata[flash_ref]'] },
          payment_intent: null,
          customer_details: null,
          customer_email: body.customer_email ?? null,
          created: Math.floor(Date.now() / 1000),
          success_url: body.success_url,
          cancel_url: body.cancel_url,
          url: `https://checkout.stripe.test/c/pay/${id}`,
        };
        stub.sessions.set(id, session);
        return send(200, session);
      }
      const m = /^\/v1\/checkout\/sessions\/([^/]+)$/.exec(url.pathname);
      if (req.method === 'GET' && m) {
        const s = stub.sessions.get(m[1]);
        return s ? send(200, s) : send(404, { error: { type: 'invalid_request_error', message: 'No such checkout.session' } });
      }
      if (req.method === 'GET' && url.pathname === '/v1/account') {
        if (stub.accountForbidden) {
          return send(403, { error: { type: 'invalid_request_error', message: "The provided key 'rk_test_***' does not have the required permissions for this endpoint." } });
        }
        return send(200, stub.account);
      }
      if (req.method === 'GET' && url.pathname === '/v1/balance') return send(200, stub.balance);
      if (req.method === 'GET' && url.pathname === '/v1/payouts') return send(200, { object: 'list', data: stub.payouts, has_more: false, url: '/v1/payouts' });
      send(404, { error: { type: 'invalid_request_error', message: `stub: unhandled ${req.method} ${url.pathname}` } });
    });
  });
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve));
  stub.port = (server.address() as AddressInfo).port;
  stub.close = () => new Promise<void>(resolve => server.close(() => resolve()));
  return stub;
}

/** Mark a stub session as paid, the way Stripe would after a successful card payment. */
export function payStubSession(stub: StripeStub, sessionId: string, email = 'buyer@example.com'): string {
  const s = stub.sessions.get(sessionId);
  if (!s) throw new Error('no such stub session');
  s.status = 'complete';
  s.payment_status = 'paid';
  s.payment_intent = `pi_${randomBytes(10).toString('hex')}`;
  s.customer_details = { email };
  return s.payment_intent;
}

const signer = new Stripe('sk_test_signer');
let eventSeq = 0;
/** Build a webhook body + header signed exactly as Stripe's own library signs them. */
export function signedEvent(type: string, object: any, opts: { secret?: string; livemode?: boolean; id?: string } = {}) {
  const payload = JSON.stringify({
    id: opts.id ?? `evt_${++eventSeq}_${randomBytes(6).toString('hex')}`,
    object: 'event',
    api_version: '2026-11-18.endive',
    created: Math.floor(Date.now() / 1000),
    livemode: opts.livemode ?? false,
    type,
    data: { object },
  });
  const header = signer.webhooks.generateTestHeaderString({ payload, secret: opts.secret ?? WEBHOOK_SECRET });
  return { payload, header };
}

// ── scripted fetch for FX, Solana RPC and the AI provider ─────────────────
export interface FakeNet {
  fetch: typeof fetch;
  calls: Array<{ url: string; body: any }>;
  fx: { coingecko: { sol: number; usdc: number } | null; coinbase: { sol: number; usdc: number } | null };
  /** reference/address → signatures */
  signatures: Map<string, any[]>;
  transactions: Map<string, any>;
  balances: Map<string, number>;
  rpcDown: boolean;
  ai: { handler: (url: string, body: any) => { status: number; json: any } };
}

export function fakeNet(): FakeNet {
  const net: FakeNet = {
    calls: [],
    fx: { coingecko: { sol: 110, usdc: 1.52 }, coinbase: { sol: 110.4, usdc: 1.521 } },
    signatures: new Map(),
    transactions: new Map(),
    balances: new Map(),
    rpcDown: false,
    ai: { handler: () => ({ status: 500, json: { error: { message: 'no ai handler' } } }) },
    fetch: (async () => new Response('{}')) as typeof fetch,
  };
  const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });

  net.fetch = (async (input: any, init?: any) => {
    const url = typeof input === 'string' ? input : input.url;
    const body = init?.body ? JSON.parse(String(init.body)) : null;
    net.calls.push({ url, body });

    if (url.includes('api.coingecko.com')) {
      return net.fx.coingecko ? json({ solana: { aud: net.fx.coingecko.sol }, 'usd-coin': { aud: net.fx.coingecko.usdc } }) : json({}, 503);
    }
    if (url.includes('api.coinbase.com/v2/exchange-rates')) {
      if (!net.fx.coinbase) return json({}, 503);
      const cur = new URL(url).searchParams.get('currency');
      return json({ data: { currency: cur, rates: { AUD: String(cur === 'SOL' ? net.fx.coinbase.sol : net.fx.coinbase.usdc) } } });
    }
    if (url.includes('generativelanguage.googleapis.com') || url.includes('/chat/completions')) {
      const r = net.ai.handler(url, body);
      return json(r.json, r.status);
    }
    if (url.includes('solana') || url.includes('rpc.test')) {
      if (net.rpcDown) return json({}, 429);
      const { method, params, id } = body;
      const ok = (result: unknown) => json({ jsonrpc: '2.0', id, result });
      if (method === 'getSignaturesForAddress') {
        const want = params[1]?.commitment ?? 'finalized';
        const list = (net.signatures.get(params[0]) ?? []).filter((s: any) => want !== 'finalized' || s.confirmationStatus === 'finalized');
        return ok(list);
      }
      if (method === 'getTransaction') return ok(net.transactions.get(params[0]) ?? null);
      if (method === 'getBalance') return ok({ context: { slot: 1 }, value: net.balances.get(params[0]) ?? 0 });
      if (method === 'getTokenAccountsByOwner') return ok({ context: { slot: 1 }, value: [] });
      return json({ jsonrpc: '2.0', id, error: { code: -32601, message: 'Method not found' } });
    }
    // Market tickers and anything else: unreachable.
    return json({}, 503);
  }) as typeof fetch;
  return net;
}

// ── wallets ───────────────────────────────────────────────────────────────
export interface TestWallet {
  address: string;
  sign(message: string): string; // base64
}

export function newWallet(): TestWallet {
  const { publicKey, privateKey } = generateKeyPairSync('ed25519');
  const raw = Buffer.from((publicKey.export({ format: 'jwk' }) as any).x, 'base64url');
  return {
    address: base58Encode(raw),
    sign: (message: string) => cryptoSign(null, Buffer.from(message, 'utf8'), privateKey).toString('base64'),
  };
}

export function randomAddress(): string {
  return base58Encode(randomBytes(32));
}

/** A finalized SOL transfer of `lamports` into `recipient`, carrying `reference`. */
export function solTransferTx(opts: { recipient: string; reference: string; lamports: number; payer?: string; failed?: boolean; signerIsRecipient?: boolean }) {
  const payer = opts.payer ?? randomAddress();
  const keys = [
    { pubkey: payer, signer: true, writable: true, source: 'transaction' },
    { pubkey: opts.recipient, signer: !!opts.signerIsRecipient, writable: true, source: 'transaction' },
    { pubkey: opts.reference, signer: false, writable: false, source: 'transaction' },
    { pubkey: '11111111111111111111111111111111', signer: false, writable: false, source: 'transaction' },
  ];
  return {
    slot: 300_000_000,
    blockTime: Math.floor(Date.now() / 1000),
    meta: {
      err: opts.failed ? { InstructionError: [0, 'Custom'] } : null,
      fee: 5000,
      preBalances: [10_000_000_000, 1_000_000, 0, 1],
      postBalances: [10_000_000_000 - opts.lamports - 5000, 1_000_000 + (opts.failed ? 0 : opts.lamports), 0, 1],
      preTokenBalances: [],
      postTokenBalances: [],
    },
    transaction: { message: { accountKeys: keys, instructions: [] }, signatures: [] },
  };
}

export function usdcTransferTx(opts: { recipient: string; reference: string; baseUnits: number; mint: string }) {
  const payer = randomAddress();
  const keys = [payer, randomAddress(), randomAddress(), opts.reference].map((pubkey, i) => ({ pubkey, signer: i === 0, writable: i < 3, source: 'transaction' }));
  const bal = (owner: string, idx: number, amount: number) => ({ accountIndex: idx, mint: opts.mint, owner, uiTokenAmount: { amount: String(amount), decimals: 6 } });
  return {
    slot: 300_000_001,
    blockTime: Math.floor(Date.now() / 1000),
    meta: {
      err: null,
      fee: 5000,
      preBalances: [1e9, 2e6, 2e6, 0],
      postBalances: [1e9 - 5000, 2e6, 2e6, 0],
      preTokenBalances: [bal(payer, 1, 500_000_000), bal(opts.recipient, 2, 1_000_000)],
      postTokenBalances: [bal(payer, 1, 500_000_000 - opts.baseUnits), bal(opts.recipient, 2, 1_000_000 + opts.baseUnits)],
    },
    transaction: { message: { accountKeys: keys, instructions: [] }, signatures: [] },
  };
}

export function sigInfo(signature: string, status: 'finalized' | 'confirmed' = 'finalized', err: unknown = null) {
  return { signature, slot: 300_000_000, err, memo: null, blockTime: Math.floor(Date.now() / 1000), confirmationStatus: status };
}

export function newSignature(): string {
  return base58Encode(randomBytes(64));
}

// ── running app ───────────────────────────────────────────────────────────
export interface Running {
  built: BuiltApp;
  url: string;
  net: FakeNet;
  stub: StripeStub | null;
  cookie: string | null;
  api(method: string, path: string, body?: unknown, opts?: { cookie?: string | null; headers?: Record<string, string>; raw?: string }): Promise<{ status: number; json: any; headers: Headers }>;
  login(extra?: Record<string, unknown>): Promise<string>;
  close(): Promise<void>;
}

let dbSeq = 0;

export async function start(env: Record<string, string | undefined> = {}, opts: { stripe?: boolean | 'live'; net?: FakeNet } = {}): Promise<Running> {
  const net = opts.net ?? fakeNet();
  const stub = opts.stripe ? await startStripeStub(opts.stripe === 'live') : null;

  // Optional: run the whole suite against a real Postgres server.
  let dropDb: (() => Promise<void>) | null = null;
  const dbEnv: Record<string, string> = { FLASH_DATA_DIR: 'memory', ALLOW_LOCAL_DB_FOR_PAYMENTS: 'true' };
  if (process.env.TEST_PG_ADMIN_URL) {
    const pg = (await import('pg')).default;
    const name = `flash_t_${process.pid}_${++dbSeq}_${randomBytes(3).toString('hex')}`;
    const admin = new pg.Client({ connectionString: process.env.TEST_PG_ADMIN_URL });
    await admin.connect();
    await admin.query(`CREATE DATABASE ${name}`);
    await admin.end();
    const u = new URL(process.env.TEST_PG_ADMIN_URL);
    u.pathname = `/${name}`;
    dbEnv.DATABASE_URL = u.toString();
    dbEnv.DATABASE_SSL = 'disable';
    delete (dbEnv as any).FLASH_DATA_DIR;
    dropDb = async () => {
      const a = new pg.Client({ connectionString: process.env.TEST_PG_ADMIN_URL });
      await a.connect();
      await a.query(`DROP DATABASE IF EXISTS ${name} WITH (FORCE)`);
      await a.end();
    };
  }

  const fullEnv: Record<string, string | undefined> = {
    NODE_ENV: 'test',
    ...dbEnv,
    DIRECTOR_PASSWORD_HASH: await passwordHash(),
    AUTOPILOT: 'false',
    SOLANA_RPC_URL: 'https://rpc.test/solana',
    ...(stub
      ? {
          STRIPE_SECRET_KEY: opts.stripe === 'live' ? 'rk_live_stub' : 'sk_test_stub',
          STRIPE_WEBHOOK_SECRET: WEBHOOK_SECRET,
          STRIPE_API_HOST: '127.0.0.1',
          STRIPE_API_PORT: String(stub.port),
          STRIPE_API_PROTOCOL: 'http',
        }
      : {}),
    ...env,
  };
  for (const k of Object.keys(fullEnv)) if (fullEnv[k] === undefined) delete fullEnv[k];

  const built = await createApp({ env: fullEnv, fetchImpl: net.fetch, serveFrontend: false });
  const server = http.createServer(built.app);
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve));
  const url = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

  const running: Running = {
    built,
    url,
    net,
    stub,
    cookie: null,
    async api(method, path, body, o = {}) {
      const headers: Record<string, string> = { 'X-Flash': '1', ...(o.headers ?? {}) };
      const cookie = o.cookie === undefined ? running.cookie : o.cookie;
      if (cookie) headers.Cookie = cookie;
      let payload: string | undefined;
      if (o.raw !== undefined) payload = o.raw;
      else if (body !== undefined) {
        payload = JSON.stringify(body);
        headers['Content-Type'] = headers['Content-Type'] ?? 'application/json';
      }
      const res = await fetch(url + path, { method, headers, body: payload, redirect: 'manual' });
      const text = await res.text();
      let json: any = null;
      try {
        json = text ? JSON.parse(text) : null;
      } catch {
        json = { _raw: text };
      }
      return { status: res.status, json, headers: res.headers };
    },
    async login(extra = {}) {
      const res = await running.api('POST', '/api/auth/login', { password: PASSWORD, ...extra }, { cookie: null });
      if (res.status !== 200) throw new Error(`login failed: ${res.status} ${JSON.stringify(res.json)}`);
      const set = res.headers.get('set-cookie') ?? '';
      running.cookie = set.split(';')[0];
      return running.cookie;
    },
    async close() {
      await new Promise<void>(resolve => server.close(() => resolve()));
      await built.close();
      if (stub) await stub.close();
      if (dropDb) await dropDb();
    },
  };
  return running;
}

/** Create and issue an invoice; returns the console view. */
export async function issueInvoice(app: Running, dollars = 250, extra: Record<string, unknown> = {}) {
  const created = await app.api('POST', '/api/console/invoices', {
    clientName: 'Real Client Pty Ltd',
    clientEmail: 'accounts@realclient.example',
    items: [{ desc: 'Automation build', qty: 1, unitDollars: dollars }],
    ...extra,
  });
  if (created.status !== 201) throw new Error(`create invoice failed: ${JSON.stringify(created.json)}`);
  const opened = await app.api('POST', `/api/console/invoices/${created.json.invoice.id}/open`);
  if (opened.status !== 200) throw new Error(`open invoice failed: ${JSON.stringify(opened.json)}`);
  return opened.json.invoice;
}
