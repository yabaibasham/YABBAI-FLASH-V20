/**
 * Card payments. The real Stripe SDK runs against a local stub of Stripe's API,
 * and webhooks are signed with Stripe's own library, so signature checks and
 * request encoding are exercised for real.
 */
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { WEBHOOK_SECRET, issueInvoice, payStubSession, signedEvent, start } from './helpers.ts';
import type { Running } from './helpers.ts';

async function checkout(app: Running, token: string, body: unknown = {}) {
  return app.api('POST', `/api/public/invoice/${token}/checkout`, body, { cookie: null });
}

async function webhook(app: Running, payload: string, header: string | null) {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (header) headers['Stripe-Signature'] = header;
  const res = await fetch(app.url + '/api/webhooks/stripe', { method: 'POST', headers, body: payload });
  return { status: res.status, json: await res.json() };
}

async function invoiceState(app: Running, id: string) {
  return (await app.api('GET', `/api/console/invoices/${id}`)).json;
}

test('checkout uses the amount the server holds, whatever the browser sends, and reuses an open session', async () => {
  const app = await start({}, { stripe: true });
  try {
    await app.login();
    const inv = await issueInvoice(app, 250);
    const pub = await app.api('GET', `/api/public/invoice/${inv.token}`, undefined, { cookie: null });
    assert.equal(pub.json.rails.card, true);

    const res = await checkout(app, inv.token, { amountCents: 1, unit_amount: 1, currency: 'usd' });
    assert.equal(res.status, 200);
    assert.match(res.json.url, /^https:\/\/checkout\.stripe\.test\//);

    const create = app.stub!.requests.filter(r => r.method === 'POST' && r.path === '/v1/checkout/sessions');
    assert.equal(create.length, 1);
    assert.equal(create[0].body['line_items[0][price_data][unit_amount]'], '25000');
    assert.equal(create[0].body['line_items[0][price_data][currency]'], 'aud');
    assert.equal(create[0].body.mode, 'payment');
    assert.equal(create[0].body['metadata[flash_ref]'], inv.id);
    assert.equal(create[0].body['payment_intent_data[metadata][flash_ref]'], inv.id);
    assert.match(create[0].body.success_url, new RegExp(`/pay/${inv.token}\\?session_id=\\{CHECKOUT_SESSION_ID\\}$`));

    const again = await checkout(app, inv.token);
    assert.equal(again.json.url, res.json.url);
    assert.equal(app.stub!.requests.filter(r => r.method === 'POST').length, 1, 'no second session for the same amount');
  } finally {
    await app.close();
  }
});

test('a signed "completed" event for a paid session marks the invoice paid — exactly once', async () => {
  const app = await start({}, { stripe: true });
  try {
    await app.login();
    const inv = await issueInvoice(app, 250);
    await checkout(app, inv.token);
    const sessionId = [...app.stub!.sessions.keys()][0];
    const pi = payStubSession(app.stub!, sessionId, 'payer@client.example');

    const ev = signedEvent('checkout.session.completed', { id: sessionId, object: 'checkout.session' });
    const first = await webhook(app, ev.payload, ev.header);
    assert.deepEqual([first.status, first.json.received], [200, true]);

    let state = await invoiceState(app, inv.id);
    assert.equal(state.invoice.status, 'paid');
    assert.equal(state.invoice.verifiedPaidCents, 25000);
    assert.equal(state.payments.length, 1);
    assert.equal(state.payments[0].proofId, `stripe:${pi}`);
    assert.equal(state.payments[0].verified, true);
    assert.equal(state.payments[0].payer, 'payer@client.example');

    // Replay the identical event.
    const replay = await webhook(app, ev.payload, ev.header);
    assert.equal(replay.json.duplicate, true);
    // A brand-new event id about the same session (Stripe can send both completed and async_succeeded).
    const second = signedEvent('checkout.session.async_payment_succeeded', { id: sessionId, object: 'checkout.session' });
    assert.equal((await webhook(app, second.payload, second.header)).status, 200);

    state = await invoiceState(app, inv.id);
    assert.equal(state.payments.length, 1, 'still exactly one payment');
    assert.equal(state.invoice.paidCents, 25000);
    const o = (await app.api('GET', '/api/console/overview')).json;
    assert.equal(o.totals.verifiedAllTimeCents, 25000);
    assert.equal(o.totals.receivableCents, 0);

    // The paid invoice no longer offers any way to pay.
    const pub = await app.api('GET', `/api/public/invoice/${inv.token}`, undefined, { cookie: null });
    assert.equal(pub.json.status, 'paid');
    assert.equal(pub.json.rails.card, false);
    assert.equal((await checkout(app, inv.token)).status, 409);
  } finally {
    await app.close();
  }
});

test('forged webhooks are rejected: bad signature, wrong secret, no signature, altered body', async () => {
  const app = await start({}, { stripe: true });
  try {
    await app.login();
    const inv = await issueInvoice(app, 250);
    await checkout(app, inv.token);
    const sessionId = [...app.stub!.sessions.keys()][0];
    payStubSession(app.stub!, sessionId);
    const obj = { id: sessionId, object: 'checkout.session', payment_status: 'paid', amount_total: 25000 };

    const wrongSecret = signedEvent('checkout.session.completed', obj, { secret: 'whsec_attacker_guess_000000000000' });
    assert.equal((await webhook(app, wrongSecret.payload, wrongSecret.header)).status, 400);

    const good = signedEvent('checkout.session.completed', obj);
    assert.equal((await webhook(app, good.payload, null)).status, 400, 'no signature header');
    assert.equal((await webhook(app, good.payload, 't=1,v1=deadbeef')).status, 400, 'garbage signature');
    assert.equal((await webhook(app, good.payload.replace('25000', '99999'), good.header)).status, 400, 'body changed after signing');

    // A signature from long ago (replay outside the tolerance window) is refused too.
    const Stripe = (await import('stripe')).default;
    const stale = new Stripe('sk_test_x').webhooks.generateTestHeaderString({ payload: good.payload, secret: WEBHOOK_SECRET, timestamp: Math.floor(Date.now() / 1000) - 3600 });
    assert.equal((await webhook(app, good.payload, stale)).status, 400, 'stale timestamp');

    const state = await invoiceState(app, inv.id);
    assert.equal(state.invoice.status, 'open');
    assert.equal(state.payments.length, 0);
    const audit = await app.built.db.query(`SELECT COUNT(*)::int AS n FROM audit_log WHERE action = 'webhook.bad_signature'`);
    assert.ok(audit.rows[0].n >= 4, 'each forgery is logged');
  } finally {
    await app.close();
  }
});

test('a correctly signed event is still only a hint: Stripe itself must say the session is paid', async () => {
  const app = await start({}, { stripe: true });
  try {
    await app.login();
    const inv = await issueInvoice(app, 250);
    await checkout(app, inv.token);
    const sessionId = [...app.stub!.sessions.keys()][0];
    // Event claims paid; Stripe's API (the stub) still says unpaid.
    const ev = signedEvent('checkout.session.completed', { id: sessionId, object: 'checkout.session', payment_status: 'paid', amount_total: 25000 });
    assert.equal((await webhook(app, ev.payload, ev.header)).status, 200);
    const state = await invoiceState(app, inv.id);
    assert.equal(state.invoice.status, 'open');
    assert.equal(state.payments.length, 0);
  } finally {
    await app.close();
  }
});

test('mismatches are rejected and logged: wrong amount, wrong currency, foreign session, wrong mode', async () => {
  const app = await start({}, { stripe: true });
  try {
    await app.login();

    // 1. Amount on Stripe's side differs from what we issued.
    const a = await issueInvoice(app, 250);
    await checkout(app, a.token);
    const sa = [...app.stub!.sessions.keys()].at(-1)!;
    payStubSession(app.stub!, sa);
    app.stub!.sessions.get(sa).amount_total = 100;
    let ev = signedEvent('checkout.session.completed', { id: sa, object: 'checkout.session' });
    await webhook(app, ev.payload, ev.header);
    assert.equal((await invoiceState(app, a.id)).payments.length, 0, 'amount mismatch must not credit');

    // 2. Currency differs.
    const b = await issueInvoice(app, 250);
    await checkout(app, b.token);
    const sb = [...app.stub!.sessions.keys()].at(-1)!;
    payStubSession(app.stub!, sb);
    app.stub!.sessions.get(sb).currency = 'usd';
    ev = signedEvent('checkout.session.completed', { id: sb, object: 'checkout.session' });
    await webhook(app, ev.payload, ev.header);
    assert.equal((await invoiceState(app, b.id)).payments.length, 0, 'currency mismatch must not credit');

    // 3. A paid session on the same Stripe account that this app never created.
    app.stub!.sessions.set('cs_test_foreign000000000000', {
      id: 'cs_test_foreign000000000000', object: 'checkout.session', livemode: false, mode: 'payment', status: 'complete', payment_status: 'paid',
      currency: 'aud', amount_total: 25000, metadata: { flash_kind: 'invoice', flash_ref: a.id }, payment_intent: 'pi_foreign', customer_details: null,
    });
    ev = signedEvent('checkout.session.completed', { id: 'cs_test_foreign000000000000', object: 'checkout.session' });
    assert.equal((await webhook(app, ev.payload, ev.header)).status, 200);
    assert.equal((await invoiceState(app, a.id)).payments.length, 0, 'sessions we did not create are never credited');

    // 4. A live-mode event arriving at a test-mode app.
    const c = await issueInvoice(app, 250);
    await checkout(app, c.token);
    const sc = [...app.stub!.sessions.keys()].at(-1)!;
    payStubSession(app.stub!, sc);
    ev = signedEvent('checkout.session.completed', { id: sc, object: 'checkout.session' }, { livemode: true });
    const res = await webhook(app, ev.payload, ev.header);
    assert.equal(res.json.ignored, 'mode');
    assert.equal((await invoiceState(app, c.id)).payments.length, 0);

    const rejected = await app.built.db.query(`SELECT detail FROM audit_log WHERE action = 'payment.rejected' ORDER BY seq`);
    assert.equal(rejected.rows.length, 2);
    assert.match(rejected.rows[0].detail, /amount/);
    assert.match(rejected.rows[1].detail, /currency/);
    const o = (await app.api('GET', '/api/console/overview')).json;
    assert.equal(o.totals.verifiedAllTimeCents, 0);
  } finally {
    await app.close();
  }
});

test('missed webhook: the treasurer job and the return page both pick the payment up', async () => {
  const app = await start({}, { stripe: true });
  try {
    await app.login();
    const a = await issueInvoice(app, 80);
    await checkout(app, a.token);
    const sa = [...app.stub!.sessions.keys()].at(-1)!;
    payStubSession(app.stub!, sa);
    const run = await app.api('POST', '/api/console/reconcile', {});
    assert.match(run.json.result, /1 newly paid/);
    assert.equal((await invoiceState(app, a.id)).invoice.status, 'paid');

    const b = await issueInvoice(app, 90);
    await checkout(app, b.token);
    const sb = [...app.stub!.sessions.keys()].at(-1)!;
    payStubSession(app.stub!, sb);
    // The customer lands back on the pay page with ?session_id=…
    const status = await app.api('GET', `/api/public/invoice/${b.token}/status?session_id=${sb}`, undefined, { cookie: null });
    assert.equal(status.json.status, 'paid');
    // Someone else's session id on this invoice's page does nothing for this invoice.
    const c = await issueInvoice(app, 70);
    const cross = await app.api('GET', `/api/public/invoice/${c.token}/status?session_id=${sb}`, undefined, { cookie: null });
    assert.equal(cross.json.status, 'open');
    assert.equal((await invoiceState(app, c.id)).payments.length, 0);
  } finally {
    await app.close();
  }
});

test('refunds and disputes flow back into the figures', async () => {
  const app = await start({}, { stripe: true });
  try {
    await app.login();
    const inv = await issueInvoice(app, 200);
    await checkout(app, inv.token);
    const sid = [...app.stub!.sessions.keys()][0];
    const pi = payStubSession(app.stub!, sid);
    let ev = signedEvent('checkout.session.completed', { id: sid, object: 'checkout.session' });
    await webhook(app, ev.payload, ev.header);
    assert.equal((await invoiceState(app, inv.id)).invoice.status, 'paid');

    ev = signedEvent('charge.refunded', { id: 'ch_1', object: 'charge', payment_intent: pi, amount: 20000, amount_refunded: 5000 });
    await webhook(app, ev.payload, ev.header);
    let state = await invoiceState(app, inv.id);
    assert.equal(state.payments[0].refundedCents, 5000);
    assert.equal(state.invoice.paidCents, 15000);
    assert.notEqual(state.invoice.status, 'paid', 'a part-refunded invoice is no longer fully paid');

    ev = signedEvent('charge.dispute.created', { id: 'dp_1', object: 'dispute', payment_intent: pi, status: 'needs_response' });
    await webhook(app, ev.payload, ev.header);
    state = await invoiceState(app, inv.id);
    assert.equal(state.payments[0].disputed, true);
    const o = (await app.api('GET', '/api/console/overview')).json;
    assert.equal(o.totals.verifiedAllTimeCents, 15000);
    assert.equal(o.totals.refundedAllTimeCents, 5000);
    assert.ok(o.attention.some((a: any) => /dispute/.test(a.text)));

    ev = signedEvent('charge.dispute.closed', { id: 'dp_1', object: 'dispute', payment_intent: pi, status: 'lost' });
    await webhook(app, ev.payload, ev.header);
    assert.equal((await invoiceState(app, inv.id)).payments[0].refundedCents, 20000, 'a lost dispute takes the whole payment back');
  } finally {
    await app.close();
  }
});

test('an account Stripe has not activated: the card option is hidden and the console says why', async () => {
  const app = await start({}, { stripe: true });
  try {
    app.stub!.account.charges_enabled = false;
    app.stub!.account.payouts_enabled = false;
    app.stub!.account.external_accounts = { object: 'list', data: [] };
    app.stub!.account.requirements = { currently_due: ['individual.verification.document'], past_due: ['external_account', 'tos_acceptance.date'], disabled_reason: 'requirements.past_due' };
    await app.login();
    const inv = await issueInvoice(app, 60);
    const payouts = (await app.api('GET', '/api/console/payouts?refresh=1')).json.stripe;
    assert.equal(payouts.chargesEnabled, false);
    assert.deepEqual(payouts.requirementsDue.sort(), ['external_account', 'individual.verification.document', 'tos_acceptance.date']);
    assert.equal(payouts.payoutDestination, null);

    const pub = await app.api('GET', `/api/public/invoice/${inv.token}`, undefined, { cookie: null });
    assert.equal(pub.json.rails.card, false);
    assert.equal((await checkout(app, inv.token)).status, 503);
    assert.equal(app.stub!.requests.filter(r => r.method === 'POST').length, 0, 'no checkout session is attempted');

    const o = (await app.api('GET', '/api/console/overview')).json;
    assert.ok(o.attention.some((a: any) => a.level === 'error' && /not activated/.test(a.text)));
    const health = (await app.api('GET', '/api/console/health')).json.checks;
    assert.equal(health.find((c: any) => c.id === 'stripe_account').state, 'error');
  } finally {
    await app.close();
  }
});

test('payout status reads straight from Stripe; without a webhook secret the endpoint refuses to process anything', async () => {
  const app = await start({ STRIPE_WEBHOOK_SECRET: undefined }, { stripe: true });
  try {
    app.stub!.balance.available[0].amount = 12345;
    app.stub!.balance.pending[0].amount = 500;
    app.stub!.payouts.push({ id: 'po_1', object: 'payout', amount: 9900, status: 'paid', arrival_date: 1790000000, method: 'standard', failure_message: null });
    await app.login();
    const p = (await app.api('GET', '/api/console/payouts?refresh=1')).json.stripe;
    assert.equal(p.availableCents, 12345);
    assert.equal(p.pendingCents, 500);
    assert.equal(p.payoutDestination, 'STUB BANK ••••4321');
    assert.equal(p.payouts[0].amountCents, 9900);

    const ev = signedEvent('checkout.session.completed', { id: 'cs_test_whatever0000000', object: 'checkout.session' });
    assert.equal((await webhook(app, ev.payload, ev.header)).status, 503);
    const health = (await app.api('GET', '/api/console/health')).json.checks;
    assert.equal(health.find((c: any) => c.id === 'stripe_webhook').state, 'error');
  } finally {
    await app.close();
  }
});

test('live keys without a durable database: the card rail stays off', async () => {
  const app = await start({ ALLOW_LOCAL_DB_FOR_PAYMENTS: 'false' }, { stripe: 'live' });
  try {
    if (app.built.db.kind === 'postgres') return; // a real database is durable; nothing to assert
    await app.login();
    const inv = await issueInvoice(app, 60);
    const pub = await app.api('GET', `/api/public/invoice/${inv.token}`, undefined, { cookie: null });
    assert.equal(pub.json.rails.card, false);
    assert.equal(pub.json.mode, 'live');
    assert.equal((await checkout(app, inv.token)).status, 503);
  } finally {
    await app.close();
  }
});
