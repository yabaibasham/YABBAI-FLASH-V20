import assert from 'node:assert/strict';
import { test } from 'node:test';
import { base32Encode, hashPassword, matchTotp, totpAt, verifyPasswordHash } from '../server/auth.ts';
import { loadConfig, passwordIsWeak } from '../server/config.ts';
import { PASSWORD, start } from './helpers.ts';

test('TOTP matches the RFC 6238 SHA-1 test vectors', () => {
  const secret = Buffer.from('12345678901234567890', 'ascii');
  // RFC vectors are 8 digits; the 6-digit code is the last six.
  assert.equal(totpAt(secret, Math.floor(59 / 30), 8), '94287082');
  assert.equal(totpAt(secret, Math.floor(1111111109 / 30), 8), '07081804');
  assert.equal(totpAt(secret, Math.floor(1234567890 / 30), 8), '89005924');
  assert.equal(totpAt(secret, Math.floor(2000000000 / 30), 8), '69279037');
  assert.equal(totpAt(secret, Math.floor(59 / 30)), '287082');
});

test('password hashing round-trips and rejects the wrong password', async () => {
  const h = await hashPassword('a long passphrase 123');
  assert.match(h, /^scrypt\.15\.8\.1\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{43}$/);
  // No character a shell, a .env parser or YAML would treat specially.
  assert.doesNotMatch(h, /[$`"'\\\s#:{}]/);
  // Hashes in the older "$" layout still verify.
  assert.equal(await verifyPasswordHash('a long passphrase 123', h.replaceAll('.', '$')), true);
  assert.equal(await verifyPasswordHash('a long passphrase 123', h), true);
  assert.equal(await verifyPasswordHash('a long passphrase 124', h), false);
  assert.equal(await verifyPasswordHash('x', 'scrypt$1$1$1$AA$AA'), false);
  assert.equal(await verifyPasswordHash('x', 'not-a-hash'), false);
});

test('the old factory key and other weak passwords are refused outright', () => {
  assert.ok(passwordIsWeak('YABBAI-DIRECTOR-88'));
  assert.ok(passwordIsWeak('short'));
  assert.ok(passwordIsWeak('aaaaaaaaaaaaaaaa'));
  assert.equal(passwordIsWeak('correct horse battery staple'), null);
  const cfg = loadConfig({ DIRECTOR_PASSWORD: 'YABBAI-DIRECTOR-88' });
  assert.equal(cfg.auth.passwordPlain, null);
  assert.ok(cfg.problems.some(p => p.code === 'WEAK_PASSWORD'));
});

test('with no password configured nobody can sign in and the console is sealed', async () => {
  const app = await start({ DIRECTOR_PASSWORD_HASH: undefined });
  try {
    const me = await app.api('GET', '/api/auth/me');
    assert.equal(me.json.configured, false);
    assert.equal(me.json.authenticated, false);
    const login = await app.api('POST', '/api/auth/login', { password: 'YABBAI-DIRECTOR-88' });
    assert.equal(login.status, 503);
    assert.equal((await app.api('GET', '/api/console/overview')).status, 401);
  } finally {
    await app.close();
  }
});

test('login: wrong password fails generically, right password sets an httpOnly strict cookie', async () => {
  const app = await start();
  try {
    const bad = await app.api('POST', '/api/auth/login', { password: 'nope nope nope nope' });
    assert.equal(bad.status, 401);
    assert.equal(bad.json.code, 'INVALID_CREDENTIALS');
    assert.equal(bad.headers.get('set-cookie'), null);

    const ok = await app.api('POST', '/api/auth/login', { password: PASSWORD });
    assert.equal(ok.status, 200);
    const cookie = ok.headers.get('set-cookie') ?? '';
    assert.match(cookie, /flash_session=/);
    assert.match(cookie, /HttpOnly/);
    assert.match(cookie, /SameSite=Strict/);
    assert.ok(!JSON.stringify(ok.json).includes(cookie.split(';')[0].split('=')[1]), 'token must not appear in the response body');

    app.cookie = cookie.split(';')[0];
    assert.equal((await app.api('GET', '/api/console/overview')).status, 200);

    // The database stores only a hash of the session token.
    const token = decodeURIComponent(app.cookie.split('=')[1]);
    const rows = await app.built.db.query('SELECT token_hash FROM sessions');
    assert.equal(rows.rows.length, 1);
    assert.notEqual(rows.rows[0].token_hash, token);
  } finally {
    await app.close();
  }
});

test('a made-up or tampered session cookie is worthless', async () => {
  const app = await start();
  try {
    await app.login();
    const forged = 'flash_session=' + 'A'.repeat(43);
    assert.equal((await app.api('GET', '/api/console/invoices', undefined, { cookie: forged })).status, 401);
    const tampered = app.cookie!.slice(0, -2) + 'zz';
    assert.equal((await app.api('GET', '/api/console/invoices', undefined, { cookie: tampered })).status, 401);
    assert.equal((await app.api('GET', '/api/console/invoices', undefined, { cookie: null })).status, 401);
  } finally {
    await app.close();
  }
});

test('every console route refuses an unauthenticated caller', async () => {
  const app = await start();
  try {
    const routes: Array<[string, string]> = [
      ['GET', '/api/console/overview'],
      ['GET', '/api/console/health'],
      ['GET', '/api/console/payments'],
      ['GET', '/api/console/invoices'],
      ['POST', '/api/console/invoices'],
      ['POST', '/api/console/invoices/inv_x/attest'],
      ['POST', '/api/console/invoices/inv_x/open'],
      ['GET', '/api/console/products'],
      ['POST', '/api/console/products'],
      ['GET', '/api/console/orders'],
      ['GET', '/api/console/leads'],
      ['POST', '/api/console/leads'],
      ['GET', '/api/console/drafts'],
      ['POST', '/api/console/ai/brief'],
      ['POST', '/api/console/ai/ask'],
      ['GET', '/api/console/payouts'],
      ['GET', '/api/console/wallet'],
      ['POST', '/api/console/wallet/challenge'],
      ['POST', '/api/console/wallet/verify'],
      ['GET', '/api/console/markets'],
      ['GET', '/api/console/settings'],
      ['PUT', '/api/console/settings/allocation'],
      ['POST', '/api/console/autopilot'],
      ['POST', '/api/console/autopilot/run'],
      ['POST', '/api/console/reconcile'],
      ['GET', '/api/console/audit'],
      ['POST', '/api/console/statements/suggest'],
    ];
    for (const [method, path] of routes) {
      const res = await app.api(method, path, method === 'GET' ? undefined : {}, { cookie: null });
      assert.equal(res.status, 401, `${method} ${path} should be 401, got ${res.status}`);
    }
  } finally {
    await app.close();
  }
});

test('cross-site requests are refused even with a valid session (CSRF)', async () => {
  const app = await start();
  try {
    await app.login();
    const noHeader = await fetch(app.url + '/api/console/invoices', {
      method: 'POST',
      headers: { Cookie: app.cookie!, 'Content-Type': 'application/json' },
      body: JSON.stringify({ clientName: 'x', items: [{ desc: 'a', qty: 1, unitDollars: 5 }] }),
    });
    assert.equal(noHeader.status, 403);

    const evilOrigin = await app.api('POST', '/api/console/invoices', { clientName: 'x', items: [{ desc: 'a', qty: 1, unitDollars: 5 }] }, { headers: { Origin: 'https://evil.example' } });
    assert.equal(evilOrigin.status, 403);

    const crossSite = await app.api('POST', '/api/console/invoices', { clientName: 'x', items: [{ desc: 'a', qty: 1, unitDollars: 5 }] }, { headers: { 'Sec-Fetch-Site': 'cross-site' } });
    assert.equal(crossSite.status, 403);

    // A plain HTML form post (the classic CSRF vector) is refused on content type as well.
    const form = await app.api('POST', '/api/auth/login', undefined, { cookie: null, raw: 'password=x', headers: { 'Content-Type': 'application/x-www-form-urlencoded' } });
    assert.equal(form.status, 415);

    assert.equal((await app.api('GET', '/api/console/invoices')).json.invoices.length, 0);
  } finally {
    await app.close();
  }
});

test('brute force: repeated failures lock login, and the lock is stored in the database', async () => {
  const app = await start();
  try {
    for (let i = 0; i < 8; i++) {
      const r = await app.api('POST', '/api/auth/login', { password: `wrong guess number ${i}` });
      assert.equal(r.status, 401);
    }
    const locked = await app.api('POST', '/api/auth/login', { password: PASSWORD });
    assert.equal(locked.status, 429, 'even the right password is refused while locked');
    const kv = await app.built.db.query(`SELECT value FROM kv WHERE key = 'auth_throttle'`);
    assert.equal(kv.rows[0].value.failures, 8);
    assert.ok(kv.rows[0].value.lockedUntil > Date.now());
    const audit = await app.built.db.query(`SELECT COUNT(*)::int AS n FROM audit_log WHERE action = 'auth.login_failed'`);
    assert.equal(audit.rows[0].n, 8);
  } finally {
    await app.close();
  }
});

test('two-factor: a code is required, must be right, and cannot be replayed', async () => {
  const secretBytes = Buffer.from('flash-test-totp-secret!!', 'ascii');
  const secret = base32Encode(secretBytes);
  const app = await start({ TOTP_SECRET: secret });
  try {
    assert.equal((await app.api('GET', '/api/auth/me')).json.totpRequired, true);
    const noCode = await app.api('POST', '/api/auth/login', { password: PASSWORD });
    assert.equal(noCode.status, 401);
    assert.equal(noCode.json.code, 'INVALID_CREDENTIALS', 'must not reveal that the password was correct');

    const wrong = await app.api('POST', '/api/auth/login', { password: PASSWORD, totp: '000000' });
    assert.equal(wrong.status, 401);

    const code = totpAt(secretBytes, Math.floor(Date.now() / 30_000));
    assert.notEqual(matchTotp(secret, code), null);
    const ok = await app.api('POST', '/api/auth/login', { password: PASSWORD, totp: code });
    assert.equal(ok.status, 200);

    const replay = await app.api('POST', '/api/auth/login', { password: PASSWORD, totp: code });
    assert.equal(replay.status, 401, 'the same code must not work twice');
  } finally {
    await app.close();
  }
});

test('sessions expire, go idle, and die on logout', async () => {
  const app = await start();
  try {
    await app.login();
    await app.built.db.query('UPDATE sessions SET last_seen_at = $1', [Date.now() - 3 * 3600_000]);
    assert.equal((await app.api('GET', '/api/console/overview')).status, 401, 'idle session must be rejected');

    await app.login();
    await app.built.db.query('UPDATE sessions SET expires_at = $1', [Date.now() - 1000]);
    assert.equal((await app.api('GET', '/api/console/overview')).status, 401, 'expired session must be rejected');

    const cookie = await app.login();
    assert.equal((await app.api('POST', '/api/auth/logout')).status, 200);
    assert.equal((await app.api('GET', '/api/console/overview', undefined, { cookie })).status, 401, 'cookie must be dead after logout');
  } finally {
    await app.close();
  }
});

test('step-up: sensitive actions need the password again once the window closes', async () => {
  const app = await start();
  try {
    await app.login();
    await app.built.db.query('UPDATE sessions SET stepup_until = 0');
    const blocked = await app.api('POST', '/api/console/wallet/challenge', {});
    assert.equal(blocked.status, 403);
    assert.equal(blocked.json.code, 'STEP_UP_REQUIRED');

    assert.equal((await app.api('POST', '/api/auth/stepup', { password: 'definitely not it!' })).status, 401);
    assert.equal((await app.api('POST', '/api/auth/stepup', { password: PASSWORD })).status, 200);
    const after = await app.api('POST', '/api/console/wallet/challenge', {});
    assert.notEqual(after.status, 403);
  } finally {
    await app.close();
  }
});
