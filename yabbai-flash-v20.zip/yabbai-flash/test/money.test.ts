/**
 * "Can anyone inject funds?" — every way we could think of to make the
 * numbers go up without real money behind them, tried against the real app.
 */
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { computeTotals, suggestFromStatement } from '../server/invoices.ts';
import { allocationPlan, recordPayment } from '../server/ledger.ts';
import { issueInvoice, start } from './helpers.ts';

test('a fresh install contains no money, no customers, no leads and no products', async () => {
  const app = await start();
  try {
    await app.login();
    const o = (await app.api('GET', '/api/console/overview')).json;
    assert.deepEqual(
      [o.totals.verifiedAllTimeCents, o.totals.attestedAllTimeCents, o.totals.receivableCents, o.totals.paymentsCount, o.totals.openInvoices, o.totals.ordersPaid],
      [0, 0, 0, 0, 0, 0]
    );
    assert.equal((await app.api('GET', '/api/console/invoices')).json.invoices.length, 0);
    assert.equal((await app.api('GET', '/api/console/leads')).json.leads.length, 0);
    assert.equal((await app.api('GET', '/api/console/products')).json.products.length, 0);
    assert.equal((await app.api('GET', '/api/console/payments')).json.payments.length, 0);

    // Running every autopilot job must not conjure any of the above.
    await app.api('POST', '/api/console/autopilot/run', {});
    const after = (await app.api('GET', '/api/console/overview')).json;
    assert.equal(after.totals.verifiedAllTimeCents, 0);
    assert.equal((await app.api('GET', '/api/console/leads')).json.leads.length, 0);
    assert.equal((await app.api('GET', '/api/console/invoices')).json.invoices.length, 0);
  } finally {
    await app.close();
  }
});

test('there is no API that adds money: the old "bank a sale" and "log funding" doors are gone', async () => {
  const app = await start();
  try {
    await app.login();
    const inv = await issueInvoice(app, 500);
    const attempts: Array<[string, string, unknown]> = [
      ['POST', '/api/console/payments', { invoiceId: inv.id, amountCents: 50000, verified: true }],
      ['POST', '/api/console/funding', { amount: 5000, verified: true }],
      ['POST', '/api/console/sale', { productId: 'x', amount: 5000 }],
      ['POST', '/api/console/pools', { TREASURY: 940000 }],
      ['PUT', '/api/console/pools', { TREASURY: 940000 }],
      ['POST', '/api/console/withdrawals', { method: 'CARD', amount: 500 }],
      ['POST', '/api/console/payouts', { amount: 500 }],
      ['POST', '/api/console/state/import', { pools: { TREASURY: 940000 } }],
      ['POST', `/api/console/invoices/${inv.id}/pay`, { amountCents: 50000 }],
      ['POST', `/api/console/invoices/${inv.id}/credit`, { amountAud: 500, proof: 'director' }],
      ['POST', '/api/public/invoice/' + inv.token + '/claim', { ref: 'NPP-1', amountAud: 500 }],
      ['POST', '/api/public/invoice/' + inv.token + '/paid', {}],
    ];
    for (const [method, path, body] of attempts) {
      const res = await app.api(method, path, body);
      assert.equal(res.status, 404, `${method} ${path} must not exist (got ${res.status})`);
    }
    const o = (await app.api('GET', '/api/console/overview')).json;
    assert.equal(o.totals.verifiedAllTimeCents, 0);
    assert.equal(o.totals.attestedAllTimeCents, 0);
  } finally {
    await app.close();
  }
});

test('an invoice cannot be flipped to "paid" by editing it', async () => {
  const app = await start();
  try {
    await app.login();
    const draft = (
      await app.api('POST', '/api/console/invoices', {
        clientName: 'Acme',
        items: [{ desc: 'Work', qty: 1, unitDollars: 100 }],
        status: 'paid',
        paidCents: 10000,
        verifiedPaidCents: 10000,
        totalCents: 1,
        livemode: true,
      })
    ).json.invoice;
    assert.equal(draft.status, 'draft');
    assert.equal(draft.paidCents, 0);
    assert.equal(draft.totalCents, 10000, 'total comes from the line items, not from the client');

    const put = await app.api('PUT', `/api/console/invoices/${draft.id}`, { clientName: 'Acme', items: [{ desc: 'Work', qty: 1, unitDollars: 100 }], status: 'paid', paidCents: 10000 });
    assert.equal(put.json.invoice.status, 'draft');
    assert.equal(put.json.invoice.paidCents, 0);

    const opened = (await app.api('POST', `/api/console/invoices/${draft.id}/open`)).json.invoice;
    assert.equal(opened.status, 'open');
    // Once issued, the amount is locked.
    const edit = await app.api('PUT', `/api/console/invoices/${draft.id}`, { clientName: 'Acme', items: [{ desc: 'Work', qty: 1, unitDollars: 1 }] });
    assert.equal(edit.status, 409);
  } finally {
    await app.close();
  }
});

test('the database itself refuses to alter or delete a payment, or to mark a typed-in payment as verified', async () => {
  const app = await start();
  try {
    await app.login();
    const inv = await issueInvoice(app, 100);
    const db = app.built.db;
    const first = await recordPayment(db.query, { proofId: 'stripe:pi_one', rail: 'stripe', kind: 'invoice', invoiceId: inv.id, amountCents: 10000, livemode: false });
    assert.equal(first.inserted, true);

    // Same proof again: no second credit.
    const again = await recordPayment(db.query, { proofId: 'stripe:pi_one', rail: 'stripe', kind: 'invoice', invoiceId: inv.id, amountCents: 99999, livemode: false });
    assert.equal(again.inserted, false);
    assert.equal(again.payment.amountCents, 10000);

    await assert.rejects(db.query(`UPDATE payments SET amount_cents = 999999 WHERE proof_id = 'stripe:pi_one'`), /append-only/);
    await assert.rejects(db.query(`UPDATE payments SET verified = FALSE, rail = 'attested' WHERE proof_id = 'stripe:pi_one'`), /append-only|verified_means_processor/);
    await assert.rejects(db.query(`UPDATE payments SET proof_id = 'stripe:pi_two' WHERE proof_id = 'stripe:pi_one'`), /append-only/);
    await assert.rejects(db.query(`DELETE FROM payments WHERE proof_id = 'stripe:pi_one'`), /append-only/);
    await assert.rejects(
      db.query(
        `INSERT INTO payments (id, proof_id, rail, kind, invoice_id, amount_cents, verified, livemode, detail, occurred_at, created_at)
         VALUES ('pay_fake', 'attested:fake', 'attested', 'invoice', $1, 500000, TRUE, FALSE, '{}', 1, 1)`,
        [inv.id]
      ),
      /verified_means_processor/
    );
    await assert.rejects(
      db.query(
        `INSERT INTO payments (id, proof_id, rail, kind, invoice_id, amount_cents, verified, livemode, detail, occurred_at, created_at)
         VALUES ('pay_neg', 'stripe:neg', 'stripe', 'invoice', $1, -500, TRUE, FALSE, '{}', 1, 1)`,
        [inv.id]
      ),
      /check/i
    );
    const count = await db.query('SELECT COUNT(*)::int AS n FROM payments');
    assert.equal(count.rows[0].n, 1);
  } finally {
    await app.close();
  }
});

test('attested bank payments: need step-up, cannot exceed what is owing, cannot repeat, and never count as verified', async () => {
  const app = await start();
  try {
    await app.login();
    const inv = await issueInvoice(app, 300);

    await app.built.db.query('UPDATE sessions SET stepup_until = 0');
    const blocked = await app.api('POST', `/api/console/invoices/${inv.id}/attest`, { amountDollars: 300, reference: 'NPP 123456' });
    assert.equal(blocked.status, 403, 'no step-up, no attestation');
    await app.api('POST', '/api/auth/stepup', { password: 'correct horse battery staple 42' });

    const tooMuch = await app.api('POST', `/api/console/invoices/${inv.id}/attest`, { amountDollars: 300.01, reference: 'NPP 123456' });
    assert.equal(tooMuch.status, 400);
    const noRef = await app.api('POST', `/api/console/invoices/${inv.id}/attest`, { amountDollars: 100 });
    assert.equal(noRef.status, 400, 'a reference is mandatory');

    const part = await app.api('POST', `/api/console/invoices/${inv.id}/attest`, { amountDollars: 100, reference: 'NPP 123456', note: 'seen in CommBank' });
    assert.equal(part.status, 200);
    assert.equal(part.json.invoice.status, 'part');
    assert.equal(part.json.payment.verified, false);
    assert.equal(part.json.payment.rail, 'attested');

    const dup = await app.api('POST', `/api/console/invoices/${inv.id}/attest`, { amountDollars: 100, reference: 'npp 123456' });
    assert.equal(dup.json.duplicate, true, 'the same bank reference cannot be credited twice');
    assert.equal(dup.json.invoice.paidCents, 10000);

    const rest = await app.api('POST', `/api/console/invoices/${inv.id}/attest`, { amountDollars: 200, reference: 'NPP 999' });
    assert.equal(rest.json.invoice.status, 'paid');

    const o = (await app.api('GET', '/api/console/overview')).json;
    assert.equal(o.totals.verifiedAllTimeCents, 0, 'attested money is never reported as verified');
    assert.equal(o.totals.attestedAllTimeCents, 30000);
    assert.equal(o.allocation.reduce((n: number, a: any) => n + a.cents, 0), 0, 'the allocation plan is built on verified income only');
  } finally {
    await app.close();
  }
});

test('customers see only their own issued invoice, and nothing internal', async () => {
  const app = await start({ BANK_PAYID: 'pay@yabbai.example', BANK_BSB: '123-456', BANK_ACCOUNT_NUMBER: '12345678', BANK_ACCOUNT_NAME: 'Test Trader' });
  try {
    await app.login();
    const draft = (await app.api('POST', '/api/console/invoices', { clientName: 'Draft Co', items: [{ desc: 'x', qty: 1, unitDollars: 10 }] })).json.invoice;
    const inv = await issueInvoice(app, 120);

    assert.equal((await app.api('GET', `/api/public/invoice/${draft.token}`, undefined, { cookie: null })).status, 404, 'drafts are private');
    assert.equal((await app.api('GET', `/api/public/invoice/${'x'.repeat(32)}`, undefined, { cookie: null })).status, 404);
    assert.equal((await app.api('GET', `/api/public/invoice/..%2f..%2fetc`, undefined, { cookie: null })).status, 400);

    const pub = await app.api('GET', `/api/public/invoice/${inv.token}`, undefined, { cookie: null });
    assert.equal(pub.status, 200);
    const text = JSON.stringify(pub.json);
    assert.ok(!text.includes(inv.id), 'internal id must not leak');
    assert.ok(!text.includes('accounts@realclient.example'), 'client email must not leak');
    assert.ok(!text.includes(draft.token));
    assert.equal(pub.json.totalCents, 12000);
    assert.equal(pub.json.rails.card, false, 'no Stripe → no card button');
    assert.equal(pub.json.rails.sol, false);
    assert.deepEqual(pub.json.rails.bank, { payId: 'pay@yabbai.example', bsb: '123-456', accountNumber: '12345678', accountName: 'Test Trader', reference: inv.number });

    // A customer cannot start a card payment that the server has not enabled, nor choose the amount.
    const co = await app.api('POST', `/api/public/invoice/${inv.token}/checkout`, { amountCents: 1 }, { cookie: null });
    assert.equal(co.status, 503);
  } finally {
    await app.close();
  }
});

test('voiding: allowed while unpaid, refused once money is recorded', async () => {
  const app = await start();
  try {
    await app.login();
    const a = await issueInvoice(app, 50);
    assert.equal((await app.api('POST', `/api/console/invoices/${a.id}/void`)).json.invoice.status, 'void');
    const pub = await app.api('GET', `/api/public/invoice/${a.token}`, undefined, { cookie: null });
    assert.equal(pub.json.status, 'void');
    assert.equal(pub.json.rails.bank, null);

    const b = await issueInvoice(app, 50);
    await app.api('POST', `/api/console/invoices/${b.id}/attest`, { amountDollars: 10, reference: 'REF-1234' });
    assert.equal((await app.api('POST', `/api/console/invoices/${b.id}/void`)).status, 409);
  } finally {
    await app.close();
  }
});

test('GST is only ever added when the business is registered', async () => {
  const off = await start();
  try {
    await off.login();
    const res = await off.api('POST', '/api/console/invoices', { clientName: 'A', items: [{ desc: 'x', qty: 1, unitDollars: 100 }], chargeGst: true });
    assert.equal(res.status, 400);
    assert.equal(res.json.code, 'GST_NOT_REGISTERED');
  } finally {
    await off.close();
  }
  const on = await start({ GST_REGISTERED: 'true', BUSINESS_ABN: '12 345 678 901' });
  try {
    await on.login();
    const res = await on.api('POST', '/api/console/invoices', { clientName: 'A', items: [{ desc: 'x', qty: 2, unitDollars: 100 }], chargeGst: true, discountDollars: 20 });
    assert.equal(res.json.invoice.subtotalCents, 20000);
    assert.equal(res.json.invoice.taxCents, 1800, '10% of the discounted amount');
    assert.equal(res.json.invoice.totalCents, 19800);
  } finally {
    await on.close();
  }
});

test('invoice arithmetic and the allocation plan use integer cents', () => {
  assert.deepEqual(computeTotals([{ desc: 'a', qty: 3, unitCents: 3333 }], false, 0), { subtotalCents: 9999, taxCents: 0, discountCents: 0, totalCents: 9999 });
  assert.deepEqual(computeTotals([{ desc: 'a', qty: 1, unitCents: 1005 }], true, 0), { subtotalCents: 1005, taxCents: 101, discountCents: 0, totalCents: 1106 });
  assert.equal(computeTotals([{ desc: 'a', qty: 1, unitCents: 500 }], false, 99999).totalCents, 0, 'a discount cannot push a total below zero');

  const plan = allocationPlan(100_000, { keepPct: 30, reservePct: 20, reinvestPct: 50 });
  assert.deepEqual(
    plan.map(p => p.cents),
    [30_000, 14_000, 28_000, 28_000]
  );
  assert.equal(
    plan.reduce((n, p) => n + p.cents, 0),
    100_000,
    'the plan always adds up to exactly the income'
  );
  assert.equal(allocationPlan(-500, { keepPct: 30, reservePct: 20, reinvestPct: 50 }).reduce((n, p) => n + p.cents, 0), 0);
});

test('bank statement import only suggests — it never credits anything by itself', async () => {
  const app = await start();
  try {
    await app.login();
    const inv = await issueInvoice(app, 5170);
    const csv = `Date,Amount,Description,Balance\n20/11/2026,5170.00,NPP ${inv.number} SOME CLIENT PTY LTD,18420.50\n20/11/2026,-45.00,OFFICE SUPPLIES,13250.50\n20/11/2026,1500.00,TRANSFER UNRELATED,14750.50`;
    const res = await app.api('POST', '/api/console/statements/suggest', { csv });
    assert.equal(res.status, 200);
    assert.equal(res.json.suggestions.length, 2, 'debits are ignored');
    assert.equal(res.json.suggestions[0].invoiceNumber, inv.number);
    assert.equal(res.json.suggestions[0].amountCents, 517000);
    assert.equal(res.json.suggestions[1].invoiceId, null);

    const o = (await app.api('GET', '/api/console/overview')).json;
    assert.equal(o.totals.attestedAllTimeCents, 0, 'pasting a statement credits nothing');
    assert.equal((await app.api('GET', `/api/console/invoices/${inv.id}`)).json.invoice.status, 'open');

    // Pure function check, including a CommBank-style export with no header row.
    const headerless = suggestFromStatement(`20/11/2026,"+120.00","Direct Credit ${inv.number}","+1,000.00"`, [inv]);
    assert.equal(headerless.length, 1);
    assert.equal(headerless[0].amountCents, 12000);
  } finally {
    await app.close();
  }
});
