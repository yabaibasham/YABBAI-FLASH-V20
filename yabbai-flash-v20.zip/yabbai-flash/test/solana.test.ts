/**
 * Crypto payments. The chain is a scripted RPC, wallets are real ed25519
 * keypairs, and every check is run through the app's HTTP API.
 */
import assert from 'node:assert/strict';
import { test } from 'node:test';
import { loadConfig } from '../server/config.ts';
import { formatUnits, receivedBaseUnits, verifyEd25519 } from '../server/solana.ts';
import { base58Decode, base58Encode } from '../server/util.ts';
import { fakeNet, issueInvoice, newSignature, newWallet, randomAddress, sigInfo, solTransferTx, start, usdcTransferTx } from './helpers.ts';
import type { Running, TestWallet } from './helpers.ts';

const USDC_MAINNET = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';

async function prove(app: Running, wallet: TestWallet) {
  const ch = await app.api('POST', '/api/console/wallet/challenge', {});
  assert.equal(ch.status, 200);
  return app.api('POST', '/api/console/wallet/verify', { signature: wallet.sign(ch.json.message) });
}

async function quote(app: Running, token: string, asset = 'SOL') {
  return app.api('POST', `/api/public/invoice/${token}/quote`, { asset }, { cookie: null });
}

async function status(app: Running, token: string) {
  // The server refuses to re-check the same quote more than once every few seconds.
  await app.built.db.query('UPDATE sol_quotes SET checked_at = 0');
  return (await app.api('GET', `/api/public/invoice/${token}/status`, undefined, { cookie: null })).json;
}

test('base58 round-trips, and the address the old build shipped is not a wallet at all', () => {
  const real = 'HKjCGdas7CVkSwQHi6Bhckj2U2P8rtTyMbikdY5pkXcb';
  const bytes = base58Decode(real)!;
  assert.equal(bytes.length, 32);
  assert.equal(base58Encode(bytes), real);
  assert.equal(base58Encode(base58Decode('11111111111111111111111111111111')!), '11111111111111111111111111111111');
  assert.equal(base58Decode('0OIl'), null, 'characters outside the alphabet are rejected');

  // The string hardcoded as the Solana Pay recipient in the previous version.
  const invented = '7dzgXb973VjS3HqXk4r8dZ5n8Y9s4T6y8U7v2P15YR';
  assert.equal(base58Decode(invented)!.length, 31);
  const cfg = loadConfig({ SOLANA_RECEIVE_ADDRESS: invented });
  assert.equal(cfg.solana.addressValid, false);
  assert.ok(cfg.problems.some(p => p.code === 'BAD_SOLANA_ADDRESS' && /31 bytes/.test(p.message)));

  assert.equal(formatUnits(1_500_000_000n, 9), '1.5');
  assert.equal(formatUnits(10_000n, 9), '0.00001');
  assert.equal(formatUnits(25_000_000n, 6), '25');
});

test('ed25519 verification accepts the real owner and nobody else', () => {
  const w = newWallet();
  const other = newWallet();
  const msg = Buffer.from('prove it');
  const sig = Buffer.from(w.sign('prove it'), 'base64');
  assert.equal(verifyEd25519(base58Decode(w.address)!, msg, sig), true);
  assert.equal(verifyEd25519(base58Decode(other.address)!, msg, sig), false);
  assert.equal(verifyEd25519(base58Decode(w.address)!, Buffer.from('prove it!'), sig), false);
  assert.equal(verifyEd25519(new Uint8Array(31), msg, sig), false);
});

test('the crypto option stays hidden until the configured wallet proves control', async () => {
  const wallet = newWallet();
  const app = await start({ SOLANA_RECEIVE_ADDRESS: wallet.address });
  try {
    await app.login();
    const inv = await issueInvoice(app, 220);

    let pub = (await app.api('GET', `/api/public/invoice/${inv.token}`, undefined, { cookie: null })).json;
    assert.equal(pub.rails.sol, false);
    assert.equal((await quote(app, inv.token)).status, 503);

    // An address-poisoning look-alike, or any other wallet, cannot pass.
    const impostor = newWallet();
    const ch = (await app.api('POST', '/api/console/wallet/challenge', {})).json;
    assert.ok(ch.message.includes(wallet.address));
    const bad = await app.api('POST', '/api/console/wallet/verify', { signature: impostor.sign(ch.message) });
    assert.equal(bad.status, 400);
    assert.equal(bad.json.code, 'BAD_SIGNATURE');
    // The challenge is single-use: the real wallet must request a fresh one.
    const reuse = await app.api('POST', '/api/console/wallet/verify', { signature: wallet.sign(ch.message) });
    assert.equal(reuse.status, 400);
    assert.equal((await app.api('GET', '/api/console/wallet')).json.wallet.proven, false);

    const ok = await prove(app, wallet);
    assert.equal(ok.status, 200);
    assert.equal(ok.json.wallet.proven, true);
    assert.equal(ok.json.wallet.proofMethod, 'signature');
    pub = (await app.api('GET', `/api/public/invoice/${inv.token}`, undefined, { cookie: null })).json;
    assert.equal(pub.rails.sol, true);
    assert.equal(pub.rails.usdc, true);
  } finally {
    await app.close();
  }
});

test('the receiving address cannot be changed from the console, and a proof does not carry over to a different address', async () => {
  const wallet = newWallet();
  const net = fakeNet();
  const app = await start({ SOLANA_RECEIVE_ADDRESS: wallet.address }, { net });
  try {
    await app.login();
    await prove(app, wallet);
    const attacker = randomAddress();
    for (const [method, path] of [
      ['PUT', '/api/console/wallet'],
      ['POST', '/api/console/wallet'],
      ['PUT', '/api/console/settings'],
      ['POST', '/api/console/settings'],
      ['PUT', '/api/console/settings/wallet'],
      ['PUT', '/api/console/settings/bank'],
    ] as const) {
      const res = await app.api(method, path, { address: attacker, solanaAddress: attacker, receiveAddress: attacker, bsb: '000-000', accountNumber: '99999999' });
      assert.equal(res.status, 404, `${method} ${path} must not exist`);
    }
    assert.equal((await app.api('GET', '/api/console/settings')).json.pinned.solanaAddress, wallet.address);

    // Simulate someone with hosting access swapping the address: the stored proof is for the old one.
    const stored = (await app.built.db.query(`SELECT value FROM kv WHERE key = 'wallet_proof'`)).rows[0].value;
    assert.equal(stored.address, wallet.address);
  } finally {
    await app.close();
  }
  const other = newWallet();
  const moved = await start({ SOLANA_RECEIVE_ADDRESS: other.address });
  try {
    await moved.built.db.query(`INSERT INTO kv (key, value, updated_at) VALUES ('wallet_proof', $1::jsonb, 1)`, [
      JSON.stringify({ address: wallet.address, cluster: 'mainnet-beta', method: 'signature', at: 1 }),
    ]);
    await moved.login();
    assert.equal((await moved.api('GET', '/api/console/wallet?refresh=1')).json.wallet.proven, false, 'a proof for another address proves nothing');
  } finally {
    await moved.close();
  }
});

test('a quote prices from two agreeing sources and points at the pinned wallet with a unique reference', async () => {
  const wallet = newWallet();
  const app = await start({ SOLANA_RECEIVE_ADDRESS: wallet.address });
  try {
    await app.login();
    await prove(app, wallet);
    const inv = await issueInvoice(app, 220.4);
    const q = (await quote(app, inv.token)).json;
    assert.equal(q.recipient, wallet.address);
    assert.equal(q.asset, 'SOL');
    assert.equal(q.audCents, 22040);
    // 220.40 / 110.2 (mean of 110 and 110.4) = 2.0 SOL
    assert.equal(q.amount, '2');
    assert.equal(base58Decode(q.reference)!.length, 32);
    const url = new URL(q.url.replace('solana:', 'https://x/'));
    assert.equal(q.url.startsWith(`solana:${wallet.address}?`), true);
    assert.equal(url.searchParams.get('amount'), '2');
    assert.equal(url.searchParams.get('reference'), q.reference);
    assert.equal(url.searchParams.get('memo'), inv.number);
    assert.equal(url.searchParams.get('spl-token'), null);

    // Asking again returns the same quote rather than a new reference to watch.
    assert.equal((await quote(app, inv.token)).json.reference, q.reference);

    const u = (await quote(app, inv.token, 'USDC')).json;
    assert.equal(new URL(u.url.replace('solana:', 'https://x/')).searchParams.get('spl-token'), USDC_MAINNET);
    assert.equal(u.amount, '144.96', '220.40 / 1.5205 = 144.952…, rounded up to the cent');
    assert.notEqual(u.reference, q.reference);

    assert.equal((await quote(app, inv.token, 'DOGE')).status, 400);
  } finally {
    await app.close();
  }
});

test('no price, no quote: disagreement between sources or an outage pauses quoting — there is no fallback number', async () => {
  const wallet = newWallet();
  const net = fakeNet();
  const app = await start({ SOLANA_RECEIVE_ADDRESS: wallet.address }, { net });
  try {
    net.fx.coinbase = { sol: 250, usdc: 1.52 }; // one feed says $250 (the old hardcoded figure), the other $110
    await app.login();
    await prove(app, wallet);
    const inv = await issueInvoice(app, 100);

    const disagree = await quote(app, inv.token);
    assert.equal(disagree.status, 503);
    assert.match(disagree.json.error, /disagree/);

    net.fx.coinbase = null;
    net.fx.coingecko = null;
    const down = await quote(app, inv.token);
    assert.equal(down.status, 503);
    assert.equal((await app.built.db.query('SELECT COUNT(*)::int AS n FROM sol_quotes')).rows[0].n, 0);

    net.fx.coingecko = { sol: 110, usdc: 1.52 }; // a single healthy source is enough
    assert.equal((await quote(app, inv.token)).status, 200);
  } finally {
    await app.close();
  }
});

test('a finalized transfer carrying the reference pays the invoice — once', async () => {
  const wallet = newWallet();
  const net = fakeNet();
  const app = await start({ SOLANA_RECEIVE_ADDRESS: wallet.address }, { net });
  try {
    await app.login();
    await prove(app, wallet);
    const inv = await issueInvoice(app, 220.4);
    const q = (await quote(app, inv.token)).json;
    assert.equal((await status(app, inv.token)).chain, 'none');

    const sig = newSignature();
    // Seen by the network but not yet final: shown to the customer, not credited.
    net.signatures.set(q.reference, [sigInfo(sig, 'confirmed')]);
    let st = await status(app, inv.token);
    assert.equal(st.chain, 'seen');
    assert.equal(st.status, 'open');

    net.signatures.set(q.reference, [sigInfo(sig, 'finalized')]);
    net.transactions.set(sig, solTransferTx({ recipient: wallet.address, reference: q.reference, lamports: 2_000_000_000 }));
    st = await status(app, inv.token);
    assert.equal(st.status, 'paid');
    assert.equal(st.paidCents, 22040);

    const detail = (await app.api('GET', `/api/console/invoices/${inv.id}`)).json;
    assert.equal(detail.payments.length, 1);
    assert.equal(detail.payments[0].proofId, `sol:${sig}`);
    assert.equal(detail.payments[0].verified, true);
    assert.equal(detail.payments[0].detail.received, '2');
    assert.match(detail.payments[0].proofUrl, new RegExp(`solscan\\.io/tx/${sig}$`));

    // Scanning again, via the page or the treasurer job, changes nothing.
    await status(app, inv.token);
    await app.api('POST', '/api/console/reconcile', {});
    assert.equal((await app.api('GET', `/api/console/invoices/${inv.id}`)).json.payments.length, 1);
    assert.equal((await app.api('GET', '/api/console/overview')).json.totals.verifiedAllTimeCents, 22040);
  } finally {
    await app.close();
  }
});

test('things that must NOT count as payment', async () => {
  const wallet = newWallet();
  const net = fakeNet();
  const app = await start({ SOLANA_RECEIVE_ADDRESS: wallet.address }, { net });
  try {
    await app.login();
    await prove(app, wallet);
    const inv = await issueInvoice(app, 220.4);
    const q = (await quote(app, inv.token)).json;

    // 1. Carries our reference but pays somebody else.
    const s1 = newSignature();
    net.transactions.set(s1, solTransferTx({ recipient: randomAddress(), reference: q.reference, lamports: 2_000_000_000 }));
    // 2. A failed transaction.
    const s2 = newSignature();
    net.transactions.set(s2, solTransferTx({ recipient: wallet.address, reference: q.reference, lamports: 2_000_000_000, failed: true }));
    // 3. Listed with an error by the RPC.
    const s3 = newSignature();
    net.transactions.set(s3, solTransferTx({ recipient: wallet.address, reference: q.reference, lamports: 2_000_000_000 }));
    // 4. Pays in and straight back out within one transaction (net zero).
    const s4 = newSignature();
    const roundTrip = solTransferTx({ recipient: wallet.address, reference: q.reference, lamports: 2_000_000_000 });
    roundTrip.meta.postBalances[1] = roundTrip.meta.preBalances[1];
    net.transactions.set(s4, roundTrip);

    net.signatures.set(q.reference, [sigInfo(s1), sigInfo(s2), sigInfo(s3, 'finalized', { InstructionError: [0, 'x'] }), sigInfo(s4)]);
    const st = await status(app, inv.token);
    assert.equal(st.status, 'open');
    assert.equal(st.paidCents, 0);
    assert.equal((await app.api('GET', `/api/console/invoices/${inv.id}`)).json.payments.length, 0);

    // 5. A real payment to our wallet with NO reference is not attributed to anyone.
    const stray = newSignature();
    net.signatures.set(wallet.address, [sigInfo(stray)]);
    net.transactions.set(stray, solTransferTx({ recipient: wallet.address, reference: randomAddress(), lamports: 5_000_000_000 }));
    await app.api('POST', '/api/console/reconcile', {});
    assert.equal((await app.api('GET', '/api/console/overview')).json.totals.verifiedAllTimeCents, 0);
  } finally {
    await app.close();
  }
});

test('one transaction cannot settle two invoices', async () => {
  const wallet = newWallet();
  const net = fakeNet();
  const app = await start({ SOLANA_RECEIVE_ADDRESS: wallet.address }, { net });
  try {
    await app.login();
    await prove(app, wallet);
    const a = await issueInvoice(app, 110.2);
    const b = await issueInvoice(app, 110.2);
    const qa = (await quote(app, a.token)).json;
    const qb = (await quote(app, b.token)).json;
    assert.notEqual(qa.reference, qb.reference);

    // The attacker pays once and tags the single transaction with both references.
    const sig = newSignature();
    const tx = solTransferTx({ recipient: wallet.address, reference: qa.reference, lamports: 1_000_000_000 });
    tx.transaction.message.accountKeys.push({ pubkey: qb.reference, signer: false, writable: false, source: 'transaction' });
    net.transactions.set(sig, tx);
    net.signatures.set(qa.reference, [sigInfo(sig)]);
    net.signatures.set(qb.reference, [sigInfo(sig)]);

    const sa = await status(app, a.token);
    const sb = await status(app, b.token);
    assert.deepEqual([sa.status, sb.status].sort(), ['open', 'paid'], 'exactly one invoice is paid');
    assert.equal((await app.api('GET', '/api/console/overview')).json.totals.verifiedAllTimeCents, 11020);
    assert.equal((await app.built.db.query('SELECT COUNT(*)::int AS n FROM payments')).rows[0].n, 1);
  } finally {
    await app.close();
  }
});

test('underpayment credits only what arrived; USDC is measured by token balance', async () => {
  const wallet = newWallet();
  const net = fakeNet();
  const app = await start({ SOLANA_RECEIVE_ADDRESS: wallet.address }, { net });
  try {
    await app.login();
    await prove(app, wallet);

    const inv = await issueInvoice(app, 220.4);
    const q = (await quote(app, inv.token)).json; // 2 SOL
    const half = newSignature();
    net.signatures.set(q.reference, [sigInfo(half)]);
    net.transactions.set(half, solTransferTx({ recipient: wallet.address, reference: q.reference, lamports: 1_000_000_000 }));
    const st = await status(app, inv.token);
    assert.equal(st.status, 'part');
    assert.equal(st.paidCents, 11020);
    assert.equal(st.outstandingCents, 11020);
    // The page now quotes only the remainder.
    const rest = (await quote(app, inv.token)).json;
    assert.equal(rest.audCents, 11020);
    assert.notEqual(rest.reference, q.reference);

    // A hair under (network dust) is accepted in full; tolerance is 0.5%.
    const inv2 = await issueInvoice(app, 110.2);
    const q2 = (await quote(app, inv2.token)).json; // 1 SOL
    const near = newSignature();
    net.signatures.set(q2.reference, [sigInfo(near)]);
    net.transactions.set(near, solTransferTx({ recipient: wallet.address, reference: q2.reference, lamports: 996_000_000 }));
    assert.equal((await status(app, inv2.token)).status, 'paid');

    const inv3 = await issueInvoice(app, 152.05);
    const q3 = (await quote(app, inv3.token, 'USDC')).json; // 100 USDC
    assert.equal(q3.amount, '100');
    const usdc = newSignature();
    net.signatures.set(q3.reference, [sigInfo(usdc)]);
    net.transactions.set(usdc, usdcTransferTx({ recipient: wallet.address, reference: q3.reference, baseUnits: 100_000_000, mint: USDC_MAINNET }));
    assert.equal((await status(app, inv3.token)).status, 'paid');

    // A look-alike token with a different mint is worth nothing.
    const inv4 = await issueInvoice(app, 152.05);
    const q4 = (await quote(app, inv4.token, 'USDC')).json;
    const fake = newSignature();
    net.signatures.set(q4.reference, [sigInfo(fake)]);
    net.transactions.set(fake, usdcTransferTx({ recipient: wallet.address, reference: q4.reference, baseUnits: 100_000_000, mint: randomAddress() }));
    assert.equal((await status(app, inv4.token)).status, 'open');
    assert.equal(receivedBaseUnits(net.transactions.get(fake), wallet.address, 'USDC', USDC_MAINNET), 0n);
  } finally {
    await app.close();
  }
});

test('on-chain proof of control: only a transaction SIGNED by the configured wallet counts', async () => {
  const wallet = newWallet();
  const net = fakeNet();
  const app = await start({ SOLANA_RECEIVE_ADDRESS: wallet.address }, { net });
  try {
    await app.login();
    const p = (await app.api('POST', '/api/console/wallet/onchain-proof', {})).json;
    assert.ok(p.url.startsWith(`solana:${wallet.address}?amount=0.000001`));

    // Someone else sends dust to the wallet with our reference: proves nothing.
    const dust = newSignature();
    net.signatures.set(p.reference, [sigInfo(dust)]);
    net.transactions.set(dust, solTransferTx({ recipient: wallet.address, reference: p.reference, lamports: 1000 }));
    assert.equal((await app.api('POST', '/api/console/wallet/onchain-check', {})).json.proven, false);

    // The wallet itself signs a transfer carrying the reference.
    const own = newSignature();
    net.signatures.set(p.reference, [sigInfo(own)]);
    net.transactions.set(own, solTransferTx({ recipient: wallet.address, reference: p.reference, lamports: 1000, signerIsRecipient: true }));
    const ok = (await app.api('POST', '/api/console/wallet/onchain-check', {})).json;
    assert.equal(ok.proven, true);
    assert.equal(ok.wallet.proofMethod, 'onchain');
    // The proof transfer is not income.
    assert.equal((await app.api('GET', '/api/console/overview')).json.totals.verifiedAllTimeCents, 0);
  } finally {
    await app.close();
  }
});

test('test-mode Stripe with a mainnet wallet keeps crypto off, so real coins are never booked as test money', async () => {
  const wallet = newWallet();
  const app = await start({ SOLANA_RECEIVE_ADDRESS: wallet.address }, { stripe: true });
  try {
    await app.login();
    await prove(app, wallet);
    const w = (await app.api('GET', '/api/console/wallet')).json;
    assert.equal(w.rail.enabled, false);
    assert.match(w.rail.reason, /mode/);
    const inv = await issueInvoice(app, 50);
    assert.equal((await quote(app, inv.token)).status, 503);
  } finally {
    await app.close();
  }
});

test('an RPC outage never credits anything and never breaks the pay page', async () => {
  const wallet = newWallet();
  const net = fakeNet();
  const app = await start({ SOLANA_RECEIVE_ADDRESS: wallet.address }, { net });
  try {
    await app.login();
    await prove(app, wallet);
    const inv = await issueInvoice(app, 110.2);
    await quote(app, inv.token);
    net.rpcDown = true;
    const st = await status(app, inv.token);
    assert.equal(st.status, 'open');
    assert.equal(st.chain, 'none');
    const run = await app.api('POST', '/api/console/reconcile', {});
    assert.match(run.json.result, /1 errors/);
    const wst = (await app.api('GET', '/api/console/wallet?refresh=1')).json.wallet;
    assert.ok(wst.error);
    assert.equal(wst.sol, null, 'no balance is shown when the chain cannot be read');
  } finally {
    await app.close();
  }
});
