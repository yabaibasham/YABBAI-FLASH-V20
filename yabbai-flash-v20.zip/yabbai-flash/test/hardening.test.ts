/**
 * The questions an attacker — or a careless future edit — would ask:
 * can the app be tricked from outside, can history be rewritten quietly,
 * can the owner be locked out, and could fake money creep back into the code?
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { test } from 'node:test';
import { fileURLToPath } from 'node:url';
import { kvGet, kvSet } from '../server/db.ts';
import { sha256hex } from '../server/util.ts';
import {
  PASSWORD,
  fakeNet,
  issueInvoice,
  newSignature,
  newWallet,
  passwordHash,
  payStubSession,
  randomAddress,
  sigInfo,
  signedEvent,
  solTransferTx,
  start,
} from './helpers.ts';
import type { Running, TestWallet } from './helpers.ts';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

async function prove(app: Running, wallet: TestWallet) {
  const ch = await app.api('POST', '/api/console/wallet/challenge', {});
  const res = await app.api('POST', '/api/console/wallet/verify', { signature: wallet.sign(ch.json.message) });
  assert.equal(res.status, 200, JSON.stringify(res.json));
}

/** A request with headers a browser would never let a page set, such as Host. */
function rawPost(base: string, pathName: string, headers: Record<string, string>): Promise<{ status: number; body: string }> {
  const u = new URL(base);
  return new Promise((resolve, reject) => {
    const req = http.request({ host: u.hostname, port: u.port, path: pathName, method: 'POST', headers: { 'Content-Length': '0', ...headers } }, res => {
      const chunks: Buffer[] = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode ?? 0, body: Buffer.concat(chunks).toString('utf8') }));
    });
    req.on('error', reject);
    req.end();
  });
}

async function webhook(app: Running, payload: string, header: string) {
  const res = await fetch(app.url + '/api/webhooks/stripe', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Stripe-Signature': header }, body: payload });
  return res.status;
}

// ── the browser-facing surface in production ────────────────────────────────
test('production responses carry strict headers and the session cookie is locked to this host over HTTPS', async () => {
  const app = await start({ NODE_ENV: 'production' });
  try {
    const res = await app.api('GET', '/api/health', undefined, { cookie: null });
    const h = res.headers;
    const csp = h.get('content-security-policy') ?? '';
    for (const rule of ["default-src 'self'", "script-src 'self'", "connect-src 'self'", "object-src 'none'", "base-uri 'self'", "form-action 'self'", "frame-ancestors 'none'", "font-src 'self'"]) {
      assert.ok(csp.includes(rule), `CSP must include: ${rule}`);
    }
    assert.ok(!/script-src[^;]*unsafe-inline/.test(csp), 'no inline scripts, ever');
    assert.ok(!/script-src[^;]*unsafe-eval/.test(csp));
    assert.ok(!/https?:\/\//.test(csp), 'no third-party origin is allowed to serve code, styles, fonts or receive data');
    assert.match(h.get('strict-transport-security') ?? '', /max-age=31536000/);
    assert.equal(h.get('x-content-type-options'), 'nosniff');
    assert.equal(h.get('referrer-policy'), 'no-referrer', 'pay links carry a secret token and must not leak through Referer');
    assert.equal(h.get('x-frame-options'), 'DENY');
    assert.equal(h.get('x-powered-by'), null);
    assert.equal(h.get('cache-control'), 'no-store');
    assert.equal(h.get('access-control-allow-origin'), null, 'no CORS: other sites cannot read or drive this API');

    const login = await app.api('POST', '/api/auth/login', { password: PASSWORD }, { cookie: null });
    assert.equal(login.status, 200);
    const cookies = login.headers.getSetCookie();
    const session = cookies.find(c => c.startsWith('__Host-flash_session='));
    assert.ok(session, 'production cookie uses the __Host- prefix');
    for (const attr of ['Secure', 'HttpOnly', 'SameSite=Strict', 'Path=/']) assert.ok(session.includes(attr), `session cookie needs ${attr}`);
    assert.ok(!/Domain=/i.test(session), '__Host- cookies must not set Domain');
    const device = cookies.find(c => c.startsWith('__Host-flash_device='));
    assert.ok(device && device.includes('Secure') && device.includes('HttpOnly') && device.includes('SameSite=Strict'));

    // A preflight from another site gets no permission to proceed.
    const pre = await fetch(app.url + '/api/console/invoices', { method: 'OPTIONS', headers: { Origin: 'https://evil.example', 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'x-flash,content-type' } });
    assert.equal(pre.headers.get('access-control-allow-origin'), null);
    assert.equal(pre.headers.get('access-control-allow-headers'), null);
  } finally {
    await app.close();
  }
});

test('oversized, malformed and hostile request bodies are refused cleanly', async () => {
  const app = await start();
  try {
    await app.login();
    const big = JSON.stringify({ clientName: 'x'.repeat(300_000), items: [{ desc: 'a', qty: 1, unitDollars: 1 }] });
    assert.equal((await app.api('POST', '/api/console/invoices', undefined, { raw: big, headers: { 'Content-Type': 'application/json' } })).status, 413);
    const bigPublic = JSON.stringify({ name: 'A', email: 'a@b.example', message: 'm'.repeat(30_000) });
    assert.equal((await app.api('POST', '/api/public/intake', undefined, { raw: bigPublic, headers: { 'Content-Type': 'application/json' }, cookie: null })).status, 413);

    const broken = await app.api('POST', '/api/console/invoices', undefined, { raw: '{"clientName": "A", ', headers: { 'Content-Type': 'application/json' } });
    assert.equal(broken.status, 400);
    assert.equal(broken.json.code, 'BAD_JSON');
    assert.ok(!/at .*\.ts|node_modules|SyntaxError/.test(JSON.stringify(broken.json)), 'no stack traces or internals in error bodies');

    assert.equal((await app.api('POST', '/api/console/invoices', undefined, { raw: 'clientName=A', headers: { 'Content-Type': 'application/x-www-form-urlencoded' } })).status, 415);
    assert.equal((await app.api('POST', '/api/console/invoices', undefined, { raw: '[1,2,3]', headers: { 'Content-Type': 'application/json' } })).status, 400);
    assert.equal((await app.api('POST', '/api/console/invoices', undefined, { raw: '"just a string"', headers: { 'Content-Type': 'application/json' } })).status, 400);

    // Prototype pollution attempts change nothing about how the server behaves.
    const polluted = await app.api('POST', '/api/console/leads', undefined, {
      raw: '{"name":"Pat","email":"pat@example.com","__proto__":{"stage":"won","admin":true},"constructor":{"prototype":{"admin":true}}}',
      headers: { 'Content-Type': 'application/json' },
    });
    assert.equal(polluted.status, 201);
    assert.equal(polluted.json.lead.stage, 'new');
    assert.equal(({} as any).admin, undefined);

    // Numbers that are not sane money never become invoices.
    for (const unitDollars of ['1e400', 'NaN', '-5', '99999999999', 'Infinity', '12abc']) {
      const r = await app.api('POST', '/api/console/invoices', { clientName: 'A', items: [{ desc: 'thing', qty: 1, unitDollars }] });
      assert.equal(r.status, 400, `unit price ${unitDollars} must be refused`);
    }
    for (const qty of [0, -1, 1.5, 1e9, '2']) {
      const r = await app.api('POST', '/api/console/invoices', { clientName: 'A', items: [{ desc: 'thing', qty, unitDollars: '10' }] });
      assert.equal(r.status, 400, `quantity ${qty} must be refused`);
    }

    // Path tricks do not reach other records or the filesystem.
    for (const bad of ['..%2F..%2Fetc%2Fpasswd', "1'%20OR%20'1'='1", '%00', 'a'.repeat(200)]) {
      const r = await app.api('GET', `/api/public/invoice/${bad}`, undefined, { cookie: null });
      assert.ok([400, 404].includes(r.status), `token ${bad.slice(0, 20)} → ${r.status}`);
    }
    // A broken cookie is simply "not signed in", not a server error.
    const junk = await app.api('GET', '/api/console/overview', undefined, { cookie: 'flash_session=%E0%A4%A' });
    assert.equal(junk.status, 401);
  } finally {
    await app.close();
  }
});

test('a forged Host header cannot change where a customer is sent after paying', async () => {
  const forged = { Host: 'evil.example', 'X-Forwarded-Host': 'evil.example', 'X-Forwarded-Proto': 'http' };

  const app = await start({ NODE_ENV: 'production', PUBLIC_BASE_URL: 'https://pay.yabbai.example' }, { stripe: true });
  try {
    await app.login();
    const inv = await issueInvoice(app, 100);
    const res = await rawPost(app.url, `/api/public/invoice/${inv.token}/checkout`, forged);
    assert.equal(res.status, 200, res.body);
    const create = app.stub!.requests.find(r => r.method === 'POST' && r.path === '/v1/checkout/sessions')!;
    assert.equal(create.body.success_url, `https://pay.yabbai.example/pay/${inv.token}?session_id={CHECKOUT_SESSION_ID}`);
    assert.equal(create.body.cancel_url, `https://pay.yabbai.example/pay/${inv.token}`);
    assert.ok(!JSON.stringify(create.body).includes('evil.example'));
  } finally {
    await app.close();
  }

  // With no address configured, the app does not guess one from the request: card checkout stays off.
  const bare = await start({ NODE_ENV: 'production' }, { stripe: true });
  try {
    await bare.login();
    const inv = await issueInvoice(bare, 100);
    const view = (await bare.api('GET', `/api/public/invoice/${inv.token}`, undefined, { cookie: null })).json;
    assert.equal(view.rails.card, false);
    const res = await rawPost(bare.url, `/api/public/invoice/${inv.token}/checkout`, forged);
    assert.equal(res.status, 503);
    assert.ok(!bare.stub!.requests.some(r => r.path === '/v1/checkout/sessions'), 'no Stripe session is created');
    const url = (await bare.api('GET', '/api/console/health')).json.checks.find((c: any) => c.id === 'url');
    assert.equal(url.state, 'error');
    assert.match(url.fix, /PUBLIC_BASE_URL/);
  } finally {
    await bare.close();
  }
});

test('rate limits follow the visitor address the host vouches for — and ignore that header unless told to trust it', async () => {
  const send = (app: Running, ip: string, n: number) =>
    app.api('POST', '/api/public/intake', { name: `Visitor ${n}`, email: `v${n}@example.com`, message: 'hello' }, { cookie: null, headers: { 'CF-Connecting-IP': ip } });

  // Not configured: a caller who invents the header gains nothing.
  const plain = await start();
  try {
    for (let i = 0; i < 8; i++) assert.equal((await send(plain, `203.0.113.${i}`, i)).status, 200);
    assert.equal((await send(plain, '198.51.100.99', 99)).status, 429, 'a made-up address does not reset the limit');
  } finally {
    await plain.close();
  }

  // Configured (the host's edge always overwrites it): each real visitor gets their own allowance.
  const edge = await start({ CLIENT_IP_HEADER: 'cf-connecting-ip' });
  try {
    for (let i = 0; i < 8; i++) assert.equal((await send(edge, '203.0.113.7', i)).status, 200);
    assert.equal((await send(edge, '203.0.113.7', 9)).status, 429);
    assert.equal((await send(edge, '203.0.113.8', 10)).status, 200, 'a different visitor is not punished for it');
    assert.equal((await send(edge, 'not-an-ip"; DROP', 11)).status, 200, 'junk in the header falls back to the socket address');
  } finally {
    await edge.close();
  }
});

// ── history cannot be rewritten quietly ─────────────────────────────────────
test('the audit log refuses edits, and a forced edit or deletion is detected and raised', async () => {
  const app = await start();
  try {
    await app.login();
    const inv = await issueInvoice(app, 100);
    await app.api('POST', `/api/console/invoices/${inv.id}/attest`, { amountDollars: '100', reference: 'bank ref 0001' });
    const q = app.built.db.query;

    let v = (await app.api('GET', '/api/console/audit/verify')).json;
    assert.equal(v.ok, true);
    assert.ok(v.entries >= 4);

    await assert.rejects(() => q(`UPDATE audit_log SET actor = 'nobody' WHERE seq = 2`), /append-only|cannot/i);
    await assert.rejects(() => q(`DELETE FROM audit_log WHERE seq = 2`), /append-only|cannot/i);
    // TRUNCATE skips row-level triggers, so it has a guard of its own — on the ledger too.
    await assert.rejects(() => q(`TRUNCATE audit_log`), /append-only/i);
    await assert.rejects(() => q(`TRUNCATE payments CASCADE`), /append-only/i);

    // Someone with full database access switches the guard off and rewrites one entry.
    await q('ALTER TABLE audit_log DISABLE TRIGGER audit_guard');
    await q(`UPDATE audit_log SET detail = '{"invoice":"INV-0001","amountCents":1,"reference":"bank ref 0001"}'::jsonb WHERE action = 'payment.attested'`);
    await q('ALTER TABLE audit_log ENABLE TRIGGER audit_guard');

    v = (await app.api('GET', '/api/console/audit/verify')).json;
    assert.equal(v.ok, false, 'the rewritten entry no longer matches its fingerprint');
    assert.ok(Number.isInteger(v.brokenAtSeq));

    const health = (await app.api('GET', '/api/console/health')).json.checks.find((c: any) => c.id === 'audit');
    assert.equal(health.state, 'error');
    await app.api('POST', '/api/console/autopilot/run', { id: 'auditor' });
    const attention = (await app.api('GET', '/api/console/overview')).json.attention;
    assert.ok(attention.some((a: any) => a.level === 'error' && /audit log/i.test(a.text)), 'the Overview raises it without being asked');
  } finally {
    await app.close();
  }

  // Removing an entry from the middle is caught the same way.
  const app2 = await start();
  try {
    await app2.login();
    await issueInvoice(app2, 50);
    const q = app2.built.db.query;
    await q('ALTER TABLE audit_log DISABLE TRIGGER audit_guard');
    await q('DELETE FROM audit_log WHERE seq = 2');
    await q('ALTER TABLE audit_log ENABLE TRIGGER audit_guard');
    const v = (await app2.api('GET', '/api/console/audit/verify')).json;
    assert.equal(v.ok, false);
    assert.equal(v.brokenAtSeq, 3);
  } finally {
    await app2.close();
  }

  // So is cutting entries off the end, or wiping the log completely — which a hash chain alone cannot see.
  for (const wipe of ['DELETE FROM audit_log WHERE seq > 2', 'DELETE FROM audit_log']) {
    const app3 = await start();
    try {
      await app3.login();
      await issueInvoice(app3, 50);
      const q = app3.built.db.query;
      const before = (await app3.api('GET', '/api/console/audit/verify')).json;
      assert.equal(before.ok, true);
      await q('ALTER TABLE audit_log DISABLE TRIGGER audit_guard');
      await q(wipe);
      await q('ALTER TABLE audit_log ENABLE TRIGGER audit_guard');
      const v = (await app3.api('GET', '/api/console/audit/verify')).json;
      assert.equal(v.ok, false, `"${wipe}" must be detected`);
      assert.ok(v.entries < before.entries);
    } finally {
      await app3.close();
    }
  }
});

// ── the owner cannot be locked out by strangers ─────────────────────────────
test('strangers failing at the login form cannot lock out a browser that has signed in before', async () => {
  const app = await start();
  try {
    const first = await app.api('POST', '/api/auth/login', { password: PASSWORD }, { cookie: null });
    assert.equal(first.status, 200);
    const device = first.headers.getSetCookie().find(c => c.startsWith('flash_device='))!.split(';')[0];
    assert.match(device, /^flash_device=[A-Za-z0-9_-]{40,}$/);
    // Only a hash of it is stored.
    const stored = await kvGet<Array<{ hash: string }>>(app.built.db.query, 'auth_devices');
    assert.equal(stored!.length, 1);
    assert.ok(!JSON.stringify(stored).includes(device.split('=')[1]));

    for (let i = 0; i < 8; i++) {
      assert.equal((await app.api('POST', '/api/auth/login', { password: `stranger guess ${i} xxxxxxxx` }, { cookie: null })).status, 401);
    }
    // Everyone else is now shut out, right password or not…
    assert.equal((await app.api('POST', '/api/auth/login', { password: PASSWORD }, { cookie: null })).status, 429);
    // …and a made-up device cookie earns nothing.
    assert.equal((await app.api('POST', '/api/auth/login', { password: PASSWORD }, { cookie: 'flash_device=' + 'A'.repeat(43) })).status, 429);
    // The owner's own browser still gets in. It still needs the real password.
    assert.equal((await app.api('POST', '/api/auth/login', { password: 'not the password at all' }, { cookie: device })).status, 401);
    const mine = await app.api('POST', '/api/auth/login', { password: PASSWORD }, { cookie: device });
    assert.equal(mine.status, 200);
    assert.ok(!mine.headers.getSetCookie().some(c => c.startsWith('flash_device=')), 'a known browser keeps its existing device cookie');

    // The remembered browser has its own ceiling, so a stolen device cookie is not a licence to guess forever.
    let limited = false;
    for (let i = 0; i < 12 && !limited; i++) {
      limited = (await app.api('POST', '/api/auth/login', { password: `guess with stolen cookie ${i}` }, { cookie: device })).status === 429;
    }
    assert.ok(limited);

    // "Sign out on every device" forgets remembered browsers as well.
    app.cookie = mine.headers.getSetCookie().find(c => c.startsWith('flash_session='))!.split(';')[0];
    const out = await app.api('POST', '/api/auth/logout-all', {});
    assert.equal(out.status, 200);
    assert.ok(out.headers.getSetCookie().some(c => c.startsWith('flash_device=;') && c.includes('Max-Age=0')));
    assert.deepEqual(await kvGet(app.built.db.query, 'auth_devices'), []);
  } finally {
    await app.close();
  }
});

test('a lock belongs to the password it was earned against: rotating the password clears it', async () => {
  const app = await start();
  try {
    const tag = sha256hex(`throttle:${await passwordHash()}`).slice(0, 16);
    const future = Date.now() + 3600_000;
    await kvSet(app.built.db.query, 'auth_throttle', { failures: 30, lockedUntil: future, tag });
    assert.equal((await app.api('POST', '/api/auth/login', { password: PASSWORD }, { cookie: null })).status, 429, 'locked under the current password');

    await kvSet(app.built.db.query, 'auth_throttle', { failures: 30, lockedUntil: future, tag: 'tag-of-an-older-password' });
    assert.equal((await app.api('POST', '/api/auth/login', { password: PASSWORD }, { cookie: null })).status, 200, 'a lock from before the password change no longer applies');
  } finally {
    await app.close();
  }
});

// ── money edge cases ────────────────────────────────────────────────────────
test('a crypto payment that arrives after the quote expired is credited at today\'s price, never above the quote', async () => {
  const pay = async (audPerSolNow: number) => {
    const wallet = newWallet();
    const net = fakeNet();
    net.fx = { coingecko: { sol: audPerSolNow, usdc: 1.52 }, coinbase: { sol: audPerSolNow, usdc: 1.52 } };
    const app = await start({ SOLANA_RECEIVE_ADDRESS: wallet.address }, { net });
    try {
      await app.login();
      await prove(app, wallet);
      const now = Date.now();
      const quoteRow = async (invoiceId: string, expiresAt: number) => {
        const reference = randomAddress();
        // Quoted when SOL was $110: 2 SOL for $220.00.
        await app.built.db.query(
          `INSERT INTO sol_quotes (reference, kind, ref_id, asset, amount_base, aud_cents, aud_per_unit, recipient, status, livemode, created_at, expires_at)
           VALUES ($1,'invoice',$2,'SOL','2000000000',22000,110,$3,'open',TRUE,$4,$5)`,
          [reference, invoiceId, wallet.address, now - 20 * 60_000, expiresAt]
        );
        return reference;
      };
      const send = (reference: string) => {
        const sig = newSignature();
        net.signatures.set(reference, [sigInfo(sig)]);
        net.transactions.set(sig, solTransferTx({ recipient: wallet.address, reference, lamports: 2_000_000_000 }));
      };

      const late = await issueInvoice(app, 220);
      send(await quoteRow(late.id, now - 5 * 60_000)); // expired five minutes before the coins arrived
      const onTime = await issueInvoice(app, 220);
      send(await quoteRow(onTime.id, now + 5 * 60_000)); // still inside its window

      await app.api('GET', `/api/public/invoice/${late.token}/status`, undefined, { cookie: null });
      await app.api('GET', `/api/public/invoice/${onTime.token}/status`, undefined, { cookie: null });
      const a = (await app.api('GET', `/api/console/invoices/${late.id}`)).json;
      const b = (await app.api('GET', `/api/console/invoices/${onTime.id}`)).json;
      return { late: a, onTime: b };
    } finally {
      await app.close();
    }
  };

  // The coin fell 20% while the customer waited.
  const fell = await pay(88);
  assert.equal(fell.late.invoice.paidCents, 17600, '2 SOL is worth $176 now, so that is what is credited');
  assert.equal(fell.late.invoice.status, 'part');
  assert.equal(fell.late.payments[0].detail.late, true);
  assert.equal(fell.late.payments[0].detail.repricedAudPerUnit, 88);
  assert.equal(fell.onTime.invoice.status, 'paid', 'a payment inside the quote window keeps the promised price');
  assert.equal(fell.onTime.invoice.paidCents, 22000);

  // The coin rose instead: the customer is credited what was quoted, not more.
  const rose = await pay(150);
  assert.equal(rose.late.invoice.paidCents, 22000);
  assert.equal(rose.late.invoice.status, 'paid');
  assert.equal(rose.late.payments[0].detail.repricedAudPerUnit, undefined);
});

test('a lost card dispute takes the download away again', async () => {
  const app = await start({}, { stripe: true });
  try {
    await app.login();
    const p = (
      await app.api('POST', '/api/console/products', {
        title: 'Invoice Chaser Kit',
        description: 'Three reminder email templates and a setup guide.',
        priceDollars: 99,
        deliverableKind: 'text',
        deliverableValue: 'LICENCE-KEY-0001',
      })
    ).json.product;
    await app.api('POST', `/api/console/products/${p.id}/status`, { status: 'listed' });
    const buy = await app.api('POST', `/api/public/product/${p.slug}/checkout`, {}, { cookie: null });
    const sid = [...app.stub!.sessions.keys()][0];
    const pi = payStubSession(app.stub!, sid);
    let ev = signedEvent('checkout.session.completed', { id: sid, object: 'checkout.session' });
    assert.equal(await webhook(app, ev.payload, ev.header), 200);
    const view = async () => (await app.api('GET', `/api/public/order/${buy.json.orderToken}`, undefined, { cookie: null })).json;
    assert.equal((await view()).deliverable.value, 'LICENCE-KEY-0001');

    ev = signedEvent('charge.dispute.closed', { id: 'dp_9', object: 'dispute', payment_intent: pi, status: 'lost' });
    assert.equal(await webhook(app, ev.payload, ev.header), 200);
    const after = await view();
    assert.equal(after.status, 'refunded');
    assert.equal(after.deliverable, null);
    assert.equal((await app.api('GET', '/api/console/overview')).json.totals.verifiedAllTimeCents, 0);

    // Even if a status flag were wrong, delivery follows the ledger.
    await app.built.db.query(`UPDATE orders SET status = 'paid'`);
    assert.equal((await view()).deliverable, null);
  } finally {
    await app.close();
  }
});

test('abandoned checkouts are cleaned out after 30 days; anything with money against it is kept', async () => {
  const app = await start({}, { stripe: true });
  try {
    await app.login();
    const p = (
      await app.api('POST', '/api/console/products', { title: 'Template Pack', description: 'Ten templates.', priceDollars: 40, deliverableKind: 'text', deliverableValue: 'the templates' })
    ).json.product;
    await app.api('POST', `/api/console/products/${p.id}/status`, { status: 'listed' });
    const tokens: string[] = [];
    for (let i = 0; i < 3; i++) tokens.push((await app.api('POST', `/api/public/product/${p.slug}/checkout`, {}, { cookie: null })).json.orderToken);
    const q = app.built.db.query;
    const ids = (await q('SELECT id, token FROM orders ORDER BY created_at ASC')).rows;
    assert.equal(ids.length, 3);
    // Order 2 received part of its price on-chain before it lapsed.
    const part = ids.find((r: any) => r.token === tokens[1])!.id;
    await q(
      `INSERT INTO payments (id, proof_id, rail, kind, order_id, amount_cents, verified, livemode, detail, occurred_at, created_at)
       VALUES ('pay_part', 'sol:partial-test', 'solana', 'order', $1, 1500, TRUE, FALSE, '{}'::jsonb, $2, $2)`,
      [part, Date.now()]
    );
    await q('UPDATE orders SET created_at = $1', [Date.now() - 40 * 86_400_000]);
    await q('UPDATE stripe_sessions SET created_at = $1', [Date.now() - 40 * 86_400_000]);

    await app.api('POST', '/api/console/autopilot/run', { id: 'janitor' }); // lapses them
    await app.api('POST', '/api/console/autopilot/run', { id: 'treasurer' }); // marks their dead checkout sessions expired
    await app.api('POST', '/api/console/autopilot/run', { id: 'janitor' }); // removes what is now dead
    const left = (await q('SELECT id, status FROM orders')).rows;
    assert.deepEqual(left.map((r: any) => r.id), [part], 'only the order that received money survives');
    assert.equal((await q(`SELECT COUNT(*)::int AS n FROM stripe_sessions`)).rows[0].n, 0);
    assert.equal((await q(`SELECT COUNT(*)::int AS n FROM payments`)).rows[0].n, 1, 'payments are never cleaned up');
    // A gone order's link simply stops working.
    assert.equal((await app.api('GET', `/api/public/order/${tokens[0]}`, undefined, { cookie: null })).status, 404);
  } finally {
    await app.close();
  }
});

test('a borrowed session cannot change what is on sale: listing and editing a live product need the password again', async () => {
  const app = await start();
  try {
    await app.login();
    const body = { title: 'Template Pack', description: 'Ten templates.', priceDollars: 40, deliverableKind: 'link', deliverableValue: 'https://files.example.com/real.zip' };
    const p = (await app.api('POST', '/api/console/products', body)).json.product;
    const expire = () => app.built.db.query('UPDATE sessions SET stepup_until = 0');

    await expire();
    const list = await app.api('POST', `/api/console/products/${p.id}/status`, { status: 'listed' });
    assert.equal(list.status, 403);
    assert.equal(list.json.code, 'STEP_UP_REQUIRED');
    // Drafts can still be edited freely.
    assert.equal((await app.api('PUT', `/api/console/products/${p.id}`, { ...body, priceDollars: 45 })).status, 200);

    assert.equal((await app.api('POST', '/api/auth/stepup', { password: PASSWORD })).status, 200);
    assert.equal((await app.api('POST', `/api/console/products/${p.id}/status`, { status: 'listed' })).status, 200);

    await expire();
    const swap = await app.api('PUT', `/api/console/products/${p.id}`, { ...body, deliverableValue: 'https://evil.example/malware.zip', priceDollars: 1 });
    assert.equal(swap.status, 403, 'the download buyers receive cannot be swapped without the password');
    const now = (await app.api('GET', '/api/console/products')).json.products[0];
    assert.equal(now.deliverableValue, 'https://files.example.com/real.zip');
    assert.equal(now.priceCents, 4500);
    // Taking something OFF sale is always allowed.
    assert.equal((await app.api('POST', `/api/console/products/${p.id}/status`, { status: 'draft' })).status, 200);
  } finally {
    await app.close();
  }
});

test('a restricted key that cannot read the account is reported as "unknown", not as a disabled account', async () => {
  const app = await start({}, { stripe: true });
  try {
    app.stub!.accountForbidden = true;
    await app.login();
    const payouts = (await app.api('GET', '/api/console/payouts?refresh=1')).json.stripe;
    assert.equal(payouts.reachable, true);
    assert.equal(payouts.chargesEnabled, null);
    assert.match(payouts.error, /permissions/);
    const check = (await app.api('GET', '/api/console/health')).json.checks.find((c: any) => c.id === 'stripe_account');
    assert.equal(check.state, 'warn');
    const o = (await app.api('GET', '/api/console/overview')).json;
    assert.equal(o.rails.stripe.enabled, true, 'checkout is not switched off on a guess');
    assert.ok(!o.attention.some((a: any) => /not activated/.test(a.text)));
    assert.ok(o.attention.some((a: any) => a.level === 'warn' && /cannot read/.test(a.text)));
  } finally {
    await app.close();
  }
});

// ── the code itself ─────────────────────────────────────────────────────────
function sourceFiles(dirs: string[]): string[] {
  const out: string[] = [];
  const walk = (p: string) => {
    const st = fs.statSync(p);
    if (st.isDirectory()) {
      for (const name of fs.readdirSync(p)) if (name !== 'node_modules' && name !== 'dist' && !name.startsWith('.')) walk(path.join(p, name));
    } else if (/\.(ts|tsx|css|html)$/.test(p)) out.push(p);
  };
  for (const d of dirs) if (fs.existsSync(path.join(ROOT, d))) walk(path.join(ROOT, d));
  return out;
}

test('guard: no simulated money, browser storage, embedded secrets or hardcoded destinations in the source', () => {
  const shipped = sourceFiles(['server', 'src', 'shared', 'scripts', 'server.ts', 'index.html']);
  assert.ok(shipped.length > 40, 'the scan must actually cover the code');

  const banned: Array<[RegExp, string, RegExp?]> = [
    [/Math\.random\s*\(/, 'Math.random — outcomes and identifiers must never be made up'],
    [/\b(localStorage|sessionStorage|indexedDB)\b/, 'browser storage — state lives on the server', /src\/lib\/api\.ts$/],
    [/dangerouslySetInnerHTML|\.innerHTML\s*=|document\.write\s*\(/, 'raw HTML injection'],
    [/\beval\s*\(|new Function\s*\(/, 'dynamic code execution'],
    [/\b(sk|rk)_(live|test)_[A-Za-z0-9]{16,}/, 'an embedded Stripe key'],
    [/\bwhsec_[A-Za-z0-9]{16,}/, 'an embedded webhook secret'],
    [/AIza[0-9A-Za-z_-]{30,}/, 'an embedded Google API key'],
    [/-----BEGIN [A-Z ]*PRIVATE KEY-----/, 'an embedded private key'],
    [/\b(secretKey|privateKey|Keypair\.fromSecretKey|signTransaction|sendTransaction|sendRawTransaction)\b/, 'wallet-signing code — this app must never be able to spend', /server\/config\.ts$|server\/stripe\.ts$/],
    [/yabbai-director-88/i, 'the old factory key', /server\/config\.ts$/],
    [/@google\/genai|generativelanguage[^'"`]*key=/, 'an AI key travelling in a URL or a browser SDK'],
  ];
  // Any 43–44 character base58 string is a Solana address. Only public program and mint ids may be written in code.
  const allowedAddresses = new Set(['EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', '4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU']);
  const problems: string[] = [];
  for (const file of shipped) {
    const rel = path.relative(ROOT, file);
    const text = fs.readFileSync(file, 'utf8');
    for (const [re, what, except] of banned) {
      if (except && except.test(rel)) continue;
      if (re.test(text)) problems.push(`${rel}: ${what}`);
    }
    for (const m of text.matchAll(/(?<![1-9A-HJ-NP-Za-km-z])[1-9A-HJ-NP-Za-km-z]{43,44}(?![1-9A-HJ-NP-Za-km-z])/g)) {
      if (!allowedAddresses.has(m[0]) && /[0-9]/.test(m[0]) && /[a-z]/.test(m[0]) && /[A-Z]/.test(m[0])) problems.push(`${rel}: a hardcoded address or token (${m[0].slice(0, 6)}…)`);
    }
  }
  // The frontend must not read build-time secrets or talk to anyone but its own server.
  for (const file of sourceFiles(['src'])) {
    const rel = path.relative(ROOT, file);
    const text = fs.readFileSync(file, 'utf8');
    if (/import\.meta\.env|process\.env/.test(text)) problems.push(`${rel}: reads environment variables in the browser`);
    for (const m of text.matchAll(/fetch\(\s*['"`](https?:)?\/\//g)) problems.push(`${rel}: the browser calls a third party directly (${m[0]})`);
  }
  assert.deepEqual(problems, []);
});

test('guard: the only Stripe calls in the app create or read — nothing can pay out, refund or transfer', () => {
  const text = fs.readFileSync(path.join(ROOT, 'server/stripe.ts'), 'utf8');
  const calls = new Set([...text.matchAll(/stripe\(\)\.([A-Za-z.]+)\(/g)].map(m => m[1]));
  assert.deepEqual([...calls].sort(), ['accounts.retrieveCurrent', 'balance.retrieve', 'checkout.sessions.create', 'checkout.sessions.retrieve', 'payouts.list', 'webhooks.constructEvent']);
  // And no other file talks to Stripe at all.
  for (const file of sourceFiles(['server', 'server.ts', 'scripts'])) {
    if (file.endsWith('stripe.ts')) continue;
    assert.ok(!/from 'stripe'|require\('stripe'\)|api\.stripe\.com/.test(fs.readFileSync(file, 'utf8')), `${path.relative(ROOT, file)} must not call Stripe directly`);
  }
  // No route exists whose job is to move money out or to credit an amount by hand.
  const routes = ['server/consoleRoutes.ts', 'server/publicRoutes.ts', 'server/coreRoutes.ts'].map(f => fs.readFileSync(path.join(ROOT, f), 'utf8')).join('\n');
  const paths = [...routes.matchAll(/router\.(get|post|put|patch|delete)\(\s*'([^']+)'/g)].map(m => `${m[1].toUpperCase()} ${m[2]}`);
  assert.ok(paths.length > 55, 'the scan must cover the council and network routes too');
  for (const p of paths) assert.ok(!/withdraw|payout\b|transfer|sweep|refund|credit|fund|deposit|mark-?paid|balance/i.test(p.replace('GET /payouts', '')), `unexpected money-moving route: ${p}`);
});

test('guard: the council has no hands — it can read the records and write only its own notebook', () => {
  const read = (f: string) => fs.readFileSync(path.join(ROOT, f), 'utf8');
  // Every function in the app that creates or changes a payment, invoice, product, order, lead or draft.
  const writers =
    /\b(recordPayment|applyVerifiedPayment|attestPayment|settleSession|checkQuote|createInvoice|updateDraftInvoice|openInvoice|voidInvoice|createProduct|updateProduct|setProductStatus|createOrder|addDraft|decideDraft|createLead|updateLead|deleteLead|setLeadScore|handleWebhook|createChallenge|verifyChallenge|createOnchainProof|reconcile)\b/;
  const mayWrite: Record<string, string[]> = {
    'server/council.ts': ['council_sessions', 'council_opinions'],
    'server/lessons.ts': ['lessons'],
    'server/seats.ts': [],
    'server/network.ts': ['network_links'],
    'server/coreRoutes.ts': [],
  };
  for (const [file, tables] of Object.entries(mayWrite)) {
    const text = read(file);
    assert.ok(!writers.test(text), `${file} must not call anything that changes a business record`);
    assert.ok(!/from '\.\/(stripe|solana|ledger|fx)\.ts'/.test(text), `${file} must not import a payment module`);
    const written = [...text.matchAll(/\b(?:INSERT INTO|UPDATE|DELETE FROM)\s+([a-z_]+)/g)].map(m => m[1]);
    assert.deepEqual([...new Set(written)].sort(), [...tables].sort(), `${file} writes to tables it has no business with`);
  }
  // Seats are handed their records through one typed doorway, built in server.ts, and nothing else.
  assert.ok(!/ctx\.|Ctx\b/.test(read('server/seats.ts')) && !/ctx\.|Ctx\b/.test(read('server/council.ts')), 'the council never holds the whole app context');
  // The model's reply is stored and nothing else is done with it: no reply is parsed for a command to run.
  assert.ok(!/JSON\.parse/.test(read('server/council.ts')), 'a verdict is text, never a structured instruction');
});
