# Security

What this app protects, how, and what it cannot protect.

## Can someone fake money, a sale or a job?

| Attempt | What stops it |
| --- | --- |
| Call an API to add a balance | No such API exists. The three ways a payment is recorded all require outside proof or the director's password |
| Send a fake Stripe webhook | The signature is checked; then the server asks Stripe itself. A signed event is only a prompt to go and look |
| Reuse someone else's paid Stripe session | Only sessions this server created are considered, and amount, currency, mode and reference must all match |
| Replay a real webhook or transaction | Each proof ID can be recorded once (unique in the database) |
| Pay less in crypto and claim the full amount | The amount is read from the chain; only what arrived is credited |
| Wait for a coin to drop, then pay an old quote | After the quote expires the payment is credited at the current price, never above the quote |
| Change the price in the browser | Prices are never read from the request |
| Mark an invoice paid | "Paid" is not stored anywhere; it is worked out from payments |
| Buy a product without paying | The deliverable is returned only when verified payments cover the price |
| Flood the enquiry form | Per-visitor and global limits, a honeypot field, and nothing is sent in response |
| Edit history | Payments and the audit log refuse UPDATE, DELETE and TRUNCATE; the audit log is hash-chained and its head is also written to the host's log stream |

## Can someone steer the council, or the links?

| Attempt | What stops it |
| --- | --- |
| Get the AI to mark something paid, send a message or move money | It has no tools. A council session can write three kinds of row — its own session, its seats' opinions, and a *suggested* lesson — and a test fails if its code ever imports anything that changes a business record |
| Type instructions into the enquiry form so a seat obeys them | No seat is handed a name, email, phone number or message. The one outsider-written field a seat does see (a lead's sector) arrives inside a data fence the text cannot close |
| Have one seat's answer tell the next seat what to do | Opinions reach the Skeptic and the verdict as fenced data, never as instructions |
| Teach the council something permanently | The model can only *suggest* a lesson. Making one active needs the password again, the database refuses a model-written lesson that has no recorded decision, and there are at most twelve |
| Spend the AI budget | Sessions are behind sign-in, limited per minute, one at a time, counted against the daily cap, and never run on a schedule |
| Repoint a link to a look-alike site from a borrowed session | Adding or changing a link needs the password again. Removing one does not |
| Add a link that runs a script | Only `http(s)` addresses are stored (checked in code and by a database constraint), https everywhere except this machine, and never with a username or password inside |
| Aim the sentinel at a private machine | It only knocks on public https names — never an IP address, `localhost` or a private suffix — with a `HEAD` request, follows no redirect, and keeps only the status code |
| Make a linked dashboard's number look like income | Nothing a linked page shows is read. The only money figures in the console come from the payments table |

## Can someone take the money?

There is nothing here to take. The app has no payout or transfer code, holds no
wallet key and uses (when you follow the README) a Stripe key that cannot create
payouts or refunds. Card money sits with Stripe until Stripe pays your bank.
Crypto goes from the customer's wallet to yours without passing through the app.

**Redirecting** money is the real risk, so the destinations are pinned:

- The Solana address and bank details are environment variables. No console
  action or API can change them.
- The address must be proven (a signature or a transaction only its owner can
  make) before any customer sees it. A proof does not carry over to a different address.
- Your payout bank account is set in Stripe, behind Stripe's own login.
- Return addresses for card checkout come from configuration, never from the
  request, so a forged `Host` header cannot send customers elsewhere.

## Can someone get into the console?

- No default or factory password. With none set, sign-in is impossible.
- The password is stored as a scrypt hash; a second factor (TOTP) is supported
  and codes cannot be replayed.
- Sessions are random tokens, stored hashed, in an `HttpOnly`, `Secure`,
  `SameSite=Strict`, `__Host-` cookie. They expire after 12 hours or 2 idle hours.
- Wrong guesses are limited per visitor and lock sign-in globally. A browser
  that has signed in before is exempt from that lock (so strangers cannot lock
  you out) but has its own limit.
- Recording a bank payment, proving the wallet, putting a product on sale and
  editing a product that is on sale all require the password again.
- Cross-site requests are refused (custom header, origin check, no CORS).
- A strict Content-Security-Policy: only this origin may serve code, styles or
  fonts, or receive data. No inline scripts.

Someone holding a stolen session, but not your password, could read invoices,
leads and product details, create or void invoices and edit drafts, spend some
of the day's AI calls on council sessions, record a ruling on a verdict, and
remove links or lessons. They
could not record a payment of any kind, change what is on sale, move money,
change where it goes, add or repoint a link, make a lesson active, or read any key. Someone holding the password (and the second
factor) could also record *attested* payments — always labelled as such and
never counted as verified income.

## What this cannot protect

- **Your hosting account.** Whoever controls the environment variables controls
  the wallet address and the keys. Use a strong password and 2FA on Render and
  GitHub.
- **Your wallet.** The app never sees its key. If the wallet itself is drained
  through a malicious site or a leaked seed phrase, nothing here can help.
  Consider receiving into a wallet you do not also use for trading and dApps.
- **Your database, against its own administrator.** Someone with full database
  access could drop the guards and rebuild the audit chain. Compare the chain
  head on the Ops page with the `[audit] … head …` lines in your host's logs.
- **The RPC provider.** On-chain payments are read through `SOLANA_RPC_URL`.
  Use a reputable provider.
- **Bank transfers.** The app cannot see your bank. An attested payment is your word.
- **What the AI provider is told.** A council session sends your question, your
  lessons and rulings, and summaries of your records (totals, counts, invoice
  numbers, product titles, linked app names) to the provider you configured.
  Choose one you trust with that, or run a local model.
- **The AI's judgment.** Several seats agreeing is not proof. The seats are kept
  apart and checked against the records, but a verdict is advice, and it can be
  wrong. Nothing it says is carried out unless you do it.
- **A public name that points somewhere private.** The sentinel refuses private
  addresses by name, but it does not resolve names itself. A public domain
  deliberately pointed at a private address would receive one `HEAD` request.
  Nothing is read back except a status code. Only watch domains you know.
- **The build team's machine.** `rig/` runs coding agents on your computer with
  your user's access. Read `rig/README.md` before starting it, and keep keys,
  wallets and `.env` files out of the copy it works in.

## If something looks wrong

1. Ops → **Sign out on every device**.
2. Run `npm run setup`, replace `DIRECTOR_PASSWORD_HASH` and `TOTP_SECRET`, restart.
3. Roll the Stripe key and webhook secret in the Stripe Dashboard and update them.
4. Ops → Audit log → **Verify the chain**, and read the recent entries.
5. Check Payouts: the wallet address, group by group, against your wallet app.

## Secrets from the old build

The original backup this app was rebuilt from mentions a wallet keypair file
(`db/vault-keypair.json`) and a `.env.local` holding live Stripe and RPC secrets.
Treat every one of those as exposed: move anything of value out of that wallet,
and roll those keys. None of them is used or needed by this version.
