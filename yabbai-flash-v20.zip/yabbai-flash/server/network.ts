/**
 * The network: every other app, site and document the business runs on, kept
 * as a list of links grouped into realms.
 *
 * The old hub pages drew a live-looking figure beside each project. Every one
 * of those figures was written by the page that showed it. So a link here
 * carries no figure at all: it has a name, an address, the realm it belongs to
 * and — only if you ask — whether its server answered the last time we knocked.
 *
 * Three rules shape this file:
 *  - Adding or changing a link needs the password again (enforced in the
 *    routes). A link is something you click from a console you trust, so a
 *    borrowed session must not be able to point one somewhere else.
 *  - The sentinel sends one HEAD request and keeps the status code. It never
 *    reads a page, follows a redirect or sends a cookie, and it only knocks on
 *    public https names — never an IP address or a machine on a private network.
 *  - Nothing a linked page shows is read, counted or displayed here as money.
 */
import type { Db, Query } from './db.ts';
import { kvGet, kvSet } from './db.ts';
import { auditTx } from './audit.ts';
import { HttpError, bad, errMessage, fetchWithTimeout, newId, notFound } from './util.ts';
import type { Obj } from './validate.ts';
import { httpUrl, optBool, optStr, reqEnum, reqStr } from './validate.ts';
import type { LinkKind, LinkState, NetworkLink } from '../shared/types.ts';

export const LINK_KINDS: readonly LinkKind[] = ['app', 'site', 'dashboard', 'artifact', 'doc', 'repo', 'tool'];
export const MAX_LINKS = 200;
export const MAX_IMPORT = 100;
const SWEEP_KEY = 'network_swept_at';

const LOOPBACK = new Set(['localhost', '127.0.0.1', '[::1]']);
const PRIVATE_SUFFIX = /\.(local|localhost|internal|intranet|lan|home|corp|test|invalid|example|home\.arpa)$/;

/** Lower-cased host with any trailing dot removed, or null if the text is not a URL. */
function hostOf(url: string): string | null {
  try {
    return new URL(url).hostname.toLowerCase().replace(/\.$/, '');
  } catch {
    return null;
  }
}

/**
 * Will the sentinel knock on this address? Only https, only a public DNS name.
 * An IP literal, a single-label host or a private suffix is refused, so the
 * check can never be aimed at this server's own network.
 */
export function watchable(url: string): boolean {
  let u: URL;
  try {
    u = new URL(url);
  } catch {
    return false;
  }
  if (u.protocol !== 'https:') return false;
  if (u.username || u.password) return false;
  const host = u.hostname.toLowerCase().replace(/\.$/, '');
  if (!host.includes('.')) return false; // single label: localhost, a docker service name…
  if (host.includes(':') || host.startsWith('[')) return false; // IPv6 literal
  if (/^[0-9.]+$/.test(host)) return false; // IPv4 literal
  if (/^0x[0-9a-f.]+$/.test(host)) return false; // hex-encoded IPv4
  if (PRIVATE_SUFFIX.test(host)) return false;
  return true;
}

function stateOf(r: { watch: boolean; lastStatus: number | null; lastCheckedAt: number | null }): LinkState {
  if (!r.watch) return 'off';
  if (r.lastCheckedAt === null) return 'unknown';
  if (r.lastStatus === null) return 'down';
  // 401, 403 and 405 still prove a server is there: it wants a sign-in, or it refuses HEAD.
  if (r.lastStatus < 400 || [401, 403, 405].includes(r.lastStatus)) return 'up';
  return 'error';
}

function mapLink(r: any): NetworkLink {
  const watch = r.watch === true && watchable(r.url);
  const lastStatus = r.last_status === null || r.last_status === undefined ? null : Number(r.last_status);
  const lastCheckedAt = r.last_checked_at === null || r.last_checked_at === undefined ? null : Number(r.last_checked_at);
  return {
    id: r.id,
    name: r.name,
    url: r.url,
    host: hostOf(r.url) ?? '',
    realm: r.realm,
    kind: r.kind,
    note: r.note ?? null,
    watch,
    watchable: watchable(r.url),
    lastStatus,
    lastError: r.last_error ?? null,
    lastCheckedAt,
    state: stateOf({ watch, lastStatus, lastCheckedAt }),
    createdAt: Number(r.created_at),
    updatedAt: Number(r.updated_at),
  };
}

export interface LinkInput {
  name: string;
  url: string;
  realm: string;
  kind: LinkKind;
  note: string | null;
  watch: boolean;
}

/**
 * Every link passes through here, whether typed into the form or imported.
 * Only web addresses; https everywhere except this machine's own loopback;
 * and never an address with a username or password inside it.
 */
export function parseLinkInput(b: Obj): LinkInput {
  const url = httpUrl(reqStr(b, 'url', 8, 500), 'url');
  const u = new URL(url);
  if (u.username || u.password) throw bad('A link must not contain a username or password.');
  if (u.protocol !== 'https:' && !LOOPBACK.has(u.hostname.toLowerCase())) {
    throw bad('Links must start with https:// (plain http is accepted only for an app on this computer, such as http://127.0.0.1:3000).');
  }
  const watch = optBool(b, 'watch') ?? false;
  if (watch && !watchable(url)) {
    throw bad('This address cannot be watched. The sentinel only knocks on public https names, never an IP address or a private network.');
  }
  return {
    name: reqStr(b, 'name', 1, 80),
    url,
    realm: reqStr(b, 'realm', 1, 40),
    kind: reqEnum(b, 'kind', LINK_KINDS),
    note: optStr(b, 'note', 240),
    watch,
  };
}

export async function listLinks(q: Query): Promise<NetworkLink[]> {
  const { rows } = await q('SELECT * FROM network_links ORDER BY realm ASC, name ASC LIMIT $1', [MAX_LINKS]);
  return rows.map(mapLink);
}

export async function getLink(q: Query, id: string): Promise<NetworkLink | null> {
  const { rows } = await q('SELECT * FROM network_links WHERE id = $1', [id]);
  return rows.length ? mapLink(rows[0]) : null;
}

async function assertRoom(q: Query, adding: number): Promise<void> {
  const { rows } = await q('SELECT COUNT(*)::int AS n FROM network_links');
  if (Number(rows[0].n) + adding > MAX_LINKS) throw new HttpError(409, 'LINKS_FULL', `The network holds at most ${MAX_LINKS} links. Remove some first.`);
}

export async function createLink(db: Db, input: LinkInput): Promise<NetworkLink> {
  const id = newId('link');
  const nowMs = Date.now();
  await db.tx(async q => {
    await assertRoom(q, 1);
    const dupe = await q('SELECT 1 FROM network_links WHERE url = $1', [input.url]);
    if (dupe.rows.length) throw new HttpError(409, 'LINK_EXISTS', 'That address is already in the network.');
    await q(
      `INSERT INTO network_links (id, name, url, realm, kind, note, watch, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8)`,
      [id, input.name, input.url, input.realm, input.kind, input.note, input.watch, nowMs]
    );
    // The host is enough for the record; a full address can carry a token in its path.
    await auditTx(q, { actor: 'director', action: 'network.added', detail: { id, host: hostOf(input.url), realm: input.realm } });
  });
  return (await getLink(db.query, id))!;
}

export async function updateLink(db: Db, id: string, input: LinkInput): Promise<NetworkLink> {
  await db.tx(async q => {
    const { rows } = await q('SELECT url FROM network_links WHERE id = $1', [id]);
    if (rows.length === 0) throw notFound('Link not found.');
    const moved = rows[0].url !== input.url;
    if (moved) {
      const dupe = await q('SELECT 1 FROM network_links WHERE url = $1 AND id <> $2', [input.url, id]);
      if (dupe.rows.length) throw new HttpError(409, 'LINK_EXISTS', 'That address is already in the network.');
    }
    // A new address has never been knocked on: its old result must not carry over.
    await q(
      `UPDATE network_links
          SET name=$2, url=$3, realm=$4, kind=$5, note=$6, watch=$7, updated_at=$8,
              last_status = CASE WHEN $9 THEN NULL ELSE last_status END,
              last_error = CASE WHEN $9 THEN NULL ELSE last_error END,
              last_checked_at = CASE WHEN $9 THEN NULL ELSE last_checked_at END
        WHERE id=$1`,
      [id, input.name, input.url, input.realm, input.kind, input.note, input.watch, Date.now(), moved]
    );
    await auditTx(q, {
      actor: 'director',
      action: 'network.changed',
      detail: { id, host: hostOf(input.url), realm: input.realm, ...(moved ? { from: hostOf(rows[0].url) } : {}) },
    });
  });
  return (await getLink(db.query, id))!;
}

export async function deleteLink(db: Db, id: string): Promise<void> {
  await db.tx(async q => {
    const { rows } = await q('DELETE FROM network_links WHERE id = $1 RETURNING url', [id]);
    if (rows.length === 0) throw notFound('Link not found.');
    await auditTx(q, { actor: 'director', action: 'network.removed', detail: { id, host: hostOf(rows[0].url) } });
  });
}

/**
 * Add a list in one go. Every row is checked before anything is written, so a
 * bad row on line 40 does not leave 39 half-imported links behind. Addresses
 * already in the network are skipped and counted, never overwritten.
 */
export async function importLinks(db: Db, raw: unknown): Promise<{ added: number; skipped: number }> {
  if (!Array.isArray(raw)) throw bad('"links" must be a list.');
  if (raw.length === 0) throw bad('The list is empty.');
  if (raw.length > MAX_IMPORT) throw bad(`Import at most ${MAX_IMPORT} links at a time.`);
  const parsed: LinkInput[] = [];
  raw.forEach((row, i) => {
    if (row === null || typeof row !== 'object' || Array.isArray(row)) throw bad(`Row ${i + 1} is not an object.`);
    try {
      parsed.push(parseLinkInput(row as Obj));
    } catch (err) {
      throw bad(`Row ${i + 1}: ${errMessage(err)}`);
    }
  });
  const nowMs = Date.now();
  return db.tx(async q => {
    const existing = new Set((await q('SELECT url FROM network_links')).rows.map(r => String(r.url)));
    const fresh = parsed.filter(p => {
      if (existing.has(p.url)) return false;
      existing.add(p.url); // also drops repeats inside the list itself
      return true;
    });
    await assertRoom(q, fresh.length);
    for (const p of fresh) {
      await q(
        `INSERT INTO network_links (id, name, url, realm, kind, note, watch, created_at, updated_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8)`,
        [newId('link'), p.name, p.url, p.realm, p.kind, p.note, p.watch, nowMs]
      );
    }
    const out = { added: fresh.length, skipped: parsed.length - fresh.length };
    await auditTx(q, { actor: 'director', action: 'network.imported', detail: { ...out, hosts: [...new Set(fresh.map(p => hostOf(p.url)))].slice(0, 30).join(' ') } });
    return out;
  });
}

// ── the sentinel ──────────────────────────────────────────────────────────
export interface SweepResult {
  checked: number;
  up: number;
  notAnswering: number;
}

export interface NetworkService {
  list(): Promise<NetworkLink[]>;
  /** Knock once on every watched link and store the status codes. */
  sweep(): Promise<SweepResult>;
  sweptAt(): Promise<number | null>;
}

export function createNetworkService(db: Db, fetchImpl: typeof fetch): NetworkService {
  let sweeping: Promise<SweepResult> | null = null;

  async function knock(link: NetworkLink): Promise<{ status: number | null; error: string | null }> {
    // Decided again at knock time, from the stored address: never trust a flag alone.
    if (!watchable(link.url)) return { status: null, error: 'not a public https address' };
    try {
      const res = await fetchWithTimeout(
        fetchImpl,
        link.url,
        // HEAD: no body is requested and none is read. manual: a redirect is recorded, not followed.
        { method: 'HEAD', redirect: 'manual', headers: { 'User-Agent': 'yabbai-flash-sentinel/1 (reachability check; reads nothing)' } },
        6000
      );
      return { status: res.status, error: null };
    } catch (err) {
      const name = err instanceof Error ? err.name : '';
      return { status: null, error: name === 'AbortError' ? 'no answer within 6 seconds' : 'no answer' };
    }
  }

  async function doSweep(): Promise<SweepResult> {
    const targets = (await listLinks(db.query)).filter(l => l.watch).slice(0, 60);
    const out: SweepResult = { checked: 0, up: 0, notAnswering: 0 };
    // A handful at a time, so a long list never opens a burst of connections.
    for (let i = 0; i < targets.length; i += 5) {
      await Promise.all(
        targets.slice(i, i + 5).map(async link => {
          const r = await knock(link);
          const nowMs = Date.now();
          await db.query('UPDATE network_links SET last_status=$2, last_error=$3, last_checked_at=$4 WHERE id=$1 AND url=$5', [link.id, r.status, r.error, nowMs, link.url]);
          out.checked += 1;
          if (stateOf({ watch: true, lastStatus: r.status, lastCheckedAt: nowMs }) === 'up') out.up += 1;
          else out.notAnswering += 1;
        })
      );
    }
    await kvSet(db.query, SWEEP_KEY, Date.now());
    return out;
  }

  return {
    list: () => listLinks(db.query),
    sweep() {
      // One sweep at a time: a second caller waits for the one already running.
      if (!sweeping) {
        sweeping = doSweep().finally(() => {
          sweeping = null;
        });
      }
      return sweeping;
    },
    sweptAt: () => kvGet<number>(db.query, SWEEP_KEY),
  };
}
