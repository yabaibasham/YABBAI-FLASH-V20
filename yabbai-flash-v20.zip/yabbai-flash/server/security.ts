/**
 * HTTP hardening: response headers, rate limiting, and same-origin checks.
 * Hand-written on purpose — it is small, and fewer dependencies means fewer
 * things that can be compromised underneath a payments app.
 */
import type { NextFunction, Request, Response } from 'express';
import type { Config } from './config.ts';
import { HttpError } from './util.ts';

export function securityHeaders(config: Config) {
  const csp = [
    "default-src 'self'",
    "script-src 'self'",
    // React sets inline style attributes; no inline <script> is ever allowed.
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data:",
    "font-src 'self'",
    "connect-src 'self'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    `frame-ancestors ${config.frameAncestors}`,
  ].join('; ');

  return (req: Request, res: Response, next: NextFunction) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    // Pay links carry a secret token in the path. Never leak it via Referer.
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), usb=(), interest-cohort=()');
    res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
    res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
    res.setHeader('X-DNS-Prefetch-Control', 'off');
    res.removeHeader('X-Powered-By');
    if (config.frameAncestors === "'none'") res.setHeader('X-Frame-Options', 'DENY');
    if (config.isProd) {
      // Vite's dev server needs inline scripts and websockets, so CSP is production-only.
      res.setHeader('Content-Security-Policy', csp);
      res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    }
    if (req.path.startsWith('/api/')) {
      res.setHeader('Cache-Control', 'no-store');
    }
    next();
  };
}

// ── rate limiting ─────────────────────────────────────────────────────────
interface Bucket {
  count: number;
  resetAt: number;
}

export class RateLimiter {
  private buckets = new Map<string, Bucket>();
  private windowMs: number;
  private max: number;

  constructor(windowMs: number, max: number) {
    this.windowMs = windowMs;
    this.max = max;
  }

  /** Returns seconds to wait if the caller is over the limit, otherwise 0. */
  hit(key: string, nowMs = Date.now()): number {
    if (this.buckets.size > 20_000) this.sweep(nowMs);
    const b = this.buckets.get(key);
    if (!b || b.resetAt <= nowMs) {
      this.buckets.set(key, { count: 1, resetAt: nowMs + this.windowMs });
      return 0;
    }
    b.count += 1;
    if (b.count > this.max) return Math.max(1, Math.ceil((b.resetAt - nowMs) / 1000));
    return 0;
  }

  reset(key: string): void {
    this.buckets.delete(key);
  }

  private sweep(nowMs: number): void {
    for (const [k, b] of this.buckets) if (b.resetAt <= nowMs) this.buckets.delete(k);
  }
}

export const CLIENT_IP_HEADER_SETTING = 'flash client ip header';

/** The visitor's address, for rate limits and the audit log. Never used to grant anything. */
export function clientIp(req: Request): string {
  const header = req.app?.get(CLIENT_IP_HEADER_SETTING) as string | null | undefined;
  if (header) {
    const value = req.get(header)?.trim();
    if (value && /^[0-9A-Fa-f:.]{3,45}$/.test(value)) return value;
  }
  return req.ip || req.socket.remoteAddress || 'unknown';
}

export function limit(limiter: RateLimiter, scope: string, keyFn: (req: Request) => string = clientIp) {
  return (req: Request, res: Response, next: NextFunction) => {
    const wait = limiter.hit(`${scope}:${keyFn(req)}`);
    if (wait > 0) {
      res.setHeader('Retry-After', String(wait));
      next(new HttpError(429, 'RATE_LIMITED', `Too many requests. Try again in ${wait}s.`));
      return;
    }
    next();
  };
}

// ── CSRF / same-origin ────────────────────────────────────────────────────
/**
 * Every state-changing console request must:
 *  - carry the custom header X-Flash: 1 (a cross-site form or image cannot set
 *    it, and a cross-site fetch that tries triggers a CORS preflight we never
 *    approve), and
 *  - come from our own origin when the browser tells us where it came from.
 * This is on top of the SameSite=Strict session cookie.
 */
export function requireSameOrigin(config: Config) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') return next();

    if (req.get('X-Flash') !== '1') {
      return next(new HttpError(403, 'CSRF', 'Request refused: missing console header.'));
    }
    const site = req.get('Sec-Fetch-Site');
    if (site && site !== 'same-origin') {
      return next(new HttpError(403, 'CSRF', 'Request refused: cross-site request.'));
    }
    const origin = req.get('Origin');
    if (origin) {
      let originHost = '';
      try {
        originHost = new URL(origin).host;
      } catch {
        return next(new HttpError(403, 'CSRF', 'Request refused: bad origin.'));
      }
      const allowed = new Set<string>();
      const host = req.get('Host');
      if (host) allowed.add(host);
      if (config.publicBaseUrl) allowed.add(new URL(config.publicBaseUrl).host);
      if (!allowed.has(originHost)) {
        return next(new HttpError(403, 'CSRF', 'Request refused: origin mismatch.'));
      }
    }
    next();
  };
}

/** Only accept JSON bodies on JSON routes (blocks form-encoded cross-site posts). */
export function requireJson(req: Request, _res: Response, next: NextFunction) {
  if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'DELETE') return next();
  const len = Number(req.get('Content-Length') ?? '0');
  if (len === 0 && !req.get('Transfer-Encoding')) return next();
  if (!req.is('application/json')) {
    return next(new HttpError(415, 'UNSUPPORTED_MEDIA_TYPE', 'Send JSON.'));
  }
  next();
}
