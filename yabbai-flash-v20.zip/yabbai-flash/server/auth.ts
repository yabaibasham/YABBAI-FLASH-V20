/**
 * Director authentication.
 *
 * What changed from the old build, and why it matters:
 *  - The old "vault" checked a password in the browser against a hash that was
 *    also stored in the browser, next to the secret used to sign the session.
 *    Anyone could read or replace all three. Here the check happens on the
 *    server; the browser only ever holds an opaque, httpOnly cookie.
 *  - There is no factory key. With no password configured, nobody can log in.
 *  - Optional TOTP second factor, with replay protection.
 *  - Throttling survives restarts (stored in the database), on top of a
 *    per-address limiter in memory.
 *  - "Step-up": sensitive actions need the password again within 5 minutes.
 */
import { createHmac, randomBytes, scrypt as scryptCb, timingSafeEqual } from 'node:crypto';
import { Router } from 'express';
import type { NextFunction, Request, Response } from 'express';
import type { Config } from './config.ts';
import type { Db } from './db.ts';
import { kvGet, kvSet } from './db.ts';
import { audit } from './audit.ts';
import { RateLimiter, clientIp } from './security.ts';
import { HttpError, sha256hex } from './util.ts';
import { optStr, reqStr, body } from './validate.ts';
import type { AuthState } from '../shared/types.ts';

// ── password hashing (scrypt) ─────────────────────────────────────────────
const SCRYPT_LOG_N = 15;
const SCRYPT_R = 8;
const SCRYPT_P = 1;
const KEY_LEN = 32;

function scrypt(password: string, salt: Buffer, logN: number, r: number, p: number): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scryptCb(password.normalize('NFKC'), salt, KEY_LEN, { N: 2 ** logN, r, p, maxmem: 256 * 1024 * 1024 }, (err, key) => {
      if (err) reject(err);
      else resolve(key as Buffer);
    });
  });
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const key = await scrypt(password, salt, SCRYPT_LOG_N, SCRYPT_R, SCRYPT_P);
  // Dots, not "$": this value gets pasted into shells, .env files and YAML,
  // and a "$" in any of those can be silently expanded into nothing.
  return ['scrypt', SCRYPT_LOG_N, SCRYPT_R, SCRYPT_P, salt.toString('base64url'), key.toString('base64url')].join('.');
}

export const PASSWORD_HASH_RE = /^scrypt[.$]\d{1,2}[.$]\d{1,2}[.$]\d[.$][A-Za-z0-9_-]{11,}[.$][A-Za-z0-9_-]{43}$/;

export async function verifyPasswordHash(password: string, stored: string): Promise<boolean> {
  if (!PASSWORD_HASH_RE.test(stored)) return false;
  const parts = stored.split(/[.$]/);
  if (parts.length !== 6 || parts[0] !== 'scrypt') return false;
  const logN = Number(parts[1]);
  const r = Number(parts[2]);
  const p = Number(parts[3]);
  if (!Number.isInteger(logN) || logN < 14 || logN > 20 || !Number.isInteger(r) || r < 1 || r > 32 || !Number.isInteger(p) || p < 1 || p > 8) return false;
  const salt = Buffer.from(parts[4], 'base64url');
  const expected = Buffer.from(parts[5], 'base64url');
  if (salt.length < 8 || expected.length !== KEY_LEN) return false;
  const actual = await scrypt(password, salt, logN, r, p);
  return timingSafeEqual(actual, expected);
}

// ── TOTP (RFC 6238, SHA-1, 6 digits, 30s) ─────────────────────────────────
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

export function base32Decode(text: string): Buffer {
  const clean = text.replace(/=+$/, '').toUpperCase();
  let bits = 0;
  let value = 0;
  const out: number[] = [];
  for (const ch of clean) {
    const idx = B32.indexOf(ch);
    if (idx < 0) throw new Error('invalid base32');
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

export function base32Encode(buf: Uint8Array): string {
  let bits = 0;
  let value = 0;
  let out = '';
  for (const b of buf) {
    value = (value << 8) | b;
    bits += 8;
    while (bits >= 5) {
      out += B32[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += B32[(value << (5 - bits)) & 31];
  return out;
}

export function totpAt(secret: Buffer, counter: number, digits = 6): string {
  const msg = Buffer.alloc(8);
  msg.writeBigUInt64BE(BigInt(counter));
  const mac = createHmac('sha1', secret).update(msg).digest();
  const offset = mac[mac.length - 1] & 0x0f;
  const code = ((mac[offset] & 0x7f) << 24) | (mac[offset + 1] << 16) | (mac[offset + 2] << 8) | mac[offset + 3];
  return String(code % 10 ** digits).padStart(digits, '0');
}

/** Returns the matched time-step counter, or null. Accepts one step either side. */
export function matchTotp(secretBase32: string, code: string, nowMs = Date.now()): number | null {
  if (!/^\d{6}$/.test(code)) return null;
  const secret = base32Decode(secretBase32);
  const step = Math.floor(nowMs / 30_000);
  for (const delta of [0, -1, 1]) {
    const candidate = totpAt(secret, step + delta);
    if (timingSafeEqual(Buffer.from(candidate), Buffer.from(code))) return step + delta;
  }
  return null;
}

// ── sessions ──────────────────────────────────────────────────────────────
export interface SessionInfo {
  tokenHash: string;
  expiresAt: number;
  stepUpUntil: number;
}

declare module 'express-serve-static-core' {
  interface Request {
    flashSession?: SessionInfo;
  }
}

export function cookieName(config: Config): string {
  // __Host- pins the cookie to this exact host over HTTPS; browsers refuse it otherwise.
  return config.isProd ? '__Host-flash_session' : 'flash_session';
}

function readCookie(req: Request, name: string): string | null {
  const header = req.headers.cookie;
  if (!header) return null;
  for (const part of header.split(';')) {
    const idx = part.indexOf('=');
    if (idx < 0) continue;
    if (part.slice(0, idx).trim() !== name) continue;
    try {
      return decodeURIComponent(part.slice(idx + 1).trim());
    } catch {
      return null; // malformed percent-encoding is just "no cookie"
    }
  }
  return null;
}

function setSessionCookie(res: Response, config: Config, token: string, maxAgeMs: number): void {
  const attrs = [`${cookieName(config)}=${encodeURIComponent(token)}`, 'Path=/', 'HttpOnly', `Max-Age=${Math.floor(maxAgeMs / 1000)}`];
  if (config.isProd) attrs.push('Secure');
  if (config.auth.cookieSameSite === 'none' && config.isProd) attrs.push('SameSite=None', 'Partitioned');
  else attrs.push('SameSite=Strict');
  res.append('Set-Cookie', attrs.join('; '));
}

function clearSessionCookie(res: Response, config: Config): void {
  const attrs = [`${cookieName(config)}=`, 'Path=/', 'HttpOnly', 'Max-Age=0', 'SameSite=Strict'];
  if (config.isProd) attrs.push('Secure');
  res.append('Set-Cookie', attrs.join('; '));
}

async function loadSession(db: Db, config: Config, req: Request): Promise<SessionInfo | null> {
  const token = readCookie(req, cookieName(config));
  if (!token || token.length < 32 || token.length > 128) return null;
  const tokenHash = sha256hex(token);
  const nowMs = Date.now();
  const { rows } = await db.query('SELECT * FROM sessions WHERE token_hash = $1', [tokenHash]);
  if (rows.length === 0) return null;
  const s = rows[0];
  const expired = Number(s.expires_at) <= nowMs || Number(s.last_seen_at) + config.auth.idleTtlMs <= nowMs;
  if (expired) {
    await db.query('DELETE FROM sessions WHERE token_hash = $1', [tokenHash]);
    return null;
  }
  // Touch at most once a minute to keep writes down.
  if (nowMs - Number(s.last_seen_at) > 60_000) {
    await db.query('UPDATE sessions SET last_seen_at = $2 WHERE token_hash = $1', [tokenHash, nowMs]);
  }
  return { tokenHash, expiresAt: Number(s.expires_at), stepUpUntil: Number(s.stepup_until) };
}

// ── remembered devices ────────────────────────────────────────────────────
/**
 * A lockout that anyone can trigger is a way to lock the owner out. So a
 * browser that has signed in before carries a second, long-lived cookie.
 * It proves nothing about identity — the password and code are still needed —
 * it only means "this browser is exempt from the lock strangers can cause",
 * and it has its own attempt limit.
 */
interface Device {
  hash: string;
  at: number;
}
const DEVICES_KEY = 'auth_devices';
const DEVICE_TTL_MS = 180 * 86_400_000;

function deviceCookieName(config: Config): string {
  return config.isProd ? '__Host-flash_device' : 'flash_device';
}

async function knownDevice(db: Db, config: Config, req: Request): Promise<string | null> {
  const token = readCookie(req, deviceCookieName(config));
  if (!token || token.length < 32 || token.length > 128) return null;
  const hash = sha256hex(token);
  const list = (await kvGet<Device[]>(db.query, DEVICES_KEY)) ?? [];
  const nowMs = Date.now();
  return Array.isArray(list) && list.some(d => d && d.hash === hash && d.at + DEVICE_TTL_MS > nowMs) ? hash : null;
}

async function rememberDevice(db: Db, config: Config, req: Request, res: Response): Promise<void> {
  if (await knownDevice(db, config, req)) return;
  const token = randomBytes(32).toString('base64url');
  const nowMs = Date.now();
  const list = ((await kvGet<Device[]>(db.query, DEVICES_KEY)) ?? []).filter(d => d && d.at + DEVICE_TTL_MS > nowMs);
  list.push({ hash: sha256hex(token), at: nowMs });
  await kvSet(db.query, DEVICES_KEY, list.slice(-10));
  const attrs = [`${deviceCookieName(config)}=${token}`, 'Path=/', 'HttpOnly', `Max-Age=${Math.floor(DEVICE_TTL_MS / 1000)}`, 'SameSite=Strict'];
  if (config.isProd) attrs.push('Secure');
  res.append('Set-Cookie', attrs.join('; '));
}

function clearDeviceCookie(res: Response, config: Config): void {
  const attrs = [`${deviceCookieName(config)}=`, 'Path=/', 'HttpOnly', 'Max-Age=0', 'SameSite=Strict'];
  if (config.isProd) attrs.push('Secure');
  res.append('Set-Cookie', attrs.join('; '));
}

export function authConfigured(config: Config): boolean {
  return !!(config.auth.passwordHash || config.auth.passwordPlain);
}

// ── throttling ────────────────────────────────────────────────────────────
interface Throttle {
  failures: number;
  lockedUntil: number;
  /** Which password this count belongs to. Rotating the password starts a clean slate. */
  tag?: string;
}
const THROTTLE_KEY = 'auth_throttle';

/**
 * Identifies the configured password without revealing anything about it:
 * a digest of the scrypt hash string, whose salt never reaches the database.
 */
function throttleTag(config: Config): string {
  return config.auth.passwordHash ? sha256hex(`throttle:${config.auth.passwordHash}`).slice(0, 16) : 'plain';
}

async function readThrottle(db: Db, config: Config): Promise<Throttle> {
  const tag = throttleTag(config);
  const t = await kvGet<Throttle>(db.query, THROTTLE_KEY);
  // A lock set under an older password does not survive a password change:
  // that is the owner's way back in if they are ever locked out with no known device.
  if (!t || (t.tag ?? tag) !== tag) return { failures: 0, lockedUntil: 0, tag };
  return { failures: Number(t.failures) || 0, lockedUntil: Number(t.lockedUntil) || 0, tag };
}

async function recordFailure(db: Db, config: Config): Promise<Throttle> {
  const t = await readThrottle(db, config);
  t.failures += 1;
  // After 8 straight failures: lock 1 min, doubling each further failure, capped at 1 hour.
  if (t.failures >= 8) {
    const lockMs = Math.min(3600_000, 60_000 * 2 ** (t.failures - 8));
    t.lockedUntil = Date.now() + lockMs;
  }
  await kvSet(db.query, THROTTLE_KEY, t);
  return t;
}

async function checkCredentials(db: Db, config: Config, password: string, totp: string | null): Promise<{ ok: boolean; reason?: string }> {
  let passwordOk = false;
  if (config.auth.passwordHash) {
    passwordOk = await verifyPasswordHash(password, config.auth.passwordHash);
  } else if (config.auth.passwordPlain) {
    // Compare digests so timing does not depend on the password's content or length.
    const a = Buffer.from(sha256hex(password.normalize('NFKC')));
    const b = Buffer.from(sha256hex(config.auth.passwordPlain.normalize('NFKC')));
    passwordOk = timingSafeEqual(a, b);
  }
  if (!passwordOk) return { ok: false, reason: 'password' };

  if (config.auth.totpSecret) {
    if (!totp) return { ok: false, reason: 'totp_required' };
    const step = matchTotp(config.auth.totpSecret, totp);
    if (step === null) return { ok: false, reason: 'totp' };
    // A code is single-use: refuse anything at or before the last accepted step.
    const last = (await kvGet<number>(db.query, 'totp_last_step')) ?? 0;
    if (step <= last) return { ok: false, reason: 'totp_reused' };
    await kvSet(db.query, 'totp_last_step', step);
  }
  return { ok: true };
}

// ── middleware ────────────────────────────────────────────────────────────
export function requireAuth(db: Db, config: Config) {
  return async (req: Request, _res: Response, next: NextFunction) => {
    const session = await loadSession(db, config, req);
    if (!session) throw new HttpError(401, 'UNAUTHENTICATED', 'Sign in required.');
    req.flashSession = session;
    next();
  };
}

/** Throws unless the password was confirmed in the last few minutes. For checks that depend on the request. */
export function assertStepUp(req: Request): void {
  const s = req.flashSession;
  if (!s) throw new HttpError(401, 'UNAUTHENTICATED', 'Sign in required.');
  if (s.stepUpUntil <= Date.now()) {
    throw new HttpError(403, 'STEP_UP_REQUIRED', 'Confirm your password to continue.');
  }
}

/** Use after requireAuth on routes that change where/how money is recorded. */
export function requireStepUp(req: Request, _res: Response, next: NextFunction) {
  assertStepUp(req);
  next();
}

// ── routes ────────────────────────────────────────────────────────────────
export function authRouter(db: Db, config: Config): Router {
  const router = Router();
  const perIp = new RateLimiter(10 * 60_000, 8);
  const perDevice = new RateLimiter(10 * 60_000, 10);

  router.get('/me', async (req, res) => {
    const session = await loadSession(db, config, req);
    const state: AuthState = {
      configured: authConfigured(config),
      authenticated: !!session,
      totpRequired: !!config.auth.totpSecret,
      stepUpUntil: session && session.stepUpUntil > Date.now() ? session.stepUpUntil : null,
      expiresAt: session ? session.expiresAt : null,
      // Before login, reveal only what someone needs to finish setup.
      problems: session
        ? config.problems.map(p => p.message)
        : config.problems.filter(p => ['NO_PASSWORD', 'WEAK_PASSWORD', 'BAD_PASSWORD_HASH'].includes(p.code)).map(p => p.message),
    };
    res.json(state);
  });

  async function guardAttempt(req: Request): Promise<void> {
    if (!authConfigured(config)) throw new HttpError(503, 'AUTH_NOT_CONFIGURED', 'No director password is configured on the server.');
    // A browser that has signed in before is limited on its own, so strangers
    // failing over and over cannot shut the owner out.
    const device = await knownDevice(db, config, req);
    if (device) {
      const wait = perDevice.hit(`device:${device}`);
      if (wait > 0) throw new HttpError(429, 'RATE_LIMITED', `Too many attempts. Try again in ${wait}s.`);
      return;
    }
    const wait = perIp.hit(`login:${clientIp(req)}`);
    if (wait > 0) throw new HttpError(429, 'RATE_LIMITED', `Too many attempts. Try again in ${wait}s.`);
    const t = await readThrottle(db, config);
    if (t.lockedUntil > Date.now()) {
      const secs = Math.ceil((t.lockedUntil - Date.now()) / 1000);
      throw new HttpError(429, 'LOCKED', `Login is locked after repeated failures. Try again in ${secs}s.`);
    }
  }

  router.post('/login', async (req, res) => {
    await guardAttempt(req);
    const b = body(req);
    const password = reqStr(b, 'password', 1, 512);
    const totp = optStr(b, 'totp', 12)?.replace(/\s+/g, '') ?? null;

    const result = await checkCredentials(db, config, password, totp);
    if (!result.ok) {
      // Deliberately no "password was right, now send the code" branch: that
      // would let an attacker confirm a guessed password without the second
      // factor. The sign-in form always sends both.
      const t = await recordFailure(db, config);
      await audit(db, { actor: 'public', action: 'auth.login_failed', detail: { ip: clientIp(req), failures: t.failures } });
      // One message for every kind of failure.
      throw new HttpError(401, 'INVALID_CREDENTIALS', 'Those details are not right.');
    }

    await kvSet(db.query, THROTTLE_KEY, { failures: 0, lockedUntil: 0, tag: throttleTag(config) });
    perIp.reset(`login:${clientIp(req)}`);

    const token = randomBytes(32).toString('base64url');
    const nowMs = Date.now();
    const expiresAt = nowMs + config.auth.sessionTtlMs;
    await db.query('DELETE FROM sessions WHERE expires_at <= $1', [nowMs]);
    await db.query(
      'INSERT INTO sessions (token_hash, created_at, expires_at, last_seen_at, stepup_until, ip, user_agent) VALUES ($1,$2,$3,$2,$4,$5,$6)',
      [sha256hex(token), nowMs, expiresAt, nowMs + config.auth.stepUpMs, clientIp(req), (req.get('User-Agent') ?? '').slice(0, 300)]
    );
    setSessionCookie(res, config, token, config.auth.sessionTtlMs);
    await rememberDevice(db, config, req, res);
    await audit(db, { actor: 'director', action: 'auth.login', detail: { ip: clientIp(req) } });
    res.json({ ok: true, expiresAt });
  });

  router.post('/logout', async (req, res) => {
    const session = await loadSession(db, config, req);
    if (session) {
      await db.query('DELETE FROM sessions WHERE token_hash = $1', [session.tokenHash]);
      await audit(db, { actor: 'director', action: 'auth.logout' });
    }
    clearSessionCookie(res, config);
    res.json({ ok: true });
  });

  /** Sign out every device. */
  router.post('/logout-all', requireAuth(db, config), async (_req, res) => {
    await db.query('DELETE FROM sessions');
    await kvSet(db.query, DEVICES_KEY, []); // forget every remembered browser too
    await audit(db, { actor: 'director', action: 'auth.logout_all' });
    clearSessionCookie(res, config);
    clearDeviceCookie(res, config);
    res.json({ ok: true });
  });

  router.post('/stepup', requireAuth(db, config), async (req, res) => {
    await guardAttempt(req);
    const b = body(req);
    const password = reqStr(b, 'password', 1, 512);
    const totp = optStr(b, 'totp', 12)?.replace(/\s+/g, '') ?? null;
    const result = await checkCredentials(db, config, password, totp);
    if (!result.ok) {
      await recordFailure(db, config);
      await audit(db, { actor: 'director', action: 'auth.stepup_failed', detail: { ip: clientIp(req) } });
      throw new HttpError(401, 'INVALID_CREDENTIALS', 'Those details are not right.');
    }
    await kvSet(db.query, THROTTLE_KEY, { failures: 0, lockedUntil: 0, tag: throttleTag(config) });
    const until = Date.now() + config.auth.stepUpMs;
    await db.query('UPDATE sessions SET stepup_until = $2 WHERE token_hash = $1', [req.flashSession!.tokenHash, until]);
    res.json({ ok: true, stepUpUntil: until });
  });

  return router;
}
