/**
 * All configuration comes from environment variables, read once at boot.
 *
 * Two rules shape this file:
 *  1. Secrets never reach the browser. Nothing here is serialised to a client
 *     except the handful of fields exposed deliberately in routes.
 *  2. Where money GOES is pinned here and nowhere else. The receiving wallet
 *     and the bank details shown on invoices can only be changed by someone
 *     with access to the hosting account — never from the console, so a
 *     stolen console session cannot redirect a single payment.
 */
import { base58Decode } from './util.ts';
import type { Mode } from '../shared/types.ts';

export interface ConfigProblem {
  level: 'error' | 'warn';
  code: string;
  message: string;
}

export interface Config {
  nodeEnv: string;
  isProd: boolean;
  port: number;
  publicBaseUrl: string | null;
  trustProxy: number | boolean;
  /** Header carrying the visitor's address, when the host's edge sets one. */
  clientIpHeader: string | null;
  frameAncestors: string;
  timeZone: string;

  databaseUrl: string | null;
  databaseSsl: 'auto' | 'require' | 'no-verify' | 'disable';
  dataDir: string | null; // null = in-memory PGlite
  allowLocalDbForPayments: boolean;

  auth: {
    passwordHash: string | null;
    passwordPlain: string | null;
    totpSecret: string | null;
    sessionTtlMs: number;
    idleTtlMs: number;
    stepUpMs: number;
    cookieSameSite: 'strict' | 'none';
  };

  mode: Mode;

  stripe: {
    secretKey: string | null;
    webhookSecret: string | null;
    keyMode: Mode | 'off';
    /** Test hooks only: point the SDK at a local stub. */
    apiHost: string | null;
    apiPort: number | null;
    apiProtocol: 'http' | 'https';
  };

  solana: {
    receiveAddress: string | null;
    addressValid: boolean;
    cluster: 'mainnet-beta' | 'devnet';
    rpcUrl: string;
    usdcMint: string;
    acceptSol: boolean;
    acceptUsdc: boolean;
    unprovenOk: boolean;
    quoteTtlMs: number;
  };

  bank: {
    payId: string | null;
    bsb: string | null;
    accountNumber: string | null;
    accountName: string | null;
  };

  business: {
    brandName: string;
    abn: string | null;
    gstRegistered: boolean;
    supportEmail: string | null;
  };

  ai: {
    provider: 'gemini' | 'openai' | 'off';
    geminiKey: string | null;
    geminiModels: string[];
    openaiBaseUrl: string | null;
    openaiKey: string | null;
    openaiModel: string | null;
    dailyCap: number;
  };

  autopilot: { enabled: boolean; intervalMs: number };

  /** How many seats may be asked at the same moment. 1 suits a small local model. */
  council: { parallel: number };

  problems: ConfigProblem[];
}

type Env = Record<string, string | undefined>;

const PLACEHOLDERS = new Set(['', 'MY_GEMINI_API_KEY', 'MY_APP_URL', 'changeme', 'CHANGE_ME', 'your-key-here']);

function str(env: Env, key: string): string | null {
  const v = env[key];
  if (v === undefined) return null;
  const t = v.trim();
  return PLACEHOLDERS.has(t) ? null : t;
}

function bool(env: Env, key: string, fallback: boolean): boolean {
  const v = str(env, key);
  if (v === null) return fallback;
  return ['1', 'true', 'yes', 'on'].includes(v.toLowerCase());
}

function int(env: Env, key: string, fallback: number, min: number, max: number): number {
  const v = str(env, key);
  if (v === null) return fallback;
  const n = Number.parseInt(v, 10);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
}

/** Passwords an attacker would try first — including the old build's hardcoded key. */
const KNOWN_WEAK = new Set(
  ['YABBAI-DIRECTOR-88', 'yabbai-director-88', 'password', 'password123', 'director', 'yabbai', 'yabbaiflash', 'letmein', 'admin', 'qwerty123456', '123456789012'].map(
    s => s.toLowerCase()
  )
);

/** Shape of the value `npm run setup` prints. Kept in step with PASSWORD_HASH_RE in auth.ts. */
const HASH_SHAPE = /^scrypt[.$]\d{1,2}[.$]\d{1,2}[.$]\d[.$][A-Za-z0-9_-]{11,}[.$][A-Za-z0-9_-]{43}$/;

export function passwordIsWeak(pw: string): string | null {
  if (pw.length < 12) return 'must be at least 12 characters';
  if (KNOWN_WEAK.has(pw.toLowerCase())) return 'is a known or previously published password';
  if (/^(.)\1+$/.test(pw)) return 'is a single repeated character';
  return null;
}

function normaliseUrl(value: string | null): string | null {
  if (!value) return null;
  try {
    const u = new URL(value);
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
    return u.origin;
  } catch {
    return null;
  }
}

const USDC_MAINNET = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v';
const USDC_DEVNET = '4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU';

export function loadConfig(env: Env = process.env): Config {
  const problems: ConfigProblem[] = [];
  const nodeEnv = str(env, 'NODE_ENV') ?? 'development';
  const isProd = nodeEnv === 'production';

  // ── where this app lives ────────────────────────────────────────────────
  const publicBaseUrl =
    normaliseUrl(str(env, 'PUBLIC_BASE_URL')) ?? normaliseUrl(str(env, 'RENDER_EXTERNAL_URL')) ?? normaliseUrl(str(env, 'APP_URL'));
  if (isProd && !publicBaseUrl) {
    problems.push({
      level: 'error',
      code: 'NO_PUBLIC_URL',
      message: 'PUBLIC_BASE_URL is not set. Card checkout stays off until it is, because the app will not guess its own address from a request.',
    });
  }
  if (isProd && publicBaseUrl && !publicBaseUrl.startsWith('https://')) {
    problems.push({ level: 'error', code: 'INSECURE_PUBLIC_URL', message: 'PUBLIC_BASE_URL must be https in production.' });
  }

  // Some hosts put several proxies in front of the app and pass the visitor's address in a
  // header the edge always overwrites (Cloudflare: cf-connecting-ip). Only set this when
  // every request is guaranteed to arrive through that edge.
  const ipHeaderRaw = str(env, 'CLIENT_IP_HEADER')?.toLowerCase() ?? null;
  const clientIpHeader = ipHeaderRaw && /^[a-z0-9-]{3,40}$/.test(ipHeaderRaw) ? ipHeaderRaw : null;
  if (ipHeaderRaw && !clientIpHeader) problems.push({ level: 'warn', code: 'BAD_IP_HEADER', message: 'CLIENT_IP_HEADER is not a valid header name and is being ignored.' });

  const trustProxyRaw = str(env, 'TRUST_PROXY');
  const trustProxy: number | boolean =
    trustProxyRaw === null ? (isProd ? 1 : false) : trustProxyRaw === 'false' ? false : trustProxyRaw === 'true' ? true : Number(trustProxyRaw) || 1;

  // ── database ────────────────────────────────────────────────────────────
  const databaseUrl = str(env, 'DATABASE_URL');
  const sslRaw = (str(env, 'DATABASE_SSL') ?? 'auto').toLowerCase();
  const databaseSsl = (['auto', 'require', 'no-verify', 'disable'].includes(sslRaw) ? sslRaw : 'auto') as Config['databaseSsl'];
  const dataDirRaw = str(env, 'FLASH_DATA_DIR');
  const dataDir = dataDirRaw === 'memory' ? null : dataDirRaw ?? (isProd ? null : './.data/pg');
  const allowLocalDbForPayments = bool(env, 'ALLOW_LOCAL_DB_FOR_PAYMENTS', false);

  // ── director login ──────────────────────────────────────────────────────
  const passwordHash = str(env, 'DIRECTOR_PASSWORD_HASH');
  let passwordPlain = str(env, 'DIRECTOR_PASSWORD');
  if (passwordHash && !HASH_SHAPE.test(passwordHash)) {
    problems.push({ level: 'error', code: 'BAD_PASSWORD_HASH', message: 'DIRECTOR_PASSWORD_HASH is not in the format produced by `npm run setup`.' });
  }
  if (!passwordHash && passwordPlain) {
    const weak = passwordIsWeak(passwordPlain);
    if (weak) {
      problems.push({ level: 'error', code: 'WEAK_PASSWORD', message: `DIRECTOR_PASSWORD ${weak}. Login stays disabled until it is replaced.` });
      passwordPlain = null;
    }
  }
  if (!passwordHash && !passwordPlain) {
    problems.push({
      level: 'error',
      code: 'NO_PASSWORD',
      message: 'No director password is configured. Run `npm run setup` and set DIRECTOR_PASSWORD_HASH. The console stays locked until then.',
    });
  }
  const totpSecret = str(env, 'TOTP_SECRET')?.replace(/\s+/g, '').toUpperCase() ?? null;
  if (totpSecret && !/^[A-Z2-7]{16,}=*$/.test(totpSecret)) {
    problems.push({ level: 'error', code: 'BAD_TOTP', message: 'TOTP_SECRET is not valid base32.' });
  }
  if (!totpSecret) {
    problems.push({ level: 'warn', code: 'NO_TOTP', message: 'Two-factor login is off. Set TOTP_SECRET (from `npm run setup`) to require an authenticator code.' });
  }
  const sameSiteRaw = (str(env, 'COOKIE_SAMESITE') ?? 'strict').toLowerCase();

  // ── Stripe ──────────────────────────────────────────────────────────────
  const stripeKey = str(env, 'STRIPE_SECRET_KEY');
  let keyMode: Mode | 'off' = 'off';
  if (stripeKey) {
    if (/^(sk|rk)_live_/.test(stripeKey)) keyMode = 'live';
    else if (/^(sk|rk)_test_/.test(stripeKey)) keyMode = 'test';
    else problems.push({ level: 'error', code: 'BAD_STRIPE_KEY', message: 'STRIPE_SECRET_KEY must start with rk_live_, sk_live_, rk_test_ or sk_test_.' });
  }
  if (stripeKey && /^sk_live_/.test(stripeKey)) {
    problems.push({
      level: 'warn',
      code: 'UNRESTRICTED_STRIPE_KEY',
      message: 'STRIPE_SECRET_KEY is an unrestricted live key. Swap it for a restricted key (rk_live_) limited to Checkout Sessions write plus read access.',
    });
  }
  const webhookSecret = str(env, 'STRIPE_WEBHOOK_SECRET');
  if (webhookSecret && !webhookSecret.startsWith('whsec_')) {
    problems.push({ level: 'error', code: 'BAD_WEBHOOK_SECRET', message: 'STRIPE_WEBHOOK_SECRET must start with whsec_.' });
  }

  // ── Solana ──────────────────────────────────────────────────────────────
  const cluster = (str(env, 'SOLANA_CLUSTER') ?? 'mainnet-beta') === 'devnet' ? 'devnet' : 'mainnet-beta';
  const receiveAddress = str(env, 'SOLANA_RECEIVE_ADDRESS');
  let addressValid = false;
  if (receiveAddress) {
    const decoded = base58Decode(receiveAddress);
    addressValid = decoded !== null && decoded.length === 32;
    if (!addressValid) {
      problems.push({
        level: 'error',
        code: 'BAD_SOLANA_ADDRESS',
        message: `SOLANA_RECEIVE_ADDRESS is not a valid Solana address (it decodes to ${decoded ? decoded.length : 0} bytes, a wallet is exactly 32). The crypto rail is off.`,
      });
    }
  }
  const rpcUrl = str(env, 'SOLANA_RPC_URL') ?? (cluster === 'devnet' ? 'https://api.devnet.solana.com' : 'https://api.mainnet-beta.solana.com');
  if (receiveAddress && !str(env, 'SOLANA_RPC_URL') && cluster === 'mainnet-beta') {
    problems.push({
      level: 'warn',
      code: 'PUBLIC_RPC',
      message: 'SOLANA_RPC_URL is not set, so the rate-limited public RPC is used. Add a Helius or Alchemy endpoint for reliable payment detection.',
    });
  }

  // ── one mode for the whole app ──────────────────────────────────────────
  const mode: Mode = keyMode === 'test' ? 'test' : keyMode === 'live' ? 'live' : cluster === 'devnet' ? 'test' : 'live';
  if (receiveAddress && addressValid && (mode === 'live') !== (cluster === 'mainnet-beta')) {
    problems.push({
      level: 'error',
      code: 'MODE_MISMATCH',
      message:
        mode === 'test'
          ? 'Stripe is in test mode but Solana points at mainnet. The crypto rail is off so real crypto is never recorded as a test payment. Use SOLANA_CLUSTER=devnet while testing.'
          : 'Stripe is live but Solana points at devnet. The crypto rail is off so play money is never recorded as real.',
    });
  }

  // ── bank details shown on invoices ──────────────────────────────────────
  const bank = {
    payId: str(env, 'BANK_PAYID'),
    bsb: str(env, 'BANK_BSB'),
    accountNumber: str(env, 'BANK_ACCOUNT_NUMBER'),
    accountName: str(env, 'BANK_ACCOUNT_NAME'),
  };
  if (bank.bsb && !/^\d{3}-?\d{3}$/.test(bank.bsb)) {
    problems.push({ level: 'error', code: 'BAD_BSB', message: 'BANK_BSB must be six digits (e.g. 123-456).' });
    bank.bsb = null;
  }
  if (bank.accountNumber && !/^\d{4,10}$/.test(bank.accountNumber)) {
    problems.push({ level: 'error', code: 'BAD_ACCOUNT', message: 'BANK_ACCOUNT_NUMBER must be 4–10 digits.' });
    bank.accountNumber = null;
  }

  // ── business identity ───────────────────────────────────────────────────
  const gstRegistered = bool(env, 'GST_REGISTERED', false);
  const abn = str(env, 'BUSINESS_ABN')?.replace(/\s+/g, '') ?? null;
  if (gstRegistered && !abn) {
    problems.push({ level: 'error', code: 'GST_NEEDS_ABN', message: 'GST_REGISTERED is on but BUSINESS_ABN is missing. GST stays off until an ABN is set.' });
  }

  // ── AI brain ────────────────────────────────────────────────────────────
  const geminiKey = str(env, 'GEMINI_API_KEY') ?? str(env, 'API_KEY');
  let openaiBaseUrl = str(env, 'LLM_BASE_URL')?.replace(/\/+$/, '') ?? null;
  if (openaiBaseUrl) {
    try {
      const u = new URL(openaiBaseUrl);
      if (u.protocol !== 'https:' && u.protocol !== 'http:') throw new Error('protocol');
    } catch {
      problems.push({ level: 'error', code: 'BAD_LLM_URL', message: 'LLM_BASE_URL is not a valid http(s) address.' });
      openaiBaseUrl = null;
    }
  }
  const openaiKey = str(env, 'LLM_API_KEY');
  const openaiModel = str(env, 'LLM_MODEL');
  const providerRaw = (str(env, 'AI_PROVIDER') ?? '').toLowerCase();
  let provider: Config['ai']['provider'] = 'off';
  if (providerRaw === 'off') provider = 'off';
  else if ((providerRaw === 'openai' || (!providerRaw && openaiBaseUrl)) && openaiBaseUrl && openaiModel) provider = 'openai';
  else if (geminiKey) provider = 'gemini';
  const geminiModels = (str(env, 'GEMINI_MODEL') ?? 'gemini-3.8-flash,gemini-3.7-flash,gemini-3.6-flash,gemini-3.5-flash')
    .split(',')
    .map(s => s.trim())
    .filter(Boolean);

  return {
    nodeEnv,
    isProd,
    port: int(env, 'PORT', 3000, 1, 65535),
    publicBaseUrl,
    trustProxy,
    clientIpHeader,
    frameAncestors: str(env, 'FRAME_ANCESTORS') ?? "'none'",
    timeZone: str(env, 'BUSINESS_TIMEZONE') ?? 'Australia/Melbourne',
    databaseUrl,
    databaseSsl,
    dataDir,
    allowLocalDbForPayments,
    auth: {
      passwordHash: passwordHash && HASH_SHAPE.test(passwordHash) ? passwordHash : null,
      passwordPlain,
      totpSecret: totpSecret && /^[A-Z2-7]{16,}=*$/.test(totpSecret) ? totpSecret : null,
      sessionTtlMs: int(env, 'SESSION_TTL_HOURS', 12, 1, 72) * 3600_000,
      idleTtlMs: int(env, 'SESSION_IDLE_MINUTES', 120, 5, 720) * 60_000,
      stepUpMs: 5 * 60_000,
      cookieSameSite: sameSiteRaw === 'none' ? 'none' : 'strict',
    },
    mode,
    stripe: {
      secretKey: keyMode === 'off' ? null : stripeKey,
      webhookSecret: webhookSecret && webhookSecret.startsWith('whsec_') ? webhookSecret : null,
      keyMode,
      apiHost: str(env, 'STRIPE_API_HOST'),
      apiPort: str(env, 'STRIPE_API_PORT') ? Number(str(env, 'STRIPE_API_PORT')) : null,
      apiProtocol: str(env, 'STRIPE_API_PROTOCOL') === 'http' ? 'http' : 'https',
    },
    solana: {
      receiveAddress,
      addressValid,
      cluster,
      rpcUrl,
      usdcMint: cluster === 'devnet' ? USDC_DEVNET : USDC_MAINNET,
      acceptSol: bool(env, 'SOLANA_ACCEPT_SOL', true),
      acceptUsdc: bool(env, 'SOLANA_ACCEPT_USDC', true),
      unprovenOk: bool(env, 'SOLANA_ADDRESS_UNPROVEN_OK', false),
      quoteTtlMs: int(env, 'SOLANA_QUOTE_MINUTES', 15, 5, 60) * 60_000,
    },
    bank,
    business: {
      brandName: str(env, 'BRAND_NAME') ?? 'YABBAI',
      abn,
      gstRegistered: gstRegistered && !!abn,
      supportEmail: str(env, 'SUPPORT_EMAIL'),
    },
    ai: {
      provider,
      geminiKey,
      geminiModels,
      openaiBaseUrl,
      openaiKey,
      openaiModel,
      dailyCap: int(env, 'AI_DAILY_CAP', 200, 0, 100000),
    },
    autopilot: { enabled: bool(env, 'AUTOPILOT', true), intervalMs: int(env, 'AUTOPILOT_INTERVAL_SECONDS', 60, 15, 3600) * 1000 },
    council: { parallel: int(env, 'COUNCIL_PARALLEL', 2, 1, 4) },
    problems,
  };
}

/**
 * Is the database something we can trust with real payment records?
 * Only a real Postgres (DATABASE_URL) qualifies. ALLOW_LOCAL_DB_FOR_PAYMENTS is
 * an explicit override for local trials and automated tests.
 */
export function storageIsDurable(config: Config): boolean {
  return !!config.databaseUrl || config.allowLocalDbForPayments;
}
