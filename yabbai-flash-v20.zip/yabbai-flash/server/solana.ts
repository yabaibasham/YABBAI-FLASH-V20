/**
 * Solana Pay: customers pay SOL or USDC straight into YOUR wallet.
 *
 * There is no private key anywhere in this app. Funds never pass through the
 * server, so there is nothing here for anyone to sweep. The server only reads
 * the chain to see whether a payment arrived.
 *
 * Three protections, each a response to something that went wrong before:
 *
 *  1. The receiving address comes from the SOLANA_RECEIVE_ADDRESS environment
 *     variable only. It cannot be changed from the console, so a stolen login
 *     cannot redirect payments. (The old build shipped an address that an AI
 *     had invented — it was not even a valid 32-byte key.)
 *
 *  2. Proof of control. Before customers are ever shown this rail, the wallet
 *     must sign a one-off message (or send a tiny self-transfer). That defeats
 *     typos, invented addresses and "address poisoning" look-alikes: only the
 *     real owner of the exact address configured can pass.
 *
 *  3. Each invoice gets its own random reference key. A payment is credited
 *     only when a FINALIZED transaction that carries that reference shows the
 *     wallet's balance actually going up, and each transaction signature can
 *     be credited once.
 */
import { createPublicKey, randomBytes, verify as cryptoVerify } from 'node:crypto';
import type { Config } from './config.ts';
import { storageIsDurable } from './config.ts';
import type { Db } from './db.ts';
import { kvGet, kvSet } from './db.ts';
import { audit, auditTx } from './audit.ts';
import type { FxService } from './fx.ts';
import { applyVerifiedPayment } from './ledger.ts';
import { HttpError, bad, base58Decode, base58Encode, errMessage, fetchWithTimeout, unavailable } from './util.ts';
import type { CryptoAsset, PublicQuote, RailState, WalletStatus } from '../shared/types.ts';

const LAMPORTS_PER_SOL = 1_000_000_000n;
const USDC_UNITS = 1_000_000n;
const UNDERPAY_TOLERANCE_PPM = 5_000n; // 0.5%
/** A quoted price is honoured until the quote expires, plus this much slack for slow blocks. */
const LATE_GRACE_MS = 120_000;
const RECHECK_MS = 4_000;
const WALLET_TTL_MS = 30_000;

interface WalletProof {
  address: string;
  cluster: string;
  method: 'signature' | 'onchain';
  at: number;
}

interface Challenge {
  address: string;
  message: string;
  expiresAt: number;
}

export interface QuoteTarget {
  kind: 'invoice' | 'order';
  refId: string;
  refLabel: string;
  asset: CryptoAsset;
  audCents: number;
}

export interface SolanaService {
  init(): Promise<void>;
  railState(): RailState;
  assets(): { sol: boolean; usdc: boolean };
  createQuote(target: QuoteTarget): Promise<PublicQuote>;
  checkRef(kind: 'invoice' | 'order', refId: string): Promise<'none' | 'seen' | 'paid'>;
  reconcile(): Promise<{ checked: number; paid: number; errors: number }>;
  walletStatus(force?: boolean): Promise<WalletStatus>;
  createChallenge(): Promise<{ message: string; address: string; expiresAt: number }>;
  verifyChallenge(signatureBase64: string): Promise<void>;
  createOnchainProof(): Promise<{ url: string; reference: string; expiresAt: number }>;
  checkOnchainProof(): Promise<boolean>;
}

export function verifyEd25519(publicKey: Uint8Array, message: Uint8Array, signature: Uint8Array): boolean {
  if (publicKey.length !== 32 || signature.length !== 64) return false;
  try {
    const key = createPublicKey({ key: { kty: 'OKP', crv: 'Ed25519', x: Buffer.from(publicKey).toString('base64url') }, format: 'jwk' });
    return cryptoVerify(null, message, key, signature);
  } catch {
    return false;
  }
}

export function formatUnits(base: bigint, decimals: number): string {
  const neg = base < 0n;
  const abs = neg ? -base : base;
  const div = 10n ** BigInt(decimals);
  const whole = abs / div;
  const frac = (abs % div).toString().padStart(decimals, '0').replace(/0+$/, '');
  return `${neg ? '-' : ''}${whole}${frac ? `.${frac}` : ''}`;
}

/** Net amount the recipient actually gained in this transaction, in base units. */
export function receivedBaseUnits(tx: any, recipient: string, asset: CryptoAsset, usdcMint: string): bigint {
  if (!tx || !tx.meta || tx.meta.err) return 0n;
  if (asset === 'SOL') {
    const keys: string[] = (tx.transaction?.message?.accountKeys ?? []).map((k: any) => (typeof k === 'string' ? k : k?.pubkey));
    const idx = keys.indexOf(recipient);
    if (idx < 0) return 0n;
    const pre = tx.meta.preBalances?.[idx];
    const post = tx.meta.postBalances?.[idx];
    if (pre === undefined || post === undefined) return 0n;
    return BigInt(post) - BigInt(pre);
  }
  const sum = (list: any[] | undefined): bigint => {
    let total = 0n;
    for (const b of list ?? []) {
      if (b?.owner === recipient && b?.mint === usdcMint) total += BigInt(b?.uiTokenAmount?.amount ?? '0');
    }
    return total;
  };
  return sum(tx.meta.postTokenBalances) - sum(tx.meta.preTokenBalances);
}

function isSigner(tx: any, address: string): boolean {
  const keys: any[] = tx?.transaction?.message?.accountKeys ?? [];
  return keys.some(k => typeof k === 'object' && k?.pubkey === address && k?.signer === true);
}

export function createSolanaService(db: Db, config: Config, fx: FxService, fetchImpl: typeof fetch): SolanaService {
  const live = config.mode === 'live';
  const address = config.solana.receiveAddress;
  const cluster = config.solana.cluster;
  let proof: WalletProof | null = null;
  let walletCache: WalletStatus | null = null;
  let rpcSeq = 0;

  async function rpc<T>(method: string, params: unknown[]): Promise<T> {
    const res = await fetchWithTimeout(
      fetchImpl,
      config.solana.rpcUrl,
      { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: ++rpcSeq, method, params }) },
      10_000
    );
    if (!res.ok) throw new Error(`Solana RPC returned HTTP ${res.status}`);
    const data: any = await res.json();
    if (data?.error) throw new Error(`Solana RPC error: ${data.error.message ?? 'unknown'}`);
    return data.result as T;
  }

  function proven(): boolean {
    if (!address) return false;
    if (config.solana.unprovenOk) return true;
    return !!proof && proof.address === address && proof.cluster === cluster;
  }

  function railState(): RailState {
    if (!address) return { enabled: false, reason: 'No receiving wallet is configured (SOLANA_RECEIVE_ADDRESS).' };
    if (!config.solana.addressValid) return { enabled: false, reason: 'SOLANA_RECEIVE_ADDRESS is not a valid Solana address.' };
    if (live !== (cluster === 'mainnet-beta')) return { enabled: false, reason: 'Solana cluster does not match the app mode (live needs mainnet, test needs devnet).' };
    if (live && !storageIsDurable(config)) return { enabled: false, reason: 'Live crypto payments need a persistent database. Set DATABASE_URL first.' };
    if (!config.solana.acceptSol && !config.solana.acceptUsdc) return { enabled: false, reason: 'Both SOL and USDC are switched off.' };
    if (!proven()) return { enabled: false, reason: 'The receiving wallet has not proven control yet. Do it once under Payouts → Wallet.' };
    return { enabled: true, reason: null };
  }

  function assets() {
    const on = railState().enabled;
    return { sol: on && config.solana.acceptSol, usdc: on && config.solana.acceptUsdc };
  }

  function payUrl(recipient: string, asset: CryptoAsset, amount: string, reference: string, message: string, memo: string): string {
    const params = new URLSearchParams();
    params.set('amount', amount);
    if (asset === 'USDC') params.set('spl-token', config.solana.usdcMint);
    params.set('reference', reference);
    params.set('label', config.business.brandName.slice(0, 60));
    params.set('message', message.slice(0, 120));
    params.set('memo', memo.slice(0, 60));
    // Solana Pay wants percent-encoding; URLSearchParams writes spaces as "+", which some wallets show literally.
    return `solana:${recipient}?${params.toString().replace(/\+/g, '%20')}`;
  }

  function toPublic(row: any, refLabel: string): PublicQuote {
    const asset = row.asset as CryptoAsset;
    const amount = formatUnits(BigInt(row.amount_base), asset === 'SOL' ? 9 : 6);
    return {
      asset,
      recipient: row.recipient,
      amount,
      reference: row.reference,
      url: payUrl(row.recipient, asset, amount, row.reference, refLabel, refLabel),
      audCents: Number(row.aud_cents),
      audPerUnit: Number(row.aud_per_unit),
      expiresAt: Number(row.expires_at),
      cluster,
    };
  }

  async function createQuote(target: QuoteTarget): Promise<PublicQuote> {
    const state = railState();
    if (!state.enabled || !address) throw unavailable(state.reason ?? 'Crypto payments are unavailable.', 'SOLANA_UNAVAILABLE');
    if (target.asset === 'SOL' ? !config.solana.acceptSol : !config.solana.acceptUsdc) throw bad(`${target.asset} is not accepted.`);
    if (!Number.isSafeInteger(target.audCents) || target.audCents < 100) throw bad('The amount owing is too small for a crypto payment (minimum $1).');

    const nowMs = Date.now();
    await db.query(`UPDATE sol_quotes SET status='expired' WHERE kind=$1 AND ref_id=$2 AND status='open' AND expires_at <= $3`, [
      target.kind,
      target.refId,
      nowMs - 6 * 3600_000,
    ]);

    // Same amount, same asset, still valid → hand back the existing quote.
    const existing = await db.query(
      `SELECT * FROM sol_quotes WHERE kind=$1 AND ref_id=$2 AND asset=$3 AND aud_cents=$4 AND status='open' AND expires_at > $5 AND recipient=$6
        ORDER BY created_at DESC LIMIT 1`,
      [target.kind, target.refId, target.asset, target.audCents, nowMs + 60_000, address]
    );
    if (existing.rows.length) return toPublic(existing.rows[0], target.refLabel);

    const open = await db.query(`SELECT COUNT(*)::int AS n FROM sol_quotes WHERE kind=$1 AND ref_id=$2 AND status='open' AND created_at > $3`, [
      target.kind,
      target.refId,
      nowMs - 3600_000,
    ]);
    if (Number(open.rows[0].n) >= 12) throw new HttpError(429, 'TOO_MANY_QUOTES', 'Too many quotes requested for this payment. Try again in a few minutes.');

    let rates;
    try {
      rates = await fx.getRates();
    } catch (err) {
      throw unavailable(errMessage(err), 'FX_UNAVAILABLE');
    }
    const audPerUnit = target.asset === 'SOL' ? rates.audPerSol : rates.audPerUsdc;
    const units = target.audCents / 100 / audPerUnit;
    let base: bigint;
    // Round UP so rounding never leaves the invoice short — to 0.00001 SOL or
    // one cent of USDC. The tiny epsilon stops floating-point noise such as
    // 100.00000000000001 from being rounded up a whole step.
    const steps = target.asset === 'SOL' ? (units * 1e9) / 10_000 : (units * 1e6) / 10_000;
    base = BigInt(Math.ceil(steps - 1e-7)) * 10_000n;
    if (base <= 0n) throw unavailable('Could not price this payment.', 'FX_UNAVAILABLE');

    const reference = base58Encode(randomBytes(32));
    const row = {
      reference,
      kind: target.kind,
      ref_id: target.refId,
      asset: target.asset,
      amount_base: base.toString(),
      aud_cents: target.audCents,
      aud_per_unit: audPerUnit,
      recipient: address,
      expires_at: nowMs + config.solana.quoteTtlMs,
    };
    await db.query(
      `INSERT INTO sol_quotes (reference, kind, ref_id, asset, amount_base, aud_cents, aud_per_unit, recipient, status, livemode, created_at, expires_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'open',$9,$10,$11)`,
      [row.reference, row.kind, row.ref_id, row.asset, row.amount_base, row.aud_cents, row.aud_per_unit, row.recipient, live, nowMs, row.expires_at]
    );
    return toPublic(row, target.refLabel);
  }

  /** Look on-chain for a payment carrying this quote's reference. */
  async function checkQuote(row: any, force = false): Promise<'none' | 'seen' | 'paid'> {
    if (row.status === 'paid') return 'paid';
    const nowMs = Date.now();
    if (!force && nowMs - Number(row.checked_at) < RECHECK_MS) return 'none';
    await db.query('UPDATE sol_quotes SET checked_at = $2 WHERE reference = $1', [row.reference, nowMs]);

    const sigs = await rpc<any[]>('getSignaturesForAddress', [row.reference, { limit: 10, commitment: 'confirmed' }]);
    if (!Array.isArray(sigs) || sigs.length === 0) return 'none';

    let outcome: 'none' | 'seen' | 'paid' = 'none';
    for (const s of sigs) {
      if (!s || s.err || typeof s.signature !== 'string') continue;
      if (s.confirmationStatus !== 'finalized') {
        outcome = outcome === 'paid' ? 'paid' : 'seen';
        continue;
      }
      const tx = await rpc<any>('getTransaction', [s.signature, { encoding: 'jsonParsed', commitment: 'finalized', maxSupportedTransactionVersion: 0 }]);
      if (!tx) {
        outcome = outcome === 'paid' ? 'paid' : 'seen';
        continue;
      }
      const got = receivedBaseUnits(tx, row.recipient, row.asset, config.solana.usdcMint);
      if (got <= 0n) continue; // carries the reference but paid us nothing

      const required = BigInt(row.amount_base);
      const quoteCents = BigInt(row.aud_cents);
      const enough = got * 1_000_000n >= required * (1_000_000n - UNDERPAY_TOLERANCE_PPM);
      let creditCents = Number(enough ? quoteCents : (quoteCents * got) / required);
      const occurredAt = typeof tx.blockTime === 'number' ? tx.blockTime * 1000 : nowMs;

      // The price was only promised until the quote ran out. Someone who waits
      // for the coin to fall and then pays the old amount must not be credited
      // the old dollars: after expiry, credit what the coins are worth now,
      // and never more than was quoted.
      const late = occurredAt > Number(row.expires_at) + LATE_GRACE_MS;
      let repricedAudPerUnit: number | null = null;
      if (late) {
        let rates;
        try {
          rates = await fx.getRates();
        } catch {
          outcome = outcome === 'paid' ? 'paid' : 'seen'; // no price right now — look again next cycle
          continue;
        }
        const per = row.asset === 'SOL' ? rates.audPerSol : rates.audPerUsdc;
        const worthCents = Math.floor((Number(got) / (row.asset === 'SOL' ? 1e9 : 1e6)) * per * 100);
        if (BigInt(worthCents) * 1_000_000n < BigInt(creditCents) * (1_000_000n - UNDERPAY_TOLERANCE_PPM)) {
          creditCents = worthCents;
          repricedAudPerUnit = per;
        }
      }
      if (creditCents <= 0) continue;

      const label = await refLabel(row.kind, row.ref_id);
      const credited = await db.tx(async q => {
        const rec = await applyVerifiedPayment(q, {
          proofId: `sol:${s.signature}`,
          rail: 'solana',
          kind: row.kind,
          invoiceId: row.kind === 'invoice' ? row.ref_id : null,
          orderId: row.kind === 'order' ? row.ref_id : null,
          amountCents: creditCents,
          livemode: live,
          payer: firstSigner(tx),
          detail: {
            signature: s.signature,
            slot: tx.slot ?? s.slot ?? null,
            asset: row.asset,
            received: formatUnits(got, row.asset === 'SOL' ? 9 : 6),
            quoted: formatUnits(required, row.asset === 'SOL' ? 9 : 6),
            audPerUnit: Number(row.aud_per_unit),
            reference: row.reference,
            underpaid: !enough,
            late,
            ...(repricedAudPerUnit !== null ? { repricedAudPerUnit } : {}),
          },
          occurredAt,
          refLabel: label,
        });
        // One transaction can settle one quote. If this signature was already
        // credited against a different reference, it does not count here.
        const mine = rec.inserted || rec.payment.detail?.reference === row.reference;
        if (mine) {
          await q(`UPDATE sol_quotes SET status='paid', signature=$2 WHERE reference=$1`, [row.reference, s.signature]);
        }
        return mine;
      });
      if (credited) outcome = 'paid';
    }
    return outcome;
  }

  function firstSigner(tx: any): string | null {
    const keys: any[] = tx?.transaction?.message?.accountKeys ?? [];
    const k = keys.find(x => typeof x === 'object' && x?.signer === true);
    return k?.pubkey ?? null;
  }

  async function refLabel(kind: string, refId: string): Promise<string> {
    if (kind === 'invoice') {
      const r = await db.query('SELECT number FROM invoices WHERE id = $1', [refId]);
      return r.rows[0]?.number ?? refId;
    }
    const r = await db.query('SELECT product_title FROM orders WHERE id = $1', [refId]);
    return r.rows[0]?.product_title ?? refId;
  }

  async function checkRef(kind: 'invoice' | 'order', refId: string): Promise<'none' | 'seen' | 'paid'> {
    if (!railState().enabled) return 'none';
    const { rows } = await db.query(
      `SELECT * FROM sol_quotes WHERE kind=$1 AND ref_id=$2 AND status='open' AND livemode=$3 AND created_at > $4 ORDER BY created_at DESC LIMIT 4`,
      [kind, refId, live, Date.now() - 24 * 3600_000]
    );
    let best: 'none' | 'seen' | 'paid' = 'none';
    for (const row of rows) {
      const r = await checkQuote(row);
      if (r === 'paid') return 'paid';
      if (r === 'seen') best = 'seen';
    }
    return best;
  }

  async function reconcile() {
    if (!railState().enabled) return { checked: 0, paid: 0, errors: 0 };
    const nowMs = Date.now();
    // Keep watching a quote for 24h after it was issued: people pay late.
    const { rows } = await db.query(
      `SELECT * FROM sol_quotes WHERE status='open' AND kind IN ('invoice','order') AND livemode=$1 AND created_at > $2 ORDER BY checked_at ASC LIMIT 20`,
      [live, nowMs - 24 * 3600_000]
    );
    let paid = 0;
    let errors = 0;
    for (const row of rows) {
      try {
        if ((await checkQuote(row, true)) === 'paid') paid++;
      } catch (err) {
        errors++;
        console.error('[solana] reconcile error:', errMessage(err));
        break; // most likely RPC rate limiting — stop and try again next cycle
      }
    }
    await db.query(`UPDATE sol_quotes SET status='expired' WHERE status='open' AND created_at <= $1`, [nowMs - 24 * 3600_000]);
    return { checked: rows.length, paid, errors };
  }

  // ── wallet status & proof of control ────────────────────────────────────
  async function walletStatus(force = false): Promise<WalletStatus> {
    const nowMs = Date.now();
    if (!force && walletCache && nowMs - walletCache.fetchedAt < WALLET_TTL_MS) return walletCache;
    const hasProof = !!proof && proof.address === address && proof.cluster === cluster;
    const st: WalletStatus = {
      configured: !!address,
      address,
      cluster,
      addressValid: config.solana.addressValid,
      proven: proven(),
      proofMethod: hasProof ? proof!.method : config.solana.unprovenOk && address ? 'override' : null,
      provenAt: hasProof ? proof!.at : null,
      sol: null,
      usdc: null,
      audValueCents: null,
      error: null,
      explorerUrl: address && config.solana.addressValid ? `https://solscan.io/account/${address}${cluster === 'devnet' ? '?cluster=devnet' : ''}` : null,
      fetchedAt: nowMs,
    };
    if (address && config.solana.addressValid) {
      try {
        const bal = await rpc<any>('getBalance', [address, { commitment: 'confirmed' }]);
        st.sol = Number(BigInt(bal?.value ?? 0)) / Number(LAMPORTS_PER_SOL);
        const tok = await rpc<any>('getTokenAccountsByOwner', [address, { mint: config.solana.usdcMint }, { encoding: 'jsonParsed', commitment: 'confirmed' }]);
        let usdc = 0n;
        for (const acc of tok?.value ?? []) usdc += BigInt(acc?.account?.data?.parsed?.info?.tokenAmount?.amount ?? '0');
        st.usdc = Number(usdc) / Number(USDC_UNITS);
        const rates = fx.peek() ?? (await fx.getRates().catch(() => null));
        if (rates) st.audValueCents = Math.round((st.sol * rates.audPerSol + st.usdc * rates.audPerUsdc) * 100);
      } catch (err) {
        st.error = errMessage(err);
      }
    }
    walletCache = st;
    return st;
  }

  async function setProof(method: WalletProof['method']): Promise<void> {
    proof = { address: address!, cluster, method, at: Date.now() };
    walletCache = null;
    await db.tx(async q => {
      await kvSet(q, 'wallet_proof', proof);
      await auditTx(q, { actor: 'director', action: 'wallet.proven', detail: { address, cluster, method } });
    });
  }

  function requireAddress(): string {
    if (!address || !config.solana.addressValid) throw bad('Set a valid SOLANA_RECEIVE_ADDRESS on the server first.', 'NO_WALLET');
    return address;
  }

  async function createChallenge() {
    const addr = requireAddress();
    const expiresAt = Date.now() + 10 * 60_000;
    const message = [
      // Plain ASCII on purpose: every wallet displays and signs it the same way.
      `${config.business.brandName.replace(/[^\x20-\x7E]/g, '?')} FLASH - prove wallet control`,
      `Wallet: ${addr}`,
      `Nonce: ${randomBytes(16).toString('hex')}`,
      `Issued: ${new Date().toISOString()}`,
      'Signing this message is free and cannot move funds.',
    ].join('\n');
    const challenge: Challenge = { address: addr, message, expiresAt };
    await kvSet(db.query, 'wallet_challenge', challenge);
    return { message, address: addr, expiresAt };
  }

  async function verifyChallenge(signatureBase64: string): Promise<void> {
    const addr = requireAddress();
    const challenge = await kvGet<Challenge>(db.query, 'wallet_challenge');
    if (!challenge || challenge.address !== addr || challenge.expiresAt < Date.now()) {
      throw bad('The verification message expired. Start again.', 'CHALLENGE_EXPIRED');
    }
    const sig = Buffer.from(signatureBase64, 'base64');
    const pub = base58Decode(addr)!;
    const ok = verifyEd25519(pub, Buffer.from(challenge.message, 'utf8'), sig);
    // Single use, whatever the result.
    await kvSet(db.query, 'wallet_challenge', { address: '', message: '', expiresAt: 0 });
    if (!ok) {
      await audit(db, { actor: 'director', action: 'wallet.proof_failed', detail: { address: addr, method: 'signature' } });
      throw new HttpError(
        400,
        'BAD_SIGNATURE',
        'That signature does not belong to the configured wallet. Make sure the wallet you connected is exactly the address shown — check every character.'
      );
    }
    await setProof('signature');
  }

  async function createOnchainProof() {
    const addr = requireAddress();
    const nowMs = Date.now();
    await db.query(`UPDATE sol_quotes SET status='expired' WHERE kind='proof' AND status='open'`);
    const reference = base58Encode(randomBytes(32));
    const expiresAt = nowMs + 30 * 60_000;
    await db.query(
      `INSERT INTO sol_quotes (reference, kind, ref_id, asset, amount_base, aud_cents, aud_per_unit, recipient, status, livemode, created_at, expires_at)
       VALUES ($1,'proof',$2,'SOL','1000',0,0,$2,'open',$3,$4,$5)`,
      [reference, addr, live, nowMs, expiresAt]
    );
    // A 0.000001 SOL transfer from the wallet to itself, tagged with our reference.
    const url = payUrl(addr, 'SOL', '0.000001', reference, 'Prove wallet control', 'FLASH wallet proof');
    return { url, reference, expiresAt };
  }

  async function checkOnchainProof(): Promise<boolean> {
    const addr = requireAddress();
    const { rows } = await db.query(`SELECT * FROM sol_quotes WHERE kind='proof' AND ref_id=$1 AND status='open' AND expires_at > $2 ORDER BY created_at DESC LIMIT 1`, [
      addr,
      Date.now(),
    ]);
    if (rows.length === 0) return false;
    const row = rows[0];
    const sigs = await rpc<any[]>('getSignaturesForAddress', [row.reference, { limit: 5, commitment: 'finalized' }]);
    for (const s of sigs ?? []) {
      if (!s || s.err) continue;
      const tx = await rpc<any>('getTransaction', [s.signature, { encoding: 'jsonParsed', commitment: 'finalized', maxSupportedTransactionVersion: 0 }]);
      // The configured address must have SIGNED this transaction: only its owner can do that.
      if (tx && !tx.meta?.err && isSigner(tx, addr)) {
        await db.query(`UPDATE sol_quotes SET status='paid', signature=$2 WHERE reference=$1`, [row.reference, s.signature]);
        await setProof('onchain');
        return true;
      }
    }
    return false;
  }

  return {
    async init() {
      proof = await kvGet<WalletProof>(db.query, 'wallet_proof');
    },
    railState,
    assets,
    createQuote,
    checkRef,
    reconcile,
    walletStatus,
    createChallenge,
    verifyChallenge,
    createOnchainProof,
    checkOnchainProof,
  };
}
