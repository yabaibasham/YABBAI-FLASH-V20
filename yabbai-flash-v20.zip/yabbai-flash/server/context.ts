import type { Request } from 'express';
import type { AiService } from './ai.ts';
import type { Autopilot } from './autopilot.ts';
import type { Config } from './config.ts';
import type { Council } from './council.ts';
import type { Db } from './db.ts';
import type { FxService } from './fx.ts';
import type { MarketsService } from './markets.ts';
import type { NetworkService } from './network.ts';
import type { SolanaService } from './solana.ts';
import type { StripeService } from './stripe.ts';

/** Everything a route handler needs. Built once in server.ts. */
export interface Ctx {
  db: Db;
  config: Config;
  stripe: StripeService;
  solana: SolanaService;
  fx: FxService;
  ai: AiService;
  markets: MarketsService;
  autopilot: Autopilot;
  /** Linked apps and the reachability check. */
  network: NetworkService;
  /** The seats, the router and the session runner. Writes text; has no tools. */
  council: Council;
  /** The public origin of this app, e.g. https://flash.example.com */
  baseUrl(req?: Request): string;
}

/**
 * In production the address comes from configuration only. The Host header is
 * whatever the caller typed, and a payment page must never send a customer
 * "back" to an address a stranger chose. Outside production (local runs,
 * tests) the request's own host is a convenient fallback.
 */
export function resolveBaseUrl(config: Config, req?: Request): string {
  if (config.publicBaseUrl) return config.publicBaseUrl;
  if (req && !config.isProd) {
    const host = req.get('host');
    if (host && /^[A-Za-z0-9.\-:[\]]+$/.test(host)) return `${req.protocol}://${host}`;
  }
  if (req && config.isProd) {
    // Shown to the signed-in director only, so the console still works while PUBLIC_BASE_URL is being set up.
    const host = req.get('host');
    if (req.flashSession && host && /^[A-Za-z0-9.\-:[\]]+$/.test(host)) return `${req.protocol}://${host}`;
  }
  return `http://localhost:${config.port}`;
}
