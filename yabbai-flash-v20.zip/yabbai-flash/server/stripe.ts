/**
 * Stripe: card / wallet payments in, automatic payouts to your bank out.
 *
 * How money is proven here:
 *  1. The server creates the Checkout Session itself, with the amount taken
 *     from its own database — the browser never supplies a price.
 *  2. A webhook is accepted only if Stripe's signature verifies against the
 *     raw request body.
 *  3. Even then the event is treated as a hint. The server re-fetches the
 *     session from Stripe's API with its own key and credits only what that
 *     says: paid, the right amount, AUD, the right mode, our own metadata.
 *  4. The credit is keyed on the PaymentIntent id, so replays change nothing.
 *
 * What this module deliberately cannot do: create payouts, issue refunds, or
 * change the bank account. Payouts are Stripe's own automatic schedule to the
 * account set in the Stripe Dashboard. Use a restricted key so that even a
 * leaked key cannot move money.
 */
import Stripe from 'stripe';
import type { Config } from './config.ts';
import { storageIsDurable } from './config.ts';
import type { Db } from './db.ts';
import { audit, auditTx } from './audit.ts';
import { applyVerifiedPayment } from './ledger.ts';
import { HttpError, errMessage, unavailable } from './util.ts';
import type { RailState, StripeStatus } from '../shared/types.ts';

export interface CheckoutTarget {
  kind: 'invoice' | 'order';
  refId: string;
  refLabel: string;
  title: string;
  amountCents: number;
  email: string | null;
  successUrl: string;
  cancelUrl: string;
}

export interface StripeService {
  railState(): RailState;
  createCheckout(target: CheckoutTarget): Promise<{ url: string; sessionId: string; reused: boolean }>;
  handleWebhook(rawBody: Buffer, signatureHeader: string | undefined): Promise<{ status: number; body: Record<string, unknown> }>;
  settleSession(sessionId: string, source: string): Promise<'paid' | 'pending' | 'expired' | 'rejected' | 'unknown'>;
  reconcile(): Promise<{ checked: number; paid: number; errors: number }>;
  status(force?: boolean): Promise<StripeStatus>;
  lastStatus(): StripeStatus | null;
}

const STATUS_TTL_MS = 60_000;
const MIN_CHARGE_CENTS = 50; // Stripe's minimum for AUD

export function createStripeService(db: Db, config: Config): StripeService {
  const expectLive = config.mode === 'live';
  let client: Stripe | null = null;
  let cached: StripeStatus | null = null;

  function stripe(): Stripe {
    if (!config.stripe.secretKey) throw unavailable('Card payments are not connected.', 'STRIPE_OFF');
    if (!client) {
      client = new Stripe(config.stripe.secretKey, {
        maxNetworkRetries: 2,
        timeout: 15_000,
        telemetry: false,
        appInfo: { name: 'yabbai-flash', version: '19.0.0' },
        ...(config.stripe.apiHost
          ? { host: config.stripe.apiHost, port: config.stripe.apiPort ?? undefined, protocol: config.stripe.apiProtocol }
          : {}),
      });
    }
    return client;
  }

  function railState(): RailState {
    if (!config.stripe.secretKey) return { enabled: false, reason: 'Stripe is not connected (STRIPE_SECRET_KEY is not set).' };
    if (expectLive && !storageIsDurable(config)) {
      return { enabled: false, reason: 'Live card payments need a persistent database. Set DATABASE_URL first.' };
    }
    if (config.isProd && (!config.publicBaseUrl || !config.publicBaseUrl.startsWith('https://'))) {
      return { enabled: false, reason: 'PUBLIC_BASE_URL must be set to your https address, so customers are sent back to the right place after paying.' };
    }
    if (cached && cached.reachable && cached.chargesEnabled === false) {
      return { enabled: false, reason: 'Your Stripe account is not activated for payments yet. Finish activation in the Stripe Dashboard.' };
    }
    return { enabled: true, reason: null };
  }

  async function createCheckout(target: CheckoutTarget) {
    const state = railState();
    if (!state.enabled) throw unavailable(state.reason ?? 'Card payments are unavailable.', 'STRIPE_UNAVAILABLE');
    if (!Number.isSafeInteger(target.amountCents) || target.amountCents < MIN_CHARGE_CENTS) {
      throw new HttpError(400, 'AMOUNT_TOO_SMALL', 'The amount owing is below the card minimum of $0.50.');
    }

    // Reuse a recent open session for the same amount instead of minting a new one per click.
    const nowMs = Date.now();
    const existing = await db.query(
      `SELECT session_id, url FROM stripe_sessions
        WHERE kind = $1 AND ref_id = $2 AND status = 'open' AND amount_cents = $3 AND livemode = $4 AND created_at > $5 AND url IS NOT NULL
        ORDER BY created_at DESC LIMIT 1`,
      [target.kind, target.refId, target.amountCents, expectLive, nowMs - 20 * 3600_000]
    );
    if (existing.rows.length) return { url: String(existing.rows[0].url), sessionId: String(existing.rows[0].session_id), reused: true };

    const meta = { flash_kind: target.kind, flash_ref: target.refId };
    let session: Stripe.Checkout.Session;
    try {
      session = await stripe().checkout.sessions.create(
        {
          mode: 'payment',
          line_items: [
            {
              quantity: 1,
              price_data: { currency: 'aud', unit_amount: target.amountCents, product_data: { name: target.title.slice(0, 120) } },
            },
          ],
          client_reference_id: target.refId,
          metadata: meta,
          payment_intent_data: { metadata: meta, description: target.title.slice(0, 200) },
          ...(target.email ? { customer_email: target.email } : {}),
          success_url: target.successUrl,
          cancel_url: target.cancelUrl,
        },
        { idempotencyKey: `flash:${target.kind}:${target.refId}:${target.amountCents}:${Math.floor(nowMs / 60_000)}` }
      );
    } catch (err) {
      await audit(db, { actor: 'stripe', action: 'checkout.create_failed', detail: { ref: target.refLabel, error: errMessage(err) } });
      throw unavailable('Card checkout could not be started. Please try another payment method or try again shortly.', 'STRIPE_ERROR');
    }
    if (!session.url || session.livemode !== expectLive) {
      throw unavailable('Card checkout could not be started.', 'STRIPE_ERROR');
    }

    await db.query(
      `INSERT INTO stripe_sessions (session_id, kind, ref_id, amount_cents, url, status, livemode, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,'open',$6,$7,$7)
       ON CONFLICT (session_id) DO NOTHING`,
      [session.id, target.kind, target.refId, target.amountCents, session.url, expectLive, nowMs]
    );
    return { url: session.url, sessionId: session.id, reused: false };
  }

  async function settleSession(sessionId: string, source: string) {
    const found = await db.query('SELECT * FROM stripe_sessions WHERE session_id = $1', [sessionId]);
    if (found.rows.length === 0) return 'unknown' as const; // not one of ours — never credited
    const row = found.rows[0];
    if (row.status === 'paid') return 'paid' as const;
    if (row.status === 'rejected') return 'rejected' as const;

    // Source of truth: Stripe's API, asked directly with our own key.
    const s = await stripe().checkout.sessions.retrieve(sessionId);

    const problems: string[] = [];
    if (s.id !== sessionId) problems.push('id');
    if (s.livemode !== expectLive) problems.push('livemode');
    if (s.mode !== 'payment') problems.push('mode');
    if ((s.currency ?? '').toLowerCase() !== 'aud') problems.push('currency');
    if (s.amount_total !== Number(row.amount_cents)) problems.push('amount');
    if (s.metadata?.flash_ref !== row.ref_id || s.metadata?.flash_kind !== row.kind) problems.push('metadata');
    if (problems.length) {
      await db.tx(async q => {
        await q(`UPDATE stripe_sessions SET status='rejected', updated_at=$2 WHERE session_id=$1`, [sessionId, Date.now()]);
        await auditTx(q, { actor: 'stripe', action: 'payment.rejected', detail: { sessionId, problems, source } });
      });
      return 'rejected' as const;
    }

    if (s.payment_status !== 'paid') {
      if (s.status === 'expired') {
        await db.query(`UPDATE stripe_sessions SET status='expired', updated_at=$2 WHERE session_id=$1 AND status='open'`, [sessionId, Date.now()]);
        return 'expired' as const;
      }
      return 'pending' as const;
    }

    const paymentIntent = typeof s.payment_intent === 'string' ? s.payment_intent : (s.payment_intent?.id ?? null);
    const payer = s.customer_details?.email ?? s.customer_email ?? null;
    const label = await refLabel(row.kind, row.ref_id);

    await db.tx(async q => {
      await applyVerifiedPayment(q, {
        proofId: `stripe:${paymentIntent ?? s.id}`,
        rail: 'stripe',
        kind: row.kind,
        invoiceId: row.kind === 'invoice' ? row.ref_id : null,
        orderId: row.kind === 'order' ? row.ref_id : null,
        amountCents: Number(row.amount_cents),
        livemode: expectLive,
        payer,
        detail: { sessionId: s.id, paymentIntent, source },
        occurredAt: (s.created ?? Math.floor(Date.now() / 1000)) * 1000,
        refLabel: label,
      });
      await q(`UPDATE stripe_sessions SET status='paid', updated_at=$2 WHERE session_id=$1`, [sessionId, Date.now()]);
    });
    return 'paid' as const;
  }

  async function refLabel(kind: string, refId: string): Promise<string> {
    if (kind === 'invoice') {
      const r = await db.query('SELECT number FROM invoices WHERE id = $1', [refId]);
      return r.rows[0]?.number ?? refId;
    }
    const r = await db.query('SELECT product_title FROM orders WHERE id = $1', [refId]);
    return r.rows[0]?.product_title ?? refId;
  }

  /** Refund / dispute markers. The payload is trusted because its signature verified. */
  async function applyRefund(obj: any): Promise<void> {
    const pi = typeof obj.payment_intent === 'string' ? obj.payment_intent : obj.payment_intent?.id;
    const refunded = Number(obj.amount_refunded);
    if (!pi || !Number.isFinite(refunded) || refunded < 0) return;
    await db.tx(async q => {
      const res = await q(
        `UPDATE payments SET refunded_cents = LEAST(amount_cents, GREATEST(refunded_cents, $2))
          WHERE proof_id = $1 RETURNING id, order_id, amount_cents, refunded_cents`,
        [`stripe:${pi}`, Math.round(refunded)]
      );
      if (res.rows.length === 0) return;
      const p = res.rows[0];
      if (p.order_id && Number(p.refunded_cents) >= Number(p.amount_cents)) {
        await q(`UPDATE orders SET status='refunded' WHERE id=$1`, [p.order_id]);
      }
      await auditTx(q, { actor: 'stripe', action: 'payment.refunded', detail: { paymentIntent: pi, refundedCents: Number(p.refunded_cents) } });
    });
  }

  async function applyDispute(obj: any, type: string): Promise<void> {
    const pi = typeof obj.payment_intent === 'string' ? obj.payment_intent : obj.payment_intent?.id;
    if (!pi) return;
    const lost = type === 'charge.dispute.closed' && obj.status === 'lost';
    const cleared = type === 'charge.dispute.closed' && obj.status !== 'lost';
    await db.tx(async q => {
      const res = await q(
        `UPDATE payments SET disputed = $2::boolean, refunded_cents = CASE WHEN $3::boolean THEN amount_cents ELSE refunded_cents END
          WHERE proof_id = $1 RETURNING id, order_id`,
        [`stripe:${pi}`, !cleared, lost]
      );
      if (res.rows.length) {
        // A lost dispute takes the money back, so the order is no longer paid for.
        if (lost && res.rows[0].order_id) await q(`UPDATE orders SET status='refunded' WHERE id=$1`, [res.rows[0].order_id]);
        await auditTx(q, { actor: 'stripe', action: `payment.${type.replace('charge.', '').replace('.', '_')}`, detail: { paymentIntent: pi, status: obj.status ?? null } });
      }
    });
  }

  async function handleWebhook(rawBody: Buffer, signatureHeader: string | undefined) {
    if (!config.stripe.secretKey || !config.stripe.webhookSecret) {
      return { status: 503, body: { error: 'Stripe webhooks are not configured.' } };
    }
    if (!signatureHeader || !Buffer.isBuffer(rawBody) || rawBody.length === 0) {
      return { status: 400, body: { error: 'Missing signature.' } };
    }

    let event: Stripe.Event;
    try {
      event = stripe().webhooks.constructEvent(rawBody, signatureHeader, config.stripe.webhookSecret);
    } catch {
      await audit(db, { actor: 'public', action: 'webhook.bad_signature', detail: { bytes: rawBody.length } });
      return { status: 400, body: { error: 'Signature verification failed.' } };
    }

    if (event.livemode !== expectLive) {
      await audit(db, { actor: 'stripe', action: 'webhook.wrong_mode', detail: { id: event.id, type: event.type, livemode: event.livemode } });
      return { status: 200, body: { received: true, ignored: 'mode' } };
    }

    const seen = await db.query('SELECT 1 FROM processed_events WHERE event_id = $1', [event.id]);
    if (seen.rows.length) return { status: 200, body: { received: true, duplicate: true } };

    const obj: any = event.data.object;
    try {
      switch (event.type) {
        case 'checkout.session.completed':
        case 'checkout.session.async_payment_succeeded':
        case 'checkout.session.async_payment_failed':
        case 'checkout.session.expired':
          await settleSession(String(obj.id), `webhook:${event.type}`);
          break;
        case 'charge.refunded':
          await applyRefund(obj);
          break;
        case 'charge.dispute.created':
        case 'charge.dispute.closed':
          await applyDispute(obj, event.type);
          break;
        case 'payout.paid':
        case 'payout.failed':
          cached = null;
          await audit(db, {
            actor: 'stripe',
            action: event.type === 'payout.paid' ? 'payout.paid' : 'payout.failed',
            detail: { id: obj.id, amountCents: obj.amount, arrivalDate: obj.arrival_date, failure: obj.failure_message ?? null },
          });
          break;
        default:
          break; // not something we act on
      }
    } catch (err) {
      // Let Stripe retry: nothing is marked processed.
      console.error('[stripe] webhook handling failed:', errMessage(err));
      return { status: 500, body: { error: 'Temporary failure, please retry.' } };
    }

    await db.query('INSERT INTO processed_events (event_id, type, received_at) VALUES ($1,$2,$3) ON CONFLICT (event_id) DO NOTHING', [
      event.id,
      event.type,
      Date.now(),
    ]);
    return { status: 200, body: { received: true } };
  }

  /** Safety net for missed webhooks: ask Stripe about every session still open. */
  async function reconcile() {
    if (!config.stripe.secretKey) return { checked: 0, paid: 0, errors: 0 };
    const { rows } = await db.query(
      `SELECT session_id FROM stripe_sessions WHERE status = 'open' AND livemode = $1 AND created_at > $2 ORDER BY created_at DESC LIMIT 40`,
      [expectLive, Date.now() - 30 * 3600_000]
    );
    let paid = 0;
    let errors = 0;
    for (const r of rows) {
      try {
        if ((await settleSession(String(r.session_id), 'reconcile')) === 'paid') paid++;
      } catch (err) {
        errors++;
        console.error('[stripe] reconcile error:', errMessage(err));
      }
    }
    // Sessions Stripe has long since expired.
    await db.query(`UPDATE stripe_sessions SET status='expired', updated_at=$1 WHERE status='open' AND created_at <= $2`, [
      Date.now(),
      Date.now() - 30 * 3600_000,
    ]);
    return { checked: rows.length, paid, errors };
  }

  async function status(force = false): Promise<StripeStatus> {
    const nowMs = Date.now();
    if (!force && cached && nowMs - cached.fetchedAt < STATUS_TTL_MS) return cached;

    const base: StripeStatus = {
      configured: !!config.stripe.secretKey,
      mode: config.stripe.keyMode,
      reachable: false,
      error: null,
      chargesEnabled: null,
      payoutsEnabled: null,
      detailsSubmitted: null,
      requirementsDue: [],
      disabledReason: null,
      payoutDestination: null,
      payoutSchedule: null,
      availableCents: null,
      pendingCents: null,
      payouts: [],
      fetchedAt: nowMs,
    };
    if (!config.stripe.secretKey) {
      cached = base;
      return base;
    }

    const errors: string[] = [];
    const [account, balance, payouts] = await Promise.allSettled([
      stripe().accounts.retrieveCurrent(),
      stripe().balance.retrieve(),
      stripe().payouts.list({ limit: 10 }),
    ]);

    if (account.status === 'fulfilled') {
      const a: any = account.value;
      base.reachable = true;
      base.chargesEnabled = a.charges_enabled === true;
      base.payoutsEnabled = a.payouts_enabled === true;
      base.detailsSubmitted = a.details_submitted === true;
      base.requirementsDue = [...new Set<string>([...(a.requirements?.past_due ?? []), ...(a.requirements?.currently_due ?? [])])];
      base.disabledReason = a.requirements?.disabled_reason ?? null;
      const ext = a.external_accounts?.data?.[0];
      if (ext) base.payoutDestination = `${ext.bank_name ?? ext.brand ?? 'Account'} ••••${ext.last4 ?? '????'}`;
      const sched = a.settings?.payouts?.schedule;
      if (sched) base.payoutSchedule = `${sched.interval}${typeof sched.delay_days === 'number' ? `, ${sched.delay_days}-day rolling` : ''}`;
    } else errors.push(`account: ${errMessage(account.reason)}`);

    if (balance.status === 'fulfilled') {
      base.reachable = true;
      const sum = (list: any[] | undefined) => (list ?? []).filter(b => b.currency === 'aud').reduce((n, b) => n + Number(b.amount), 0);
      base.availableCents = sum(balance.value.available as any[]);
      base.pendingCents = sum(balance.value.pending as any[]);
    } else errors.push(`balance: ${errMessage(balance.reason)}`);

    if (payouts.status === 'fulfilled') {
      base.reachable = true;
      base.payouts = payouts.value.data.map((p: any) => ({
        id: p.id,
        amountCents: Number(p.amount),
        status: String(p.status),
        arrivalDate: Number(p.arrival_date) * 1000,
        method: String(p.method ?? 'standard'),
        failureMessage: p.failure_message ?? null,
      }));
    } else errors.push(`payouts: ${errMessage(payouts.reason)}`);

    base.error = errors.length ? errors.join(' · ') : null;
    cached = base;
    return base;
  }

  return { railState, createCheckout, handleWebhook, settleSession, reconcile, status, lastStatus: () => cached };
}
