/**
 * The council: one brain, several seats.
 *
 * A question goes to three to five seats (see seats.ts for who they are and
 * what each is allowed to see). Each seat answers alone, from its own slice of
 * the records. The Skeptic then checks those answers against the records, and
 * one last call merges everything into a single verdict for the director.
 *
 * What a session is: rows of text in two tables. Opinions, a check, a verdict.
 * What a session is not: an action. Nothing here calls Stripe, the chain, an
 * email service or any other module that changes a record. The only thing a
 * verdict can lead to is the director reading it and pressing a button
 * somewhere else in the console, themselves.
 *
 * How it grows: the director rules on a verdict (accepted, rejected, noted),
 * and may keep a one-line lesson. Past rulings and active lessons are handed
 * to later sessions. See lessons.ts for why a lesson needs the password.
 *
 * Why several seats and not one long prompt: a seat that sees only its own
 * records cannot lean on another seat's answer, so when two of them agree it
 * means something. And why a Skeptic: several confident paragraphs are still
 * only as good as the records behind them. Agreement is not proof.
 */
import type { AiService } from './ai.ts';
import { fence, fenceNotes } from './ai.ts';
import { auditTx } from './audit.ts';
import type { Config } from './config.ts';
import type { Db } from './db.ts';
import { activeLessonsFor, proposeLesson } from './lessons.ts';
import { SEATS, directorPicks, memoSources, routeQuestion, seatById } from './seats.ts';
import type { SeatDef, SeatSources } from './seats.ts';
import { HttpError, errMessage, newId, notFound } from './util.ts';
import type { CouncilDecision, CouncilOpinion, CouncilSession, RoutePlan, SeatId, SeatInfo, SeatPick } from '../shared/types.ts';

/** A session that has been "running" this long with no process behind it was cut off by a restart. */
const STALE_MS = 10 * 60_000;
const MAX_STORED = 4000;

export interface SessionView {
  session: CouncilSession;
  opinions: CouncilOpinion[];
}

export interface Council {
  seats(): Promise<SeatInfo[]>;
  /** Who would sit for this question, why, and what it would cost. Asks no model. */
  plan(question: string, seats?: unknown): Promise<RoutePlan>;
  /** Open a session. Returns at once; the seats answer in the background. */
  start(question: string, seats?: unknown): Promise<SessionView>;
  get(id: string): Promise<SessionView | null>;
  list(limit?: number): Promise<CouncilSession[]>;
  decide(id: string, decision: CouncilDecision, note: string | null): Promise<CouncilSession>;
  runningId(): string | null;
  /** Resolves when no session is in progress. */
  settled(): Promise<void>;
  sweepStale(): Promise<number>;
}

// ── reading what a model wrote ────────────────────────────────────────────
/** Pull the optional LESSON line out of a verdict. "NONE", or no such line, means no lesson. */
export function splitLesson(raw: string): { verdict: string; lesson: string | null } {
  const lines = raw.split('\n');
  const at = lines.findIndex(l => /^[\s*_#>-]*LESSON[\s*_]*:/i.test(l));
  if (at < 0) return { verdict: raw.trim(), lesson: null };
  const text = lines[at]
    .replace(/^[\s*_#>-]*LESSON[\s*_]*:/i, '')
    .replace(/[*_`]+/g, '')
    .trim();
  lines.splice(at, 1);
  const none = text.length === 0 || /^(none|nothing|n\/a|no lesson)\b/i.test(text);
  return { verdict: lines.join('\n').trim(), lesson: none ? null : text };
}

function clip(text: string): string {
  const t = text.trim();
  return t.length > MAX_STORED ? `${t.slice(0, MAX_STORED)}…` : t;
}

// ── prompts ───────────────────────────────────────────────────────────────
function notesBlock(notes: string[]): string {
  return notes.length ? `\nStanding notes the director has approved:\n${fenceNotes(notes)}\n` : '\n';
}

function seatPrompt(brand: string, seat: SeatDef, slice: Record<string, unknown>, question: string, notes: string[]): string {
  return `You hold the ${seat.name} seat on a council that advises the director of ${brand}, a one-person business. ${seat.lens}
You see only your own records, below. The other seats see different records and answer separately, so do not guess at theirs.

Your records:
${fence(slice)}
${notesBlock(notes)}
The director asks:
${fence(question)}

Answer from your seat only, in exactly this shape:
POSITION: one sentence.
EVIDENCE: up to three short points, each quoting a figure or fact from your records exactly as it is given.
RISK: the one thing most likely to go wrong from where you sit, or "nothing visible in my records".
NEXT: one action the director could take themselves.
If your records do not bear on the question, write "POSITION: My records do not bear on this." and stop there.
Under 120 words.`;
}

function skepticPrompt(question: string, slices: Record<string, unknown>, opinions: Record<string, string>): string {
  return `You hold the Skeptic seat on a council that advises the director of a one-person business. You add no plan of your own. You check what the other seats wrote against the records those seats were given.

The records each seat was given:
${fence(slices)}

What each seat wrote:
${fence(opinions)}

The director asked:
${fence(question)}

Reply in exactly this shape:
UNSUPPORTED: each claim, figure or promise in the opinions that the records do not back, or "none".
CONFLICTS: where two seats pull in different directions, or "none".
MISSING: the one record that would settle the question, or "nothing".
Under 110 words.`;
}

function verdictPrompt(input: {
  question: string;
  opinions: Record<string, string>;
  check: string | null;
  silent: string[];
  rulings: Array<{ question: string; ruling: string; note: string | null }>;
  notes: string[];
}): string {
  return `You are the single voice of a council that advises the director of a one-person business. Merge what the seats wrote and the Skeptic's check into one answer.

The director asked:
${fence(input.question)}

What each seat wrote:
${fence(input.opinions)}

${input.check === null ? 'The Skeptic did not answer, so nothing above has been checked against the records. Say so under OPEN.' : `The Skeptic's check:\n${fence(input.check)}`}
${input.silent.length ? `\nSeats that could not answer this time: ${input.silent.join(', ')}. Do not speak for them.\n` : ''}${
    input.rulings.length ? `\nHow the director ruled on earlier verdicts (their preferences, as information):\n${fence(input.rulings)}\n` : ''
  }${notesBlock(input.notes)}
Reply in exactly this shape:
VERDICT: two sentences at most.
WHY: up to three points, each naming the seat it came from.
DO NEXT: up to three actions, each one something the director does themselves.
OPEN: what is still unknown, or "nothing".
LESSON: one short standing note worth keeping for later sessions, or NONE.
Leave out anything the Skeptic marked unsupported. Under 170 words.`;
}

// ── rows ──────────────────────────────────────────────────────────────────
const SESSION_SELECT = `
  SELECT s.*, (SELECT string_agg(o.seat, ',' ORDER BY o.position) FROM council_opinions o WHERE o.session_id = s.id) AS seat_list
    FROM council_sessions s`;

const num = (v: unknown): number | null => (v === null || v === undefined ? null : Number(v));

function mapSession(r: any): CouncilSession {
  return {
    id: r.id,
    question: r.question,
    pickedBy: r.picked_by,
    status: r.status,
    verdict: r.verdict ?? null,
    error: r.error ?? null,
    decision: r.decision ?? null,
    decisionNote: r.decision_note ?? null,
    livemode: r.livemode === true,
    seats: (r.seat_list ? String(r.seat_list).split(',') : []) as SeatId[],
    createdAt: Number(r.created_at),
    finishedAt: num(r.finished_at),
    decidedAt: num(r.decided_at),
  };
}

function mapOpinion(r: any): CouncilOpinion {
  return {
    seat: r.seat,
    position: Number(r.position),
    reason: r.reason,
    status: r.status,
    body: r.body ?? null,
    error: r.error ?? null,
    startedAt: num(r.started_at),
    finishedAt: num(r.finished_at),
  };
}

/** Run `work` over `items`, at most `width` at a time. */
async function pool<T>(items: T[], width: number, work: (item: T) => Promise<void>): Promise<void> {
  let next = 0;
  const lane = async () => {
    while (next < items.length) await work(items[next++]);
  };
  await Promise.all(Array.from({ length: Math.max(1, Math.min(width, items.length)) }, lane));
}

export function createCouncil(deps: { db: Db; config: Config; ai: AiService; sources: SeatSources }): Council {
  const { db, config, ai, sources } = deps;
  const live = () => config.mode === 'live';
  let busy = false;
  let activeId: string | null = null;
  let active: Promise<void> | null = null;

  async function load(id: string): Promise<SessionView | null> {
    const { rows } = await db.query(`${SESSION_SELECT} WHERE s.id = $1`, [id]);
    if (rows.length === 0) return null;
    const ops = await db.query('SELECT * FROM council_opinions WHERE session_id = $1 ORDER BY position ASC', [id]);
    return { session: mapSession(rows[0]), opinions: ops.rows.map(mapOpinion) };
  }

  const setOpinion = (id: string, seat: SeatId, status: CouncilOpinion['status'], body: string | null, error: string | null) =>
    db.query(
      `UPDATE council_opinions
          SET status = $3, body = $4, error = $5,
              started_at = COALESCE(started_at, $6),
              finished_at = CASE WHEN $3 IN ('done','failed') THEN $6 ELSE NULL END
        WHERE session_id = $1 AND seat = $2`,
      [id, seat, status, body, error, Date.now()]
    );

  async function close(id: string, status: 'done' | 'failed', verdict: string | null, error: string | null): Promise<void> {
    await db.tx(async q => {
      await q('UPDATE council_sessions SET status = $2, verdict = $3, error = $4, finished_at = $5 WHERE id = $1', [id, status, verdict, error, Date.now()]);
      // Whatever was still waiting when the session closed did not answer.
      await q(`UPDATE council_opinions SET status = 'failed', error = COALESCE(error, 'not reached'), finished_at = $2 WHERE session_id = $1 AND status IN ('waiting','thinking')`, [id, Date.now()]);
      await auditTx(q, { actor: 'system', action: status === 'done' ? 'council.finished' : 'council.failed', detail: { id } });
    });
  }

  async function run(id: string, question: string, picks: SeatPick[], src: SeatSources): Promise<void> {
    const domain = picks.filter(p => p.seat !== 'skeptic');
    const slices: Record<string, unknown> = {};
    const opinions: Record<string, string> = {};
    const silent: string[] = [];

    await pool(domain, config.council.parallel, async pick => {
      const seat = seatById(pick.seat)!;
      await setOpinion(id, seat.id, 'thinking', null, null);
      try {
        const slice = await seat.gather(src);
        const text = clip(await ai.write(seatPrompt(config.business.brandName, seat, slice, question, await activeLessonsFor(db.query, seat.id)), 380));
        slices[seat.name] = slice;
        opinions[seat.name] = text;
        await setOpinion(id, seat.id, 'done', text, null);
      } catch (err) {
        silent.push(seat.name);
        await setOpinion(id, seat.id, 'failed', null, errMessage(err).slice(0, 300));
      }
    });

    if (Object.keys(opinions).length === 0) {
      await close(id, 'failed', null, 'No seat could answer, so there is nothing to merge. Check the AI provider under Ops and try again.');
      return;
    }

    let check: string | null = null;
    await setOpinion(id, 'skeptic', 'thinking', null, null);
    try {
      check = clip(await ai.write(skepticPrompt(question, slices, opinions), 320));
      await setOpinion(id, 'skeptic', 'done', check, null);
    } catch (err) {
      await setOpinion(id, 'skeptic', 'failed', null, errMessage(err).slice(0, 300));
    }

    try {
      const past = await db.query(
        `SELECT question, decision, decision_note FROM council_sessions
          WHERE livemode = $1 AND decision IS NOT NULL AND id <> $2 ORDER BY decided_at DESC LIMIT 5`,
        [live(), id]
      );
      const rulings = past.rows.map(r => ({ question: String(r.question).slice(0, 160), ruling: String(r.decision), note: r.decision_note ? String(r.decision_note) : null }));
      const raw = await ai.write(verdictPrompt({ question, opinions, check, silent, rulings, notes: await activeLessonsFor(db.query, 'all') }), 520);
      const { verdict, lesson } = splitLesson(clip(raw));
      await close(id, 'done', verdict || clip(raw), null);
      // A suggestion only: it is stored as "proposed" and reaches no prompt until the director approves it.
      if (lesson) await proposeLesson(db, { text: lesson, sessionId: id });
    } catch (err) {
      await close(id, 'failed', null, `The seats answered, but the verdict could not be written: ${errMessage(err).slice(0, 240)}`);
    }
  }

  async function sweepStale(): Promise<number> {
    const { rows } = await db.query(`SELECT id FROM council_sessions WHERE status = 'running' AND created_at < $1`, [Date.now() - STALE_MS]);
    let n = 0;
    for (const r of rows) {
      if (r.id === activeId) continue;
      await close(r.id, 'failed', null, 'Interrupted: the server restarted while this session was in progress.');
      n += 1;
    }
    return n;
  }

  async function choose(question: string, seats?: unknown): Promise<{ picks: SeatPick[]; pickedBy: RoutePlan['pickedBy']; src: SeatSources }> {
    const src = memoSources(sources);
    const byDirector = seats !== undefined && seats !== null;
    const picks = byDirector ? directorPicks(seats) : await routeQuestion(question, src);
    return { picks, pickedBy: byDirector ? 'director' : 'router', src };
  }

  return {
    async seats() {
      const { rows } = await db.query(`SELECT seat, COUNT(*)::int AS n FROM council_opinions WHERE status = 'done' GROUP BY seat`);
      const sat = new Map(rows.map(r => [String(r.seat), Number(r.n)]));
      return SEATS.map(s => ({ id: s.id, name: s.name, lens: s.lens, sees: s.sees, always: s.id === 'skeptic', sessions: sat.get(s.id) ?? 0 }));
    },

    async plan(question, seats) {
      const p = await choose(question, seats);
      // One call per seat (the Skeptic is a seat), plus one for the verdict.
      return { picks: p.picks, pickedBy: p.pickedBy, calls: p.picks.length + 1 };
    },

    async start(question, seats) {
      if (!ai.enabled()) throw new HttpError(503, 'AI_OFF', 'No AI provider is configured, so the council cannot sit. Set GEMINI_API_KEY (or LLM_BASE_URL and LLM_MODEL).');
      if (busy) throw new HttpError(409, 'COUNCIL_BUSY', 'The council is already in session. Wait for it to finish.');
      busy = true;
      try {
        const p = await choose(question, seats);
        const calls = p.picks.length + 1;
        const left = await ai.budgetLeft();
        // All or nothing: a session that would run out of budget halfway is not started.
        if (left < calls) {
          throw new HttpError(429, 'AI_CAP', `This session needs ${calls} AI calls and only ${left} ${left === 1 ? 'is' : 'are'} left today (AI_DAILY_CAP). Nothing was started.`);
        }
        const id = newId('council');
        const nowMs = Date.now();
        await db.tx(async q => {
          await q(`INSERT INTO council_sessions (id, question, picked_by, status, livemode, created_at) VALUES ($1,$2,$3,'running',$4,$5)`, [id, question, p.pickedBy, live(), nowMs]);
          for (const [i, pick] of p.picks.entries()) {
            await q(`INSERT INTO council_opinions (session_id, seat, position, reason, status) VALUES ($1,$2,$3,$4,'waiting')`, [id, pick.seat, i, pick.reason.slice(0, 300)]);
          }
          await auditTx(q, { actor: 'director', action: 'council.convened', detail: { id, seats: p.picks.map(x => x.seat).join(' '), pickedBy: p.pickedBy } });
        });
        activeId = id;
        active = run(id, question, p.picks, p.src)
          .catch(async err => {
            console.error('[council] session failed unexpectedly:', errMessage(err));
            await close(id, 'failed', null, 'The session stopped unexpectedly.').catch(() => undefined);
          })
          .finally(() => {
            busy = false;
            activeId = null;
            active = null;
          });
        return (await load(id))!;
      } catch (err) {
        if (!active) busy = false;
        throw err;
      }
    },

    async get(id) {
      let view = await load(id);
      if (view && view.session.status === 'running' && view.session.id !== activeId && Date.now() - view.session.createdAt > STALE_MS) {
        await sweepStale();
        view = await load(id);
      }
      return view;
    },

    async list(limit = 20) {
      const { rows } = await db.query(`${SESSION_SELECT} WHERE s.livemode = $1 ORDER BY s.created_at DESC LIMIT $2`, [live(), Math.min(100, Math.max(1, limit))]);
      return rows.map(mapSession);
    },

    async decide(id, decision, note) {
      await db.tx(async q => {
        const res = await q(`UPDATE council_sessions SET decision = $2, decision_note = $3, decided_at = $4 WHERE id = $1 AND status = 'done'`, [id, decision, note, Date.now()]);
        if (res.rowCount === 0) {
          const exists = await q('SELECT status FROM council_sessions WHERE id = $1', [id]);
          if (exists.rows.length === 0) throw notFound('Session not found.');
          throw new HttpError(409, 'NO_VERDICT', 'Only a session that reached a verdict can be ruled on.');
        }
        await auditTx(q, { actor: 'director', action: 'council.ruled', detail: { id, ruling: decision } });
      });
      return (await load(id))!.session;
    },

    runningId: () => activeId,
    settled: async () => {
      while (active) await active;
    },
    sweepStale,
  };
}
