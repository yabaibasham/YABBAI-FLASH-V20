/**
 * Market watch — read-only.
 *
 * The old "BANG engine" decided each trade's outcome with a random number generator and
 * showed the result as profit. That is gone. This module only fetches public
 * prices and shows the cross-exchange spread AFTER typical taker fees, which
 * is the honest picture: for a retail account the net figure is almost always
 * negative. Nothing here places a trade or changes any money figure.
 */
import { fetchWithTimeout } from './util.ts';
import type { MarketRow } from '../shared/types.ts';

export const SYMBOLS = ['BTC', 'ETH', 'SOL', 'XRP', 'ADA', 'AVAX', 'LINK', 'DOGE'] as const;

/** Typical published taker fees at the lowest volume tier, in basis points. */
export const TAKER_FEE_BPS: Record<string, number> = { Coinbase: 60, Kraken: 40, Binance: 10 };

const KRAKEN_PAIRS: Record<string, string[]> = {
  BTC: ['XXBTZUSD', 'XBTUSD'],
  ETH: ['XETHZUSD', 'ETHUSD'],
  SOL: ['SOLUSD'],
  XRP: ['XXRPZUSD', 'XRPUSD'],
  ADA: ['ADAUSD'],
  AVAX: ['AVAXUSD'],
  LINK: ['LINKUSD'],
  DOGE: ['XDGUSD', 'DOGEUSD'],
};

type Book = { bid: number; ask: number };

export interface MarketsService {
  snapshot(): Promise<{ rows: MarketRow[]; venuesUp: Record<string, boolean>; fetchedAt: number; fees: Record<string, number> }>;
}

export function createMarketsService(fetchImpl: typeof fetch): MarketsService {
  let cache: Awaited<ReturnType<MarketsService['snapshot']>> | null = null;

  async function coinbase(): Promise<Record<string, Book>> {
    const out: Record<string, Book> = {};
    await Promise.all(
      SYMBOLS.map(async sym => {
        try {
          const res = await fetchWithTimeout(fetchImpl, `https://api.exchange.coinbase.com/products/${sym}-USD/ticker`, {}, 5000);
          if (!res.ok) return;
          const d: any = await res.json();
          const bid = Number(d.bid);
          const ask = Number(d.ask);
          if (bid > 0 && ask > 0 && ask >= bid) out[sym] = { bid, ask };
        } catch {
          /* venue unreachable — shown as down, never guessed */
        }
      })
    );
    return out;
  }

  async function kraken(): Promise<Record<string, Book>> {
    const out: Record<string, Book> = {};
    try {
      const pairs = SYMBOLS.map(s => KRAKEN_PAIRS[s][KRAKEN_PAIRS[s].length - 1]).join(',');
      const res = await fetchWithTimeout(fetchImpl, `https://api.kraken.com/0/public/Ticker?pair=${pairs}`, {}, 6000);
      if (!res.ok) return out;
      const d: any = await res.json();
      for (const sym of SYMBOLS) {
        const item = KRAKEN_PAIRS[sym].map(k => d?.result?.[k]).find(Boolean);
        const bid = Number(item?.b?.[0]);
        const ask = Number(item?.a?.[0]);
        if (bid > 0 && ask > 0 && ask >= bid) out[sym] = { bid, ask };
      }
    } catch {
      /* down */
    }
    return out;
  }

  async function binance(): Promise<Record<string, Book>> {
    const out: Record<string, Book> = {};
    try {
      const symbols = encodeURIComponent(JSON.stringify(SYMBOLS.map(s => `${s}USDT`)));
      const res = await fetchWithTimeout(fetchImpl, `https://api.binance.com/api/v3/ticker/bookTicker?symbols=${symbols}`, {}, 6000);
      if (!res.ok) return out;
      const list: any = await res.json();
      if (!Array.isArray(list)) return out;
      for (const item of list) {
        const sym = String(item.symbol ?? '').replace(/USDT$/, '');
        const bid = Number(item.bidPrice);
        const ask = Number(item.askPrice);
        if ((SYMBOLS as readonly string[]).includes(sym) && bid > 0 && ask > 0 && ask >= bid) out[sym] = { bid, ask };
      }
    } catch {
      /* down (Binance blocks some regions) */
    }
    return out;
  }

  return {
    async snapshot() {
      if (cache && Date.now() - cache.fetchedAt < 15_000) return cache;
      const [cb, kr, bn] = await Promise.all([coinbase(), kraken(), binance()]);
      const books: Record<string, Record<string, Book>> = { Coinbase: cb, Kraken: kr, Binance: bn };
      const rows: MarketRow[] = SYMBOLS.map(symbol => {
        const venues = Object.entries(books)
          .filter(([, b]) => b[symbol])
          .map(([venue, b]) => ({ venue, bid: b[symbol].bid, ask: b[symbol].ask }));
        let best: { buy: (typeof venues)[number]; sell: (typeof venues)[number]; gross: number; net: number } | null = null;
        for (const buy of venues) {
          for (const sell of venues) {
            if (buy.venue === sell.venue) continue;
            const gross = ((sell.bid - buy.ask) / buy.ask) * 10_000;
            const net = gross - (TAKER_FEE_BPS[buy.venue] ?? 50) - (TAKER_FEE_BPS[sell.venue] ?? 50);
            if (!best || net > best.net) best = { buy, sell, gross, net };
          }
        }
        return {
          symbol,
          venues,
          bestBuy: best ? { venue: best.buy.venue, ask: best.buy.ask } : null,
          bestSell: best ? { venue: best.sell.venue, bid: best.sell.bid } : null,
          grossBps: best ? Math.round(best.gross * 10) / 10 : null,
          netBps: best ? Math.round(best.net * 10) / 10 : null,
        };
      });
      cache = {
        rows,
        venuesUp: { Coinbase: Object.keys(cb).length > 0, Kraken: Object.keys(kr).length > 0, Binance: Object.keys(bn).length > 0 },
        fetchedAt: Date.now(),
        fees: TAKER_FEE_BPS,
      };
      return cache;
    },
  };
}
