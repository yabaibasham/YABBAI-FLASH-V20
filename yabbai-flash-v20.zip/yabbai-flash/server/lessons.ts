/**
 * Lessons — how the council grows.
 *
 * A lesson is one short standing note that is handed to the seats at every
 * later session ("quote prices without GST", "I only take retainers over
 * $500"). It is the only thing that carries over from one session to the next,
 * so it is the only way the council changes over time.
 *
 * That makes it the one place a wrong or planted sentence could steer every
 * future answer. So:
 *  - The council may PROPOSE a lesson. A proposal is inert text: it is shown to
 *    you and reaches no prompt.
 *  - Only the director makes a lesson active, and doing so needs the password
 *    again (enforced in the routes, and by a CHECK constraint in the database).
 *  - There is a small fixed number of active lessons. Growth here means better
 *    notes, not a longer and longer prompt.
 *  - A lesson can shape wording and priorities. It can never change a figure,
 *    lift a rule or cause an action: the model has no tools either way.
 */
import type { Db, Query } from './db.ts';
import { auditTx } from './audit.ts';
import { HttpError, bad, newId, notFound } from './util.ts';
import type { Lesson, SeatId } from '../shared/types.ts';

export const MAX_ACTIVE_LESSONS = 12;
export const MAX_LESSON_LENGTH = 240;

function mapLesson(r: any): Lesson {
  return {
    id: r.id,
    text: r.text,
    seat: r.seat,
    source: r.source,
    sessionId: r.session_id ?? null,
    status: r.status,
    createdAt: Number(r.created_at),
    decidedAt: r.decided_at === null || r.decided_at === undefined ? null : Number(r.decided_at),
  };
}

/** One line of plain text. Anything that looks like a tag is dropped so a note cannot pose as a prompt section. */
export function cleanLesson(text: string): string {
  return text
    .replace(/[\u0000-\u001F\u007F]+/g, ' ')
    .replace(/<[^>]{0,40}>/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, MAX_LESSON_LENGTH);
}

export async function listLessons(q: Query): Promise<Lesson[]> {
  const { rows } = await q(
    `SELECT * FROM lessons WHERE status <> 'dismissed'
      ORDER BY CASE status WHEN 'proposed' THEN 0 WHEN 'active' THEN 1 ELSE 2 END, created_at DESC LIMIT 120`
  );
  return rows.map(mapLesson);
}

async function getLesson(q: Query, id: string): Promise<Lesson | null> {
  const { rows } = await q('SELECT * FROM lessons WHERE id = $1', [id]);
  return rows.length ? mapLesson(rows[0]) : null;
}

export async function proposedForSession(q: Query, sessionId: string): Promise<Lesson | null> {
  const { rows } = await q(`SELECT * FROM lessons WHERE session_id = $1 AND source = 'council' ORDER BY created_at DESC LIMIT 1`, [sessionId]);
  return rows.length ? mapLesson(rows[0]) : null;
}

/** The notes a seat is handed: the ones for everyone, plus its own. Oldest first, so the order is stable. */
export async function activeLessonsFor(q: Query, seat: SeatId | 'all'): Promise<string[]> {
  const { rows } = await q(
    `SELECT text FROM lessons WHERE status = 'active' AND (seat = 'all' OR seat = $1) ORDER BY decided_at ASC NULLS FIRST, created_at ASC LIMIT $2`,
    [seat, MAX_ACTIVE_LESSONS]
  );
  return rows.map(r => String(r.text));
}

async function assertRoom(q: Query): Promise<void> {
  const { rows } = await q(`SELECT COUNT(*)::int AS n FROM lessons WHERE status = 'active'`);
  if (Number(rows[0].n) >= MAX_ACTIVE_LESSONS) {
    throw new HttpError(409, 'LESSONS_FULL', `The council keeps at most ${MAX_ACTIVE_LESSONS} active lessons. Retire one before adding another.`);
  }
}

/** The director writes a lesson. The route that calls this requires the password again. */
export async function addLesson(db: Db, input: { text: string; seat: SeatId | 'all' }): Promise<Lesson> {
  const text = cleanLesson(input.text);
  if (text.length < 8) throw bad('A lesson needs at least a short sentence.');
  const id = newId('lesson');
  const nowMs = Date.now();
  await db.tx(async q => {
    await assertRoom(q);
    await q(`INSERT INTO lessons (id, text, seat, source, status, created_at, decided_at) VALUES ($1,$2,$3,'director','active',$4,$4)`, [id, text, input.seat, nowMs]);
    await auditTx(q, { actor: 'director', action: 'lesson.added', detail: { id, seat: input.seat } });
  });
  return (await getLesson(db.query, id))!;
}

/**
 * The council suggests a lesson. Stored as 'proposed' and nothing more: it is
 * model output, so it waits for the director like every other draft.
 */
export async function proposeLesson(db: Db, input: { text: string; sessionId: string }): Promise<Lesson | null> {
  const text = cleanLesson(input.text);
  if (text.length < 8) return null;
  const same = await db.query(`SELECT 1 FROM lessons WHERE lower(text) = lower($1) AND status IN ('proposed','active') LIMIT 1`, [text]);
  if (same.rows.length) return null;
  const id = newId('lesson');
  await db.tx(async q => {
    await q(`INSERT INTO lessons (id, text, seat, source, session_id, status, created_at) VALUES ($1,$2,'all','council',$3,'proposed',$4)`, [id, text, input.sessionId, Date.now()]);
    await auditTx(q, { actor: 'system', action: 'lesson.proposed', detail: { id, session: input.sessionId } });
  });
  return getLesson(db.query, id);
}

/** Proposed → active. The director may reword it first. The route requires the password again. */
export async function approveLesson(db: Db, id: string, reworded: string | null): Promise<Lesson> {
  await db.tx(async q => {
    const current = await getLesson(q, id);
    if (!current || current.status !== 'proposed') throw notFound('No proposed lesson with that id.');
    const text = reworded === null ? current.text : cleanLesson(reworded);
    if (text.length < 8) throw bad('A lesson needs at least a short sentence.');
    await assertRoom(q);
    await q(`UPDATE lessons SET status = 'active', text = $2, decided_at = $3 WHERE id = $1 AND status = 'proposed'`, [id, text, Date.now()]);
    await auditTx(q, { actor: 'director', action: 'lesson.approved', detail: { id, reworded: text !== current.text } });
  });
  return (await getLesson(db.query, id))!;
}

/** Taking a lesson away is always allowed, like taking a product off sale. */
export async function closeLesson(db: Db, id: string, how: 'dismiss' | 'retire'): Promise<Lesson> {
  const from = how === 'dismiss' ? 'proposed' : 'active';
  const to = how === 'dismiss' ? 'dismissed' : 'retired';
  await db.tx(async q => {
    const res = await q(`UPDATE lessons SET status = $3, decided_at = $4 WHERE id = $1 AND status = $2`, [id, from, to, Date.now()]);
    if (res.rowCount === 0) throw notFound(how === 'dismiss' ? 'No proposed lesson with that id.' : 'No active lesson with that id.');
    await auditTx(q, { actor: 'director', action: how === 'dismiss' ? 'lesson.dismissed' : 'lesson.retired', detail: { id } });
  });
  return (await getLesson(db.query, id))!;
}
