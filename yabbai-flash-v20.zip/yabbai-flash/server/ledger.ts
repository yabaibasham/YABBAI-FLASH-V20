/**
 * The payments ledger — the only source of money figures in the app.
 *
 * A row gets in by exactly three doors, all on the server:
 *   stripe.ts    after re-fetching a paid Checkout Session from Stripe's API
 *   solana.ts    after reading a finalized transaction from the chain
 *   invoices.ts  when the director attests a bank/PayID payment (step-up
 *                required; stored as verified = false, always labelled)
 *
 * There is no endpoint that accepts an amount and adds it to a balance.
 */
import type { Config } from './config.ts';
import type { Query } from './db.ts';
import { auditTx } from './audit.ts';
import { businessDay, newId } from './util.ts';
import type { AllocationRow, Payment, Rail } from '../shared/types.ts';

export interface NewPayment {
  proofId: string;
  rail: Rail;
  kind: 'invoice' | 'order';
  invoiceId?: string | null;
  orderId?: string | null;
  amountCents: number;
  livemode: boolean;
  payer?: string | null;
  detail?: Record<string, unknown>;
  occurredAt?: number;
}

export function mapPayment(r: any, config?: Config): Payment {
  const detail = (r.detail ?? {}) as Record<string, unknown>;
  const p: Payment = {
    id: r.id,
    proofId: r.proof_id,
    rail: r.rail,
    kind: r.kind,
    invoiceId: r.invoice_id ?? null,
    orderId: r.order_id ?? null,
    amountCents: Number(r.amount_cents),
    refundedCents: Number(r.refunded_cents),
    verified: r.verified === true,
    disputed: r.disputed === true,
    livemode: r.livemode === true,
    payer: r.payer ?? null,
    detail,
    occurredAt: Number(r.occurred_at),
    createdAt: Number(r.created_at),
  };
  if (r.ref_label) p.label = String(r.ref_label);
  if (p.rail === 'stripe') {
    const pi = typeof detail.paymentIntent === 'string' ? detail.paymentIntent : null;
    p.proofUrl = pi ? `https://dashboard.stripe.com/${p.livemode ? '' : 'test/'}payments/${pi}` : null;
  } else if (p.rail === 'solana') {
    const sig = typeof detail.signature === 'string' ? detail.signature : null;
    const devnet = config?.solana.cluster === 'devnet';
    p.proofUrl = sig ? `https://solscan.io/tx/${sig}${devnet ? '?cluster=devnet' : ''}` : null;
  } else {
    p.proofUrl = null;
  }
  return p;
}

/**
 * Insert a payment exactly once. A second call with the same proofId is a
 * no-op that returns the original row — this is what makes replayed webhooks
 * and repeated chain scans harmless.
 */
export async function recordPayment(q: Query, p: NewPayment): Promise<{ inserted: boolean; payment: Payment }> {
  if (!Number.isSafeInteger(p.amountCents) || p.amountCents <= 0) throw new Error('recordPayment: amount must be a positive integer of cents');
  const nowMs = Date.now();
  const ins = await q(
    `INSERT INTO payments (id, proof_id, rail, kind, invoice_id, order_id, amount_cents, verified, livemode, payer, detail, occurred_at, created_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb,$12,$13)
     ON CONFLICT (proof_id) DO NOTHING
     RETURNING *`,
    [
      newId('pay'),
      p.proofId,
      p.rail,
      p.kind,
      p.kind === 'invoice' ? p.invoiceId : null,
      p.kind === 'order' ? p.orderId : null,
      p.amountCents,
      p.rail !== 'attested',
      p.livemode,
      p.payer ?? null,
      JSON.stringify(p.detail ?? {}),
      p.occurredAt ?? nowMs,
      nowMs,
    ]
  );
  if (ins.rows.length > 0) return { inserted: true, payment: mapPayment(ins.rows[0]) };
  const existing = await q('SELECT * FROM payments WHERE proof_id = $1', [p.proofId]);
  return { inserted: false, payment: mapPayment(existing.rows[0]) };
}

/**
 * Credit a processor- or chain-verified payment to an invoice or an order,
 * exactly once, and write the audit entry in the same transaction.
 * An order is only released once verified payments cover its full price.
 */
export async function applyVerifiedPayment(
  q: Query,
  p: NewPayment & { rail: 'stripe' | 'solana'; refLabel: string }
): Promise<{ inserted: boolean; payment: Payment }> {
  const rec = await recordPayment(q, p);
  if (!rec.inserted) return rec;

  if (p.kind === 'order' && p.orderId) {
    const sum = await q('SELECT COALESCE(SUM(amount_cents - refunded_cents), 0)::bigint AS net FROM payments WHERE order_id = $1 AND verified = TRUE', [
      p.orderId,
    ]);
    await q(
      `UPDATE orders
          SET status = 'paid', paid_at = COALESCE(paid_at, $2), customer_email = COALESCE(customer_email, $3)
        WHERE id = $1 AND status IN ('pending','expired') AND price_cents <= $4`,
      [p.orderId, p.occurredAt ?? Date.now(), p.payer ?? null, Number(sum.rows[0].net)]
    );
  }
  await auditTx(q, {
    actor: p.rail,
    action: 'payment.verified',
    detail: { proofId: p.proofId, kind: p.kind, ref: p.refLabel, amountCents: p.amountCents, livemode: p.livemode },
  });
  return rec;
}

export async function listPayments(
  q: Query,
  config: Config,
  opts: { limit?: number; invoiceId?: string; orderId?: string } = {}
): Promise<Payment[]> {
  const where: string[] = ['p.livemode = $1'];
  const params: unknown[] = [config.mode === 'live'];
  if (opts.invoiceId) {
    params.push(opts.invoiceId);
    where.push(`p.invoice_id = $${params.length}`);
  }
  if (opts.orderId) {
    params.push(opts.orderId);
    where.push(`p.order_id = $${params.length}`);
  }
  params.push(Math.min(500, Math.max(1, opts.limit ?? 100)));
  const { rows } = await q(
    `SELECT p.*, COALESCE(i.number || ' · ' || i.client_name, o.product_title) AS ref_label
       FROM payments p
       LEFT JOIN invoices i ON i.id = p.invoice_id
       LEFT JOIN orders o ON o.id = p.order_id
      WHERE ${where.join(' AND ')}
      ORDER BY p.occurred_at DESC
      LIMIT $${params.length}`,
    params
  );
  return rows.map(r => mapPayment(r, config));
}

export interface PaidSplit {
  verified: number;
  attested: number;
}

/** Net paid (after refunds) per invoice, split by how it was proven. */
export async function paidByInvoice(q: Query, invoiceIds: string[]): Promise<Map<string, PaidSplit>> {
  const out = new Map<string, PaidSplit>();
  if (invoiceIds.length === 0) return out;
  const { rows } = await q(
    `SELECT invoice_id, verified, COALESCE(SUM(amount_cents - refunded_cents), 0)::bigint AS net
       FROM payments
      WHERE invoice_id IN (SELECT jsonb_array_elements_text($1::jsonb))
      GROUP BY invoice_id, verified`,
    [JSON.stringify(invoiceIds)]
  );
  for (const r of rows) {
    const cur = out.get(r.invoice_id) ?? { verified: 0, attested: 0 };
    if (r.verified === true) cur.verified += Number(r.net);
    else cur.attested += Number(r.net);
    out.set(r.invoice_id, cur);
  }
  return out;
}

export interface LedgerTotals {
  verifiedAllTimeCents: number;
  verified30dCents: number;
  verified7dCents: number;
  verifiedMonthCents: number;
  attestedAllTimeCents: number;
  refundedAllTimeCents: number;
  paymentsCount: number;
  byRail: Array<{ rail: Rail; cents: number; count: number }>;
  daily: Array<{ day: string; verifiedCents: number; attestedCents: number }>;
}

export async function ledgerTotals(q: Query, config: Config): Promise<LedgerTotals> {
  const live = config.mode === 'live';
  const nowMs = Date.now();
  const day = 86_400_000;

  const agg = await q(
    `SELECT rail, verified,
            COALESCE(SUM(amount_cents - refunded_cents), 0)::bigint AS net,
            COALESCE(SUM(refunded_cents), 0)::bigint AS refunded,
            COUNT(*)::int AS n
       FROM payments WHERE livemode = $1
      GROUP BY rail, verified`,
    [live]
  );
  let verifiedAll = 0;
  let attestedAll = 0;
  let refundedAll = 0;
  let count = 0;
  const byRail: LedgerTotals['byRail'] = [];
  for (const r of agg.rows) {
    const net = Number(r.net);
    if (r.verified === true) verifiedAll += net;
    else attestedAll += net;
    refundedAll += Number(r.refunded);
    count += Number(r.n);
    byRail.push({ rail: r.rail, cents: net, count: Number(r.n) });
  }

  // Recent rows are bucketed in JS so "today" follows the business time zone.
  const recent = await q(
    `SELECT verified, amount_cents - refunded_cents AS net, occurred_at
       FROM payments WHERE livemode = $1 AND occurred_at >= $2`,
    [live, nowMs - 31 * day]
  );
  const month = businessDay(nowMs, config.timeZone).slice(0, 7);
  let v30 = 0;
  let v7 = 0;
  let vMonth = 0;
  const buckets = new Map<string, { verifiedCents: number; attestedCents: number }>();
  for (let i = 29; i >= 0; i--) buckets.set(businessDay(nowMs - i * day, config.timeZone), { verifiedCents: 0, attestedCents: 0 });
  for (const r of recent.rows) {
    const at = Number(r.occurred_at);
    const net = Number(r.net);
    const key = businessDay(at, config.timeZone);
    const b = buckets.get(key);
    if (b) {
      if (r.verified === true) b.verifiedCents += net;
      else b.attestedCents += net;
    }
    if (r.verified === true) {
      if (at >= nowMs - 30 * day) v30 += net;
      if (at >= nowMs - 7 * day) v7 += net;
      if (key.startsWith(month)) vMonth += net;
    }
  }

  return {
    verifiedAllTimeCents: verifiedAll,
    verified30dCents: v30,
    verified7dCents: v7,
    verifiedMonthCents: vMonth,
    attestedAllTimeCents: attestedAll,
    refundedAllTimeCents: refundedAll,
    paymentsCount: count,
    byRail,
    daily: [...buckets.entries()].map(([d, v]) => ({ day: d, ...v })),
  };
}

export interface AllocationSettings {
  keepPct: number; // of verified income, untouchable
  reservePct: number; // of what remains
  reinvestPct: number; // of what remains after reserve
}

export const DEFAULT_ALLOCATION: AllocationSettings = { keepPct: 30, reservePct: 20, reinvestPct: 50 };

/**
 * The "30% treasury law" as a budget. It is arithmetic on verified income,
 * shown as a plan — never a set of balances that can be moved or withdrawn.
 */
export function allocationPlan(verifiedCents: number, s: AllocationSettings): AllocationRow[] {
  const base = Math.max(0, verifiedCents);
  const keep = Math.round((base * s.keepPct) / 100);
  const distributable = base - keep;
  const reserve = Math.round((distributable * s.reservePct) / 100);
  const rest = distributable - reserve;
  const reinvest = Math.round((rest * s.reinvestPct) / 100);
  const pay = rest - reinvest;
  const pct = (c: number) => (base > 0 ? Math.round((c / base) * 1000) / 10 : 0);
  return [
    { key: 'treasury', label: 'Treasury (kept)', pct: pct(keep), cents: keep },
    { key: 'reserve', label: 'Reserve', pct: pct(reserve), cents: reserve },
    { key: 'reinvest', label: 'Reinvest', pct: pct(reinvest), cents: reinvest },
    { key: 'pay', label: 'Pay yourself', pct: pct(pay), cents: pay },
  ];
}
