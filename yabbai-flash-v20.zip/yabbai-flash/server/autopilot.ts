/**
 * Autopilot: scheduled jobs that run on the server.
 *
 * The old "autopilot" was a browser timer that invented leads, flipped coins
 * for trade results and queued payouts of money that did not exist. These
 * jobs do real, bounded work and nothing else:
 *
 *   treasurer   re-checks Stripe and the chain for payments (safety net for webhooks)
 *   auditor     verifies the audit log's hash chain and refreshes account status
 *   qualifier   scores new leads that real people submitted            (AI)
 *   supporter   drafts reminders for overdue invoices, for you to send (AI)
 *   janitor     expires stale sessions, quotes and abandoned checkouts
 *   sentinel    asks each watched link whether its server still answers
 *
 * No job can create a payment without proof, and no job sends anything.
 * The council is deliberately NOT a job: it sits only when the director asks,
 * so the AI budget is never spent on a schedule.
 */
import type { Config } from './config.ts';
import type { Db } from './db.ts';
import { kvGet, kvSet } from './db.ts';
import { audit, verifyAuditChain } from './audit.ts';
import type { AiService } from './ai.ts';
import type { Council } from './council.ts';
import { listInvoices } from './invoices.ts';
import { addDraft, hasPendingDraft, listLeads, setLeadScore } from './leads.ts';
import type { NetworkService } from './network.ts';
import { expireStaleOrders } from './products.ts';
import type { SolanaService } from './solana.ts';
import type { StripeService } from './stripe.ts';
import { businessDay, errMessage } from './util.ts';

export interface JobState {
  id: string;
  name: string;
  does: string;
  everySec: number;
  needs: string | null;
  lastRunAt: number | null;
  lastResult: string | null;
  lastError: string | null;
  running: boolean;
}

export interface Autopilot {
  start(): void;
  stop(): void;
  isOn(): boolean;
  setOn(on: boolean): Promise<void>;
  jobs(): JobState[];
  runNow(id?: string): Promise<JobState[]>;
  auditBroken(): boolean;
}

interface Deps {
  db: Db;
  config: Config;
  stripe: StripeService;
  solana: SolanaService;
  ai: AiService;
  network: NetworkService;
  council: Council;
  baseUrl: () => string;
}

interface Job extends JobState {
  run: () => Promise<string>;
  available: () => boolean;
}

export function createAutopilot(deps: Deps): Autopilot {
  const { db, config, stripe, solana, ai, network, council } = deps;
  let on = config.autopilot.enabled;
  let timer: NodeJS.Timeout | null = null;
  let ticking = false;
  let chainBroken = false;
  let lastLoggedHead = '';

  const job = (id: string, name: string, does: string, everySec: number, needs: string | null, available: () => boolean, run: () => Promise<string>): Job => ({
    id,
    name,
    does,
    everySec,
    needs,
    lastRunAt: null,
    lastResult: null,
    lastError: null,
    running: false,
    run,
    available,
  });

  const list: Job[] = [
    job(
      'treasurer',
      'Treasurer',
      'Re-checks Stripe and the Solana chain for payments on open invoices and orders.',
      60,
      null,
      () => true,
      async () => {
        const s = await stripe.reconcile();
        const c = await solana.reconcile();
        return `Stripe: ${s.checked} checked, ${s.paid} newly paid${s.errors ? `, ${s.errors} errors` : ''} · Chain: ${c.checked} checked, ${c.paid} newly paid${c.errors ? `, ${c.errors} errors` : ''}`;
      }
    ),
    job(
      'auditor',
      'Auditor',
      'Verifies the audit log hash chain and refreshes Stripe account and wallet status.',
      600,
      null,
      () => true,
      async () => {
        const chain = await verifyAuditChain(db.query);
        if (!chain.ok && !chainBroken) {
          console.error(`[autopilot] AUDIT CHAIN BROKEN at seq ${chain.brokenAtSeq}`);
        }
        chainBroken = !chain.ok;
        // The fingerprint also goes to the host's log stream, which the database cannot rewrite.
        if (chain.ok && chain.headHash !== lastLoggedHead) {
          console.log(`[audit] chain intact · ${chain.entries} entries · head ${chain.headHash}`);
          lastLoggedHead = chain.headHash;
        }
        const st = await stripe.status(true);
        await solana.walletStatus(true).catch(() => null);
        const stripeWord = !st.configured ? 'not connected' : !st.reachable ? 'unreachable' : st.chargesEnabled === null ? 'status not readable' : st.chargesEnabled ? 'ready' : 'not activated';
        return `Audit chain ${chain.ok ? 'intact' : `BROKEN at #${chain.brokenAtSeq}`} (${chain.entries} entries) · Stripe ${stripeWord}`;
      }
    ),
    job(
      'qualifier',
      'Qualifier',
      'Scores new leads that came in through the intake form or were added by you.',
      1800,
      'an AI provider',
      () => ai.enabled(),
      async () => {
        const fresh = (await listLeads(db.query)).filter(l => l.stage === 'new' && l.score === null).slice(0, 3);
        let scored = 0;
        for (const lead of fresh) {
          const r = await ai.qualifyLead(lead);
          await setLeadScore(db, lead.id, r.score, r.rationale);
          scored++;
        }
        return `${scored} lead${scored === 1 ? '' : 's'} scored`;
      }
    ),
    job(
      'supporter',
      'Supporter',
      'Drafts a reminder for each overdue invoice. Drafts wait in Pipeline for you to send.',
      3600,
      'an AI provider',
      () => ai.enabled(),
      async () => {
        // A reminder carries the pay link, so there must be a real public address to put in it.
        if (config.isProd && !config.publicBaseUrl) return 'Waiting for PUBLIC_BASE_URL — reminders need the real pay link';
        const overdue = (await listInvoices(db.query, config)).filter(i => i.status === 'overdue' && i.outstandingCents > 0);
        const today = businessDay(Date.now(), config.timeZone);
        let drafted = 0;
        for (const inv of overdue) {
          if (drafted >= 2) break;
          if (await hasPendingDraft(db.query, 'followup', inv.id)) continue;
          const last = (await kvGet<number>(db.query, `followup:${inv.id}`)) ?? 0;
          if (Date.now() - last < 7 * 86_400_000) continue; // at most one reminder draft a week
          const days = Math.max(1, Math.round((Date.parse(today) - Date.parse(inv.dueDate)) / 86_400_000));
          const body = await ai.draftFollowUp(inv, days, `${deps.baseUrl()}/pay/${inv.token}`);
          await addDraft(db.query, { type: 'followup', title: `Reminder: ${inv.number} · ${inv.clientName}`, body, refKind: 'invoice', refId: inv.id, source: 'ai' });
          await kvSet(db.query, `followup:${inv.id}`, Date.now());
          drafted++;
        }
        return `${overdue.length} overdue · ${drafted} reminder${drafted === 1 ? '' : 's'} drafted`;
      }
    ),
    job(
      'janitor',
      'Janitor',
      'Clears expired sessions, old webhook receipts and abandoned checkouts.',
      900,
      null,
      () => true,
      async () => {
        const nowMs = Date.now();
        const s = await db.query('DELETE FROM sessions WHERE expires_at <= $1', [nowMs]);
        const e = await db.query('DELETE FROM processed_events WHERE received_at <= $1', [nowMs - 90 * 86_400_000]);
        const o = await expireStaleOrders(db);
        // A council session cut off by a restart would otherwise read "running" forever.
        const c = await council.sweepStale();
        return `${s.rowCount} sessions, ${e.rowCount} receipts, ${o} abandoned checkouts cleared${c ? `, ${c} interrupted council session${c === 1 ? '' : 's'} closed` : ''}`;
      }
    ),
    job(
      'sentinel',
      'Sentinel',
      'Asks each watched link whether its server answers. One HEAD request each; it reads no page and counts no figure.',
      900,
      null,
      () => true,
      async () => {
        const r = await network.sweep();
        if (r.checked === 0) return 'No links are being watched';
        return `${r.checked} checked · ${r.up} answering${r.notAnswering ? ` · ${r.notAnswering} not answering` : ''}`;
      }
    ),
  ];

  async function runJob(j: Job): Promise<void> {
    if (j.running) return;
    if (!j.available()) {
      j.lastResult = `Idle — needs ${j.needs}`;
      return;
    }
    j.running = true;
    try {
      j.lastResult = await j.run();
      j.lastError = null;
    } catch (err) {
      j.lastError = errMessage(err);
    } finally {
      j.lastRunAt = Date.now();
      j.running = false;
    }
  }

  async function tick(): Promise<void> {
    if (ticking || !on) return; // one loop at a time
    ticking = true;
    try {
      const nowMs = Date.now();
      for (const j of list) {
        if (j.lastRunAt === null || nowMs - j.lastRunAt >= j.everySec * 1000) await runJob(j);
      }
    } finally {
      ticking = false;
    }
  }

  const view = (): JobState[] =>
    list.map(({ run: _run, available, ...rest }) => ({ ...rest, lastResult: available() ? rest.lastResult : `Idle — needs ${rest.needs}` }));

  return {
    start() {
      if (timer) return;
      void kvGet<boolean>(db.query, 'autopilot_on').then(v => {
        if (typeof v === 'boolean') on = v;
      });
      timer = setInterval(() => void tick(), Math.min(config.autopilot.intervalMs, 60_000));
      timer.unref();
      setTimeout(() => void tick(), 3000).unref();
    },
    stop() {
      if (timer) clearInterval(timer);
      timer = null;
    },
    isOn: () => on,
    async setOn(next) {
      on = next;
      await kvSet(db.query, 'autopilot_on', next);
      await audit(db, { actor: 'director', action: next ? 'autopilot.on' : 'autopilot.off' });
    },
    jobs: view,
    async runNow(id) {
      for (const j of list) if (!id || j.id === id) await runJob(j);
      return view();
    },
    auditBroken: () => chainBroken,
  };
}
