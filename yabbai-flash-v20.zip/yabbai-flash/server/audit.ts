/**
 * Tamper-evident audit log.
 *
 * Each entry's hash covers the previous entry's hash, so removing or editing
 * any row breaks every hash after it. The table also refuses UPDATE and DELETE
 * at the database level. "Tamper-evident" is the honest word: someone with
 * full database access could rebuild the whole chain, but nothing inside this
 * app can, and any partial edit is detectable with `verifyAuditChain`.
 */
import type { Db, Query } from './db.ts';
import { kvGet, kvSet } from './db.ts';
import { sha256hex, stableJson } from './util.ts';
import type { AuditEntry } from '../shared/types.ts';

const GENESIS = 'GENESIS';
const LOCK_KEY = 4217001;
/**
 * The newest entry's position and fingerprint, kept outside the log table.
 * A hash chain alone cannot tell "nothing happened yet" from "everything was
 * wiped", or notice entries cut off the end. This marker can.
 */
const HEAD_KEY = 'audit_head';
interface Head {
  seq: number;
  hash: string;
}

export interface AuditInput {
  actor: string; // 'director' | 'stripe' | 'solana' | 'system' | 'public'
  action: string;
  detail?: Record<string, unknown>;
}

function entryHash(seq: number, at: number, actor: string, action: string, detailText: string, prevHash: string): string {
  return sha256hex(`${seq}|${at}|${actor}|${action}|${detailText}|${prevHash}`);
}

/** Append inside an existing transaction. */
export async function auditTx(q: Query, input: AuditInput): Promise<void> {
  // Serialise appends so two transactions can never claim the same seq.
  await q('SELECT pg_advisory_xact_lock($1)', [LOCK_KEY]);
  const { rows } = await q('SELECT seq, hash FROM audit_log ORDER BY seq DESC LIMIT 1');
  const prevSeq = rows.length ? Number(rows[0].seq) : 0;
  const prevHash = rows.length ? String(rows[0].hash) : GENESIS;
  const seq = prevSeq + 1;
  const at = Date.now();
  const detailText = stableJson(input.detail ?? {});
  const hash = entryHash(seq, at, input.actor, input.action, detailText, prevHash);
  await q('INSERT INTO audit_log (seq, at, actor, action, detail, prev_hash, hash) VALUES ($1,$2,$3,$4,$5,$6,$7)', [
    seq,
    at,
    input.actor,
    input.action,
    detailText,
    prevHash,
    hash,
  ]);
  await kvSet(q, HEAD_KEY, { seq, hash } satisfies Head);
}

/** Append in its own transaction. Never throws into the caller's happy path. */
export async function audit(db: Db, input: AuditInput): Promise<void> {
  try {
    await db.tx(q => auditTx(q, input));
  } catch (err) {
    console.error('[audit] failed to append:', err instanceof Error ? err.message : err);
  }
}

function mapRow(r: any): AuditEntry {
  let detail: Record<string, unknown> = {};
  try {
    detail = JSON.parse(r.detail);
  } catch {
    detail = { raw: String(r.detail) };
  }
  return { seq: Number(r.seq), at: Number(r.at), actor: r.actor, action: r.action, detail, hash: r.hash, prevHash: r.prev_hash };
}

export async function listAudit(q: Query, limit = 100, beforeSeq?: number): Promise<AuditEntry[]> {
  const lim = Math.min(500, Math.max(1, limit));
  const { rows } = beforeSeq
    ? await q('SELECT * FROM audit_log WHERE seq < $1 ORDER BY seq DESC LIMIT $2', [beforeSeq, lim])
    : await q('SELECT * FROM audit_log ORDER BY seq DESC LIMIT $1', [lim]);
  return rows.map(mapRow);
}

export async function verifyAuditChain(q: Query): Promise<{ ok: boolean; entries: number; brokenAtSeq: number | null; headHash: string }> {
  // Read the marker first: anything appended while we walk only makes the log longer than it.
  const head = await kvGet<Head>(q, HEAD_KEY);
  let hashAtHead: string | null = null;
  let prevHash = GENESIS;
  let expectedSeq = 1;
  let entries = 0;
  let cursor = 0;
  for (;;) {
    const { rows } = await q('SELECT * FROM audit_log WHERE seq > $1 ORDER BY seq ASC LIMIT 1000', [cursor]);
    if (rows.length === 0) break;
    for (const r of rows) {
      const seq = Number(r.seq);
      const good =
        seq === expectedSeq && r.prev_hash === prevHash && r.hash === entryHash(seq, Number(r.at), r.actor, r.action, r.detail, prevHash);
      if (!good) return { ok: false, entries, brokenAtSeq: seq, headHash: prevHash };
      prevHash = r.hash;
      expectedSeq = seq + 1;
      cursor = seq;
      entries += 1;
      if (head && seq === Number(head.seq)) hashAtHead = r.hash;
    }
  }
  // Entries the marker says existed are gone, or the entry at that position is not the one recorded.
  if (head && Number(head.seq) > 0 && hashAtHead !== head.hash) {
    return { ok: false, entries, brokenAtSeq: Math.min(entries + 1, Number(head.seq)), headHash: prevHash };
  }
  return { ok: true, entries, brokenAtSeq: null, headHash: prevHash };
}
