/**
 * One small database interface over two real Postgres engines:
 *
 *  - `pg` against DATABASE_URL — what production uses.
 *  - PGlite (Postgres compiled to WASM) when DATABASE_URL is absent, so the
 *    app runs locally with zero setup. Same SQL, same constraints, same
 *    triggers. It is not treated as durable enough for live payments unless
 *    explicitly allowed (see storageIsDurable in config.ts).
 */
import type { Config } from './config.ts';
import { MIGRATIONS } from './schema.ts';

export type Row = Record<string, any>;
export type Query = <T extends Row = Row>(sql: string, params?: unknown[]) => Promise<{ rows: T[]; rowCount: number }>;

export interface Db {
  kind: 'postgres' | 'pglite';
  query: Query;
  /** Run statements atomically. Inside `fn`, use ONLY the query function passed in. */
  tx<T>(fn: (q: Query) => Promise<T>): Promise<T>;
  exec(sql: string): Promise<void>;
  close(): Promise<void>;
}

async function openPostgres(config: Config): Promise<Db> {
  const pg = (await import('pg')).default;
  // int8 → number. Every bigint we store (cents, epoch ms) is far below 2^53.
  pg.types.setTypeParser(20, (v: string) => Number(v));

  let ssl: undefined | false | { rejectUnauthorized: boolean };
  if (config.databaseSsl === 'require') ssl = { rejectUnauthorized: true };
  else if (config.databaseSsl === 'no-verify') ssl = { rejectUnauthorized: false };
  else if (config.databaseSsl === 'disable') ssl = false;

  const pool = new pg.Pool({
    connectionString: config.databaseUrl!,
    ...(ssl === undefined ? {} : { ssl }),
    max: 8,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 10_000,
  });
  pool.on('error', err => console.error('[db] idle client error:', err.message));

  const query: Query = async (sql, params) => {
    const res = await pool.query(sql, params as any[]);
    return { rows: res.rows as any[], rowCount: res.rowCount ?? 0 };
  };

  return {
    kind: 'postgres',
    query,
    async tx(fn) {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const q: Query = async (sql, params) => {
          const res = await client.query(sql, params as any[]);
          return { rows: res.rows as any[], rowCount: res.rowCount ?? 0 };
        };
        const out = await fn(q);
        await client.query('COMMIT');
        return out;
      } catch (err) {
        try {
          await client.query('ROLLBACK');
        } catch {
          /* connection already gone */
        }
        throw err;
      } finally {
        client.release();
      }
    },
    async exec(sql) {
      await pool.query(sql);
    },
    async close() {
      await pool.end();
    },
  };
}

async function openPglite(config: Config): Promise<Db> {
  const { PGlite } = await import('@electric-sql/pglite');
  let dir: string | undefined;
  if (config.dataDir) {
    const fs = await import('node:fs');
    const path = await import('node:path');
    dir = path.resolve(config.dataDir);
    fs.mkdirSync(dir, { recursive: true });
  }
  const lite: any = dir ? new PGlite(dir) : new PGlite();
  await lite.waitReady;

  const normalise = (res: any) => ({ rows: (res.rows ?? []) as any[], rowCount: Number(res.affectedRows ?? res.rows?.length ?? 0) });
  const query: Query = async (sql, params) => normalise(await lite.query(sql, params ?? []));

  return {
    kind: 'pglite',
    query,
    async tx(fn) {
      return lite.transaction(async (t: any) => {
        const q: Query = async (sql, params) => normalise(await t.query(sql, params ?? []));
        return fn(q);
      });
    },
    async exec(sql) {
      await lite.exec(sql);
    },
    async close() {
      await lite.close();
    },
  };
}

export async function openDb(config: Config): Promise<Db> {
  const db = config.databaseUrl ? await openPostgres(config) : await openPglite(config);
  await migrate(db);
  return db;
}

async function migrate(db: Db): Promise<void> {
  await db.exec('CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, name TEXT NOT NULL, applied_at BIGINT NOT NULL)');
  const { rows } = await db.query<{ version: number }>('SELECT version FROM schema_migrations');
  const done = new Set(rows.map(r => Number(r.version)));
  for (const m of MIGRATIONS) {
    if (done.has(m.version)) continue;
    // One migration = one atomic unit. DDL is transactional in Postgres.
    await db.exec(`BEGIN;\n${m.sql}\nINSERT INTO schema_migrations (version, name, applied_at) VALUES (${m.version}, '${m.name}', ${Date.now()});\nCOMMIT;`);
    console.log(`[db] applied migration ${m.version} (${m.name})`);
  }
}

// ── tiny key/value helpers ────────────────────────────────────────────────
export async function kvGet<T>(q: Query, key: string): Promise<T | null> {
  const { rows } = await q('SELECT value FROM kv WHERE key = $1', [key]);
  return rows.length ? (rows[0].value as T) : null;
}

export async function kvSet(q: Query, key: string, value: unknown): Promise<void> {
  await q(
    `INSERT INTO kv (key, value, updated_at) VALUES ($1, $2::jsonb, $3)
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = EXCLUDED.updated_at`,
    [key, JSON.stringify(value), Date.now()]
  );
}

/** Atomically increment and return a named counter. */
export async function nextCounter(q: Query, name: string): Promise<number> {
  const { rows } = await q(
    `INSERT INTO counters (name, value) VALUES ($1, 1)
     ON CONFLICT (name) DO UPDATE SET value = counters.value + 1
     RETURNING value`,
    [name]
  );
  return Number(rows[0].value);
}
