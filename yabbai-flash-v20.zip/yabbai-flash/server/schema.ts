/**
 * Database schema.
 *
 * The rules that keep money honest are enforced here, in Postgres, and not
 * only in application code:
 *
 *  - payments.proof_id is UNIQUE: one Stripe payment or one chain transaction
 *    can be credited exactly once, no matter how many times it is reported.
 *  - payments are append-only. A trigger rejects DELETE and rejects any UPDATE
 *    that touches the amount, the proof, the rail or what it was paid against.
 *    Only refund and dispute markers can change.
 *  - verified = (rail <> 'attested'): a payment you typed in yourself can
 *    never be stored as processor-verified, and vice versa.
 *  - a product cannot be 'listed' without a deliverable ("never sell air").
 *  - the audit log rejects UPDATE and DELETE outright.
 *  - a network link is a web address (http or https) and nothing else.
 *  - a lesson the council wrote cannot be active without a recorded decision.
 */

export const MIGRATIONS: Array<{ version: number; name: string; sql: string }> = [
  {
    version: 1,
    name: 'initial',
    sql: `
CREATE TABLE kv (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  updated_at BIGINT NOT NULL
);

CREATE TABLE counters (
  name TEXT PRIMARY KEY,
  value BIGINT NOT NULL
);

CREATE TABLE sessions (
  token_hash TEXT PRIMARY KEY,
  created_at BIGINT NOT NULL,
  expires_at BIGINT NOT NULL,
  last_seen_at BIGINT NOT NULL,
  stepup_until BIGINT NOT NULL DEFAULT 0,
  ip TEXT,
  user_agent TEXT
);

CREATE TABLE leads (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  company TEXT,
  email TEXT,
  phone TEXT,
  sector TEXT,
  message TEXT,
  source TEXT NOT NULL CHECK (source IN ('manual','intake','import')),
  stage TEXT NOT NULL CHECK (stage IN ('new','qualified','contacted','replied','proposal','won','lost')),
  score INTEGER CHECK (score IS NULL OR (score >= 0 AND score <= 100)),
  score_rationale TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);

CREATE TABLE invoices (
  id TEXT PRIMARY KEY,
  number TEXT NOT NULL,
  token TEXT NOT NULL UNIQUE,
  client_name TEXT NOT NULL,
  client_email TEXT,
  items JSONB NOT NULL,
  subtotal_cents BIGINT NOT NULL CHECK (subtotal_cents >= 0),
  tax_cents BIGINT NOT NULL CHECK (tax_cents >= 0),
  discount_cents BIGINT NOT NULL CHECK (discount_cents >= 0),
  total_cents BIGINT NOT NULL CHECK (total_cents >= 0),
  note TEXT,
  due_date TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('draft','open','void')),
  livemode BOOLEAN NOT NULL,
  lead_id TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  opened_at BIGINT,
  UNIQUE (number, livemode)
);

CREATE TABLE products (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  price_cents BIGINT NOT NULL CHECK (price_cents >= 0),
  status TEXT NOT NULL CHECK (status IN ('draft','listed','archived')),
  ships JSONB NOT NULL,
  does_not_ship JSONB NOT NULL,
  deliverable_kind TEXT CHECK (deliverable_kind IN ('link','text')),
  deliverable_value TEXT,
  livemode BOOLEAN NOT NULL,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE (slug, livemode),
  CONSTRAINT never_sell_air CHECK (
    status <> 'listed'
    OR (deliverable_kind IS NOT NULL AND deliverable_value IS NOT NULL AND length(btrim(deliverable_value)) > 0 AND price_cents >= 100)
  )
);

CREATE TABLE orders (
  id TEXT PRIMARY KEY,
  token TEXT NOT NULL UNIQUE,
  product_id TEXT NOT NULL REFERENCES products(id),
  product_title TEXT NOT NULL,
  price_cents BIGINT NOT NULL CHECK (price_cents > 0),
  customer_email TEXT,
  status TEXT NOT NULL CHECK (status IN ('pending','paid','refunded','expired')),
  livemode BOOLEAN NOT NULL,
  created_at BIGINT NOT NULL,
  paid_at BIGINT,
  delivered_at BIGINT
);
CREATE INDEX orders_product ON orders(product_id);

CREATE TABLE payments (
  id TEXT PRIMARY KEY,
  proof_id TEXT NOT NULL UNIQUE,
  rail TEXT NOT NULL CHECK (rail IN ('stripe','solana','attested')),
  kind TEXT NOT NULL CHECK (kind IN ('invoice','order')),
  invoice_id TEXT REFERENCES invoices(id),
  order_id TEXT REFERENCES orders(id),
  amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
  refunded_cents BIGINT NOT NULL DEFAULT 0 CHECK (refunded_cents >= 0),
  verified BOOLEAN NOT NULL,
  disputed BOOLEAN NOT NULL DEFAULT FALSE,
  livemode BOOLEAN NOT NULL,
  payer TEXT,
  detail JSONB NOT NULL,
  occurred_at BIGINT NOT NULL,
  created_at BIGINT NOT NULL,
  CONSTRAINT payment_target CHECK (
    (kind = 'invoice' AND invoice_id IS NOT NULL AND order_id IS NULL)
    OR (kind = 'order' AND order_id IS NOT NULL AND invoice_id IS NULL)
  ),
  CONSTRAINT verified_means_processor CHECK (verified = (rail <> 'attested')),
  CONSTRAINT refund_within_amount CHECK (refunded_cents <= amount_cents)
);
CREATE INDEX payments_invoice ON payments(invoice_id);
CREATE INDEX payments_order ON payments(order_id);
CREATE INDEX payments_time ON payments(livemode, occurred_at);

CREATE FUNCTION flash_payments_guard() RETURNS trigger AS $fn$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'payments are append-only: rows cannot be deleted';
  END IF;
  IF NEW.id <> OLD.id
     OR NEW.proof_id <> OLD.proof_id
     OR NEW.rail <> OLD.rail
     OR NEW.kind <> OLD.kind
     OR NEW.amount_cents <> OLD.amount_cents
     OR NEW.verified <> OLD.verified
     OR NEW.livemode <> OLD.livemode
     OR NEW.occurred_at <> OLD.occurred_at
     OR NEW.created_at <> OLD.created_at
     OR NEW.invoice_id IS DISTINCT FROM OLD.invoice_id
     OR NEW.order_id IS DISTINCT FROM OLD.order_id THEN
    RAISE EXCEPTION 'payments are append-only: only refund and dispute markers may change';
  END IF;
  RETURN NEW;
END
$fn$ LANGUAGE plpgsql;

CREATE TRIGGER payments_guard BEFORE UPDATE OR DELETE ON payments
  FOR EACH ROW EXECUTE FUNCTION flash_payments_guard();

CREATE TABLE stripe_sessions (
  session_id TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('invoice','order')),
  ref_id TEXT NOT NULL,
  amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
  url TEXT,
  status TEXT NOT NULL CHECK (status IN ('open','paid','expired','rejected')),
  livemode BOOLEAN NOT NULL,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX stripe_sessions_ref ON stripe_sessions(kind, ref_id);
CREATE INDEX stripe_sessions_open ON stripe_sessions(status, created_at);

CREATE TABLE sol_quotes (
  reference TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('invoice','order','proof')),
  ref_id TEXT NOT NULL,
  asset TEXT NOT NULL CHECK (asset IN ('SOL','USDC')),
  amount_base TEXT NOT NULL,
  aud_cents BIGINT NOT NULL CHECK (aud_cents >= 0),
  aud_per_unit DOUBLE PRECISION NOT NULL,
  recipient TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('open','paid','expired')),
  signature TEXT,
  livemode BOOLEAN NOT NULL,
  created_at BIGINT NOT NULL,
  expires_at BIGINT NOT NULL,
  checked_at BIGINT NOT NULL DEFAULT 0
);
CREATE INDEX sol_quotes_ref ON sol_quotes(kind, ref_id);
CREATE INDEX sol_quotes_open ON sol_quotes(status, created_at);

CREATE TABLE processed_events (
  event_id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  received_at BIGINT NOT NULL
);

CREATE TABLE drafts (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL CHECK (type IN ('outreach','followup','product_spec','brief')),
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  ref_kind TEXT CHECK (ref_kind IN ('lead','invoice','product')),
  ref_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('pending','used','dismissed')),
  source TEXT NOT NULL CHECK (source IN ('ai','director')),
  created_at BIGINT NOT NULL,
  decided_at BIGINT
);
CREATE INDEX drafts_status ON drafts(status, created_at);

CREATE TABLE audit_log (
  seq BIGINT PRIMARY KEY,
  at BIGINT NOT NULL,
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  detail TEXT NOT NULL,
  prev_hash TEXT NOT NULL,
  hash TEXT NOT NULL
);

CREATE FUNCTION flash_audit_guard() RETURNS trigger AS $fn$
BEGIN
  RAISE EXCEPTION 'the audit log is append-only';
END
$fn$ LANGUAGE plpgsql;

CREATE TRIGGER audit_guard BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION flash_audit_guard();
`,
  },
  {
    version: 2,
    name: 'truncate guards',
    // Row-level triggers do not fire for TRUNCATE, so without these a single
    // statement could empty the ledger or the audit log.
    sql: `
CREATE FUNCTION flash_no_truncate() RETURNS trigger AS $fn$
BEGIN
  RAISE EXCEPTION '% is append-only and cannot be truncated', TG_TABLE_NAME;
END
$fn$ LANGUAGE plpgsql;

CREATE TRIGGER audit_no_truncate BEFORE TRUNCATE ON audit_log
  FOR EACH STATEMENT EXECUTE FUNCTION flash_no_truncate();

CREATE TRIGGER payments_no_truncate BEFORE TRUNCATE ON payments
  FOR EACH STATEMENT EXECUTE FUNCTION flash_no_truncate();
`,
  },
  {
    version: 3,
    name: 'core: network links, council, lessons',
    // None of these tables holds money. A link carries no figure, a council
    // session is text, and a lesson is a note. Two rules still live here, in the
    // database: a link is a web address and nothing else, and a note the model
    // wrote cannot become active without a recorded decision by the director.
    sql: `
CREATE TABLE network_links (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  url TEXT NOT NULL UNIQUE,
  realm TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('app','site','dashboard','artifact','doc','repo','tool')),
  note TEXT,
  watch BOOLEAN NOT NULL DEFAULT FALSE,
  last_status INTEGER,
  last_error TEXT,
  last_checked_at BIGINT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  CONSTRAINT link_is_a_web_address CHECK (url ~ '^https?://')
);
CREATE INDEX network_links_realm ON network_links(realm, name);

CREATE TABLE council_sessions (
  id TEXT PRIMARY KEY,
  question TEXT NOT NULL,
  picked_by TEXT NOT NULL CHECK (picked_by IN ('router','director')),
  status TEXT NOT NULL CHECK (status IN ('running','done','failed')),
  verdict TEXT,
  error TEXT,
  decision TEXT CHECK (decision IS NULL OR decision IN ('accepted','rejected','noted')),
  decision_note TEXT,
  livemode BOOLEAN NOT NULL,
  created_at BIGINT NOT NULL,
  finished_at BIGINT,
  decided_at BIGINT
);
CREATE INDEX council_sessions_time ON council_sessions(created_at);

CREATE TABLE council_opinions (
  session_id TEXT NOT NULL REFERENCES council_sessions(id) ON DELETE CASCADE,
  seat TEXT NOT NULL,
  position INTEGER NOT NULL,
  reason TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('waiting','thinking','done','failed')),
  body TEXT,
  error TEXT,
  started_at BIGINT,
  finished_at BIGINT,
  PRIMARY KEY (session_id, seat)
);

CREATE TABLE lessons (
  id TEXT PRIMARY KEY,
  text TEXT NOT NULL,
  seat TEXT NOT NULL,
  source TEXT NOT NULL CHECK (source IN ('director','council')),
  session_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('proposed','active','retired','dismissed')),
  created_at BIGINT NOT NULL,
  decided_at BIGINT,
  CONSTRAINT council_notes_wait_for_the_director CHECK (source = 'director' OR status = 'proposed' OR decided_at IS NOT NULL)
);
CREATE INDEX lessons_status ON lessons(status, created_at);
`,
  },
];
