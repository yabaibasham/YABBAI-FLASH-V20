/**
 * AUD prices for SOL and USDC, used only to quote crypto invoices.
 *
 * The old build fell back to a hardcoded "$250 per SOL" whenever a price feed
 * failed. Here there is no fallback number: two independent sources are asked,
 * they must agree within 3%, and if neither answers the quote is refused.
 * A wrong price means a customer under- or over-pays in real money.
 */
import { fetchWithTimeout } from './util.ts';

export interface Rates {
  audPerSol: number;
  audPerUsdc: number;
  sources: string[];
  at: number;
}

const TTL_MS = 60_000;
const MAX_DISAGREEMENT = 0.03;

export interface FxService {
  getRates(): Promise<Rates>;
  /** Last good rates if still reasonably fresh — for display only, never for quoting. */
  peek(): Rates | null;
}

export function createFxService(fetchImpl: typeof fetch): FxService {
  let cache: Rates | null = null;
  let inflight: Promise<Rates> | null = null;

  async function fromCoinGecko(): Promise<{ sol: number; usdc: number } | null> {
    try {
      const res = await fetchWithTimeout(fetchImpl, 'https://api.coingecko.com/api/v3/simple/price?ids=solana,usd-coin&vs_currencies=aud', {}, 6000);
      if (!res.ok) return null;
      const d: any = await res.json();
      const sol = Number(d?.solana?.aud);
      const usdc = Number(d?.['usd-coin']?.aud);
      return sane(sol, usdc) ? { sol, usdc } : null;
    } catch {
      return null;
    }
  }

  async function fromCoinbase(): Promise<{ sol: number; usdc: number } | null> {
    try {
      const [a, b] = await Promise.all([
        fetchWithTimeout(fetchImpl, 'https://api.coinbase.com/v2/exchange-rates?currency=SOL', {}, 6000),
        fetchWithTimeout(fetchImpl, 'https://api.coinbase.com/v2/exchange-rates?currency=USDC', {}, 6000),
      ]);
      if (!a.ok || !b.ok) return null;
      const da: any = await a.json();
      const dbb: any = await b.json();
      const sol = Number(da?.data?.rates?.AUD);
      const usdc = Number(dbb?.data?.rates?.AUD);
      return sane(sol, usdc) ? { sol, usdc } : null;
    } catch {
      return null;
    }
  }

  function sane(sol: number, usdc: number): boolean {
    // Wide plausibility bounds: catches zeros, NaN and unit mix-ups, nothing else.
    return Number.isFinite(sol) && Number.isFinite(usdc) && sol > 1 && sol < 100_000 && usdc > 0.5 && usdc < 5;
  }

  function agree(a: number, b: number): boolean {
    return Math.abs(a - b) / ((a + b) / 2) <= MAX_DISAGREEMENT;
  }

  async function load(): Promise<Rates> {
    const [cg, cb] = await Promise.all([fromCoinGecko(), fromCoinbase()]);
    if (cg && cb) {
      if (!agree(cg.sol, cb.sol) || !agree(cg.usdc, cb.usdc)) {
        throw new Error('Price sources disagree by more than 3%. Crypto quotes are paused until they agree.');
      }
      return { audPerSol: (cg.sol + cb.sol) / 2, audPerUsdc: (cg.usdc + cb.usdc) / 2, sources: ['coingecko', 'coinbase'], at: Date.now() };
    }
    const one = cg ?? cb;
    if (!one) throw new Error('No price source is reachable. Crypto quotes are paused.');
    return { audPerSol: one.sol, audPerUsdc: one.usdc, sources: [cg ? 'coingecko' : 'coinbase'], at: Date.now() };
  }

  return {
    async getRates() {
      if (cache && Date.now() - cache.at < TTL_MS) return cache;
      if (!inflight) {
        inflight = load()
          .then(r => {
            cache = r;
            return r;
          })
          .finally(() => {
            inflight = null;
          });
      }
      return inflight;
    },
    peek() {
      return cache && Date.now() - cache.at < 15 * 60_000 ? cache : null;
    },
  };
}
