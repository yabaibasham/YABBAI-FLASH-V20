/**
 * Console API — everything here requires a signed-in director session.
 *
 * Read the routes below and notice what is missing: there is no route that
 * takes an amount and adds it to a balance, none that marks an invoice paid,
 * none that sets the wallet or bank destination, and none that creates a
 * payout. Those operations do not exist in this app.
 */
import { Router } from 'express';
import express from 'express';
import type { Ctx } from './context.ts';
import { storageIsDurable } from './config.ts';
import { audit, listAudit, verifyAuditChain } from './audit.ts';
import { assertStepUp, requireStepUp } from './auth.ts';
import { coreRouter } from './coreRoutes.ts';
import { kvGet, kvSet } from './db.ts';
import {
  attestPayment,
  createInvoice,
  getInvoice,
  listInvoices,
  openInvoice,
  parseInvoiceInput,
  suggestFromStatement,
  updateDraftInvoice,
  voidInvoice,
} from './invoices.ts';
import { LEAD_STAGES, addDraft, createLead, decideDraft, deleteLead, getLead, listDrafts, listLeads, parseLeadInput, setLeadScore, updateLead } from './leads.ts';
import { DEFAULT_ALLOCATION, allocationPlan, ledgerTotals, listPayments } from './ledger.ts';
import type { AllocationSettings } from './ledger.ts';
import { createProduct, getProduct, listOrders, listProducts, parseProductInput, setProductStatus, updateProduct } from './products.ts';
import { RateLimiter, limit } from './security.ts';
import { HttpError, bad, dollarsToCents, isIsoDate, notFound } from './util.ts';
import { body, optBool, optStr, reqEnum, reqInt, reqStr, safeParam } from './validate.ts';
import type { HealthCheck, Overview } from '../shared/types.ts';

export async function buildHealth(ctx: Ctx): Promise<HealthCheck[]> {
  const { config, db, stripe, solana, ai, autopilot } = ctx;
  const checks: HealthCheck[] = [];
  const has = (code: string) => config.problems.find(p => p.code === code);
  const live = config.mode === 'live';

  checks.push({
    id: 'login',
    label: 'Director login',
    state: config.auth.passwordHash ? 'ok' : 'warn',
    detail: config.auth.passwordHash ? 'Password stored as a scrypt hash.' : 'Password is set in plain text in the environment.',
    fix: config.auth.passwordHash ? undefined : 'Run `npm run setup` and set DIRECTOR_PASSWORD_HASH instead of DIRECTOR_PASSWORD.',
  });
  checks.push({
    id: 'totp',
    label: 'Two-factor login',
    state: config.auth.totpSecret ? 'ok' : 'warn',
    detail: config.auth.totpSecret ? 'An authenticator code is required at sign-in.' : 'Off. Your password is the only thing protecting the console.',
    fix: config.auth.totpSecret ? undefined : 'Run `npm run setup`, scan the code with an authenticator app and set TOTP_SECRET.',
  });

  checks.push({
    id: 'database',
    label: 'Database',
    state: db.kind === 'postgres' ? 'ok' : (live || config.isProd) && (!storageIsDurable(config) || !config.dataDir) ? 'error' : 'warn',
    detail:
      db.kind === 'postgres'
        ? 'Postgres via DATABASE_URL.'
        : config.dataDir
          ? `Built-in local database at ${config.dataDir}. Fine for trying things out, not for real payments.`
          : 'In-memory database. Everything is lost when the server restarts.',
    fix: db.kind === 'postgres' ? undefined : 'Create a managed Postgres database and set DATABASE_URL. Live payment rails stay off until you do.',
  });

  checks.push({
    id: 'url',
    label: 'Public address',
    state: config.publicBaseUrl ? (has('INSECURE_PUBLIC_URL') ? 'error' : 'ok') : config.isProd ? 'error' : 'off',
    detail: config.publicBaseUrl
      ? has('INSECURE_PUBLIC_URL')
        ? `${config.publicBaseUrl} — must be https.`
        : config.publicBaseUrl
      : config.isProd
        ? 'Not set. Card checkout is off: the app will not guess its own address from a request.'
        : 'Not set. Fine for local runs; pay links use the address you are browsing on.',
    fix: config.publicBaseUrl && !has('INSECURE_PUBLIC_URL') ? undefined : 'Set PUBLIC_BASE_URL to the https address customers will use (Render fills this in for you).',
  });

  // Stripe
  const st = await stripe.status();
  if (!st.configured) {
    checks.push({
      id: 'stripe',
      label: 'Stripe (cards → your bank)',
      state: has('BAD_STRIPE_KEY') ? 'error' : 'off',
      detail: has('BAD_STRIPE_KEY')?.message ?? 'Not connected.',
      fix: 'Create a restricted key in Stripe (Checkout Sessions: write; Balance, Payouts, PaymentIntents: read) and set STRIPE_SECRET_KEY.',
    });
  } else {
    checks.push({
      id: 'stripe',
      label: 'Stripe key',
      state: has('UNRESTRICTED_STRIPE_KEY') ? 'warn' : 'ok',
      detail: `${st.mode === 'live' ? 'Live' : 'Test'} mode${has('UNRESTRICTED_STRIPE_KEY') ? ' — unrestricted secret key' : ''}.`,
      fix: has('UNRESTRICTED_STRIPE_KEY') ? 'Replace it with a restricted key (rk_live_) so a leak cannot move money.' : undefined,
    });
    const due = st.requirementsDue;
    // null means this key was not allowed to read the account, which says nothing about activation.
    const unknown = st.reachable && st.chargesEnabled === null;
    checks.push({
      id: 'stripe_account',
      label: 'Stripe account',
      state: !st.reachable || unknown ? 'warn' : st.chargesEnabled && st.payoutsEnabled ? 'ok' : 'error',
      detail: !st.reachable
        ? `Could not read account status (${st.error ?? 'unknown error'}).`
        : unknown
          ? `This key cannot read whether the account is activated (${st.error ?? 'no detail'}). Checkout still works if it is.`
          : st.chargesEnabled && st.payoutsEnabled
            ? `Can take payments and pay out${st.payoutDestination ? ` to ${st.payoutDestination}` : ''}${st.payoutSchedule ? ` (${st.payoutSchedule})` : ''}.`
            : `Payments ${st.chargesEnabled ? 'enabled' : 'DISABLED'}, payouts ${st.payoutsEnabled ? 'enabled' : 'DISABLED'}.${
                due.length ? ` Stripe still needs: ${due.join(', ')}.` : ''
              }`,
      fix: !st.reachable
        ? undefined
        : unknown
          ? 'Add the permission Stripe names in that message to the restricted key, or confirm activation yourself in the Stripe Dashboard.'
          : !(st.chargesEnabled && st.payoutsEnabled)
            ? 'Finish activating the account in the Stripe Dashboard (identity, business details, bank account).'
            : undefined,
    });
    const lastEvent = await db.query('SELECT MAX(received_at) AS at FROM processed_events');
    const lastAt = lastEvent.rows[0]?.at ? Number(lastEvent.rows[0].at) : null;
    checks.push({
      id: 'stripe_webhook',
      label: 'Stripe webhook',
      state: config.stripe.webhookSecret ? (lastAt ? 'ok' : 'warn') : 'error',
      detail: config.stripe.webhookSecret
        ? lastAt
          ? `Signing secret set. Last event received ${new Date(lastAt).toISOString()}.`
          : 'Signing secret set, but no event has arrived yet.'
        : 'No signing secret. Payments are only picked up by the periodic re-check.',
      fix: config.stripe.webhookSecret
        ? lastAt
          ? undefined
          : `In Stripe, confirm the endpoint is ${ctx.baseUrl()}/api/webhooks/stripe and send a test event.`
        : `Add a webhook endpoint in Stripe pointing at ${ctx.baseUrl()}/api/webhooks/stripe and set STRIPE_WEBHOOK_SECRET.`,
    });
  }

  // Solana
  const w = await solana.walletStatus().catch(() => null);
  const solRail = solana.railState();
  if (!config.solana.receiveAddress) {
    checks.push({ id: 'wallet', label: 'Solana wallet', state: 'off', detail: 'No receiving wallet configured.', fix: 'Set SOLANA_RECEIVE_ADDRESS to your wallet address.' });
  } else {
    checks.push({
      id: 'wallet',
      label: 'Solana wallet',
      state: !config.solana.addressValid || has('MODE_MISMATCH') ? 'error' : w?.proven ? (w.proofMethod === 'override' ? 'warn' : 'ok') : 'error',
      detail: !config.solana.addressValid
        ? (has('BAD_SOLANA_ADDRESS')?.message ?? 'Invalid address.')
        : has('MODE_MISMATCH')
          ? has('MODE_MISMATCH')!.message
          : w?.proven
            ? w.proofMethod === 'override'
              ? `${config.solana.receiveAddress} — accepted WITHOUT proof (SOLANA_ADDRESS_UNPROVEN_OK).`
              : `${config.solana.receiveAddress} — control proven (${w.proofMethod}).`
            : `${config.solana.receiveAddress} — not yet proven. Customers are not shown the crypto option.`,
      fix: w?.proven && w.proofMethod !== 'override' ? undefined : solRail.reason ?? 'Open Payouts → Wallet and prove control.',
    });
    checks.push({
      id: 'rpc',
      label: 'Solana RPC',
      state: w?.error ? 'warn' : has('PUBLIC_RPC') ? 'warn' : 'ok',
      detail: w?.error ? `Not reachable: ${w.error}` : has('PUBLIC_RPC') ? 'Using the shared public RPC, which is heavily rate limited.' : 'Private RPC endpoint configured.',
      fix: w?.error || has('PUBLIC_RPC') ? 'Set SOLANA_RPC_URL to a Helius or Alchemy endpoint.' : undefined,
    });
  }

  const b = config.bank;
  checks.push({
    id: 'bank',
    label: 'Bank transfer details',
    state: b.payId || (b.bsb && b.accountNumber) ? 'ok' : 'off',
    detail: b.payId || (b.bsb && b.accountNumber) ? 'Shown on invoices. Bank payments are recorded by you and labelled "attested".' : 'Not shown on invoices.',
    fix: b.payId || (b.bsb && b.accountNumber) ? undefined : 'Optional: set BANK_PAYID or BANK_BSB + BANK_ACCOUNT_NUMBER + BANK_ACCOUNT_NAME.',
  });

  checks.push({
    id: 'gst',
    label: 'GST',
    state: has('GST_NEEDS_ABN') ? 'error' : 'ok',
    detail: config.business.gstRegistered ? `Registered — ABN ${config.business.abn}. Invoices can add 10% GST.` : 'Not registered: invoices show no GST.',
    fix: has('GST_NEEDS_ABN') ? 'Set BUSINESS_ABN.' : undefined,
  });

  checks.push({
    id: 'ai',
    label: 'AI brain',
    state: !ai.enabled() ? 'off' : ai.lastError() ? 'warn' : 'ok',
    detail: !ai.enabled() ? 'No provider configured. Drafting and scoring are unavailable.' : ai.lastError() ? `Last call failed: ${ai.lastError()}` : `${ai.providerLabel()}${ai.lastOkAt() ? '' : ' (not called yet)'}.`,
    fix: !ai.enabled() ? 'Set GEMINI_API_KEY, or LLM_BASE_URL + LLM_MODEL for another provider.' : undefined,
  });

  const chain = await verifyAuditChain(db.query);
  checks.push({
    id: 'audit',
    label: 'Audit log',
    state: chain.ok ? 'ok' : 'error',
    detail: chain.ok ? `${chain.entries} entries, hash chain intact.` : `Hash chain broken at entry #${chain.brokenAtSeq}. Someone or something altered the log.`,
  });

  checks.push({
    id: 'autopilot',
    label: 'Autopilot',
    state: autopilot.isOn() ? 'ok' : 'warn',
    detail: autopilot.isOn() ? 'Scheduled jobs are running.' : 'Paused. Payments are still caught by webhooks and when a customer has the pay page open.',
  });

  const links = await ctx.network.list();
  const watched = links.filter(l => l.watch);
  const stopped = watched.filter(l => l.state === 'down' || l.state === 'error');
  checks.push({
    id: 'network',
    label: 'Linked apps',
    state: links.length === 0 ? 'off' : stopped.length ? 'warn' : 'ok',
    detail:
      links.length === 0
        ? 'No links yet. The Network tab is empty.'
        : stopped.length
          ? `${links.length} linked, ${watched.length} watched. Not answering: ${stopped.slice(0, 6).map(l => l.name).join(', ')}${stopped.length > 6 ? ` and ${stopped.length - 6} more` : ''}.`
          : `${links.length} linked, ${watched.length} watched${watched.length ? ', all answering at the last check' : ''}.`,
    fix: stopped.length ? 'Open Network to see what each one last answered. This app only watches them; fix them where they are hosted.' : undefined,
  });

  for (const p of config.problems) {
    if (['BAD_BSB', 'BAD_ACCOUNT', 'BAD_TOTP', 'BAD_WEBHOOK_SECRET', 'BAD_PASSWORD_HASH'].includes(p.code)) {
      checks.push({ id: p.code.toLowerCase(), label: 'Configuration', state: p.level === 'error' ? 'error' : 'warn', detail: p.message });
    }
  }
  return checks;
}

export async function buildOverview(ctx: Ctx): Promise<Overview> {
  const { db, config, stripe, solana } = ctx;
  const [totals, invoices, payments, leads, drafts, orders] = await Promise.all([
    ledgerTotals(db.query, config),
    listInvoices(db.query, config),
    listPayments(db.query, config, { limit: 8 }),
    listLeads(db.query),
    listDrafts(db.query, 'pending'),
    listOrders(db.query, config),
  ]);
  const alloc = (await kvGet<AllocationSettings>(db.query, 'allocation')) ?? DEFAULT_ALLOCATION;
  const open = invoices.filter(i => ['open', 'part', 'overdue'].includes(i.status));
  const overdue = invoices.filter(i => i.status === 'overdue');
  const b = config.bank;
  const stripeRail = stripe.railState();
  const solRail = solana.railState();

  const attention: Overview['attention'] = [];
  const st = stripe.lastStatus() ?? (await stripe.status());
  if (config.mode === 'test') attention.push({ level: 'warn', text: 'TEST MODE. Nothing on this screen is real money.', tab: 'ops' });
  if (!st.configured) attention.push({ level: 'error', text: 'Stripe is not connected, so customers cannot pay by card.', tab: 'ops' });
  else {
    if (st.reachable && st.chargesEnabled === false) attention.push({ level: 'error', text: 'Your Stripe account is not activated: it cannot take payments or pay out yet.', tab: 'payouts' });
    else if (st.reachable && st.payoutsEnabled === false) attention.push({ level: 'error', text: 'Stripe can take payments but payouts to your bank are disabled.', tab: 'payouts' });
    else if (st.reachable && st.chargesEnabled === null) attention.push({ level: 'warn', text: 'The Stripe key cannot read whether the account is activated. Confirm it in the Stripe Dashboard.', tab: 'payouts' });
    else if (!st.reachable) attention.push({ level: 'warn', text: 'Stripe could not be reached just now, so its status is unknown.', tab: 'payouts' });
    // Anything else keeping the card button hidden (no database, no public address) is said in its own words.
    if (!stripeRail.enabled && stripeRail.reason && !/not activated/.test(stripeRail.reason)) attention.push({ level: 'error', text: `Card payments are off: ${stripeRail.reason}`, tab: 'ops' });
  }
  if (st.configured && !config.stripe.webhookSecret) attention.push({ level: 'warn', text: 'Stripe webhook secret is missing.', tab: 'ops' });
  if (config.solana.receiveAddress && !solRail.enabled) attention.push({ level: 'warn', text: `Crypto payments are off: ${solRail.reason}`, tab: 'payouts' });
  if (!stripeRail.enabled && !solRail.enabled && !(b.payId || b.bsb)) attention.push({ level: 'error', text: 'No payment method is switched on. An invoice sent now cannot be paid.', tab: 'ops' });
  if (ctx.autopilot.auditBroken()) attention.push({ level: 'error', text: 'The audit log failed its integrity check.', tab: 'ops' });
  if (!config.auth.totpSecret) attention.push({ level: 'warn', text: 'Two-factor login is off.', tab: 'ops' });
  if (overdue.length) attention.push({ level: 'warn', text: `${overdue.length} invoice${overdue.length === 1 ? ' is' : 's are'} overdue.`, tab: 'receive' });
  const overpaid = invoices.filter(i => i.paidCents > i.totalCents);
  if (overpaid.length) attention.push({ level: 'warn', text: `${overpaid.map(i => i.number).join(', ')} received more than invoiced — a refund may be owed.`, tab: 'receive' });
  if (payments.some(p => p.disputed)) attention.push({ level: 'error', text: 'A card payment is under dispute. Respond in the Stripe Dashboard.', tab: 'receive' });
  const leadsNew = leads.filter(l => l.stage === 'new').length;
  if (leadsNew) attention.push({ level: 'info', text: `${leadsNew} new lead${leadsNew === 1 ? '' : 's'} to look at.`, tab: 'pipeline' });
  if (drafts.length) attention.push({ level: 'info', text: `${drafts.length} draft${drafts.length === 1 ? '' : 's'} waiting for you.`, tab: 'pipeline' });
  const stopped = (await ctx.network.list()).filter(l => l.state === 'down' || l.state === 'error');
  if (stopped.length) {
    const named = stopped.slice(0, 4).map(l => l.name).join(', ');
    attention.push({ level: 'warn', text: `${stopped.length} linked app${stopped.length === 1 ? ' is' : 's are'} not answering: ${named}${stopped.length > 4 ? ` and ${stopped.length - 4} more` : ''}.`, tab: 'network' });
  }
  const proposed = await db.query(`SELECT COUNT(*)::int AS n FROM lessons WHERE status = 'proposed'`);
  const waiting = Number(proposed.rows[0]?.n ?? 0);
  if (waiting) attention.push({ level: 'info', text: `${waiting} lesson${waiting === 1 ? '' : 's'} suggested by the council ${waiting === 1 ? 'is' : 'are'} waiting for your decision.`, tab: 'brain' });

  return {
    mode: config.mode,
    brandName: config.business.brandName,
    generatedAt: Date.now(),
    totals: {
      verifiedAllTimeCents: totals.verifiedAllTimeCents,
      verified30dCents: totals.verified30dCents,
      verified7dCents: totals.verified7dCents,
      attestedAllTimeCents: totals.attestedAllTimeCents,
      refundedAllTimeCents: totals.refundedAllTimeCents,
      receivableCents: open.reduce((n, i) => n + i.outstandingCents, 0),
      openInvoices: open.length,
      overdueInvoices: overdue.length,
      paymentsCount: totals.paymentsCount,
      ordersPaid: orders.filter(o => o.status === 'paid').length,
    },
    byRail: totals.byRail,
    daily: totals.daily,
    allocation: allocationPlan(totals.verifiedMonthCents, alloc),
    recentPayments: payments,
    attention,
    rails: {
      stripe: stripeRail,
      solana: solRail,
      bank: b.payId || (b.bsb && b.accountNumber) ? { enabled: true, reason: null } : { enabled: false, reason: 'No bank details configured.' },
    },
    counts: { leadsNew, draftsPending: drafts.length },
  };
}

/** A compact, PII-free picture of the business for the AI brief. */
async function aiSnapshot(ctx: Ctx): Promise<Record<string, unknown>> {
  const o = await buildOverview(ctx);
  const aud = (c: number) => `$${(c / 100).toFixed(2)} AUD`;
  return {
    mode: o.mode,
    verifiedIncome: { last7Days: aud(o.totals.verified7dCents), last30Days: aud(o.totals.verified30dCents), allTime: aud(o.totals.verifiedAllTimeCents) },
    attestedBankPaymentsAllTime: aud(o.totals.attestedAllTimeCents),
    openInvoices: o.totals.openInvoices,
    overdueInvoices: o.totals.overdueInvoices,
    owedToYou: aud(o.totals.receivableCents),
    paidOrders: o.totals.ordersPaid,
    newLeads: o.counts.leadsNew,
    draftsWaiting: o.counts.draftsPending,
    paymentMethods: { card: o.rails.stripe.enabled, crypto: o.rails.solana.enabled, bankTransfer: o.rails.bank.enabled },
    issues: o.attention.filter(a => a.level !== 'info').map(a => a.text),
  };
}

export function consoleRouter(ctx: Ctx): Router {
  const { db, config, stripe, solana, ai, autopilot } = ctx;
  const router = Router();
  const json = express.json({ limit: '200kb' });
  const bigJson = express.json({ limit: '2mb' });
  const aiLimiter = new RateLimiter(60_000, 20);
  const id = (v: unknown) => safeParam(v, 80);

  // ── read models ─────────────────────────────────────────────────────────
  router.get('/overview', async (req, res) => {
    res.json({ ...(await buildOverview(ctx)), baseUrl: ctx.baseUrl(req) });
  });
  router.get('/health', async (_req, res) => {
    res.json({ checks: await buildHealth(ctx), mode: config.mode });
  });
  router.get('/payments', async (_req, res) => {
    res.json({ payments: await listPayments(db.query, config, { limit: 300 }) });
  });
  router.post('/reconcile', async (_req, res) => {
    const jobs = await autopilot.runNow('treasurer');
    res.json({ result: jobs.find(j => j.id === 'treasurer')?.lastResult ?? null, error: jobs.find(j => j.id === 'treasurer')?.lastError ?? null });
  });

  // ── invoices ────────────────────────────────────────────────────────────
  router.get('/invoices', async (_req, res) => {
    res.json({ invoices: await listInvoices(db.query, config), gstRegistered: config.business.gstRegistered });
  });
  router.post('/invoices', json, async (req, res) => {
    res.status(201).json({ invoice: await createInvoice(db, config, parseInvoiceInput(config, body(req))) });
  });
  router.get('/invoices/:id', async (req, res) => {
    const inv = await getInvoice(db.query, config, id(req.params.id));
    if (!inv) throw notFound('Invoice not found.');
    res.json({ invoice: inv, payments: await listPayments(db.query, config, { invoiceId: inv.id }) });
  });
  router.put('/invoices/:id', json, async (req, res) => {
    res.json({ invoice: await updateDraftInvoice(db, config, id(req.params.id), parseInvoiceInput(config, body(req))) });
  });
  router.post('/invoices/:id/open', async (req, res) => {
    res.json({ invoice: await openInvoice(db, config, id(req.params.id)) });
  });
  router.post('/invoices/:id/void', async (req, res) => {
    res.json({ invoice: await voidInvoice(db, config, id(req.params.id)) });
  });
  /** Record a bank/PayID payment you have checked yourself. Needs password re-entry. */
  router.post('/invoices/:id/attest', requireStepUp, json, async (req, res) => {
    const b = body(req);
    const amountCents = dollarsToCents(b.amountDollars);
    if (amountCents === null || amountCents <= 0) throw bad('Enter the amount that arrived.');
    const reference = reqStr(b, 'reference', 4, 120);
    const date = optStr(b, 'date', 10);
    if (date && !isIsoDate(date)) throw bad('Date must be YYYY-MM-DD.');
    const out = await attestPayment(db, config, id(req.params.id), { amountCents, reference, note: optStr(b, 'note', 300), date });
    res.json(out);
  });
  router.post('/statements/suggest', bigJson, async (req, res) => {
    const csv = reqStr(body(req), 'csv', 1, 1_500_000, true);
    res.json({ suggestions: suggestFromStatement(csv, await listInvoices(db.query, config)) });
  });

  // ── products & orders ───────────────────────────────────────────────────
  router.get('/products', async (_req, res) => {
    res.json({ products: await listProducts(db.query, config) });
  });
  router.post('/products', json, async (req, res) => {
    res.status(201).json({ product: await createProduct(db, config, parseProductInput(body(req))) });
  });
  // What is on sale, at what price, and what buyers are handed after paying: changing any of
  // that for a live listing needs the password again, so a borrowed session cannot do it.
  router.put('/products/:id', json, async (req, res) => {
    const current = await getProduct(db.query, config, id(req.params.id));
    if (current?.status === 'listed') assertStepUp(req);
    res.json({ product: await updateProduct(db, config, id(req.params.id), parseProductInput(body(req))) });
  });
  router.post('/products/:id/status', json, async (req, res) => {
    const status = reqEnum(body(req), 'status', ['draft', 'listed', 'archived'] as const);
    if (status === 'listed') assertStepUp(req);
    res.json({ product: await setProductStatus(db, config, id(req.params.id), status) });
  });
  router.get('/orders', async (_req, res) => {
    res.json({ orders: await listOrders(db.query, config) });
  });

  // ── leads & drafts ──────────────────────────────────────────────────────
  router.get('/leads', async (_req, res) => {
    res.json({ leads: await listLeads(db.query), stages: LEAD_STAGES });
  });
  router.post('/leads', json, async (req, res) => {
    res.status(201).json({ lead: await createLead(db, parseLeadInput(body(req)), 'manual') });
  });
  router.patch('/leads/:id', json, async (req, res) => {
    res.json({ lead: await updateLead(db, id(req.params.id), body(req)) });
  });
  router.delete('/leads/:id', async (req, res) => {
    await deleteLead(db, id(req.params.id));
    res.json({ ok: true });
  });
  router.get('/drafts', async (_req, res) => {
    res.json({ drafts: await listDrafts(db.query) });
  });
  router.post('/drafts/:id/decide', json, async (req, res) => {
    const status = reqEnum(body(req), 'status', ['used', 'dismissed'] as const);
    res.json({ draft: await decideDraft(db, id(req.params.id), status) });
  });

  // ── AI (drafts and scores only) ─────────────────────────────────────────
  router.get('/ai', (_req, res) => {
    res.json({ enabled: ai.enabled(), provider: ai.providerLabel(), lastError: ai.lastError(), lastOkAt: ai.lastOkAt(), dailyCap: config.ai.dailyCap });
  });
  router.post('/ai/brief', limit(aiLimiter, 'ai'), async (_req, res) => {
    res.json({ text: await ai.brief(await aiSnapshot(ctx)) });
  });
  router.post('/ai/ask', limit(aiLimiter, 'ai'), json, async (req, res) => {
    const question = reqStr(body(req), 'question', 2, 500, true);
    res.json({ text: await ai.ask(question, await aiSnapshot(ctx)) });
  });
  router.post('/ai/leads/:id/qualify', limit(aiLimiter, 'ai'), async (req, res) => {
    const lead = await getLead(db.query, id(req.params.id));
    if (!lead) throw notFound('Lead not found.');
    const r = await ai.qualifyLead(lead);
    await setLeadScore(db, lead.id, r.score, r.rationale);
    res.json({ lead: await getLead(db.query, lead.id), fit: r.fit });
  });
  router.post('/ai/leads/:id/outreach', limit(aiLimiter, 'ai'), json, async (req, res) => {
    const lead = await getLead(db.query, id(req.params.id));
    if (!lead) throw notFound('Lead not found.');
    const offer = optStr(body(req), 'offer', 600, true) ?? 'AI automation for small businesses: lead capture, enquiry triage and follow-up.';
    const text = await ai.draftOutreach(lead, offer);
    const draft = await addDraft(db.query, { type: 'outreach', title: `Outreach: ${lead.name}${lead.company ? ` (${lead.company})` : ''}`, body: text, refKind: 'lead', refId: lead.id, source: 'ai' });
    res.json({ draft });
  });
  router.post('/ai/invoices/:id/followup', limit(aiLimiter, 'ai'), async (req, res) => {
    const inv = await getInvoice(db.query, config, id(req.params.id));
    if (!inv) throw notFound('Invoice not found.');
    if (inv.outstandingCents <= 0 || inv.storedStatus !== 'open') throw new HttpError(409, 'NOTHING_OWING', 'Nothing is owing on this invoice.');
    const days = Math.max(0, Math.round((Date.now() - Date.parse(inv.dueDate)) / 86_400_000));
    const text = await ai.draftFollowUp(inv, days, `${ctx.baseUrl(req)}/pay/${inv.token}`);
    const draft = await addDraft(db.query, { type: 'followup', title: `Reminder: ${inv.number} · ${inv.clientName}`, body: text, refKind: 'invoice', refId: inv.id, source: 'ai' });
    res.json({ draft });
  });
  router.post('/ai/products/:id/scope', limit(aiLimiter, 'ai'), async (req, res) => {
    const product = await getProduct(db.query, config, id(req.params.id));
    if (!product) throw notFound('Product not found.');
    res.json({ scope: await ai.draftProductScope(product) });
  });

  // ── where the money is ──────────────────────────────────────────────────
  router.get('/payouts', async (req, res) => {
    res.json({ stripe: await stripe.status(req.query.refresh === '1'), webhookUrl: `${ctx.baseUrl(req)}/api/webhooks/stripe` });
  });
  router.get('/wallet', async (req, res) => {
    res.json({ wallet: await solana.walletStatus(req.query.refresh === '1'), rail: solana.railState(), accepts: { sol: config.solana.acceptSol, usdc: config.solana.acceptUsdc } });
  });
  router.post('/wallet/challenge', requireStepUp, async (_req, res) => {
    res.json(await solana.createChallenge());
  });
  router.post('/wallet/verify', requireStepUp, json, async (req, res) => {
    const signature = reqStr(body(req), 'signature', 80, 120);
    if (!/^[A-Za-z0-9+/]+=*$/.test(signature)) throw bad('Signature must be base64.');
    await solana.verifyChallenge(signature);
    res.json({ wallet: await solana.walletStatus(true), rail: solana.railState() });
  });
  router.post('/wallet/onchain-proof', requireStepUp, async (_req, res) => {
    res.json(await solana.createOnchainProof());
  });
  router.post('/wallet/onchain-check', async (_req, res) => {
    const proven = await solana.checkOnchainProof();
    res.json({ proven, wallet: await solana.walletStatus(true), rail: solana.railState() });
  });

  // ── markets (read-only) ─────────────────────────────────────────────────
  router.get('/markets', async (_req, res) => {
    res.json(await ctx.markets.snapshot());
  });

  // ── settings ────────────────────────────────────────────────────────────
  router.get('/settings', async (req, res) => {
    const b = config.bank;
    res.json({
      allocation: (await kvGet<AllocationSettings>(db.query, 'allocation')) ?? DEFAULT_ALLOCATION,
      // Destinations are shown, never editable here: they are pinned in the hosting environment.
      pinned: {
        solanaAddress: config.solana.receiveAddress,
        bank: { payId: b.payId, bsb: b.bsb, accountLast4: b.accountNumber ? b.accountNumber.slice(-4) : null, accountName: b.accountName },
        brandName: config.business.brandName,
        abn: config.business.abn,
        gstRegistered: config.business.gstRegistered,
        supportEmail: config.business.supportEmail,
        publicBaseUrl: ctx.baseUrl(req),
        timeZone: config.timeZone,
      },
    });
  });
  router.put('/settings/allocation', json, async (req, res) => {
    const b = body(req);
    const next: AllocationSettings = { keepPct: reqInt(b, 'keepPct', 0, 100), reservePct: reqInt(b, 'reservePct', 0, 100), reinvestPct: reqInt(b, 'reinvestPct', 0, 100) };
    await kvSet(db.query, 'allocation', next);
    await audit(db, { actor: 'director', action: 'settings.allocation', detail: { ...next } });
    res.json({ allocation: next });
  });

  // ── autopilot ───────────────────────────────────────────────────────────
  router.get('/autopilot', (_req, res) => {
    res.json({ on: autopilot.isOn(), jobs: autopilot.jobs() });
  });
  router.post('/autopilot', json, async (req, res) => {
    const on = optBool(body(req), 'on');
    if (on === null) throw bad('"on" is required.');
    await autopilot.setOn(on);
    res.json({ on: autopilot.isOn(), jobs: autopilot.jobs() });
  });
  router.post('/autopilot/run', json, async (req, res) => {
    const jobId = optStr(body(req), 'id', 40);
    res.json({ on: autopilot.isOn(), jobs: await autopilot.runNow(jobId ?? undefined) });
  });

  // ── audit ───────────────────────────────────────────────────────────────
  router.get('/audit', async (req, res) => {
    const before = typeof req.query.before === 'string' && /^\d+$/.test(req.query.before) ? Number(req.query.before) : undefined;
    res.json({ entries: await listAudit(db.query, 100, before) });
  });
  router.get('/audit/verify', async (_req, res) => {
    res.json(await verifyAuditChain(db.query));
  });

  // ── the core: council and linked apps (see coreRoutes.ts) ───────────────
  router.use(coreRouter(ctx));

  return router;
}
