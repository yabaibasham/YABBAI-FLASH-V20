/**
 * Products and orders.
 *
 * "Never sell air" is enforced three times: here, in the route that lists a
 * product, and by a CHECK constraint in the database. A product cannot be put
 * on sale without a real deliverable attached, and the deliverable is only
 * ever revealed to a buyer after verified payment covers the full price.
 */
import type { Config } from './config.ts';
import type { Db, Query } from './db.ts';
import { auditTx } from './audit.ts';
import { HttpError, bad, dollarsToCents, newId, newToken, notFound, slugify } from './util.ts';
import type { Obj } from './validate.ts';
import { httpUrl, optEnum, optStr, reqStr, strList } from './validate.ts';
import type { Order, Product } from '../shared/types.ts';

function mapProduct(r: any, includeSecret: boolean): Product {
  const p: Product = {
    id: r.id,
    slug: r.slug,
    title: r.title,
    description: r.description,
    priceCents: Number(r.price_cents),
    status: r.status,
    ships: (r.ships ?? []) as string[],
    doesNotShip: (r.does_not_ship ?? []) as string[],
    hasDeliverable: !!r.deliverable_kind && !!r.deliverable_value,
    deliverableKind: r.deliverable_kind ?? null,
    livemode: r.livemode === true,
    soldCount: Number(r.sold_count ?? 0),
    revenueCents: Number(r.revenue_cents ?? 0),
    createdAt: Number(r.created_at),
    updatedAt: Number(r.updated_at),
  };
  if (includeSecret) p.deliverableValue = r.deliverable_value ?? null;
  return p;
}

const PRODUCT_SELECT = `
  SELECT p.*,
         (SELECT COUNT(*) FROM orders o WHERE o.product_id = p.id AND o.status = 'paid')::int AS sold_count,
         (SELECT COALESCE(SUM(pay.amount_cents - pay.refunded_cents), 0)
            FROM payments pay JOIN orders o ON o.id = pay.order_id
           WHERE o.product_id = p.id AND pay.verified = TRUE)::bigint AS revenue_cents
    FROM products p`;

export async function listProducts(q: Query, config: Config): Promise<Product[]> {
  const { rows } = await q(`${PRODUCT_SELECT} WHERE p.livemode = $1 ORDER BY p.created_at DESC LIMIT 200`, [config.mode === 'live']);
  return rows.map(r => mapProduct(r, true));
}

export async function getProduct(q: Query, config: Config, id: string): Promise<Product | null> {
  const { rows } = await q(`${PRODUCT_SELECT} WHERE p.id = $1 AND p.livemode = $2`, [id, config.mode === 'live']);
  return rows.length ? mapProduct(rows[0], true) : null;
}

export async function getProductBySlug(q: Query, config: Config, slug: string): Promise<Product | null> {
  const { rows } = await q(`${PRODUCT_SELECT} WHERE p.slug = $1 AND p.livemode = $2`, [slug, config.mode === 'live']);
  return rows.length ? mapProduct(rows[0], true) : null;
}

interface ProductInput {
  title: string;
  description: string;
  priceCents: number;
  ships: string[];
  doesNotShip: string[];
  deliverableKind: 'link' | 'text' | null;
  deliverableValue: string | null;
}

export function parseProductInput(b: Obj): ProductInput {
  const title = reqStr(b, 'title', 2, 120);
  const description = reqStr(b, 'description', 1, 2000, true);
  const priceCents = dollarsToCents(b.priceDollars);
  if (priceCents === null || priceCents < 0 || priceCents > 10_000_000) throw bad('Price must be between $0 and $100,000.');
  const deliverableKind = optEnum(b, 'deliverableKind', ['link', 'text'] as const);
  let deliverableValue = optStr(b, 'deliverableValue', 4000, true);
  if (deliverableKind === 'link' && deliverableValue) deliverableValue = httpUrl(deliverableValue, 'deliverableValue');
  return {
    title,
    description,
    priceCents,
    ships: strList(b, 'ships', 8, 200),
    doesNotShip: strList(b, 'doesNotShip', 8, 200),
    deliverableKind: deliverableValue ? deliverableKind : null,
    deliverableValue: deliverableKind ? deliverableValue : null,
  };
}

export async function createProduct(db: Db, config: Config, input: ProductInput): Promise<Product> {
  const live = config.mode === 'live';
  const id = newId('prod');
  const base = slugify(input.title) || 'product';
  await db.tx(async q => {
    let slug = base;
    for (let i = 2; i < 50; i++) {
      const clash = await q('SELECT 1 FROM products WHERE slug = $1 AND livemode = $2', [slug, live]);
      if (clash.rows.length === 0) break;
      slug = `${base}-${i}`;
    }
    const nowMs = Date.now();
    await q(
      `INSERT INTO products (id, slug, title, description, price_cents, status, ships, does_not_ship, deliverable_kind, deliverable_value, livemode, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,'draft',$6::jsonb,$7::jsonb,$8,$9,$10,$11,$11)`,
      [
        id,
        slug,
        input.title,
        input.description,
        input.priceCents,
        JSON.stringify(input.ships),
        JSON.stringify(input.doesNotShip),
        input.deliverableKind,
        input.deliverableValue,
        live,
        nowMs,
      ]
    );
    await auditTx(q, { actor: 'director', action: 'product.created', detail: { id, slug, priceCents: input.priceCents } });
  });
  return (await getProduct(db.query, config, id))!;
}

export async function updateProduct(db: Db, config: Config, id: string, input: ProductInput): Promise<Product> {
  const current = await getProduct(db.query, config, id);
  if (!current) throw notFound('Product not found.');
  if (current.status === 'listed' && (!input.deliverableKind || !input.deliverableValue)) {
    throw new HttpError(409, 'NEVER_SELL_AIR', 'A product on sale must keep its deliverable. Take it off sale first.');
  }
  await db.tx(async q => {
    await q(
      `UPDATE products SET title=$2, description=$3, price_cents=$4, ships=$5::jsonb, does_not_ship=$6::jsonb,
                           deliverable_kind=$7, deliverable_value=$8, updated_at=$9
        WHERE id=$1`,
      [
        id,
        input.title,
        input.description,
        input.priceCents,
        JSON.stringify(input.ships),
        JSON.stringify(input.doesNotShip),
        input.deliverableKind,
        input.deliverableValue,
        Date.now(),
      ]
    );
    await auditTx(q, {
      actor: 'director',
      action: 'product.updated',
      detail: { id, priceCents: input.priceCents, deliverableChanged: input.deliverableValue !== current.deliverableValue },
    });
  });
  return (await getProduct(db.query, config, id))!;
}

export async function setProductStatus(db: Db, config: Config, id: string, status: 'draft' | 'listed' | 'archived'): Promise<Product> {
  const current = await getProduct(db.query, config, id);
  if (!current) throw notFound('Product not found.');
  if (status === 'listed') {
    if (!current.hasDeliverable) {
      throw new HttpError(409, 'NEVER_SELL_AIR', 'Attach the real deliverable (a download link or the content itself) before putting this on sale.');
    }
    if (current.priceCents < 100) throw new HttpError(409, 'PRICE_TOO_LOW', 'Set a price of at least $1 before putting this on sale.');
  }
  await db.tx(async q => {
    await q('UPDATE products SET status=$2, updated_at=$3 WHERE id=$1', [id, status, Date.now()]);
    await auditTx(q, { actor: 'director', action: `product.${status}`, detail: { id, slug: current.slug } });
  });
  return (await getProduct(db.query, config, id))!;
}

// ── orders ────────────────────────────────────────────────────────────────
function mapOrder(r: any): Order {
  return {
    id: r.id,
    token: r.token,
    productId: r.product_id,
    productTitle: r.product_title,
    priceCents: Number(r.price_cents),
    customerEmail: r.customer_email ?? null,
    status: r.status,
    livemode: r.livemode === true,
    createdAt: Number(r.created_at),
    paidAt: r.paid_at === null || r.paid_at === undefined ? null : Number(r.paid_at),
    deliveredAt: r.delivered_at === null || r.delivered_at === undefined ? null : Number(r.delivered_at),
  };
}

/** A buyer clicked "buy". Price and title are snapshotted from the server's own record. */
export async function createOrder(db: Db, config: Config, product: Product): Promise<Order> {
  if (product.status !== 'listed' || !product.hasDeliverable) throw new HttpError(409, 'NOT_FOR_SALE', 'This product is not on sale.');
  const id = newId('ord');
  const { rows } = await db.query(
    `INSERT INTO orders (id, token, product_id, product_title, price_cents, status, livemode, created_at)
     VALUES ($1,$2,$3,$4,$5,'pending',$6,$7) RETURNING *`,
    [id, newToken(), product.id, product.title, product.priceCents, config.mode === 'live', Date.now()]
  );
  return mapOrder(rows[0]);
}

export async function getOrderByToken(q: Query, config: Config, token: string): Promise<Order | null> {
  const { rows } = await q('SELECT * FROM orders WHERE token = $1 AND livemode = $2', [token, config.mode === 'live']);
  return rows.length ? mapOrder(rows[0]) : null;
}

export async function getOrder(q: Query, config: Config, id: string): Promise<Order | null> {
  const { rows } = await q('SELECT * FROM orders WHERE id = $1 AND livemode = $2', [id, config.mode === 'live']);
  return rows.length ? mapOrder(rows[0]) : null;
}

export async function listOrders(q: Query, config: Config, includePending = false): Promise<Order[]> {
  const { rows } = await q(
    `SELECT * FROM orders WHERE livemode = $1 ${includePending ? '' : "AND status IN ('paid','refunded')"} ORDER BY created_at DESC LIMIT 300`,
    [config.mode === 'live']
  );
  return rows.map(mapOrder);
}

/** The deliverable, only if this order is fully paid. */
export async function deliverableFor(db: Db, order: Order): Promise<{ kind: 'link' | 'text'; value: string } | null> {
  if (order.status !== 'paid') return null;
  // Belt and braces: the status flag is not trusted on its own. The ledger must
  // still show verified money, net of refunds and lost disputes, covering the price.
  const paid = await db.query('SELECT COALESCE(SUM(amount_cents - refunded_cents), 0)::bigint AS net FROM payments WHERE order_id = $1 AND verified = TRUE', [order.id]);
  if (Number(paid.rows[0].net) < order.priceCents) return null;
  const { rows } = await db.query('SELECT deliverable_kind, deliverable_value FROM products WHERE id = $1', [order.productId]);
  const r = rows[0];
  if (!r?.deliverable_kind || !r?.deliverable_value) return null;
  if (!order.deliveredAt) await db.query('UPDATE orders SET delivered_at = $2 WHERE id = $1 AND delivered_at IS NULL', [order.id, Date.now()]);
  return { kind: r.deliverable_kind, value: r.deliverable_value };
}

/** Abandoned checkouts are housekeeping, not history. */
export async function expireStaleOrders(db: Db): Promise<number> {
  const nowMs = Date.now();
  const res = await db.query(`UPDATE orders SET status='expired' WHERE status='pending' AND created_at <= $1`, [nowMs - 48 * 3600_000]);
  // Abandoned checkouts that never received a cent are removed after 30 days, with their dead payment codes.
  const old = nowMs - 30 * 86_400_000;
  await db.query(`DELETE FROM orders o WHERE o.status='expired' AND o.created_at <= $1 AND NOT EXISTS (SELECT 1 FROM payments p WHERE p.order_id = o.id)`, [old]);
  await db.query(`DELETE FROM stripe_sessions WHERE status IN ('expired','rejected') AND created_at <= $1`, [old]);
  await db.query(`DELETE FROM sol_quotes WHERE status = 'expired' AND created_at <= $1`, [old]);
  return res.rowCount;
}
