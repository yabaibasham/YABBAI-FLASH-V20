/**
 * Public API: what a customer's browser can reach without logging in.
 *
 * Kept deliberately small. A customer can look at one invoice or product
 * (by an unguessable token or a published slug), start a payment for the
 * amount the SERVER says is owing, and ask whether it has arrived. They can
 * never send an amount, mark anything paid, or see anything else.
 */
import { Router } from 'express';
import express from 'express';
import type { Request } from 'express';
import type { Ctx } from './context.ts';
import { audit } from './audit.ts';
import { getInvoiceByToken } from './invoices.ts';
import { createLead, parseLeadInput } from './leads.ts';
import { createOrder, deliverableFor, getOrderByToken, getProductBySlug } from './products.ts';
import { RateLimiter, clientIp, limit, requireJson } from './security.ts';
import { HttpError, bad, errMessage, notFound } from './util.ts';
import { body, optStr, reqEnum, safeParam } from './validate.ts';
import type { PublicInvoiceView, PublicOrderView, PublicProductView } from '../shared/types.ts';

const SESSION_ID_RE = /^cs_(test|live)_[A-Za-z0-9]{10,200}$/;

export function publicRouter(ctx: Ctx): Router {
  const { db, config, stripe, solana } = ctx;
  const router = Router();
  const json = express.json({ limit: '20kb' });

  const readLimiter = new RateLimiter(60_000, 120);
  const statusLimiter = new RateLimiter(60_000, 60);
  const payLimiter = new RateLimiter(60_000, 12);
  const intakeLimiter = new RateLimiter(3600_000, 8);
  const intakeGlobal = new RateLimiter(86_400_000, 300);
  // Every "buy" click makes an unpaid order row. Cap the total so nobody can fill the database with them.
  const orderGlobal = new RateLimiter(3600_000, 400);

  router.get('/site', limit(readLimiter, 'site'), (_req, res) => {
    res.json({ brandName: config.business.brandName, mode: config.mode, supportEmail: config.business.supportEmail });
  });

  // ── invoices ────────────────────────────────────────────────────────────
  async function loadInvoice(req: Request) {
    const token = safeParam(req.params.token, 64);
    const inv = await getInvoiceByToken(db.query, config, token);
    // Drafts are private. Unknown and draft look identical from outside.
    if (!inv || inv.storedStatus === 'draft') throw notFound('This payment link is not valid.');
    return inv;
  }

  router.get('/invoice/:token', limit(readLimiter, 'inv'), async (req, res) => {
    const inv = await loadInvoice(req);
    const payable = inv.storedStatus === 'open' && inv.outstandingCents > 0;
    // On a cold start, ask Stripe once whether the account can actually take
    // payments, so we never show a card button that is bound to fail.
    if (payable && !stripe.lastStatus()) await stripe.status().catch(() => null);
    const crypto = solana.assets();
    const b = config.bank;
    const hasBank = !!(b.payId || (b.bsb && b.accountNumber));
    const view: PublicInvoiceView = {
      brandName: config.business.brandName,
      mode: config.mode,
      number: inv.number,
      clientName: inv.clientName,
      items: inv.items,
      subtotalCents: inv.subtotalCents,
      taxCents: inv.taxCents,
      discountCents: inv.discountCents,
      totalCents: inv.totalCents,
      paidCents: inv.paidCents,
      outstandingCents: inv.outstandingCents,
      status: inv.status,
      dueDate: inv.dueDate,
      issuedAt: inv.openedAt,
      note: inv.note,
      gstRegistered: config.business.gstRegistered,
      abn: config.business.abn,
      supportEmail: config.business.supportEmail,
      rails: {
        card: payable && stripe.railState().enabled && inv.outstandingCents >= 50,
        sol: payable && crypto.sol && inv.outstandingCents >= 100,
        usdc: payable && crypto.usdc && inv.outstandingCents >= 100,
        bank: payable && hasBank ? { payId: b.payId, bsb: b.bsb, accountNumber: b.accountNumber, accountName: b.accountName, reference: inv.number } : null,
      },
    };
    res.json(view);
  });

  router.post('/invoice/:token/checkout', limit(payLimiter, 'pay'), async (req, res) => {
    const inv = await loadInvoice(req);
    if (inv.storedStatus !== 'open') throw new HttpError(409, 'NOT_PAYABLE', 'This invoice can no longer be paid.');
    if (inv.outstandingCents <= 0) throw new HttpError(409, 'ALREADY_PAID', 'This invoice is already paid.');
    const base = ctx.baseUrl(req);
    const out = await stripe.createCheckout({
      kind: 'invoice',
      refId: inv.id,
      refLabel: inv.number,
      title: `${config.business.brandName} invoice ${inv.number}`,
      amountCents: inv.outstandingCents, // the server's figure, never the browser's
      email: inv.clientEmail,
      successUrl: `${base}/pay/${inv.token}?session_id={CHECKOUT_SESSION_ID}`,
      cancelUrl: `${base}/pay/${inv.token}`,
    });
    res.json({ url: out.url });
  });

  router.post('/invoice/:token/quote', limit(payLimiter, 'pay'), requireJson, json, async (req, res) => {
    const inv = await loadInvoice(req);
    if (inv.storedStatus !== 'open') throw new HttpError(409, 'NOT_PAYABLE', 'This invoice can no longer be paid.');
    if (inv.outstandingCents <= 0) throw new HttpError(409, 'ALREADY_PAID', 'This invoice is already paid.');
    const asset = reqEnum(body(req), 'asset', ['SOL', 'USDC'] as const);
    const quote = await solana.createQuote({ kind: 'invoice', refId: inv.id, refLabel: inv.number, asset, audCents: inv.outstandingCents });
    res.json(quote);
  });

  /** Ask the processors whether this invoice has been paid. Read-only for the caller. */
  router.get('/invoice/:token/status', limit(statusLimiter, 'status'), async (req, res) => {
    let inv = await loadInvoice(req);
    let chain: 'none' | 'seen' | 'paid' = 'none';
    if (inv.storedStatus === 'open' && inv.outstandingCents > 0) {
      const sessionId = typeof req.query.session_id === 'string' ? req.query.session_id : null;
      if (sessionId && SESSION_ID_RE.test(sessionId)) {
        const mine = await db.query(`SELECT 1 FROM stripe_sessions WHERE session_id=$1 AND kind='invoice' AND ref_id=$2`, [sessionId, inv.id]);
        if (mine.rows.length) await stripe.settleSession(sessionId, 'return').catch(err => console.error('[public] settle:', errMessage(err)));
      }
      chain = await solana.checkRef('invoice', inv.id).catch(() => 'none' as const);
      inv = (await getInvoiceByToken(db.query, config, inv.token)) ?? inv;
    }
    res.json({ status: inv.status, paidCents: inv.paidCents, outstandingCents: inv.outstandingCents, chain });
  });

  // ── products & orders ───────────────────────────────────────────────────
  async function loadProduct(req: Request) {
    const slug = safeParam(req.params.slug, 80);
    const product = await getProductBySlug(db.query, config, slug);
    if (!product || product.status !== 'listed' || !product.hasDeliverable) throw notFound('This product is not available.');
    return product;
  }

  router.get('/product/:slug', limit(readLimiter, 'prod'), async (req, res) => {
    const p = await loadProduct(req);
    if (!stripe.lastStatus()) await stripe.status().catch(() => null);
    const crypto = solana.assets();
    const view: PublicProductView = {
      brandName: config.business.brandName,
      mode: config.mode,
      slug: p.slug,
      title: p.title,
      description: p.description,
      priceCents: p.priceCents,
      ships: p.ships,
      doesNotShip: p.doesNotShip,
      available: true,
      rails: { card: stripe.railState().enabled, sol: crypto.sol, usdc: crypto.usdc },
      supportEmail: config.business.supportEmail,
      gstRegistered: config.business.gstRegistered,
    };
    res.json(view);
  });

  /** A buyer who already has an unpaid order for this product keeps it instead of starting another. */
  async function orderFor(product: Awaited<ReturnType<typeof loadProduct>>, token: string | null) {
    let order = token ? await getOrderByToken(db.query, config, safeParam(token, 64)) : null;
    if (order && (order.productId !== product.id || order.status !== 'pending' || order.priceCents !== product.priceCents)) order = null;
    if (order) return order;
    if (orderGlobal.hit('all') > 0) throw new HttpError(429, 'RATE_LIMITED', 'Checkout is very busy right now. Please try again in a few minutes.');
    return createOrder(db, config, product);
  }

  router.post('/product/:slug/checkout', limit(payLimiter, 'pay'), requireJson, json, async (req, res) => {
    const product = await loadProduct(req);
    if (!stripe.railState().enabled) throw new HttpError(503, 'STRIPE_UNAVAILABLE', 'Card payments are not available right now.');
    const order = await orderFor(product, optStr(body(req), 'orderToken', 64));
    const base = ctx.baseUrl(req);
    const out = await stripe.createCheckout({
      kind: 'order',
      refId: order.id,
      refLabel: product.title,
      title: product.title,
      amountCents: order.priceCents,
      email: null,
      successUrl: `${base}/order/${order.token}?session_id={CHECKOUT_SESSION_ID}`,
      cancelUrl: `${base}/p/${product.slug}`,
    });
    res.json({ url: out.url, orderToken: order.token });
  });

  router.post('/product/:slug/quote', limit(payLimiter, 'pay'), requireJson, json, async (req, res) => {
    const product = await loadProduct(req);
    const b = body(req);
    const asset = reqEnum(b, 'asset', ['SOL', 'USDC'] as const);
    if (!solana.railState().enabled) throw new HttpError(503, 'SOLANA_UNAVAILABLE', 'Crypto payments are not available right now.');
    const order = await orderFor(product, optStr(b, 'orderToken', 64));
    const quote = await solana.createQuote({ kind: 'order', refId: order.id, refLabel: product.title, asset, audCents: order.priceCents });
    res.json({ quote, orderToken: order.token });
  });

  router.get('/order/:token', limit(statusLimiter, 'status'), async (req, res) => {
    const token = safeParam(req.params.token, 64);
    let order = await getOrderByToken(db.query, config, token);
    if (!order) throw notFound('This order link is not valid.');
    let chain: 'none' | 'seen' | 'paid' = 'none';
    if (order.status === 'pending' || order.status === 'expired') {
      const sessionId = typeof req.query.session_id === 'string' ? req.query.session_id : null;
      if (sessionId && SESSION_ID_RE.test(sessionId)) {
        const mine = await db.query(`SELECT 1 FROM stripe_sessions WHERE session_id=$1 AND kind='order' AND ref_id=$2`, [sessionId, order.id]);
        if (mine.rows.length) await stripe.settleSession(sessionId, 'return').catch(err => console.error('[public] settle:', errMessage(err)));
      }
      chain = await solana.checkRef('order', order.id).catch(() => 'none' as const);
      order = (await getOrderByToken(db.query, config, token)) ?? order;
    }
    // An unpaid order can ask for a fresh payment code, but only while the product is still on sale.
    const pending = order.status === 'pending';
    const prod = pending ? await db.query(`SELECT slug FROM products WHERE id=$1 AND status='listed'`, [order.productId]) : { rows: [] };
    const slug: string | null = prod.rows[0]?.slug ?? null;
    if (slug && !stripe.lastStatus()) await stripe.status().catch(() => null);
    const crypto = solana.assets();
    const view: PublicOrderView & { chain: string } = {
      brandName: config.business.brandName,
      mode: config.mode,
      productTitle: order.productTitle,
      productSlug: slug,
      rails: { card: !!slug && stripe.railState().enabled, sol: !!slug && crypto.sol, usdc: !!slug && crypto.usdc },
      priceCents: order.priceCents,
      status: order.status,
      deliverable: await deliverableFor(db, order), // null unless fully paid
      supportEmail: config.business.supportEmail,
      chain,
    };
    res.json(view);
  });

  // ── lead intake ─────────────────────────────────────────────────────────
  router.post('/intake', limit(intakeLimiter, 'intake'), requireJson, json, async (req, res) => {
    const b = body(req);
    // Honeypot: real people never see or fill this field. Answer "ok" either way.
    if (typeof b.website === 'string' && b.website.trim() !== '') {
      res.json({ ok: true });
      return;
    }
    if (intakeGlobal.hit('all') > 0) throw new HttpError(429, 'RATE_LIMITED', 'We are receiving a lot of enquiries. Please email us instead.');
    const input = parseLeadInput(b);
    if (!input.email && !input.phone) throw bad('Leave an email address or phone number so we can reply.');
    await createLead(db, input, 'intake');
    await audit(db, { actor: 'public', action: 'intake.received', detail: { ip: clientIp(req) } });
    res.json({ ok: true });
  });

  return router;
}
