/**
 * Invoices.
 *
 * Only three states are stored: draft, open, void. Whether an invoice is
 * part-paid, paid or overdue is worked out from the payments ledger every
 * time it is read, so an invoice can never say "paid" without payments behind
 * it — and no code path can set it by hand.
 */
import type { Config } from './config.ts';
import type { Db, Query } from './db.ts';
import { nextCounter } from './db.ts';
import { auditTx } from './audit.ts';
import { paidByInvoice, recordPayment } from './ledger.ts';
import { HttpError, bad, businessDay, dollarsToCents, isIsoDate, newId, newToken, notFound, sha256hex } from './util.ts';
import type { Obj } from './validate.ts';
import { optEmail, optStr, reqStr } from './validate.ts';
import type { Invoice, InvoiceItem, InvoiceStatus, Payment } from '../shared/types.ts';

export const GST_BPS = 1000; // 10%

export function computeTotals(
  items: InvoiceItem[],
  chargeGst: boolean,
  discountCents: number
): { subtotalCents: number; taxCents: number; discountCents: number; totalCents: number } {
  const subtotal = items.reduce((sum, it) => sum + it.qty * it.unitCents, 0);
  const discount = Math.min(Math.max(0, discountCents), subtotal);
  const taxable = subtotal - discount;
  const tax = chargeGst ? Math.round((taxable * GST_BPS) / 10_000) : 0;
  return { subtotalCents: subtotal, taxCents: tax, discountCents: discount, totalCents: taxable + tax };
}

export function parseItems(raw: unknown): InvoiceItem[] {
  if (!Array.isArray(raw) || raw.length === 0) throw bad('Add at least one line item.');
  if (raw.length > 50) throw bad('Too many line items (max 50).');
  const items: InvoiceItem[] = [];
  for (const r of raw) {
    if (!r || typeof r !== 'object') throw bad('Each line item needs a description, quantity and price.');
    const o = r as Obj;
    const desc = reqStr(o, 'desc', 1, 200);
    const qty = typeof o.qty === 'number' && Number.isInteger(o.qty) ? o.qty : NaN;
    if (!(qty >= 1 && qty <= 10_000)) throw bad(`Quantity for "${desc}" must be a whole number from 1 to 10,000.`);
    let unitCents: number | null = null;
    if (typeof o.unitCents === 'number' && Number.isInteger(o.unitCents)) unitCents = o.unitCents;
    else if (o.unitDollars !== undefined) unitCents = dollarsToCents(o.unitDollars);
    if (unitCents === null || unitCents < 0 || unitCents > 100_000_000) throw bad(`Price for "${desc}" must be between $0 and $1,000,000.`);
    items.push({ desc, qty, unitCents });
  }
  return items;
}

function deriveStatus(stored: string, totalCents: number, paidCents: number, dueDate: string, today: string): InvoiceStatus {
  if (stored === 'draft' || stored === 'void') return stored;
  if (totalCents > 0 && paidCents >= totalCents) return 'paid';
  if (dueDate < today) return 'overdue';
  if (paidCents > 0) return 'part';
  return 'open';
}

function mapInvoice(r: any, paid: { verified: number; attested: number } | undefined, today: string): Invoice {
  const total = Number(r.total_cents);
  const verified = paid?.verified ?? 0;
  const attested = paid?.attested ?? 0;
  const paidCents = verified + attested;
  return {
    id: r.id,
    number: r.number,
    token: r.token,
    clientName: r.client_name,
    clientEmail: r.client_email ?? null,
    items: (r.items ?? []) as InvoiceItem[],
    subtotalCents: Number(r.subtotal_cents),
    taxCents: Number(r.tax_cents),
    discountCents: Number(r.discount_cents),
    totalCents: total,
    note: r.note ?? null,
    dueDate: r.due_date,
    storedStatus: r.status,
    status: deriveStatus(r.status, total, paidCents, r.due_date, today),
    paidCents,
    verifiedPaidCents: verified,
    attestedPaidCents: attested,
    outstandingCents: Math.max(0, total - paidCents),
    livemode: r.livemode === true,
    leadId: r.lead_id ?? null,
    createdAt: Number(r.created_at),
    updatedAt: Number(r.updated_at),
    openedAt: r.opened_at === null || r.opened_at === undefined ? null : Number(r.opened_at),
  };
}

async function hydrate(q: Query, config: Config, rows: any[]): Promise<Invoice[]> {
  const paid = await paidByInvoice(
    q,
    rows.map(r => r.id)
  );
  const today = businessDay(Date.now(), config.timeZone);
  return rows.map(r => mapInvoice(r, paid.get(r.id), today));
}

export async function listInvoices(q: Query, config: Config): Promise<Invoice[]> {
  const { rows } = await q('SELECT * FROM invoices WHERE livemode = $1 ORDER BY created_at DESC LIMIT 500', [config.mode === 'live']);
  return hydrate(q, config, rows);
}

export async function getInvoice(q: Query, config: Config, id: string): Promise<Invoice | null> {
  const { rows } = await q('SELECT * FROM invoices WHERE id = $1 AND livemode = $2', [id, config.mode === 'live']);
  return rows.length ? (await hydrate(q, config, rows))[0] : null;
}

export async function getInvoiceByToken(q: Query, config: Config, token: string): Promise<Invoice | null> {
  const { rows } = await q('SELECT * FROM invoices WHERE token = $1 AND livemode = $2', [token, config.mode === 'live']);
  return rows.length ? (await hydrate(q, config, rows))[0] : null;
}

function defaultDueDate(config: Config): string {
  return businessDay(Date.now() + 7 * 86_400_000, config.timeZone);
}

interface InvoiceInput {
  clientName: string;
  clientEmail: string | null;
  items: InvoiceItem[];
  chargeGst: boolean;
  discountCents: number;
  note: string | null;
  dueDate: string;
  leadId: string | null;
}

export function parseInvoiceInput(config: Config, b: Obj): InvoiceInput {
  const clientName = reqStr(b, 'clientName', 1, 120);
  const clientEmail = optEmail(b, 'clientEmail');
  const items = parseItems(b.items);
  const wantsGst = b.chargeGst === true;
  if (wantsGst && !config.business.gstRegistered) {
    throw bad('GST can only be charged once GST_REGISTERED and BUSINESS_ABN are set on the server.', 'GST_NOT_REGISTERED');
  }
  const discountCents = b.discountDollars === undefined || b.discountDollars === null || b.discountDollars === '' ? 0 : dollarsToCents(b.discountDollars);
  if (discountCents === null || discountCents < 0) throw bad('Discount must be zero or more.');
  const note = optStr(b, 'note', 1000, true);
  const dueDate = b.dueDate === undefined || b.dueDate === null || b.dueDate === '' ? defaultDueDate(config) : b.dueDate;
  if (!isIsoDate(dueDate)) throw bad('Due date must be a real date (YYYY-MM-DD).');
  const leadId = optStr(b, 'leadId', 80);
  return { clientName, clientEmail, items, chargeGst: wantsGst, discountCents, note, dueDate, leadId };
}

export async function createInvoice(db: Db, config: Config, input: InvoiceInput): Promise<Invoice> {
  const live = config.mode === 'live';
  const totals = computeTotals(input.items, input.chargeGst, input.discountCents);
  if (totals.totalCents <= 0) throw bad('Invoice total must be more than $0.');
  const id = newId('inv');
  await db.tx(async q => {
    const seq = await nextCounter(q, `invoice_seq_${live ? 'live' : 'test'}`);
    const number = `INV-${String(seq).padStart(4, '0')}`;
    const nowMs = Date.now();
    await q(
      `INSERT INTO invoices (id, number, token, client_name, client_email, items, subtotal_cents, tax_cents, discount_cents, total_cents,
                             note, due_date, status, livemode, lead_id, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6::jsonb,$7,$8,$9,$10,$11,$12,'draft',$13,$14,$15,$15)`,
      [
        id,
        number,
        newToken(),
        input.clientName,
        input.clientEmail,
        JSON.stringify(input.items),
        totals.subtotalCents,
        totals.taxCents,
        totals.discountCents,
        totals.totalCents,
        input.note,
        input.dueDate,
        live,
        input.leadId,
        nowMs,
      ]
    );
    await auditTx(q, { actor: 'director', action: 'invoice.created', detail: { id, number, totalCents: totals.totalCents, client: input.clientName } });
  });
  return (await getInvoice(db.query, config, id))!;
}

export async function updateDraftInvoice(db: Db, config: Config, id: string, input: InvoiceInput): Promise<Invoice> {
  const totals = computeTotals(input.items, input.chargeGst, input.discountCents);
  if (totals.totalCents <= 0) throw bad('Invoice total must be more than $0.');
  await db.tx(async q => {
    const res = await q(
      `UPDATE invoices SET client_name=$2, client_email=$3, items=$4::jsonb, subtotal_cents=$5, tax_cents=$6, discount_cents=$7,
                           total_cents=$8, note=$9, due_date=$10, updated_at=$11
        WHERE id=$1 AND status='draft' AND livemode=$12`,
      [
        id,
        input.clientName,
        input.clientEmail,
        JSON.stringify(input.items),
        totals.subtotalCents,
        totals.taxCents,
        totals.discountCents,
        totals.totalCents,
        input.note,
        input.dueDate,
        Date.now(),
        config.mode === 'live',
      ]
    );
    if (res.rowCount === 0) throw new HttpError(409, 'NOT_DRAFT', 'Only draft invoices can be edited. Void it and issue a new one instead.');
    await auditTx(q, { actor: 'director', action: 'invoice.updated', detail: { id, totalCents: totals.totalCents } });
  });
  return (await getInvoice(db.query, config, id))!;
}

/** Make a draft payable. From here its amount is locked. */
export async function openInvoice(db: Db, config: Config, id: string): Promise<Invoice> {
  await db.tx(async q => {
    const nowMs = Date.now();
    const res = await q(`UPDATE invoices SET status='open', opened_at=$2, updated_at=$2 WHERE id=$1 AND status='draft' AND livemode=$3`, [
      id,
      nowMs,
      config.mode === 'live',
    ]);
    if (res.rowCount === 0) throw new HttpError(409, 'NOT_DRAFT', 'This invoice is not a draft.');
    await auditTx(q, { actor: 'director', action: 'invoice.opened', detail: { id } });
  });
  return (await getInvoice(db.query, config, id))!;
}

export async function voidInvoice(db: Db, config: Config, id: string): Promise<Invoice> {
  const inv = await getInvoice(db.query, config, id);
  if (!inv) throw notFound('Invoice not found.');
  if (inv.paidCents > 0) {
    throw new HttpError(409, 'HAS_PAYMENTS', 'This invoice has payments recorded against it and cannot be voided. Refund in Stripe first if needed.');
  }
  await db.tx(async q => {
    const res = await q(`UPDATE invoices SET status='void', updated_at=$2 WHERE id=$1 AND status IN ('draft','open')`, [id, Date.now()]);
    if (res.rowCount === 0) throw new HttpError(409, 'ALREADY_VOID', 'This invoice is already void.');
    await q(`UPDATE sol_quotes SET status='expired' WHERE kind='invoice' AND ref_id=$1 AND status='open'`, [id]);
    await auditTx(q, { actor: 'director', action: 'invoice.voided', detail: { id, number: inv.number } });
  });
  return (await getInvoice(db.query, config, id))!;
}

/**
 * Record a payment the director has personally confirmed in their bank
 * (transfer, PayID, cash). It closes the invoice but is never counted as
 * processor-verified, and the same reference cannot be attested twice.
 */
export async function attestPayment(
  db: Db,
  config: Config,
  id: string,
  input: { amountCents: number; reference: string; note: string | null; date: string | null }
): Promise<{ invoice: Invoice; payment: Payment; duplicate: boolean }> {
  const inv = await getInvoice(db.query, config, id);
  if (!inv) throw notFound('Invoice not found.');
  if (inv.storedStatus !== 'open') throw new HttpError(409, 'NOT_OPEN', 'Only issued invoices can take payments.');
  if (input.amountCents <= 0) throw bad('Amount must be more than $0.');
  if (input.amountCents > inv.outstandingCents) {
    throw bad(`That is more than the $${(inv.outstandingCents / 100).toFixed(2)} still owing on ${inv.number}.`, 'OVER_OUTSTANDING');
  }
  const proofId = `attested:${inv.id}:${sha256hex(input.reference.trim().toLowerCase()).slice(0, 24)}`;
  const occurredAt = input.date ? new Date(`${input.date}T12:00:00+10:00`).getTime() : Date.now();

  const result = await db.tx(async q => {
    const rec = await recordPayment(q, {
      proofId,
      rail: 'attested',
      kind: 'invoice',
      invoiceId: inv.id,
      amountCents: input.amountCents,
      livemode: config.mode === 'live',
      payer: inv.clientName,
      detail: { reference: input.reference, note: input.note, attestedBy: 'director' },
      occurredAt,
    });
    if (rec.inserted) {
      await auditTx(q, {
        actor: 'director',
        action: 'payment.attested',
        detail: { invoice: inv.number, amountCents: input.amountCents, reference: input.reference },
      });
    }
    return rec;
  });
  return { invoice: (await getInvoice(db.query, config, id))!, payment: result.payment, duplicate: !result.inserted };
}

// ── bank statement helper (suggestions only — nothing is credited here) ────
const REF_RE = /\bINV[\s\-_]*0*(\d{1,6})\b/i;

function splitCsvLine(line: string, delim: string): string[] {
  const out: string[] = [];
  let cur = '';
  let quoted = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (quoted && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else quoted = !quoted;
    } else if (ch === delim && !quoted) {
      out.push(cur.trim());
      cur = '';
    } else cur += ch;
  }
  out.push(cur.trim());
  return out;
}

function parseAmount(raw: string): number | null {
  let s = (raw ?? '').trim();
  if (!s) return null;
  const paren = s.startsWith('(') && s.endsWith(')');
  if (paren) s = s.slice(1, -1);
  s = s.replace(/[$\sA-Za-z]/g, '').replace(/,/g, '');
  const n = Number(s);
  if (!Number.isFinite(n)) return null;
  const cents = Math.round(n * 100);
  return paren ? -Math.abs(cents) : cents;
}

function parseStatementDate(raw: string): string | null {
  const s = (raw ?? '').trim();
  let m = /^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$/.exec(s);
  if (m) {
    const iso = `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
    return isIsoDate(iso) ? iso : null;
  }
  m = /^(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})$/.exec(s);
  if (m) {
    const iso = `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
    return isIsoDate(iso) ? iso : null;
  }
  return null;
}

export interface StatementSuggestion {
  date: string;
  amountCents: number;
  description: string;
  invoiceId: string | null;
  invoiceNumber: string | null;
  reference: string;
  reason: string;
}

/**
 * Read a bank CSV export and suggest which credits match which open invoices.
 * Pure function: it never writes. The director confirms each suggestion,
 * which goes through attestPayment like any other bank payment.
 */
export function suggestFromStatement(csv: string, invoices: Invoice[]): StatementSuggestion[] {
  const lines = String(csv ?? '')
    .replace(/^﻿/, '')
    .split(/\r?\n/)
    .map(l => l.trim())
    .filter(Boolean)
    .slice(0, 2000);
  if (lines.length === 0) throw bad('The statement is empty.');
  const count = (l: string, ch: string) => l.split(ch).length - 1;
  const first = lines[0];
  const delim = count(first, '\t') > count(first, ',') ? '\t' : count(first, ';') > count(first, ',') ? ';' : ',';

  let headerIdx = -1;
  let col = { date: 0, amount: 1, credit: -1, debit: -1, desc: 2 };
  for (let i = 0; i < Math.min(8, lines.length); i++) {
    const cols = splitCsvLine(lines[i], delim).map(c => c.toLowerCase());
    const find = (...names: string[]) => cols.findIndex(c => names.some(n => c === n || c.includes(n)));
    const date = find('date');
    const amount = find('amount', 'value');
    const credit = find('credit');
    const debit = find('debit');
    if (date >= 0 && (amount >= 0 || credit >= 0)) {
      headerIdx = i;
      col = { date, amount: credit >= 0 && debit >= 0 ? -1 : amount, credit, debit, desc: find('description', 'narrative', 'details', 'particulars', 'memo') };
      break;
    }
  }
  // CommBank exports have no header row: Date, Amount, Description, Balance.
  const start = headerIdx + 1;

  const open = invoices.filter(i => i.storedStatus === 'open' && i.outstandingCents > 0);
  const byNumber = new Map(open.map(i => [Number(i.number.replace(/\D/g, '')), i]));
  const out: StatementSuggestion[] = [];

  for (let i = start; i < lines.length; i++) {
    const cols = splitCsvLine(lines[i], delim);
    const date = parseStatementDate(cols[col.date] ?? '');
    let amount = col.amount >= 0 ? parseAmount(cols[col.amount] ?? '') : null;
    if (amount === null && col.credit >= 0) amount = parseAmount(cols[col.credit] ?? '');
    if (!date || amount === null || amount <= 0) continue; // credits only
    const description = (col.desc >= 0 ? cols[col.desc] : cols.slice(2).join(' ')) ?? '';
    const reference = `bank:${date}:${amount}:${sha256hex(lines[i]).slice(0, 10)}`;
    const m = REF_RE.exec(description);
    const inv = m ? byNumber.get(Number(m[1])) : undefined;
    out.push({
      date,
      amountCents: amount,
      description: description.slice(0, 200),
      invoiceId: inv?.id ?? null,
      invoiceNumber: inv?.number ?? null,
      reference,
      reason: inv
        ? amount > inv.outstandingCents
          ? `Mentions ${inv.number} but is more than the amount owing`
          : `Mentions ${inv.number}`
        : m
          ? 'Mentions an invoice number that is not open'
          : 'No invoice number in the description',
    });
  }
  return out;
}
