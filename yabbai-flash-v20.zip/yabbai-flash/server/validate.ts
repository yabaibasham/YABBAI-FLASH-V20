/**
 * Small, strict input validators. Every value that arrives over HTTP passes
 * through one of these before it touches the database.
 */
import type { Request } from 'express';
import { bad } from './util.ts';

export type Obj = Record<string, unknown>;

export function body(req: Request): Obj {
  const b = req.body;
  if (b === undefined || b === null) return {};
  if (typeof b !== 'object' || Array.isArray(b)) throw bad('Request body must be a JSON object.');
  return b as Obj;
}

/** Remove control characters; keep newlines and tabs only when multiline. */
function clean(text: string, multiline: boolean): string {
  const re = multiline ? /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g : /[\u0000-\u001F\u007F]/g;
  return text.replace(re, '').trim();
}

export function reqStr(o: Obj, key: string, min: number, max: number, multiline = false): string {
  const v = o[key];
  if (typeof v !== 'string') throw bad(`"${key}" is required.`);
  const s = clean(v, multiline);
  if (s.length < min) throw bad(`"${key}" is required.`);
  if (s.length > max) throw bad(`"${key}" is too long (max ${max} characters).`);
  return s;
}

export function optStr(o: Obj, key: string, max: number, multiline = false): string | null {
  const v = o[key];
  if (v === undefined || v === null) return null;
  if (typeof v !== 'string') throw bad(`"${key}" must be text.`);
  const s = clean(v, multiline);
  if (s.length === 0) return null;
  if (s.length > max) throw bad(`"${key}" is too long (max ${max} characters).`);
  return s;
}

export function reqInt(o: Obj, key: string, min: number, max: number): number {
  const v = o[key];
  if (typeof v !== 'number' || !Number.isInteger(v)) throw bad(`"${key}" must be a whole number.`);
  if (v < min || v > max) throw bad(`"${key}" must be between ${min} and ${max}.`);
  return v;
}

export function optInt(o: Obj, key: string, min: number, max: number): number | null {
  if (o[key] === undefined || o[key] === null) return null;
  return reqInt(o, key, min, max);
}

export function optBool(o: Obj, key: string): boolean | null {
  const v = o[key];
  if (v === undefined || v === null) return null;
  if (typeof v !== 'boolean') throw bad(`"${key}" must be true or false.`);
  return v;
}

export function reqEnum<T extends string>(o: Obj, key: string, values: readonly T[]): T {
  const v = o[key];
  if (typeof v !== 'string' || !values.includes(v as T)) throw bad(`"${key}" must be one of: ${values.join(', ')}.`);
  return v as T;
}

export function optEnum<T extends string>(o: Obj, key: string, values: readonly T[]): T | null {
  if (o[key] === undefined || o[key] === null) return null;
  return reqEnum(o, key, values);
}

const EMAIL_RE = /^[^\s@<>"',;]+@[^\s@<>"',;]+\.[^\s@<>"',;]{2,}$/;

export function optEmail(o: Obj, key: string): string | null {
  const s = optStr(o, key, 254);
  if (s === null) return null;
  if (!EMAIL_RE.test(s)) throw bad(`"${key}" is not a valid email address.`);
  return s.toLowerCase();
}

export function strList(o: Obj, key: string, maxItems: number, maxLen: number): string[] {
  const v = o[key];
  if (v === undefined || v === null) return [];
  if (!Array.isArray(v)) throw bad(`"${key}" must be a list.`);
  if (v.length > maxItems) throw bad(`"${key}" has too many items (max ${maxItems}).`);
  const out: string[] = [];
  for (const item of v) {
    if (typeof item !== 'string') throw bad(`"${key}" must contain only text.`);
    const s = clean(item, false);
    if (s.length > maxLen) throw bad(`An item in "${key}" is too long.`);
    if (s) out.push(s);
  }
  return out;
}

/** Only http(s) links are ever stored or shown. Blocks javascript:, data:, etc. */
export function httpUrl(value: string, key = 'url'): string {
  let u: URL;
  try {
    u = new URL(value);
  } catch {
    throw bad(`"${key}" must be a full web address starting with https://`);
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') throw bad(`"${key}" must start with https://`);
  return u.toString();
}

/** Path parameters: ids and tokens are URL-safe base64 with an optional prefix. */
export function safeParam(value: unknown, max = 80): string {
  if (typeof value !== 'string' || value.length === 0 || value.length > max || !/^[A-Za-z0-9_-]+$/.test(value)) {
    throw bad('Invalid identifier.');
  }
  return value;
}
