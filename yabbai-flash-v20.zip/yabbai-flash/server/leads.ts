/**
 * Leads and drafts.
 *
 * A lead exists only because a real person entered it: you, a CSV you
 * imported, or someone who filled in the public intake form. Nothing in this
 * app invents prospects, replies or "closed deals". AI writes drafts; a draft
 * does nothing until you copy it out and send it yourself.
 */
import type { Db, Query } from './db.ts';
import { auditTx } from './audit.ts';
import { bad, newId, notFound } from './util.ts';
import type { Obj } from './validate.ts';
import { optEmail, optEnum, optStr, reqStr } from './validate.ts';
import type { Draft, DraftType, Lead, LeadStage } from '../shared/types.ts';

export const LEAD_STAGES: readonly LeadStage[] = ['new', 'qualified', 'contacted', 'replied', 'proposal', 'won', 'lost'];

function mapLead(r: any): Lead {
  return {
    id: r.id,
    name: r.name,
    company: r.company ?? null,
    email: r.email ?? null,
    phone: r.phone ?? null,
    sector: r.sector ?? null,
    message: r.message ?? null,
    source: r.source,
    stage: r.stage,
    score: r.score === null || r.score === undefined ? null : Number(r.score),
    scoreRationale: r.score_rationale ?? null,
    createdAt: Number(r.created_at),
    updatedAt: Number(r.updated_at),
  };
}

export interface LeadInput {
  name: string;
  company: string | null;
  email: string | null;
  phone: string | null;
  sector: string | null;
  message: string | null;
}

export function parseLeadInput(b: Obj): LeadInput {
  const phone = optStr(b, 'phone', 40);
  if (phone && !/^[0-9+()\-\s.]{6,40}$/.test(phone)) throw bad('Phone number looks wrong.');
  return {
    name: reqStr(b, 'name', 1, 120),
    company: optStr(b, 'company', 160),
    email: optEmail(b, 'email'),
    phone,
    sector: optStr(b, 'sector', 80),
    message: optStr(b, 'message', 2000, true),
  };
}

export async function createLead(db: Db, input: LeadInput, source: Lead['source']): Promise<Lead> {
  const id = newId('lead');
  const nowMs = Date.now();
  await db.tx(async q => {
    await q(
      `INSERT INTO leads (id, name, company, email, phone, sector, message, source, stage, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'new',$9,$9)`,
      [id, input.name, input.company, input.email, input.phone, input.sector, input.message, source, nowMs]
    );
    await auditTx(q, { actor: source === 'intake' ? 'public' : 'director', action: 'lead.created', detail: { id, source } });
  });
  return (await getLead(db.query, id))!;
}

export async function getLead(q: Query, id: string): Promise<Lead | null> {
  const { rows } = await q('SELECT * FROM leads WHERE id = $1', [id]);
  return rows.length ? mapLead(rows[0]) : null;
}

export async function listLeads(q: Query): Promise<Lead[]> {
  const { rows } = await q('SELECT * FROM leads ORDER BY created_at DESC LIMIT 500');
  return rows.map(mapLead);
}

export async function updateLead(db: Db, id: string, b: Obj): Promise<Lead> {
  const current = await getLead(db.query, id);
  if (!current) throw notFound('Lead not found.');
  const stage = optEnum(b, 'stage', LEAD_STAGES) ?? current.stage;
  const merged: LeadInput =
    b.name !== undefined
      ? parseLeadInput(b)
      : { name: current.name, company: current.company, email: current.email, phone: current.phone, sector: current.sector, message: current.message };
  await db.tx(async q => {
    await q('UPDATE leads SET name=$2, company=$3, email=$4, phone=$5, sector=$6, message=$7, stage=$8, updated_at=$9 WHERE id=$1', [
      id,
      merged.name,
      merged.company,
      merged.email,
      merged.phone,
      merged.sector,
      merged.message,
      stage,
      Date.now(),
    ]);
    if (stage !== current.stage) await auditTx(q, { actor: 'director', action: 'lead.stage', detail: { id, from: current.stage, to: stage } });
  });
  return (await getLead(db.query, id))!;
}

export async function setLeadScore(db: Db, id: string, score: number, rationale: string): Promise<void> {
  await db.query(
    `UPDATE leads SET score=$2, score_rationale=$3, stage = CASE WHEN stage = 'new' THEN 'qualified' ELSE stage END, updated_at=$4 WHERE id=$1`,
    [id, Math.max(0, Math.min(100, Math.round(score))), rationale.slice(0, 600), Date.now()]
  );
}

export async function deleteLead(db: Db, id: string): Promise<void> {
  await db.tx(async q => {
    const res = await q('DELETE FROM leads WHERE id = $1', [id]);
    if (res.rowCount === 0) throw notFound('Lead not found.');
    await q(`DELETE FROM drafts WHERE ref_kind = 'lead' AND ref_id = $1`, [id]);
    await auditTx(q, { actor: 'director', action: 'lead.deleted', detail: { id } });
  });
}

// ── drafts ────────────────────────────────────────────────────────────────
function mapDraft(r: any): Draft {
  return {
    id: r.id,
    type: r.type,
    title: r.title,
    body: r.body,
    refKind: r.ref_kind ?? null,
    refId: r.ref_id ?? null,
    status: r.status,
    source: r.source,
    createdAt: Number(r.created_at),
    decidedAt: r.decided_at === null || r.decided_at === undefined ? null : Number(r.decided_at),
  };
}

export async function addDraft(
  q: Query,
  d: { type: DraftType; title: string; body: string; refKind?: Draft['refKind']; refId?: string | null; source: Draft['source'] }
): Promise<Draft> {
  const id = newId('draft');
  const { rows } = await q(
    `INSERT INTO drafts (id, type, title, body, ref_kind, ref_id, status, source, created_at)
     VALUES ($1,$2,$3,$4,$5,$6,'pending',$7,$8) RETURNING *`,
    [id, d.type, d.title.slice(0, 200), d.body.slice(0, 8000), d.refKind ?? null, d.refId ?? null, d.source, Date.now()]
  );
  return mapDraft(rows[0]);
}

export async function listDrafts(q: Query, status?: Draft['status']): Promise<Draft[]> {
  const { rows } = status
    ? await q('SELECT * FROM drafts WHERE status = $1 ORDER BY created_at DESC LIMIT 200', [status])
    : await q('SELECT * FROM drafts ORDER BY created_at DESC LIMIT 200');
  return rows.map(mapDraft);
}

export async function decideDraft(db: Db, id: string, status: 'used' | 'dismissed'): Promise<Draft> {
  const { rows } = await db.query(`UPDATE drafts SET status=$2, decided_at=$3 WHERE id=$1 AND status='pending' RETURNING *`, [id, status, Date.now()]);
  if (rows.length === 0) throw notFound('Draft not found or already decided.');
  const draft = mapDraft(rows[0]);
  // Marking an outreach draft as used means YOU sent it; move the lead along.
  if (status === 'used' && draft.type === 'outreach' && draft.refKind === 'lead' && draft.refId) {
    await db.query(`UPDATE leads SET stage='contacted', updated_at=$2 WHERE id=$1 AND stage IN ('new','qualified')`, [draft.refId, Date.now()]);
  }
  return draft;
}

export async function hasPendingDraft(q: Query, type: DraftType, refId: string): Promise<boolean> {
  const { rows } = await q(`SELECT 1 FROM drafts WHERE type=$1 AND ref_id=$2 AND status='pending' LIMIT 1`, [type, refId]);
  return rows.length > 0;
}
