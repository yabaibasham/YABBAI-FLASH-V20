/**
 * Console API for the core: the council (Brain tab) and the linked apps
 * (Network tab). Mounted inside the console router, so every route here is
 * already behind requireSameOrigin + requireAuth.
 *
 * Read the routes and notice, again, what is missing: nothing here takes an
 * amount, touches a payment, an invoice or a product, or sends a message.
 * A council session writes text. A link is an address.
 *
 * Two things do need the password again, because both outlive the session
 * that made them:
 *  - making a lesson active (it is handed to every later council session), and
 *  - adding or changing a link (it is something you will click and trust).
 * Taking either away never does.
 */
import { Router } from 'express';
import express from 'express';
import type { Ctx } from './context.ts';
import { requireStepUp } from './auth.ts';
import { MAX_ACTIVE_LESSONS, addLesson, approveLesson, closeLesson, listLessons, proposedForSession } from './lessons.ts';
import { LINK_KINDS, MAX_IMPORT, MAX_LINKS, createLink, deleteLink, importLinks, parseLinkInput, updateLink } from './network.ts';
import { RateLimiter, limit } from './security.ts';
import { MAX_DOMAIN_SEATS, MIN_DOMAIN_SEATS, SEATS } from './seats.ts';
import { notFound } from './util.ts';
import { body, optEnum, optStr, reqEnum, reqStr, safeParam } from './validate.ts';
import type { SeatId } from '../shared/types.ts';

const LESSON_SEATS = ['all', ...SEATS.map(s => s.id)] as const;

export function coreRouter(ctx: Ctx): Router {
  const { db, config, ai, council, network, autopilot } = ctx;
  const router = Router();
  const json = express.json({ limit: '200kb' });
  const id = (v: unknown) => safeParam(v, 80);
  const conveneLimiter = new RateLimiter(60_000, 6);
  const lightLimiter = new RateLimiter(60_000, 40);
  const question = (b: Record<string, unknown>) => reqStr(b, 'question', 8, 500, true);

  // ── the council ─────────────────────────────────────────────────────────
  router.get('/brain', async (_req, res) => {
    res.json({
      mode: config.mode,
      ai: { enabled: ai.enabled(), provider: ai.providerLabel(), budgetLeft: ai.enabled() ? await ai.budgetLeft() : 0, dailyCap: config.ai.dailyCap, lastError: ai.lastError() },
      seats: await council.seats(),
      limits: { minSeats: MIN_DOMAIN_SEATS + 1, maxSeats: MAX_DOMAIN_SEATS + 1, maxActiveLessons: MAX_ACTIVE_LESSONS },
      running: council.runningId(),
      sessions: await council.list(20),
      lessons: await listLessons(db.query),
    });
  });

  /** Who would sit, and why. Costs nothing: no model is asked. */
  router.post('/brain/route', limit(lightLimiter, 'route'), json, async (req, res) => {
    const b = body(req);
    res.json(await council.plan(question(b), b.seats));
  });

  /** Open a session. Answers at once; the console then watches the seats fill in. */
  router.post('/brain/sessions', limit(conveneLimiter, 'council'), json, async (req, res) => {
    const b = body(req);
    res.status(202).json(await council.start(question(b), b.seats));
  });

  router.get('/brain/sessions/:id', async (req, res) => {
    const view = await council.get(id(req.params.id));
    if (!view) throw notFound('Session not found.');
    res.json({ ...view, lesson: await proposedForSession(db.query, view.session.id) });
  });

  /** The director rules on a verdict. A ruling is a note for later sessions; it carries out nothing. */
  router.post('/brain/sessions/:id/rule', json, async (req, res) => {
    const b = body(req);
    const ruling = reqEnum(b, 'ruling', ['accepted', 'rejected', 'noted'] as const);
    res.json({ session: await council.decide(id(req.params.id), ruling, optStr(b, 'note', 400, true)) });
  });

  // ── lessons ─────────────────────────────────────────────────────────────
  router.post('/brain/lessons', requireStepUp, json, async (req, res) => {
    const b = body(req);
    const seat = (optEnum(b, 'seat', LESSON_SEATS) ?? 'all') as SeatId | 'all';
    res.status(201).json({ lesson: await addLesson(db, { text: reqStr(b, 'text', 8, 240), seat }) });
  });
  router.post('/brain/lessons/:id/approve', requireStepUp, json, async (req, res) => {
    res.json({ lesson: await approveLesson(db, id(req.params.id), optStr(body(req), 'text', 240)) });
  });
  router.post('/brain/lessons/:id/dismiss', async (req, res) => {
    res.json({ lesson: await closeLesson(db, id(req.params.id), 'dismiss') });
  });
  router.post('/brain/lessons/:id/retire', async (req, res) => {
    res.json({ lesson: await closeLesson(db, id(req.params.id), 'retire') });
  });

  // ── the network ─────────────────────────────────────────────────────────
  router.get('/network', async (_req, res) => {
    const links = await network.list();
    res.json({ links, realms: [...new Set(links.map(l => l.realm))], kinds: LINK_KINDS, sweptAt: await network.sweptAt(), limits: { maxLinks: MAX_LINKS, maxImport: MAX_IMPORT } });
  });
  router.post('/network', requireStepUp, json, async (req, res) => {
    res.status(201).json({ link: await createLink(db, parseLinkInput(body(req))) });
  });
  router.put('/network/:id', requireStepUp, json, async (req, res) => {
    res.json({ link: await updateLink(db, id(req.params.id), parseLinkInput(body(req))) });
  });
  router.delete('/network/:id', async (req, res) => {
    await deleteLink(db, id(req.params.id));
    res.json({ ok: true });
  });
  router.post('/network/import', requireStepUp, json, async (req, res) => {
    res.json(await importLinks(db, body(req).links));
  });
  /** Knock on every watched link now. */
  router.post('/network/check', limit(new RateLimiter(60_000, 6), 'sentinel'), async (_req, res) => {
    const job = (await autopilot.runNow('sentinel')).find(j => j.id === 'sentinel');
    res.json({ result: job?.lastResult ?? null, error: job?.lastError ?? null, links: await network.list(), sweptAt: await network.sweptAt() });
  });

  return router;
}
