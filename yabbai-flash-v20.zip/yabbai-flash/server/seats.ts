/**
 * The eight seats of the council, and the router that decides who sits.
 *
 * One brain, several points of view: each seat judges the same question from
 * a single angle, and each is handed ONLY the records that angle needs. The
 * Treasurer never sees the lead list; the Pipeline seat never sees the wallet.
 * That separation is the point. Seats that all read the same page tend to
 * agree with each other, and agreement between copies is not evidence.
 *
 * What no seat is ever handed: a customer's name, email, phone number or
 * message; a wallet address; a key; a pay link. Slices are counts, totals,
 * invoice numbers, product titles and yes/no settings.
 *
 * The router is plain rules — keyword matches plus what the records already
 * show. It costs no AI call, it gives the same answer every time, and it
 * explains itself: every seat comes with the reason it was seated.
 */
import type { Config } from './config.ts';
import type { Db } from './db.ts';
import type { JobState } from './autopilot.ts';
import { verifyAuditChain } from './audit.ts';
import { listInvoices } from './invoices.ts';
import { listDrafts, listLeads } from './leads.ts';
import { listOrders, listProducts } from './products.ts';
import { bad } from './util.ts';
import type { HealthCheck, MarketRow, NetworkLink, Overview, RailState, SeatId, SeatPick, WalletStatus } from '../shared/types.ts';

/** Everything a seat may draw its slice from. Built once in server.ts. */
export interface SeatSources {
  db: Db;
  config: Config;
  overview(): Promise<Overview>;
  health(): Promise<HealthCheck[]>;
  wallet(): Promise<WalletStatus | null>;
  cryptoRail(): RailState;
  markets(): Promise<{ rows: MarketRow[]; venuesUp: Record<string, boolean> }>;
  autopilot(): { on: boolean; jobs: JobState[] };
  aiLabel(): string;
  links(): Promise<NetworkLink[]>;
  auditBroken(): boolean;
}

/** Within one session every source is read at most once, so all seats quote the same moment. */
export function memoSources(s: SeatSources): SeatSources {
  const once = <T,>(fn: () => Promise<T>): (() => Promise<T>) => {
    let p: Promise<T> | null = null;
    return () => (p ??= fn());
  };
  return { ...s, overview: once(s.overview), health: once(s.health), wallet: once(s.wallet), markets: once(s.markets), links: once(s.links) };
}

export interface SeatDef {
  id: SeatId;
  name: string;
  lens: string;
  sees: string;
  /** Router keywords, matched at the start of a word. A trailing space means the whole word. */
  words: string[];
  gather(s: SeatSources): Promise<Record<string, unknown>>;
}

const aud = (cents: number) => `$${(cents / 100).toFixed(2)} AUD`;
const minutesAgo = (ms: number | null) => (ms === null ? null : Math.max(0, Math.round((Date.now() - ms) / 60_000)));
const daysSince = (ms: number) => Math.max(0, Math.floor((Date.now() - ms) / 86_400_000));
const plural = (n: number, one: string, many = `${one}s`) => `${n} ${n === 1 ? one : many}`;

export const SEATS: readonly SeatDef[] = [
  {
    id: 'treasurer',
    name: 'Treasurer',
    lens: 'You judge one thing: money that has verifiably arrived, and money that is owed.',
    sees: 'Verified and attested totals, what each payment method brought in, open and overdue invoices by number, disputes, which payment methods are on.',
    words: ['invoice', 'paid ', 'pay', 'owed', 'owing', 'overdue', 'income', 'revenue', 'money', 'cash', 'bank', 'stripe', 'refund', 'dispute', 'gst', 'tax', 'receivable', 'chase', 'earn'],
    async gather(s) {
      const o = await s.overview();
      const invoices = await listInvoices(s.db.query, s.config);
      const today = Date.now();
      const overdue = invoices
        .filter(i => i.status === 'overdue')
        .slice(0, 8)
        .map(i => ({ invoice: i.number, owing: aud(i.outstandingCents), dueDate: i.dueDate, daysOverdue: Math.max(1, Math.round((today - Date.parse(i.dueDate)) / 86_400_000)) }));
      const disputed = await s.db.query('SELECT COUNT(*)::int AS n FROM payments WHERE livemode = $1 AND disputed = TRUE', [s.config.mode === 'live']);
      return {
        mode: o.mode,
        verifiedIncome: { last7Days: aud(o.totals.verified7dCents), last30Days: aud(o.totals.verified30dCents), allTime: aud(o.totals.verifiedAllTimeCents) },
        attestedByTheDirectorAllTime: aud(o.totals.attestedAllTimeCents),
        refundedAllTime: aud(o.totals.refundedAllTimeCents),
        byPaymentMethod: o.byRail.map(r => ({ method: r.rail, total: aud(r.cents), payments: r.count })),
        owedToYou: aud(o.totals.receivableCents),
        openInvoices: o.totals.openInvoices,
        overdueInvoices: overdue,
        paymentsUnderDispute: Number(disputed.rows[0]?.n ?? 0),
        paymentMethodsOn: { card: o.rails.stripe.enabled, crypto: o.rails.solana.enabled, bankTransfer: o.rails.bank.enabled },
        gstRegistered: s.config.business.gstRegistered,
      };
    },
  },
  {
    id: 'pipeline',
    name: 'Pipeline',
    lens: 'You judge one thing: whether real enquiries are being turned into paying client work.',
    sees: 'How many leads sit in each stage and where they came from, how they scored, the sectors they are in, how long new ones have waited, drafts waiting to be sent. Never names or contact details.',
    words: ['lead', 'client', 'customer', 'outreach', 'prospect', 'enquir', 'inquir', 'agency', 'retainer', 'follow', 'pipeline', 'proposal', 'smb', 'cold ', 'contact', 'reply'],
    async gather(s) {
      const leads = await listLeads(s.db.query);
      const drafts = await listDrafts(s.db.query, 'pending');
      const count = <K extends string>(keys: readonly K[], of: (l: (typeof leads)[number]) => string) =>
        Object.fromEntries(keys.map(k => [k, leads.filter(l => of(l) === k).length])) as Record<K, number>;
      const fresh = leads.filter(l => l.stage === 'new');
      const sectors = new Map<string, number>();
      for (const l of leads) {
        const key = (l.sector ?? '').toLowerCase().replace(/\s+/g, ' ').trim().slice(0, 40);
        if (key) sectors.set(key, (sectors.get(key) ?? 0) + 1);
      }
      const scored = leads.filter(l => l.score !== null);
      return {
        leadsByStage: count(['new', 'qualified', 'contacted', 'replied', 'proposal', 'won', 'lost'] as const, l => l.stage),
        leadsBySource: count(['intake', 'manual', 'import'] as const, l => l.source),
        scoredLeads: { hot: scored.filter(l => l.score! >= 70).length, warm: scored.filter(l => l.score! >= 45 && l.score! < 70).length, cold: scored.filter(l => l.score! < 45).length },
        newLeadsNotYetScored: fresh.filter(l => l.score === null).length,
        oldestNewLeadHasWaitedDays: fresh.length ? Math.max(...fresh.map(l => daysSince(l.createdAt))) : null,
        wonInLast30Days: leads.filter(l => l.stage === 'won' && Date.now() - l.updatedAt < 30 * 86_400_000).length,
        topSectors: [...sectors.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([sector, n]) => ({ sector, leads: n })),
        draftsWaitingToBeSent: { outreach: drafts.filter(d => d.type === 'outreach').length, paymentReminders: drafts.filter(d => d.type === 'followup').length },
      };
    },
  },
  {
    id: 'storekeeper',
    name: 'Storekeeper',
    lens: 'You judge one thing: what is actually on the shelf and whether it sells.',
    sees: 'Each product title, price, status, whether its deliverable is attached, how many sold and the verified revenue behind it; orders by state. Never buyers.',
    words: ['product ', 'products ', 'store ', 'price', 'pricing', 'gumroad', 'listing', 'listed', 'orders ', 'deliverable', 'sell', 'sale ', 'sales ', 'launch', 'bundle', 'sku', 'template', 'kit ', 'download'],
    async gather(s) {
      const products = await listProducts(s.db.query, s.config);
      const orders = await listOrders(s.db.query, s.config, true);
      const o = await s.overview();
      return {
        products: products.slice(0, 14).map(p => ({
          title: p.title,
          price: aud(p.priceCents),
          status: p.status,
          deliverableAttached: p.hasDeliverable,
          sold: p.soldCount,
          verifiedRevenue: aud(p.revenueCents),
          daysSinceLastEdit: daysSince(p.updatedAt),
        })),
        onSale: products.filter(p => p.status === 'listed').length,
        drafts: products.filter(p => p.status === 'draft').length,
        draftsWithNoDeliverable: products.filter(p => p.status === 'draft' && !p.hasDeliverable).length,
        orders: {
          paid: orders.filter(x => x.status === 'paid').length,
          startedButNotPaid: orders.filter(x => x.status === 'pending').length,
          refunded: orders.filter(x => x.status === 'refunded').length,
        },
        buyersCanPayBy: { card: o.rails.stripe.enabled, crypto: o.rails.solana.enabled },
      };
    },
  },
  {
    id: 'watcher',
    name: 'Chain Watcher',
    lens: 'You judge one thing: what the chain and the public order books show right now. You watch; this business places no trades from here.',
    sees: 'Whether the receiving wallet is proven and what it holds, whether crypto payments are on, and exchange spreads after fees. Never an address or a key.',
    words: ['crypto', 'sol ', 'solana', 'usdc', 'wallet', 'chain', 'token', 'market ', 'markets ', 'spread ', 'spreads ', 'arbitrage', 'arb ', 'exchange', 'airdrop', 'coin ', 'coins ', 'defi', 'trade ', 'trades ', 'trading', 'flip'],
    async gather(s) {
      const w = await s.wallet();
      const rail = s.cryptoRail();
      const m = await s.markets().catch(() => ({ rows: [] as MarketRow[], venuesUp: {} as Record<string, boolean> }));
      const ranked = m.rows.filter(r => r.netBps !== null).sort((a, b) => (b.netBps ?? 0) - (a.netBps ?? 0));
      return {
        network: s.config.solana.cluster,
        walletConfigured: !!s.config.solana.receiveAddress,
        walletControlProven: w ? w.proven : null,
        howItWasProven: w?.proofMethod ?? null,
        walletHolds: w && !w.error ? { sol: w.sol, usdc: w.usdc, worth: w.audValueCents === null ? null : aud(w.audValueCents) } : null,
        walletReadError: w?.error ?? null,
        cryptoPaymentsOn: rail.enabled,
        whyOff: rail.enabled ? null : rail.reason,
        accepts: { sol: s.config.solana.acceptSol, usdc: s.config.solana.acceptUsdc },
        exchangesAnswering: Object.entries(m.venuesUp)
          .filter(([, up]) => up)
          .map(([v]) => v),
        bestSpreadsAfterFees: ranked.slice(0, 3).map(r => ({ asset: r.symbol, route: r.bestBuy && r.bestSell ? `${r.bestBuy.venue} to ${r.bestSell.venue}` : null, netBasisPoints: r.netBps })),
        note: 'Spreads are basis points after entry-tier taker fees on both legs and leave out withdrawal fees, transfer time and slippage.',
      };
    },
  },
  {
    id: 'engineer',
    name: 'Engineer',
    lens: 'You judge one thing: whether the machinery is running — this app, its scheduled jobs and the other apps it links to.',
    sees: 'The go-live checklist states and fixes, scheduled jobs and their last errors, the database kind, the AI provider, and which linked apps stopped answering.',
    words: ['bug', 'deploy', 'server', 'database', 'render', 'build', 'code', 'test', 'autopilot', 'down ', 'outage', 'link', 'app ', 'apps ', 'site', 'uptime', 'api ', 'webhook', 'broken', 'error', 'host', 'fix'],
    async gather(s) {
      const health = await s.health();
      const auto = s.autopilot();
      const links = await s.links();
      const watched = links.filter(l => l.watch);
      return {
        checklist: health.map(c => ({ item: c.label, state: c.state, toFix: c.fix ?? null })),
        database: s.db.kind === 'postgres' ? 'managed Postgres' : 'built-in local database (not for live payments)',
        aiProvider: s.aiLabel(),
        scheduledJobs: { running: auto.on, jobs: auto.jobs.map(j => ({ job: j.name, lastRanMinutesAgo: minutesAgo(j.lastRunAt), lastError: j.lastError })) },
        linkedApps: {
          total: links.length,
          watched: watched.length,
          neverChecked: watched.filter(l => l.state === 'unknown').length,
          notAnswering: watched
            .filter(l => l.state === 'down' || l.state === 'error')
            .slice(0, 12)
            .map(l => ({ name: l.name, realm: l.realm, lastAnswer: l.lastStatus === null ? 'none' : `status ${l.lastStatus}`, checkedMinutesAgo: minutesAgo(l.lastCheckedAt) })),
        },
      };
    },
  },
  {
    id: 'guardian',
    name: 'Guardian',
    lens: 'You judge one thing: how someone could get in, redirect money or rewrite history, and whether the locks are on.',
    sees: 'Sign-in settings, whether keys are restricted, the audit log check, and counts of failed sign-ins, refused webhooks and changes to links and lessons over seven days. Never a secret.',
    words: ['security', 'secure', 'password', '2fa', 'totp', 'key ', 'keys ', 'secret', 'hack', 'breach', 'audit', 'login', 'sign in', 'session', 'phish', 'leak', 'rotate', 'stolen', 'safe'],
    async gather(s) {
      const cfg = s.config;
      const has = (code: string) => cfg.problems.some(p => p.code === code);
      const chain = await verifyAuditChain(s.db.query);
      const since = Date.now() - 7 * 86_400_000;
      const { rows } = await s.db.query('SELECT action, COUNT(*)::int AS n FROM audit_log WHERE at >= $1 GROUP BY action', [since]);
      const n = (re: RegExp) => rows.filter(r => re.test(String(r.action))).reduce((sum, r) => sum + Number(r.n), 0);
      const sessions = await s.db.query('SELECT COUNT(*)::int AS n FROM sessions WHERE expires_at > $1', [Date.now()]);
      const w = await s.wallet();
      return {
        twoFactorSignIn: !!cfg.auth.totpSecret,
        passwordStoredAsHash: !!cfg.auth.passwordHash,
        stripeKey: cfg.stripe.keyMode === 'off' ? 'not connected' : has('UNRESTRICTED_STRIPE_KEY') ? 'unrestricted (could move money if leaked)' : 'restricted',
        webhookSigningSecretSet: !!cfg.stripe.webhookSecret,
        customerAddressIsHttps: cfg.publicBaseUrl ? cfg.publicBaseUrl.startsWith('https://') : null,
        walletProof: w ? (w.proven ? w.proofMethod : 'not proven') : null,
        auditLog: { intact: chain.ok, entries: chain.entries, brokenAtEntry: chain.brokenAtSeq },
        last7Days: {
          signIns: n(/^auth\.login$/),
          failedSignIns: n(/^auth\.login_failed$/),
          failedPasswordConfirmations: n(/^auth\.stepup_failed$/),
          refusedWebhooks: n(/^webhook\./),
          linkChanges: n(/^network\./),
          lessonChanges: n(/^lesson\.(added|approved|retired|dismissed)$/),
        },
        browsersSignedInNow: Number(sessions.rows[0]?.n ?? 0),
        configurationProblems: cfg.problems.map(p => ({ level: p.level, code: p.code })),
      };
    },
  },
  {
    id: 'planner',
    name: 'Planner',
    lens: 'You judge one thing: order. Of everything open, what comes first, what waits, and what should be dropped.',
    sees: 'The list of things needing attention, counts of open work in each area, last 30 days of verified income, and how many apps sit in each realm of the network.',
    words: ['priorit', 'focus', 'plan', 'next ', 'week', 'month', 'roadmap', 'first ', 'strategy', 'decide', 'should', 'which ', 'today', 'goal', 'drop', 'stop'],
    async gather(s) {
      const o = await s.overview();
      const links = await s.links();
      const realms = new Map<string, { links: number; watched: number; notAnswering: number }>();
      for (const l of links) {
        const r = realms.get(l.realm) ?? { links: 0, watched: 0, notAnswering: 0 };
        r.links += 1;
        if (l.watch) r.watched += 1;
        if (l.state === 'down' || l.state === 'error') r.notAnswering += 1;
        realms.set(l.realm, r);
      }
      return {
        needsAttention: o.attention.map(a => `${a.level}: ${a.text}`),
        openWork: {
          openInvoices: o.totals.openInvoices,
          overdueInvoices: o.totals.overdueInvoices,
          newLeads: o.counts.leadsNew,
          draftsWaitingToBeSent: o.counts.draftsPending,
          paidOrders: o.totals.ordersPaid,
        },
        verifiedIncomeLast30Days: aud(o.totals.verified30dCents),
        network: { totalLinkedApps: links.length, realms: [...realms.entries()].map(([realm, r]) => ({ realm, ...r })) },
      };
    },
  },
  {
    id: 'skeptic',
    name: 'Skeptic',
    lens: 'You add no plan. You check what the other seats wrote against the records they were given.',
    sees: 'The records handed to the seats at this session, and what each of them wrote.',
    words: [],
    async gather() {
      return {};
    },
  },
];

export const DOMAIN_SEATS = SEATS.filter(s => s.id !== 'skeptic');
export const MIN_DOMAIN_SEATS = 2;
export const MAX_DOMAIN_SEATS = 4;
const DEFAULTS: SeatId[] = ['planner', 'treasurer', 'pipeline'];
const SKEPTIC_REASON = 'sits at every session to check the others against the records';

export function seatById(id: string): SeatDef | undefined {
  return SEATS.find(s => s.id === id);
}

function matches(question: string, words: string[]): string[] {
  const text = ` ${question.toLowerCase().replace(/[^a-z0-9]+/g, ' ')} `;
  return words.filter(w => text.includes(` ${w}`)).map(w => w.trim());
}

/**
 * Decide who sits. Two to four seats with something to say, then the Skeptic:
 * three to five in all. No model is asked; the same question and the same
 * records always seat the same council.
 */
export async function routeQuestion(question: string, s: SeatSources): Promise<SeatPick[]> {
  const o = await s.overview();
  const links = await s.links();
  const stopped = links.filter(l => l.state === 'down' || l.state === 'error').length;
  const facts: Record<string, Array<[number, string]>> = {
    treasurer: [
      [o.totals.overdueInvoices > 0 ? 2 : 0, `${plural(o.totals.overdueInvoices, 'invoice is', 'invoices are')} overdue`],
      [o.recentPayments.some(p => p.disputed) ? 2 : 0, 'a payment is under dispute'],
    ],
    pipeline: [
      [o.counts.leadsNew > 0 ? 1 : 0, `${plural(o.counts.leadsNew, 'new lead is', 'new leads are')} waiting`],
      [o.counts.draftsPending > 0 ? 1 : 0, `${plural(o.counts.draftsPending, 'draft is', 'drafts are')} waiting to be sent`],
    ],
    storekeeper: [],
    watcher: [[s.config.solana.receiveAddress && !s.cryptoRail().enabled ? 1 : 0, 'crypto payments are switched off']],
    engineer: [
      [stopped > 0 ? 2 : 0, `${plural(stopped, 'linked app is', 'linked apps are')} not answering`],
      [o.attention.some(a => a.level === 'error' && a.tab === 'ops') ? 1 : 0, 'a go-live item is blocking'],
    ],
    guardian: [
      [s.auditBroken() ? 3 : 0, 'the audit log failed its check'],
      [s.config.auth.totpSecret ? 0 : 1, 'two-factor sign-in is off'],
    ],
    planner: [],
  };

  const scored = DOMAIN_SEATS.map((seat, order) => {
    const hits = matches(question, seat.words);
    const shown = facts[seat.id].filter(([points]) => points > 0);
    const score = Math.min(hits.length, 3) * 2 + shown.reduce((sum, [points]) => sum + points, 0);
    const reasons = [hits.length ? `you asked about ${hits.slice(0, 3).join(', ')}` : null, ...shown.map(([, why]) => why)].filter(Boolean) as string[];
    return { seat: seat.id, order, score, reason: reasons.join(' · ') };
  });

  const picked = scored
    .filter(x => x.score >= 2)
    .sort((a, b) => b.score - a.score || a.order - b.order)
    .slice(0, MAX_DOMAIN_SEATS);
  for (const id of DEFAULTS) {
    if (picked.length >= MIN_DOMAIN_SEATS) break;
    if (!picked.some(p => p.seat === id)) picked.push({ seat: id, order: DOMAIN_SEATS.findIndex(d => d.id === id), score: 0, reason: 'nothing more specific matched, so seated by default' });
  }
  picked.sort((a, b) => a.order - b.order);
  return [...picked.map(p => ({ seat: p.seat, reason: p.reason })), { seat: 'skeptic' as const, reason: SKEPTIC_REASON }];
}

/** The director names the seats. Same limits as the router; the Skeptic is added whether asked for or not. */
export function directorPicks(raw: unknown): SeatPick[] {
  if (!Array.isArray(raw) || raw.some(x => typeof x !== 'string')) throw bad('"seats" must be a list of seat names.');
  const asked = (raw as string[]).filter(id => id !== 'skeptic');
  if (new Set(asked).size !== asked.length) throw bad('Name each seat once.');
  for (const id of asked) if (!DOMAIN_SEATS.some(s => s.id === id)) throw bad(`There is no seat called "${id.slice(0, 30)}".`);
  if (asked.length < MIN_DOMAIN_SEATS || asked.length > MAX_DOMAIN_SEATS) {
    throw bad(`Seat between ${MIN_DOMAIN_SEATS} and ${MAX_DOMAIN_SEATS} seats. The Skeptic joins every session on top of those.`);
  }
  const ordered = DOMAIN_SEATS.filter(s => asked.includes(s.id)).map(s => ({ seat: s.id, reason: 'chosen by you' }));
  return [...ordered, { seat: 'skeptic' as const, reason: SKEPTIC_REASON }];
}
