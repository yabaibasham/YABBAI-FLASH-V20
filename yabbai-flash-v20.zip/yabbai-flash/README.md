# YABBAI FLASH

A revenue cockpit for a one-person business: send invoices and sell digital
products, get paid by card, by SOL/USDC or by bank transfer, and see exactly
what has arrived.

**The one rule this version is built around: the only money the console counts
is money a payment processor or the blockchain has confirmed reached you.**
Nothing can be typed in, simulated or projected into a balance.

---

## Why the old version showed a balance but paid nothing

The previous build kept its whole "treasury" in the browser's local storage.
Every number was something the page had written for itself.

| What the old app did | Why no money ever arrived |
| --- | --- |
| "Bank a sale", "Record credit", terminal `sale`, sample bank statement, JSON import | Each one added to the balance with nothing behind it |
| Trade results | Decided by a random number, then shown as profit |
| Leads | Generated from five hard-coded names |
| "Public payment portal" | A pop-up inside your own console. No customer could ever open it |
| PayPal button | Showed a message. The payout route did not exist |
| Solana recipient in the code | Not a real wallet: it decodes to 31 bytes, a wallet is 32 |
| Stripe test-key balance | Counted as treasury |
| Password | A factory key shipped in the code, checked in the browser |
| Stripe secret key, Alchemy key | Sat in the browser where anyone could read them |

So there was never a way for a customer to pay, and nowhere real for money to go.

## What this version is

- **A server** (Node + Express + Postgres) that owns all state. The browser holds
  nothing but a sign-in cookie it cannot read.
- **Real pay pages** customers open from a link: `/pay/<token>` for an invoice,
  `/p/<product>` for a product, `/order/<token>` for their purchase.
- **Three ways money gets recorded, and no others:**
  1. **Stripe** — the server asks Stripe directly whether a checkout was paid,
     for the amount the server set. A webhook is only a hint to go and ask.
  2. **Solana** — a finalized transfer into your wallet carrying a one-off
     reference for that invoice. The amount is read from the chain.
  3. **Attested** — a bank transfer you checked yourself. Needs your password
     again, is labelled "attested by you" in gold, and never counts as verified.
- **No way to move money out.** No payout, refund, transfer or withdrawal code
  exists. The app holds no wallet key. Stripe pays your bank on its own schedule;
  crypto lands in your wallet directly from the customer.
- **Destinations pinned outside the app.** Your wallet address and bank details
  are environment variables. Someone who gets into the console cannot change them.

Colour means how a figure is proven: green = verified, gold = attested by you,
purple = test mode, red = something is blocking payment.

---

## The core: Brain, Network and the build team

Version 20 turns the cockpit into the centre of everything else you run, in three parts.

**Brain — one question, several points of view.** Eight seats each read a *different* part of your records: Treasurer, Pipeline, Storekeeper, Chain Watcher, Engineer, Guardian, Planner and Skeptic. For any question, three to five of them sit. A plain-rules router picks who (it asks no model and says why it picked each one), or you pick. Each seat answers alone from its own slice; the Skeptic checks what they wrote against the records; one verdict comes back. You rule on it — accepted, rejected or noted.

**Network — every other app, as a list of links.** Your other sites, dashboards, documents and repositories, grouped into realms. A link carries no figure. If you ask for one to be watched, the sentinel sends its server one `HEAD` request every 15 minutes and shows whether it answered.

**The build team — agents that change the code.** `rig/` holds an [OpenRig](https://github.com/mvschwarz/openrig) team that works on this repository under `AGENTS.md`: built on one harness, verified on the other, audited, then handed to you. It runs on your computer, not in the app. See [`rig/README.md`](./rig/README.md).

How the idea maps to what is here:

| The idea | What is built | Where |
| --- | --- | --- |
| One brain, split into several minds | Eight seats, three to five sitting at a time | `server/seats.ts` |
| Each mind on its own plane, nothing leaking between them | Each seat is handed only its own records, and never a person, an address or a secret | `server/seats.ts`, `test/council.test.ts` |
| They combine into one answer | The Skeptic's check, then one verdict | `server/council.ts` |
| It keeps growing | Your rulings, and up to twelve lessons you approve, are handed to later sessions | `server/lessons.ts` |
| Hubs and realms | Links grouped by realm, with a reachability check | `server/network.ts` |
| Duplicated agents doing the work | A separate team of coding agents with independent verification | `rig/` |

And what was deliberately **not** built: an agent that acts. The council has no tools. It cannot record a payment, send a message, change a setting, follow a link or run on a schedule; a verdict is text that you read. Several models agreeing is not proof of anything — which is why the seats are kept apart, why a Skeptic sits at every session, and why the only money on the Overview is still money Stripe or the chain confirmed.

**What it costs.** A session is one AI call per seat plus one for the verdict: four to six calls, counted against `AI_DAILY_CAP`. The console shows the cost before you start, and a session that would run out of budget halfway does not start. With a small local model, set `COUNCIL_PARALLEL=1` so the seats are asked one at a time.

**What the AI provider sees in a council session.** Your question, your lessons and past rulings, totals, counts, invoice numbers, product titles, the sector an enquirer typed, the names and realms of your linked apps, and yes/no settings. Not customer names, emails, phone numbers or messages, not a wallet address, a key, a pay link or a deliverable. (Scoring or drafting for one lead or one invoice, under Pipeline and Receive, still sends that record's own details, as it did before.) If that is more than you want leaving your machine, point `LLM_BASE_URL` at a model you run yourself.

---

## Run it on your computer

Needs Node 22.18 or newer.

```bash
npm install
npm run setup -- --write     # choose a password, scan the 2FA code; saves ./.env
npm run dev                  # http://localhost:3000
```

With no `DATABASE_URL` it uses a small built-in database in `./.data`. That is
fine for looking around. Live payment methods stay off until a real database is set.

To try payments safely, put a Stripe **test** key (`sk_test_…`) in `.env` and set
`SOLANA_CLUSTER=devnet`. The whole app turns purple and says TEST.

**Editing in Google AI Studio or another hosted editor:** the entry point is
still `server.ts` on port 3000, so the preview runs. Open the preview in its own
browser tab to sign in — the session cookie is deliberately not sent when the
app is framed inside another site. Real payments need a proper deployment (a
database and a fixed https address), which a preview does not have.

## Going live — in this order

The console's **Ops → Go-live checklist** shows the state of every item below
and tells you what is still missing.

1. **Activate your Stripe account.** In the Stripe Dashboard: accept the terms,
   verify your identity, add your business website and support phone, and add the
   bank account for payouts. Until Stripe shows payments and payouts as enabled,
   it will not take or pay out a cent — no software can change that.
2. **Deploy.** Push this folder to a private GitHub repository. In Render choose
   **New → Blueprint** and pick it; `render.yaml` creates the web service and a
   Postgres database. Run `npm run setup` on your own computer and paste the two
   values it prints when Render asks.
3. **Sign in** at your new address and open **Ops**.
4. **Connect Stripe.** Create a *restricted* key (Checkout Sessions: Write,
   Balance: Read, Payouts: Read) and set `STRIPE_SECRET_KEY`. Add a webhook
   endpoint at `https://<your-address>/api/webhooks/stripe` for the events below
   and set `STRIPE_WEBHOOK_SECRET`.
5. **Connect the wallet.** `SOLANA_RECEIVE_ADDRESS` is already set in
   `render.yaml`. Add `SOLANA_RPC_URL` (a Helius or Alchemy endpoint), then open
   **Payouts** and prove you control the wallet — sign a message with Phantom or
   Solflare, or approve a tiny transfer to yourself. Customers are not shown the
   crypto option until that is done.
6. **Optional:** bank details (`BANK_PAYID` …), `SUPPORT_EMAIL`, `BUSINESS_ABN`,
   an AI key.
7. **Prove it end to end.** Issue yourself a $2 invoice, pay it with a real card,
   and watch it turn green. Then check **Payouts** for the Stripe payout to your bank.

Webhook events to select in Stripe: `checkout.session.completed`,
`checkout.session.async_payment_succeeded`, `checkout.session.async_payment_failed`,
`checkout.session.expired`, `charge.refunded`, `charge.dispute.created`,
`charge.dispute.closed`, `payout.paid`, `payout.failed`.

If Stripe refuses a call because the restricted key lacks a permission, its
message names the permission. The console shows that message rather than guessing.

## Day to day

| Tab | What it is for |
| --- | --- |
| **Overview** | Verified income, what is owed, what is blocking payment, recent payments with proof links |
| **Receive** | Invoices and pay links, recording a bank transfer, the payments ledger |
| **Store** | Digital products. One cannot go on sale without its real deliverable attached |
| **Pipeline** | Real enquiries from `/intake` and leads you add; AI scores and drafts for you to send |
| **Brain** | Put a decision to the council; read what each seat wrote; rule on the verdict; keep or retire lessons |
| **Network** | Links to your other apps, sites and documents by realm, and whether the watched ones still answer |
| **Payouts** | Stripe account state, balance and payouts; your wallet; proof of wallet control |
| **Markets** | Read-only exchange spreads after fees. No trades, no profit counter |
| **Ops** | Go-live checklist, autopilot jobs, AI brief, audit log, sign out everywhere |

Press `` ` `` for the terminal. It reads your records and cannot change money. `council <question>`, `lessons` and `network` work there too.

**Autopilot** is six jobs on the server: re-check Stripe and the chain for
payments, verify the audit log, score new enquiries, draft reminders for overdue
invoices, clean up expired sessions and abandoned checkouts, and knock on each
watched link. None of them can create a payment without proof and none of them
sends anything. The council is not one of them: it sits only when you ask.

**The AI** writes words — a brief, a lead score, a draft email, a seat's opinion,
a verdict. It has no tools. It cannot record a payment, change a setting or send a message. Works with Gemini
or any OpenAI-compatible provider (`LLM_BASE_URL`, `LLM_MODEL`), or not at all.

### Things worth knowing

- **Crypto from an exchange.** The QR code attaches a reference so the payment
  matches itself to the invoice. A withdrawal straight from an exchange carries
  no reference: it still lands in your wallet, but you record it by hand on the
  invoice (as attested, with the transaction signature as the reference).
- **Crypto prices** are held for 15 minutes per quote. A payment that arrives
  after that is credited at the price when it is seen, never above the quote.
- **GST** is never added unless `GST_REGISTERED=true` and `BUSINESS_ABN` are set.
- **Refunds** are made in the Stripe Dashboard. They flow back here automatically.
- **Test and live records never mix.** Switching keys switches which set you see.

## Setting up a copy for a client

One copy serves one business. Each copy has its own hosting account, database,
Stripe account, wallet, sign-in, links and lessons, and nothing is shared between
copies — so one client's records never meet another's, and a problem in one
cannot reach the rest.

1. **The client owns the accounts.** The hosting account, the Stripe account and
   the wallet are created by them, in their name. You are invited in to do the
   setup. Their money goes from their customers to them and never passes through
   anything of yours, and the destinations are pinned in *their* hosting
   environment where only they can change them.
2. **Deploy from `render.yaml`** (New → Blueprint) inside their hosting account,
   and set `BRAND_NAME`, `SUPPORT_EMAIL` and `BUSINESS_ABN` for their business.
3. **They choose the password.** Run `npm run setup` with them, not for them, so
   the password and the authenticator code never exist anywhere but with them.
4. **Follow "Going live — in this order"** above, with their Stripe key and wallet.
5. **Make it theirs.** Import their links under Network. Add the lessons that
   describe how they work under Brain (each one asks for their password).

**A preview before anyone pays.** Run a copy with a Stripe *test* key and
`SOLANA_CLUSTER=devnet`. The whole console turns purple and says TEST on every
screen, so nothing in it can be mistaken for real money. Show that copy on a call
or record it. Do not put invented figures in front of a prospect: a preview that
shows income nobody earned is the same mistake the old build made, pointed at a
customer.

**Getting paid for the setup itself.** Use this app: list the setup as a product
under Store with the hand-over as its deliverable, or send an invoice from
Receive. The deliverable is released only when Stripe or the chain confirms the
payment covers the price, which is "pay first, then full access" enforced by the
ledger rather than by trust.

What is the same in every copy: the code and the rules in `AGENTS.md`.
What differs: the environment settings, the links, the lessons and the records.

## Settings

Every setting is an environment variable; `.env.example` lists them all with
comments. The ones that matter most:

| Variable | Purpose |
| --- | --- |
| `DIRECTOR_PASSWORD_HASH`, `TOTP_SECRET` | Sign-in. From `npm run setup`. No default exists |
| `DATABASE_URL` | Postgres. Required before live payments switch on |
| `PUBLIC_BASE_URL` | Your https address (Render supplies it). Required for card checkout in production |
| `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` | Cards. A test key puts the whole app in test mode |
| `SOLANA_RECEIVE_ADDRESS`, `SOLANA_RPC_URL`, `SOLANA_CLUSTER` | Crypto |
| `BANK_PAYID` / `BANK_BSB` + `BANK_ACCOUNT_NUMBER` + `BANK_ACCOUNT_NAME` | Bank details printed on invoices |
| `BRAND_NAME`, `SUPPORT_EMAIL`, `BUSINESS_ABN`, `GST_REGISTERED` | What customers see |
| `GEMINI_API_KEY` or `LLM_BASE_URL` + `LLM_API_KEY` + `LLM_MODEL` | Optional AI |
| `AI_DAILY_CAP`, `COUNCIL_PARALLEL` | How many AI calls a day (a council session uses four to six), and how many seats are asked at once |

To change the password: run `npm run setup` again, replace the two values on your
host, restart. That also clears any sign-in lock.

## Checks

```bash
npm run lint     # type-check
npm test         # 82 tests: every way in, tried as an attacker would
npm run build    # production frontend
```

The tests run the real server against a real database, the real Stripe SDK
against a local stand-in for Stripe's API, and a scripted Solana chain. Set
`TEST_PG_ADMIN_URL=postgres://user@host:port/postgres` to run them against a
Postgres server instead of the built-in one.

Three of them guard the code itself: one fails if simulated money, browser storage,
an embedded key or a hard-coded address ever appears in the source; one fails
if any Stripe call other than "create a checkout" or "read" is added; and one fails
if the council's code ever imports something that changes a business record, or
writes to a table that is not its own.

## Suggested services

- **Hosting:** Render, using `render.yaml`. Keep the database on a paid plan.
- **Solana RPC:** Helius or Alchemy. The shared public endpoint drops requests.
- **Email:** the app does not send email. Drafts are copied into your own mail.
  If you want invoices and receipts sent for you, Resend or Postmark is a small,
  contained addition — see `AGENTS.md` for the rules it must follow.
- **Second factor:** any authenticator app. Keep the setup key somewhere safe.

See `SECURITY.md` for what is protected and what is not, and `AGENTS.md` before
letting any AI tool edit this code.
