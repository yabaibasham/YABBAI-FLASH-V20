# Read AGENTS.md first

The rules for editing this project are in [AGENTS.md](./AGENTS.md). They are not optional:
this app handles real money, and `npm test` enforces them.
