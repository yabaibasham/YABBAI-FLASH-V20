# Where you are

You are working on **YABBAI FLASH**: a revenue cockpit for a one-person business. It sends invoices, sells digital products, records payments that Stripe or the Solana chain has confirmed, and — in its core — runs a council of AI seats that writes advice and a network page of links to the owner's other apps.

Stack: Node 22.18 or newer (it runs the TypeScript directly), Express 5, React 19 with Vite, Postgres (a built-in one locally).

## Map

| Path | What is there |
| --- | --- |
| `AGENTS.md` | The rules. Read it first. `npm test` enforces most of them. |
| `server.ts`, `server/` | The API. Money lives in `ledger.ts`, `stripe.ts`, `solana.ts`, `invoices.ts`, `products.ts`. |
| `server/council.ts`, `seats.ts`, `lessons.ts` | The council: seats, router, sessions, lessons. It writes text and has no tools. |
| `server/network.ts`, `coreRoutes.ts` | Linked apps, the reachability check, and the routes for both. |
| `src/console/` | The director console (React). `src/public/` is what customers see. |
| `shared/types.ts` | Types shared by server and browser. |
| `test/` | The suite. Real server, real database, stand-ins for Stripe, the chain and the AI provider. |
| `rig/` | This team: specs, culture and role files. |

## Commands (from the repository root)

```bash
npm ci
npm run lint     # type-check
npm test         # the whole suite, about three minutes
npm run build    # production frontend
```

The tests need no keys and no `.env`. This working copy has none on purpose. Do not create one, and do not ask for one.
