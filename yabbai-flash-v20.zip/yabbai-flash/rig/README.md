# The build team

A team of coding agents that works on this repository under its own rules, run by [OpenRig](https://github.com/mvschwarz/openrig).

This is a different thing from the **Brain** tab in the console. The Brain is part of the running app: it reads your records and writes advice. This team is not part of the app at all. It runs on your computer, in terminals, and its job is to change the code — one small, tested change at a time.

## What is here

| File | What it is |
| --- | --- |
| `rig.yaml` | **Start here.** Four seats: a lead, a builder (Claude Code), a verifier and an auditor (Codex). |
| `rig.full.yaml` | Eight seats on three harnesses: adds an architect, a second builder (Codex), a verifier on Claude Code for the Codex builder, and a scout (Pi). |
| `CULTURE.md` | The team's seven rules. The first is that `AGENTS.md` outranks everything, including this folder. |
| `startup/context.md` | What every seat is told at boot: the map of the code and how to run the checks. |
| `agents/<role>/` | One folder per role: `agent.yaml` and `guidance/role.md`. |

The shape that matters: **nobody verifies their own work.** A change is built on one harness and re-run and attacked on the other, then read against `AGENTS.md` rule by rule by a seat that edits nothing. The lead never merges. You do.

## What was checked, and what was not

Checked with OpenRig CLI 0.7.20, the newest release when this was written:

- `rig spec validate` — both specs valid.
- `rig spec audit` — both clean.
- `rig agent validate` — all six agent specs valid.
- `rig spec preflight` — both report "Preflight ready".

**Not checked: the team has never been launched.** The machine these files were written on had no Claude Code, Codex or Pi sign-in, so `rig up` has not been run against them. Expect to adjust something the first time. OpenRig moves quickly; if a field is refused, its error names it, and `docs/reference/rig-spec.md` in the OpenRig repository is the reference.

## Before you start — read this part

**1. OpenRig changes things on your machine, and its own operator has wide access.** Its README lists everything: a global npm install, a block added to `~/.tmux.conf`, it may install tmux and a missing coding agent, and it writes hooks and trust settings into `~/.claude.json` and `~/.codex/config.toml`. It also starts a team of its own, the *kernel*, whose seats by default run with broader permissions than a project team — on Codex, full access with no approval prompts. Read "What OpenRig changes on your machine" in its README before installing, and back those files up first.

**2. Use a computer, or at least a user account, that holds nothing you cannot afford to lose.** No wallet files, no seed phrases, no exchange sessions, no password vault. On Windows, OpenRig runs inside WSL2 (Ubuntu); keep the project in the Linux filesystem (`~/flash`), not on OneDrive and not under `/mnt/c`.

**3. Give the team a clean copy with no secrets in it.** Clone the repository fresh. Do not copy `.env` into it. The test suite needs no keys — it brings stand-ins for Stripe, the chain and the AI provider — so the team has no reason to hold one. A seat's permissions here are *allowances, not a sandbox*: a seat can edit files in the working copy and run the project's tests, and a test command can run any code. What keeps your money safe is that there is nothing in reach to take.

**4. Nothing here can deploy.** No seat has, or should be given, your hosting login, a deploy key or a push token. Getting a change live is: you read the auditor's report, you run the three checks yourself, you push.

## Run it

Install OpenRig by following its own quick start (it needs Node 22 or 24, tmux, and Claude Code or Codex signed in):
<https://github.com/mvschwarz/openrig/blob/main/docs/reference/quickstart.md>

Then, from the root of a clean clone of this repository:

```bash
npm ci
rig spec validate rig/rig.yaml      # should print: Rig spec valid: flash-guild
rig spec preflight rig/rig.yaml     # should end with: Preflight ready
rig up rig/rig.yaml                 # starts the four seats
rig ps                              # what is running
rig down flash-guild                # stop the team
```

Talk to the lead. Say what you want changed in one or two sentences. The lead plans it, a builder builds it, the verifier re-runs and attacks it, the auditor reads the diff, and the lead comes back to you with a report that ends in what nobody checked.

For the eight-seat team use `rig/rig.full.yaml` (rig name `flash-guild-full`); it also needs Pi installed for the scout. Four Claude Code seats use a subscription's limits about four times as fast as one, which is why the four-seat team is the default.

## What OpenRig writes into this folder

- For Claude Code seats, OpenRig keeps its own instructions in `CLAUDE.local.md` (set by `managed_blocks` in the specs, and listed in `.gitignore`). The tracked `CLAUDE.md` is left alone.
- Also for Claude Code seats, its README says activity hooks go into this project's `.claude/settings.local.json`. That file is listed in `.gitignore` too.
- For Codex and Pi seats, OpenRig's documentation says its managed block normally goes to `AGENTS.md` in the working directory, except where a recent Codex takes it as launch instructions. **`AGENTS.md` is this project's law.** After a session, run `git diff AGENTS.md`. If OpenRig has added a block, do not commit it.

## Finished means

```bash
npm run lint && npm test && npm run build
```

run by you, on the final diff, after reading the auditor's report. If a guard in `test/hardening.test.ts` was changed to get there, the answer is no until you understand exactly why.
