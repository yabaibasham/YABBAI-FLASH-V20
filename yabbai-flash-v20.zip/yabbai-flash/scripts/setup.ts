/**
 * One-time setup: turns a password you choose into the two secrets the server
 * needs. Run it on your own computer:
 *
 *     npm run setup              prints the values to copy into your host
 *     npm run setup -- --write   also saves them into ./.env for local use
 *
 * The password itself is never stored anywhere — only a scrypt hash of it.
 */
import { randomBytes } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';
import QRCode from 'qrcode';
import { base32Encode, hashPassword, matchTotp } from '../server/auth.ts';
import { passwordIsWeak } from '../server/config.ts';

const args = new Set(process.argv.slice(2));
const WRITE = args.has('--write');
const NO_TOTP = args.has('--no-totp');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

/** Read one line. Hides what is typed when attached to a real terminal. */
function ask(question: string, hidden = false): Promise<string> {
  const stdin = process.stdin;
  if (!hidden || !stdin.isTTY) {
    const rl = readline.createInterface({ input: stdin, output: process.stdout, terminal: false });
    process.stdout.write(question);
    return new Promise(resolve => {
      rl.once('line', line => {
        resolve(line); // before close(): closing fires the handler below straight away
        rl.close();
      });
      rl.once('close', () => resolve(''));
    });
  }
  return new Promise((resolve, reject) => {
    process.stdout.write(question);
    let value = '';
    stdin.setRawMode(true);
    stdin.resume();
    stdin.setEncoding('utf8');
    const done = (err?: Error) => {
      stdin.setRawMode(false);
      stdin.pause();
      stdin.off('data', onData);
      process.stdout.write('\n');
      if (err) reject(err);
      else resolve(value);
    };
    const onData = (chunk: string) => {
      for (const ch of chunk) {
        if (ch === '\r' || ch === '\n') return done();
        if (ch === '\u0003') return done(new Error('Cancelled.'));
        if (ch === '\u007f' || ch === '\b') value = value.slice(0, -1);
        else if (ch >= ' ') value += ch;
      }
    };
    stdin.on('data', onData);
  });
}

function upsertEnv(file: string, values: Record<string, string>): void {
  const lines = fs.existsSync(file) ? fs.readFileSync(file, 'utf8').split(/\r?\n/) : [];
  for (const [key, value] of Object.entries(values)) {
    const at = lines.findIndex(l => l.startsWith(`${key}=`));
    if (at >= 0) lines[at] = `${key}=${value}`;
    else lines.push(`${key}=${value}`);
  }
  // A plain-text password must not sit next to its hash.
  const cleaned = lines.filter(l => !l.startsWith('DIRECTOR_PASSWORD='));
  fs.writeFileSync(file, `${cleaned.join('\n').replace(/\n+$/, '')}\n`, { mode: 0o600 });
  fs.chmodSync(file, 0o600);
}

async function main(): Promise<void> {
  console.log('\nYABBAI FLASH setup\n');
  console.log('Choose the director password. At least 12 characters; a few random words works well.');
  console.log('It is not shown as you type and is never saved — only a hash of it is.\n');

  let password = '';
  for (;;) {
    password = await ask('Password: ', true);
    const weak = passwordIsWeak(password);
    if (weak) {
      console.log(`  That password ${weak}. Try another.\n`);
      if (!process.stdin.isTTY) process.exit(1);
      continue;
    }
    if (process.stdin.isTTY) {
      const again = await ask('Type it again: ', true);
      if (again !== password) {
        console.log('  Those did not match. Start over.\n');
        continue;
      }
    }
    break;
  }

  const values: Record<string, string> = { DIRECTOR_PASSWORD_HASH: await hashPassword(password) };

  if (!NO_TOTP) {
    const secret = base32Encode(randomBytes(20));
    const label = encodeURIComponent('YABBAI FLASH:director');
    const uri = `otpauth://totp/${label}?secret=${secret}&issuer=${encodeURIComponent('YABBAI FLASH')}&algorithm=SHA1&digits=6&period=30`;
    console.log('\nTwo-factor sign-in');
    console.log('Scan this with an authenticator app (Google Authenticator, Authy, 1Password, Aegis):\n');
    console.log(await QRCode.toString(uri, { type: 'terminal', small: true }));
    console.log(`Cannot scan? Enter this key by hand: ${secret.replace(/(.{4})/g, '$1 ').trim()}\n`);

    if (process.stdin.isTTY) {
      for (let tries = 0; tries < 3; tries++) {
        const code = (await ask('Enter the 6-digit code the app shows now: ')).replace(/\s+/g, '');
        if (matchTotp(secret, code) !== null) {
          console.log('  Code accepted — the authenticator is set up correctly.');
          break;
        }
        console.log(tries < 2 ? '  That code is not right. Wait for the next one and try again.' : '  Still not matching. Check the clock on this computer and on your phone, then run setup again.');
        if (tries === 2) process.exit(1);
      }
    }
    values.TOTP_SECRET = secret;
  }

  console.log('\nAdd these to your hosting environment (Render → your service → Environment):\n');
  for (const [k, v] of Object.entries(values)) console.log(`${k}=${v}`);
  console.log('\nTreat both like passwords. Anyone holding the TOTP_SECRET can produce your sign-in codes.');

  if (WRITE) {
    const file = path.join(root, '.env');
    upsertEnv(file, values);
    console.log(`\nSaved to ${file} (readable only by you). That file is ignored by git — keep it that way.`);
  } else {
    console.log('\nNothing was written to disk. Run `npm run setup -- --write` to also save them to ./.env for running locally.');
  }
  if (NO_TOTP) console.log('\nYou skipped two-factor sign-in. The password is now the only thing protecting the console.');
  console.log('');
}

main().catch(err => {
  console.error(`\n${err instanceof Error ? err.message : String(err)}`);
  process.exit(1);
});
