/**
 * YABBAI FLASH — server entry point.
 *
 * One Express app serves three things:
 *   /api/webhooks/stripe   signed events from Stripe
 *   /api/public/*          what customers' browsers may call (pay pages)
 *   /api/console/*         the director console, behind login
 *                          (including the council and the linked apps)
 * and the built React app for everything else.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import { createAiService } from './server/ai.ts';
import { authRouter, requireAuth } from './server/auth.ts';
import { createAutopilot } from './server/autopilot.ts';
import { loadConfig } from './server/config.ts';
import type { Config } from './server/config.ts';
import { createCouncil } from './server/council.ts';
import { buildHealth, buildOverview, consoleRouter } from './server/consoleRoutes.ts';
import { resolveBaseUrl } from './server/context.ts';
import type { Ctx } from './server/context.ts';
import { openDb } from './server/db.ts';
import type { Db } from './server/db.ts';
import { createFxService } from './server/fx.ts';
import { createMarketsService } from './server/markets.ts';
import { createNetworkService } from './server/network.ts';
import { publicRouter } from './server/publicRoutes.ts';
import { CLIENT_IP_HEADER_SETTING, RateLimiter, limit, requireJson, requireSameOrigin, securityHeaders } from './server/security.ts';
import { createSolanaService } from './server/solana.ts';
import { createStripeService } from './server/stripe.ts';
import { HttpError } from './server/util.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface AppOptions {
  env?: Record<string, string | undefined>;
  fetchImpl?: typeof fetch;
  /** Serve the built frontend / Vite dev server. Tests turn this off. */
  serveFrontend?: boolean;
}

export interface BuiltApp {
  app: express.Express;
  ctx: Ctx;
  config: Config;
  db: Db;
  close(): Promise<void>;
}

export async function createApp(options: AppOptions = {}): Promise<BuiltApp> {
  const config = loadConfig(options.env ?? process.env);
  const fetchImpl = options.fetchImpl ?? fetch;
  const db = await openDb(config);

  const fx = createFxService(fetchImpl);
  const stripe = createStripeService(db, config);
  const solana = createSolanaService(db, config, fx, fetchImpl);
  await solana.init();
  const ai = createAiService(db, config, fetchImpl);
  const markets = createMarketsService(fetchImpl);
  const baseUrl = (req?: Request) => resolveBaseUrl(config, req);
  const network = createNetworkService(db, fetchImpl);
  // The council reads the same records the console shows — through these doors only.
  // Each is called when a session runs, by which time `ctx` and `autopilot` exist.
  let ctx!: Ctx;
  const council = createCouncil({
    db,
    config,
    ai,
    sources: {
      db,
      config,
      overview: () => buildOverview(ctx),
      health: () => buildHealth(ctx),
      wallet: () => solana.walletStatus().catch(() => null),
      cryptoRail: () => solana.railState(),
      markets: () => markets.snapshot(),
      autopilot: () => ({ on: autopilot.isOn(), jobs: autopilot.jobs() }),
      aiLabel: () => ai.providerLabel(),
      links: () => network.list(),
      auditBroken: () => autopilot.auditBroken(),
    },
  });
  const autopilot = createAutopilot({ db, config, stripe, solana, ai, network, council, baseUrl: () => baseUrl() });
  ctx = { db, config, stripe, solana, fx, ai, markets, autopilot, network, council, baseUrl };

  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', config.trustProxy);
  app.set(CLIENT_IP_HEADER_SETTING, config.clientIpHeader);
  app.use(securityHeaders(config));

  // Liveness probe for the hosting platform. Says nothing about the business.
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  // Stripe needs the exact bytes it signed, so this route gets the raw body
  // and must be registered before any JSON parser.
  const webhookLimiter = new RateLimiter(60_000, 600);
  app.post('/api/webhooks/stripe', limit(webhookLimiter, 'wh'), express.raw({ type: () => true, limit: '1mb' }), async (req, res) => {
    const out = await stripe.handleWebhook(req.body as Buffer, req.get('stripe-signature'));
    res.status(out.status).json(out.body);
  });

  app.use('/api/public', publicRouter(ctx));
  app.use('/api/auth', requireSameOrigin(config), requireJson, express.json({ limit: '10kb' }), authRouter(db, config));
  app.use('/api/console', requireSameOrigin(config), requireAuth(db, config), requireJson, consoleRouter(ctx));

  app.use('/api', (_req, _res, next) => {
    next(new HttpError(404, 'NOT_FOUND', 'API endpoint not found.'));
  });

  app.get('/robots.txt', (_req, res) => {
    res.type('text/plain').send('User-agent: *\nDisallow: /api/\nDisallow: /pay/\nDisallow: /order/\n');
  });

  if (options.serveFrontend !== false) {
    if (!config.isProd) {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true', watch: process.env.DISABLE_HMR === 'true' ? null : {} },
        appType: 'spa',
      });
      app.use(vite.middlewares);
    } else {
      const distDir = path.resolve(__dirname, 'dist');
      const indexFile = path.join(distDir, 'index.html');
      app.use(
        express.static(distDir, {
          index: false,
          setHeaders(res, filePath) {
            // Hashed build assets never change; everything else is revalidated.
            if (filePath.includes(`${path.sep}assets${path.sep}`)) res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
            else res.setHeader('Cache-Control', 'no-cache');
          },
        })
      );
      app.use((req, res, next) => {
        if (req.method !== 'GET' && req.method !== 'HEAD') return next();
        if (!fs.existsSync(indexFile)) return next(new HttpError(503, 'NOT_BUILT', 'The frontend has not been built. Run `npm run build`.'));
        // Pay and order pages carry secret tokens: keep them out of search engines and caches.
        res.setHeader('X-Robots-Tag', 'noindex, nofollow');
        res.setHeader('Cache-Control', 'no-store');
        res.sendFile(indexFile);
      });
    }
  }

  // Errors: say what the caller can act on, never internals.
  app.use((err: any, req: Request, res: Response, _next: NextFunction) => {
    if (res.headersSent) return;
    let status = 500;
    let code = 'INTERNAL';
    let message = 'Something went wrong on the server.';
    if (err instanceof HttpError) {
      status = err.status;
      code = err.code;
      message = err.message;
    } else if (err?.type === 'entity.too.large') {
      status = 413;
      code = 'TOO_LARGE';
      message = 'That request is too large.';
    } else if (err?.type === 'entity.parse.failed' || err instanceof SyntaxError) {
      status = 400;
      code = 'BAD_JSON';
      message = 'The request body is not valid JSON.';
    } else {
      console.error(`[error] ${req.method} ${req.path}:`, err instanceof Error ? (err.stack ?? err.message) : err);
    }
    if (req.path.startsWith('/api/')) res.status(status).json({ error: message, code });
    else res.status(status).type('text/plain').send(message);
  });

  return {
    app,
    ctx,
    config,
    db,
    async close() {
      autopilot.stop();
      // Let a council session that is mid-answer finish writing, but never hang a shutdown on it.
      await Promise.race([council.settled(), new Promise<void>(resolve => setTimeout(resolve, 5000).unref())]);
      await db.close();
    },
  };
}

function loadEnvFiles(): void {
  for (const name of ['.env', '.env.local']) {
    const file = path.resolve(__dirname, name);
    if (fs.existsSync(file)) {
      try {
        process.loadEnvFile(file); // does not override variables that are already set
      } catch (err) {
        console.error(`[boot] could not read ${name}:`, err instanceof Error ? err.message : err);
      }
    }
  }
}

async function main(): Promise<void> {
  loadEnvFiles();
  const built = await createApp();
  const { app, config, ctx } = built;

  console.log(`[boot] YABBAI FLASH · mode=${config.mode.toUpperCase()} · db=${built.db.kind} · stripe=${config.stripe.keyMode} · solana=${config.solana.receiveAddress ? config.solana.cluster : 'off'} · ai=${config.ai.provider}`);
  for (const p of config.problems) console.log(`[boot] ${p.level === 'error' ? 'ERROR' : 'warn '} ${p.code}: ${p.message}`);

  ctx.autopilot.start();
  const server = app.listen(config.port, '0.0.0.0', () => {
    console.log(`[boot] listening on http://0.0.0.0:${config.port}`);
  });

  const shutdown = (signal: string) => {
    console.log(`[boot] ${signal} received, shutting down`);
    server.close(() => {
      void built.close().finally(() => process.exit(0));
    });
    setTimeout(() => process.exit(0), 8000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

const isDirectRun = !!process.argv[1] && path.resolve(process.argv[1]) === path.resolve(__filename);
if (isDirectRun) {
  main().catch(err => {
    console.error('[boot] failed to start:', err);
    process.exit(1);
  });
}
