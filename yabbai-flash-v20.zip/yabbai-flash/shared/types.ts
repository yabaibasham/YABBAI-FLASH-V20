/**
 * Types shared by the server and the browser.
 *
 * Money is always integer cents (AUD). Nothing here is a balance the browser
 * can write: every figure is computed by the server from verified records.
 */

export type Mode = 'live' | 'test';

export type Rail = 'stripe' | 'solana' | 'attested';
export type CryptoAsset = 'SOL' | 'USDC';

export interface InvoiceItem {
  desc: string;
  qty: number;
  unitCents: number;
}

/** Stored state. "paid", "part" and "overdue" are never stored — they are derived. */
export type InvoiceStoredStatus = 'draft' | 'open' | 'void';
export type InvoiceStatus = 'draft' | 'open' | 'part' | 'paid' | 'overdue' | 'void';

export interface Invoice {
  id: string;
  number: string;
  token: string;
  clientName: string;
  clientEmail: string | null;
  items: InvoiceItem[];
  subtotalCents: number;
  taxCents: number;
  discountCents: number;
  totalCents: number;
  note: string | null;
  dueDate: string; // YYYY-MM-DD
  storedStatus: InvoiceStoredStatus;
  status: InvoiceStatus;
  paidCents: number;
  verifiedPaidCents: number;
  attestedPaidCents: number;
  outstandingCents: number;
  livemode: boolean;
  leadId: string | null;
  createdAt: number;
  updatedAt: number;
  openedAt: number | null;
}

export interface Payment {
  id: string;
  proofId: string;
  rail: Rail;
  kind: 'invoice' | 'order';
  invoiceId: string | null;
  orderId: string | null;
  amountCents: number;
  refundedCents: number;
  /** true only when Stripe or the chain itself proved it. */
  verified: boolean;
  disputed: boolean;
  livemode: boolean;
  payer: string | null;
  detail: Record<string, unknown>;
  occurredAt: number;
  createdAt: number;
  /** Convenience for the UI. */
  label?: string;
  proofUrl?: string | null;
}

export type ProductStatus = 'draft' | 'listed' | 'archived';

export interface Product {
  id: string;
  slug: string;
  title: string;
  description: string;
  priceCents: number;
  status: ProductStatus;
  ships: string[];
  doesNotShip: string[];
  hasDeliverable: boolean;
  deliverableKind: 'link' | 'text' | null;
  /** Only ever sent to the signed-in director. */
  deliverableValue?: string | null;
  livemode: boolean;
  soldCount: number;
  revenueCents: number;
  createdAt: number;
  updatedAt: number;
}

export type OrderStatus = 'pending' | 'paid' | 'refunded' | 'expired';

export interface Order {
  id: string;
  token: string;
  productId: string;
  productTitle: string;
  priceCents: number;
  customerEmail: string | null;
  status: OrderStatus;
  livemode: boolean;
  createdAt: number;
  paidAt: number | null;
  deliveredAt: number | null;
}

export type LeadStage = 'new' | 'qualified' | 'contacted' | 'replied' | 'proposal' | 'won' | 'lost';

export interface Lead {
  id: string;
  name: string;
  company: string | null;
  email: string | null;
  phone: string | null;
  sector: string | null;
  message: string | null;
  source: 'manual' | 'intake' | 'import';
  stage: LeadStage;
  score: number | null;
  scoreRationale: string | null;
  createdAt: number;
  updatedAt: number;
}

export type DraftType = 'outreach' | 'followup' | 'product_spec' | 'brief';

export interface Draft {
  id: string;
  type: DraftType;
  title: string;
  body: string;
  refKind: 'lead' | 'invoice' | 'product' | null;
  refId: string | null;
  status: 'pending' | 'used' | 'dismissed';
  source: 'ai' | 'director';
  createdAt: number;
  decidedAt: number | null;
}

export interface AuditEntry {
  seq: number;
  at: number;
  actor: string;
  action: string;
  detail: Record<string, unknown>;
  hash: string;
  prevHash: string;
}

export interface HealthCheck {
  id: string;
  label: string;
  state: 'ok' | 'warn' | 'error' | 'off';
  detail: string;
  fix?: string;
}

export interface RailState {
  enabled: boolean;
  reason: string | null;
}

export interface AllocationRow {
  key: string;
  label: string;
  pct: number;
  cents: number;
}

export interface StripeStatus {
  configured: boolean;
  mode: Mode | 'off';
  reachable: boolean;
  error: string | null;
  chargesEnabled: boolean | null;
  payoutsEnabled: boolean | null;
  detailsSubmitted: boolean | null;
  requirementsDue: string[];
  disabledReason: string | null;
  payoutDestination: string | null;
  payoutSchedule: string | null;
  availableCents: number | null;
  pendingCents: number | null;
  payouts: Array<{
    id: string;
    amountCents: number;
    status: string;
    arrivalDate: number;
    method: string;
    failureMessage: string | null;
  }>;
  fetchedAt: number;
}

export interface WalletStatus {
  configured: boolean;
  address: string | null;
  cluster: string;
  addressValid: boolean;
  proven: boolean;
  proofMethod: 'signature' | 'onchain' | 'override' | null;
  provenAt: number | null;
  sol: number | null;
  usdc: number | null;
  audValueCents: number | null;
  error: string | null;
  explorerUrl: string | null;
  fetchedAt: number;
}

export interface Overview {
  mode: Mode;
  brandName: string;
  generatedAt: number;
  totals: {
    verifiedAllTimeCents: number;
    verified30dCents: number;
    verified7dCents: number;
    attestedAllTimeCents: number;
    refundedAllTimeCents: number;
    receivableCents: number;
    openInvoices: number;
    overdueInvoices: number;
    paymentsCount: number;
    ordersPaid: number;
  };
  byRail: Array<{ rail: Rail; cents: number; count: number }>;
  daily: Array<{ day: string; verifiedCents: number; attestedCents: number }>;
  allocation: AllocationRow[];
  recentPayments: Payment[];
  attention: Array<{ level: 'error' | 'warn' | 'info'; text: string; tab?: string }>;
  rails: { stripe: RailState; solana: RailState; bank: RailState };
  counts: { leadsNew: number; draftsPending: number };
}

export interface PublicInvoiceView {
  brandName: string;
  mode: Mode;
  number: string;
  clientName: string;
  items: InvoiceItem[];
  subtotalCents: number;
  taxCents: number;
  discountCents: number;
  totalCents: number;
  paidCents: number;
  outstandingCents: number;
  status: InvoiceStatus;
  dueDate: string;
  /** When the invoice was issued (ms). */
  issuedAt: number | null;
  note: string | null;
  gstRegistered: boolean;
  abn: string | null;
  supportEmail: string | null;
  rails: {
    card: boolean;
    sol: boolean;
    usdc: boolean;
    bank: null | { payId: string | null; bsb: string | null; accountNumber: string | null; accountName: string | null; reference: string };
  };
}

export interface PublicQuote {
  asset: CryptoAsset;
  recipient: string;
  amount: string; // decimal string in whole units
  reference: string;
  url: string; // solana: pay URL
  audCents: number;
  audPerUnit: number;
  expiresAt: number;
  cluster: string;
}

export interface PublicProductView {
  brandName: string;
  mode: Mode;
  slug: string;
  title: string;
  description: string;
  priceCents: number;
  ships: string[];
  doesNotShip: string[];
  available: boolean;
  rails: { card: boolean; sol: boolean; usdc: boolean };
  supportEmail: string | null;
  gstRegistered: boolean;
}

export interface PublicOrderView {
  brandName: string;
  mode: Mode;
  productTitle: string;
  /** Lets a buyer with an unpaid order get a fresh payment code. Null once the product is off sale. */
  productSlug: string | null;
  /** Which ways to pay are on right now. All false once the order is settled. */
  rails: { card: boolean; sol: boolean; usdc: boolean };
  priceCents: number;
  status: OrderStatus;
  deliverable: null | { kind: 'link' | 'text'; value: string };
  supportEmail: string | null;
}

export interface MarketRow {
  symbol: string;
  venues: Array<{ venue: string; bid: number; ask: number }>;
  bestBuy: { venue: string; ask: number } | null;
  bestSell: { venue: string; bid: number } | null;
  grossBps: number | null;
  netBps: number | null;
}

export interface AuthState {
  configured: boolean;
  authenticated: boolean;
  totpRequired: boolean;
  stepUpUntil: number | null;
  expiresAt: number | null;
  problems: string[];
}

// ── the core: linked apps, the council and its notes ───────────────────────
// None of these carries money. A link has no figure; a session is text.

export type LinkKind = 'app' | 'site' | 'dashboard' | 'artifact' | 'doc' | 'repo' | 'tool';

/**
 * What the sentinel last saw. "up" means the server answered, not that the
 * app behind it works or that any number on it is true.
 */
export type LinkState = 'up' | 'error' | 'down' | 'unknown' | 'off';

export interface NetworkLink {
  id: string;
  name: string;
  url: string;
  host: string;
  realm: string;
  kind: LinkKind;
  note: string | null;
  watch: boolean;
  /** False when the sentinel will not knock on this address: not https, a bare IP, or a private name. */
  watchable: boolean;
  lastStatus: number | null;
  lastError: string | null;
  lastCheckedAt: number | null;
  state: LinkState;
  createdAt: number;
  updatedAt: number;
}

export type SeatId = 'treasurer' | 'pipeline' | 'storekeeper' | 'watcher' | 'engineer' | 'guardian' | 'planner' | 'skeptic';

export interface SeatInfo {
  id: SeatId;
  name: string;
  /** The one angle this seat judges from. */
  lens: string;
  /** In plain words, the only records this seat is handed. */
  sees: string;
  /** The Skeptic sits at every session. */
  always: boolean;
  /** Sessions this seat has answered in. */
  sessions: number;
}

export interface SeatPick {
  seat: SeatId;
  reason: string;
}

export interface RoutePlan {
  picks: SeatPick[];
  pickedBy: 'router' | 'director';
  /** AI calls a session with these seats costs: one per seat, plus one for the verdict. */
  calls: number;
}

export type OpinionStatus = 'waiting' | 'thinking' | 'done' | 'failed';

export interface CouncilOpinion {
  seat: SeatId;
  position: number;
  reason: string;
  status: OpinionStatus;
  body: string | null;
  error: string | null;
  startedAt: number | null;
  finishedAt: number | null;
}

export type CouncilDecision = 'accepted' | 'rejected' | 'noted';

export interface CouncilSession {
  id: string;
  question: string;
  pickedBy: 'router' | 'director';
  status: 'running' | 'done' | 'failed';
  verdict: string | null;
  error: string | null;
  decision: CouncilDecision | null;
  decisionNote: string | null;
  livemode: boolean;
  seats: SeatId[];
  createdAt: number;
  finishedAt: number | null;
  decidedAt: number | null;
}

export interface Lesson {
  id: string;
  text: string;
  seat: SeatId | 'all';
  source: 'director' | 'council';
  sessionId: string | null;
  status: 'proposed' | 'active' | 'retired' | 'dismissed';
  createdAt: number;
  decidedAt: number | null;
}
