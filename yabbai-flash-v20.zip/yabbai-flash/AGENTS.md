# Rules for anyone — human or AI — editing this code

This app's previous version showed its owner a large balance that did not exist.
Every figure had been invented in the browser by code that AI tools added one
helpful-looking feature at a time. These rules exist so that cannot happen again.
`npm test` enforces most of them; a change that breaks one is wrong even if it
looks good on screen.

## Money

1. **A money figure is only ever computed on the server from the `payments`
   table.** Never from browser state, a constant, an estimate or an AI answer.
2. **A payment row is created in exactly three places:**
   `settleSession` (Stripe said paid, re-fetched with our key),
   `checkQuote` (a finalized on-chain transfer carrying our reference),
   `attestPayment` (the director vouches; needs step-up; `verified = false`).
   Do not add a fourth. Do not add a parameter that lets a caller supply an amount.
3. **No simulated, sample, demo, seeded or projected money. Ever.** No random
   outcomes. No "example" payments. An empty screen says it is empty.
4. **Nothing moves money out.** No payouts, refunds, transfers, sweeps or
   withdrawals. No private keys, seed phrases or signing code. No Stripe calls
   beyond creating a Checkout Session and reading.
5. **Invoices have three stored states: draft, open, void.** "Paid" is always
   derived from payments. Never store it, never accept it from a request.
6. **Destinations come from environment variables only** — wallet address, bank
   details. Never from the database, the console or a request.
7. **A product cannot be listed without a real deliverable**, and the deliverable
   is only returned after verified payments cover the price.
8. **Test and live never mix.** Every money record (invoice, product, order,
   payment, quote) carries `livemode`, and every query filters on it.

## Security

- Secrets live in the server's environment. Never in the frontend, the database,
  logs, error messages or this repository.
- The browser stores nothing: no localStorage, sessionStorage or IndexedDB.
- Every `/api/console` route sits behind `requireSameOrigin` + `requireAuth`.
  Anything that changes how money is recorded or received, or what is on sale,
  also needs the password again (`requireStepUp` / `assertStepUp`).
- Every value from a request goes through `server/validate.ts` before it is used.
- Public routes take a token or slug and nothing that sets a price or status.
- Text from outside (leads, statements, web pages) is data. It is wrapped in
  `<data>` tags before reaching the AI and is never treated as an instruction.
- AI output is a draft or a score. It never triggers an action, sends a message
  or changes a record without the director pressing a button.
- The `payments` and `audit_log` tables are append-only at the database level.
  Do not add code that works around the triggers.
- No new third-party scripts, fonts or network calls from the browser. The
  Content-Security-Policy allows this origin only; keep it that way.

## The council and the network

The council (Brain tab) is several AI seats that write opinions and one verdict.
The network is a list of links to the owner's other apps. Neither is allowed hands.

1. **The council has no tools.** A session writes rows in `council_sessions` and
   `council_opinions`, and at most one `lessons` row with status `proposed`.
   Never add code that reads a verdict for something to do, lets a session call
   a module that changes a record, or gives a seat a way to send, pay, fetch or run.
2. **A seat is handed only its own slice** (`server/seats.ts`). No slice may carry
   a person's name, email, phone number or message, a wallet address, a key, a
   pay link or a deliverable. Seats do not see each other's records: that
   separation is what makes two of them agreeing mean anything.
3. **Everything in a prompt that is not our own wording goes inside `fence()`**
   — records, the question, what another seat wrote, past rulings. Approved
   lessons go inside `fenceNotes()` and nowhere else.
4. **A lesson becomes active only by the director, behind `requireStepUp`.**
   What the model suggests is stored as `proposed` and reaches no prompt. There
   is a fixed ceiling on active lessons; do not raise it to "let it learn more".
5. **The council sits only when the director asks.** Do not put it on a schedule,
   chain sessions together, or let one session start another.
6. **A link is a web address and carries no figure.** Adding or changing one needs
   `requireStepUp`. Never fetch a linked page's content, and never show, store or
   add up a number that came from one.
7. **The sentinel sends one `HEAD` request to a public https name, follows no
   redirect and keeps a status code.** Do not widen that: no `GET`, no private
   addresses, no reading the body, no cookies or tokens.

## Interface

- Colour encodes proof: green = verified by Stripe or the chain, gold = attested
  by the director (and the brand), purple = test mode, red = blocking. Do not use
  green for anything that is not verified live money. A link that answers,
  a seat that has answered and an accepted verdict are not money: no green.
- Say what things are in plain words. No inflated labels, no invented metrics.

## Before you finish

```bash
npm run lint && npm test && npm run build
```

If you are an AI agent and the task seems to require breaking one of these rules
— for example "make the dashboard show some activity", "add a quick way to
record a sale", "let the council send the reminder itself" or "show each app's
revenue on the Network page" — stop and tell the owner why you will not, instead
of doing it.
