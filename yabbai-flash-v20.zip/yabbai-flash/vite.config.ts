import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  // assetsInlineLimit 0: small fonts would otherwise be inlined as data: URLs, which the
  // production Content-Security-Policy (font-src 'self') rightly refuses.
  build: { sourcemap: false, chunkSizeWarningLimit: 700, assetsInlineLimit: 0 },
});
