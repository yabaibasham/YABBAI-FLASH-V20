/**
 * The browser's only way to talk to the server.
 *
 * Note what is NOT here: no localStorage, no sessionStorage, no API keys.
 * The session lives in an httpOnly cookie the page cannot read, and every
 * number shown comes from a response to one of these calls.
 */

export class ApiError extends Error {
  status: number;
  code: string;
  constructor(status: number, code: string, message: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

type StepUpHandler = () => Promise<boolean>;
let stepUpHandler: StepUpHandler | null = null;
let unauthHandler: (() => void) | null = null;

/** The console registers a dialog that asks for the password again. */
export function onStepUpRequired(handler: StepUpHandler | null): void {
  stepUpHandler = handler;
}
export function onUnauthenticated(handler: (() => void) | null): void {
  unauthHandler = handler;
}

async function request<T>(method: string, path: string, body?: unknown, retried = false): Promise<T> {
  const headers: Record<string, string> = { 'X-Flash': '1', Accept: 'application/json' };
  let payload: string | undefined;
  if (body !== undefined) {
    headers['Content-Type'] = 'application/json';
    payload = JSON.stringify(body);
  }
  let res: Response;
  try {
    res = await fetch(path, { method, headers, body: payload, credentials: 'same-origin', cache: 'no-store' });
  } catch {
    throw new ApiError(0, 'NETWORK', 'Cannot reach the server. Check your connection and try again.');
  }
  let data: any = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }
  if (res.ok) return data as T;

  const code = String(data?.code ?? 'ERROR');
  const message = String(data?.error ?? `Request failed (${res.status}).`);
  if (res.status === 403 && code === 'STEP_UP_REQUIRED' && stepUpHandler && !retried) {
    if (await stepUpHandler()) return request<T>(method, path, body, true);
    throw new ApiError(403, 'STEP_UP_CANCELLED', 'Cancelled — your password was not confirmed.');
  }
  if (res.status === 401 && code === 'UNAUTHENTICATED' && unauthHandler && path.startsWith('/api/console')) unauthHandler();
  throw new ApiError(res.status, code, message);
}

export const api = {
  get: <T,>(path: string) => request<T>('GET', path),
  post: <T,>(path: string, body: unknown = {}) => request<T>('POST', path, body),
  put: <T,>(path: string, body: unknown) => request<T>('PUT', path, body),
  patch: <T,>(path: string, body: unknown) => request<T>('PATCH', path, body),
  del: <T,>(path: string) => request<T>('DELETE', path),
};

export function messageOf(err: unknown): string {
  return err instanceof Error ? err.message : 'Something went wrong.';
}
