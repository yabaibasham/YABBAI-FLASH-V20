import '@fontsource-variable/space-grotesk';
import '@fontsource-variable/jetbrains-mono';
import './index.css';
import { StrictMode, Suspense, lazy } from 'react';
import { createRoot } from 'react-dom/client';

// Customers only download the pay pages; the console is a separate chunk.
const ConsoleApp = lazy(() => import('./console/ConsoleApp.tsx'));
const PublicApp = lazy(() => import('./public/PublicApp.tsx'));

const path = window.location.pathname;
const isPublic = /^\/(pay|p|order|intake)(\/|$)/.test(path);
if (isPublic) document.body.classList.add('public');

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Suspense fallback={null}>{isPublic ? <PublicApp path={path} /> : <ConsoleApp />}</Suspense>
  </StrictMode>
);
