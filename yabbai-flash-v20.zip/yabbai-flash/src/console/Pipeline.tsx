import { useState } from 'react';
import { Mail, Plus, Sparkles } from 'lucide-react';
import { api } from '../lib/api.ts';
import { ago } from '../lib/format.ts';
import type { Draft, Invoice, Lead, LeadStage } from '../../shared/types.ts';
import { Button, CopyButton, Dialog, Empty, Field, Input, Loading, Notice, Section, Select, Table, Textarea, cx, useAction, useLoad } from './ui.tsx';

const STAGE_WORD: Record<LeadStage, string> = {
  new: 'New',
  qualified: 'Qualified',
  contacted: 'Contacted',
  replied: 'Replied',
  proposal: 'Proposal sent',
  won: 'Won',
  lost: 'Lost',
};
const SOURCE_WORD = { manual: 'Added by you', intake: 'Enquiry form', import: 'Imported' } as const;
const DRAFT_WORD = { outreach: 'First contact', followup: 'Payment reminder', product_spec: 'Product scope', brief: 'Brief' } as const;

export function Pipeline() {
  const leads = useLoad(() => api.get<{ leads: Lead[]; stages: LeadStage[] }>('/api/console/leads'), [], 30_000);
  const drafts = useLoad(() => api.get<{ drafts: Draft[] }>('/api/console/drafts'), [], 30_000);
  const invoices = useLoad(() => api.get<{ invoices: Invoice[] }>('/api/console/invoices'), []);
  const site = useLoad(() => api.get<{ pinned: { publicBaseUrl: string } }>('/api/console/settings'), []);
  const [adding, setAdding] = useState(false);
  const [viewing, setViewing] = useState<Lead | null>(null);
  const [showDone, setShowDone] = useState(false);
  const act = useAction();

  if (!leads.data) return <Loading error={leads.error} onRetry={() => void leads.reload()} />;
  const all = leads.data.leads;
  const stages = leads.data.stages;
  const intake = `${site.data?.pinned.publicBaseUrl ?? window.location.origin}/intake`;
  const pending = (drafts.data?.drafts ?? []).filter(d => d.status === 'pending');
  const decided = (drafts.data?.drafts ?? []).filter(d => d.status !== 'pending');

  const emailFor = (d: Draft): string | null => {
    if (d.refKind === 'lead') return all.find(l => l.id === d.refId)?.email ?? null;
    if (d.refKind === 'invoice') return invoices.data?.invoices.find(i => i.id === d.refId)?.clientEmail ?? null;
    return null;
  };

  const decide = (d: Draft, status: 'used' | 'dismissed') =>
    void act.run(async () => {
      await api.post(`/api/console/drafts/${d.id}/decide`, { status });
      await Promise.all([drafts.reload(true), leads.reload(true)]);
    });

  return (
    <>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Pipeline</h1>
          <p className="mt-1 max-w-2xl text-sm text-mute">
            Real people only. A lead exists here because someone filled in your enquiry form or you typed them in. The AI can score a lead and draft an email, but it never sends anything and
            never invents a contact.
          </p>
        </div>
        <Button variant="primary" onClick={() => setAdding(true)}>
          <Plus className="h-4 w-4" aria-hidden /> Add a lead
        </Button>
      </div>

      <div className="flex flex-wrap items-center gap-2 text-sm">
        <span className="text-mute">Your enquiry form:</span>
        <code className="num min-w-0 truncate rounded border border-rule-strong bg-ink px-2 py-1 text-[13px]">{intake}</code>
        <CopyButton text={intake} label="Copy link" />
        <a href={intake} target="_blank" rel="noreferrer noopener" className="text-mute underline hover:text-bone">
          Open
        </a>
      </div>
      {act.error && <Notice tone="error">{act.error}</Notice>}

      <Section title="Drafts waiting for you" aside={<span>{pending.length} pending</span>}>
        {!drafts.data ? (
          <Loading error={drafts.error} onRetry={() => void drafts.reload()} />
        ) : pending.length === 0 ? (
          <p className="text-sm text-dim">Nothing waiting. Drafts appear when you ask for an outreach email or a payment reminder, or when autopilot writes one for an overdue invoice.</p>
        ) : (
          <ul className="space-y-4">
            {pending.map(d => {
              const to = emailFor(d);
              return (
                <li key={d.id} className="rounded-md border border-rule-strong bg-panel p-4">
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <p className="font-medium">{d.title}</p>
                    <p className="text-[13px] text-dim">
                      {DRAFT_WORD[d.type]} · {d.source === 'ai' ? 'written by AI' : 'written by you'} · {ago(d.createdAt)}
                    </p>
                  </div>
                  <pre className="mt-2 max-h-64 overflow-y-auto font-sans text-sm whitespace-pre-wrap text-bone">{d.body}</pre>
                  <div className="mt-3 flex flex-wrap items-center gap-2">
                    <CopyButton text={d.body} label="Copy text" />
                    {to && (
                      <a
                        href={`mailto:${encodeURIComponent(to).replace('%40', '@')}?subject=${encodeURIComponent(d.title.replace(/^[^:]+:\s*/, ''))}&body=${encodeURIComponent(d.body)}`}
                        className="inline-flex items-center gap-1.5 rounded-md border border-rule-strong px-2.5 py-1 text-[13px] hover:border-mute"
                      >
                        <Mail className="h-3.5 w-3.5" aria-hidden /> Open in your email app
                      </a>
                    )}
                    <span className="flex-1" />
                    <Button small busy={act.busy} onClick={() => decide(d, 'used')}>
                      I sent it
                    </Button>
                    <Button small variant="ghost" busy={act.busy} onClick={() => decide(d, 'dismissed')}>
                      Discard
                    </Button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
        {decided.length > 0 && (
          <div className="mt-4">
            <button className="text-sm text-mute underline" onClick={() => setShowDone(v => !v)}>
              {showDone ? 'Hide' : 'Show'} {decided.length} earlier draft{decided.length === 1 ? '' : 's'}
            </button>
            {showDone && (
              <ul className="mt-2 space-y-1 text-sm text-mute">
                {decided.slice(0, 40).map(d => (
                  <li key={d.id} className="flex justify-between gap-4">
                    <span className="truncate">{d.title}</span>
                    <span className="shrink-0 text-dim">{d.status === 'used' ? 'sent by you' : 'discarded'}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </Section>

      <Section title="Leads" aside={<span>{all.length} total</span>}>
        {all.length === 0 ? (
          <Empty title="No leads yet" action={<CopyButton text={intake} label="Copy the enquiry form link" small={false} />}>
            Put the enquiry form link on your site, your socials and in your email signature. Every submission lands here, and autopilot scores it if the AI is switched on.
          </Empty>
        ) : (
          <Table head={['Who', 'Contact', 'Came from', <span className="block text-right">Fit</span>, 'Stage', '']}>
            {all.map(l => (
              <tr key={l.id}>
                <td className="max-w-[240px]">
                  <span className="block truncate font-medium">{l.name}</span>
                  {l.company && <span className="block truncate text-[13px] text-mute">{l.company}</span>}
                </td>
                <td className="max-w-[220px] text-[13px] text-mute">
                  <span className="block truncate">{l.email ?? '—'}</span>
                  {l.phone && <span className="num block truncate">{l.phone}</span>}
                </td>
                <td className="text-[13px] whitespace-nowrap text-mute">
                  {SOURCE_WORD[l.source]}
                  <span className="block text-dim">{ago(l.createdAt)}</span>
                </td>
                <td className="text-right">
                  {l.score === null ? <span className="text-dim">—</span> : <span className={cx('num', l.score >= 45 ? 'text-bone' : 'text-mute')}>{l.score}</span>}
                </td>
                <td>
                  <Select
                    aria-label={`Stage for ${l.name}`}
                    value={l.stage}
                    className="!w-auto !py-1 text-[13px]"
                    onChange={e =>
                      void act.run(async () => {
                        await api.patch(`/api/console/leads/${l.id}`, { stage: e.target.value });
                        await leads.reload(true);
                      })
                    }
                  >
                    {stages.map(s => (
                      <option key={s} value={s}>
                        {STAGE_WORD[s]}
                      </option>
                    ))}
                  </Select>
                </td>
                <td className="text-right whitespace-nowrap">
                  <Button small aria-label={`View ${l.name}`} onClick={() => setViewing(l)}>
                    View
                  </Button>
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Section>

      {adding && (
        <LeadForm
          onClose={() => setAdding(false)}
          onSaved={() => {
            setAdding(false);
            void leads.reload(true);
          }}
        />
      )}
      {viewing && (
        <LeadDetail
          lead={all.find(l => l.id === viewing.id) ?? viewing}
          onClose={() => setViewing(null)}
          onChanged={() => {
            void leads.reload(true);
            void drafts.reload(true);
          }}
          onDeleted={() => {
            setViewing(null);
            void leads.reload(true);
          }}
        />
      )}
    </>
  );
}

function LeadForm({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const [f, setF] = useState({ name: '', company: '', email: '', phone: '', sector: '', message: '' });
  const save = useAction();
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF(v => ({ ...v, [k]: e.target.value }));
  return (
    <Dialog title="Add a lead" onClose={onClose}>
      <form
        className="space-y-4"
        onSubmit={async e => {
          e.preventDefault();
          if (await save.run(() => api.post('/api/console/leads', f))) onSaved();
        }}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Name">
            <Input required maxLength={120} value={f.name} onChange={set('name')} />
          </Field>
          <Field label="Business">
            <Input maxLength={160} value={f.company} onChange={set('company')} />
          </Field>
          <Field label="Email">
            <Input type="email" maxLength={254} value={f.email} onChange={set('email')} />
          </Field>
          <Field label="Phone">
            <Input type="tel" maxLength={40} value={f.phone} onChange={set('phone')} />
          </Field>
        </div>
        <Field label="Industry">
          <Input maxLength={80} value={f.sector} onChange={set('sector')} />
        </Field>
        <Field label="What they need" hint="Their words if you have them. This is what the AI scores.">
          <Textarea maxLength={2000} value={f.message} onChange={set('message')} />
        </Field>
        {save.error && <Notice tone="error">{save.error}</Notice>}
        <div className="flex justify-end gap-2">
          <Button onClick={onClose}>Cancel</Button>
          <Button type="submit" variant="primary" busy={save.busy}>
            Add lead
          </Button>
        </div>
      </form>
    </Dialog>
  );
}

function LeadDetail({ lead, onClose, onChanged, onDeleted }: { lead: Lead; onClose: () => void; onChanged: () => void; onDeleted: () => void }) {
  const [offer, setOffer] = useState('');
  const [made, setMade] = useState<Draft | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const act = useAction();

  return (
    <Dialog title={lead.company ? `${lead.name} · ${lead.company}` : lead.name} onClose={onClose} wide>
      <div className="space-y-5">
        <dl className="grid gap-x-8 gap-y-2 text-sm sm:grid-cols-2">
          <Pair k="Email" v={lead.email} />
          <Pair k="Phone" v={lead.phone} mono />
          <Pair k="Industry" v={lead.sector} />
          <Pair k="Came from" v={SOURCE_WORD[lead.source]} />
        </dl>
        {lead.message ? (
          <div>
            <p className="mb-1 text-[13px] text-mute">What they wrote</p>
            <p className="rounded-md border border-rule-strong bg-ink p-3 text-sm whitespace-pre-wrap">{lead.message}</p>
          </div>
        ) : (
          <p className="text-sm text-dim">No message on file.</p>
        )}

        <div>
          <p className="mb-1 text-[13px] text-mute">Fit score</p>
          {lead.score === null ? (
            <p className="text-sm text-dim">Not scored yet.</p>
          ) : (
            <p className="text-sm">
              <span className="num mr-2 text-lg">{lead.score}/100</span>
              {lead.scoreRationale}
            </p>
          )}
          <Button
            small
            className="mt-2"
            busy={act.busy}
            onClick={() =>
              void act.run(async () => {
                await api.post(`/api/console/ai/leads/${lead.id}/qualify`);
                onChanged();
              })
            }
          >
            <Sparkles className="h-3.5 w-3.5" aria-hidden /> {lead.score === null ? 'Score with AI' : 'Score again'}
          </Button>
          <p className="mt-1 text-xs text-dim">An opinion based only on what is written above. It is not a prediction of revenue.</p>
        </div>

        <div className="border-t border-rule pt-4">
          <Field label="Draft a first email" hint="Optional: say what you would offer them. Leave blank to use your standard offer.">
            <Textarea maxLength={600} value={offer} onChange={e => setOffer(e.target.value)} className="min-h-16" />
          </Field>
          <Button
            small
            className="mt-2"
            busy={act.busy}
            onClick={() =>
              void act.run(async () => {
                const out = await api.post<{ draft: Draft }>(`/api/console/ai/leads/${lead.id}/outreach`, { offer });
                setMade(out.draft);
                onChanged();
              })
            }
          >
            <Sparkles className="h-3.5 w-3.5" aria-hidden /> Write the draft
          </Button>
          {made && (
            <div className="mt-3 rounded-md border border-rule-strong bg-ink p-3">
              <div className="mb-2 flex items-center justify-between gap-2">
                <p className="text-[13px] text-mute">Saved to your drafts. Not sent.</p>
                <CopyButton text={made.body} />
              </div>
              <pre className="font-sans text-sm whitespace-pre-wrap">{made.body}</pre>
            </div>
          )}
        </div>

        {act.error && <Notice tone="error">{act.error}</Notice>}
        <div className="flex flex-wrap justify-between gap-2 border-t border-rule pt-4">
          {confirmDelete ? (
            <div className="flex gap-2">
              <Button
                variant="danger"
                busy={act.busy}
                onClick={() =>
                  void act.run(async () => {
                    await api.del(`/api/console/leads/${lead.id}`);
                    onDeleted();
                  })
                }
              >
                Yes, delete this lead
              </Button>
              <Button onClick={() => setConfirmDelete(false)}>Keep</Button>
            </div>
          ) : (
            <Button variant="ghost" onClick={() => setConfirmDelete(true)}>
              Delete lead
            </Button>
          )}
          <Button onClick={onClose}>Done</Button>
        </div>
      </div>
    </Dialog>
  );
}

function Pair({ k, v, mono }: { k: string; v: string | null; mono?: boolean }) {
  return (
    <div className="flex justify-between gap-4 border-b border-rule/70 py-1">
      <dt className="text-mute">{k}</dt>
      <dd className={cx('truncate text-right', mono && 'num', !v && 'text-dim')}>{v ?? '—'}</dd>
    </div>
  );
}
