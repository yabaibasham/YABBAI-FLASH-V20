import { useEffect } from 'react';
import { ExternalLink } from 'lucide-react';
import { api } from '../lib/api.ts';
import { aud, dateTime } from '../lib/format.ts';
import type { Mode, Overview as OverviewData, StripeStatus, WalletStatus } from '../../shared/types.ts';
import type { TabId } from './tabs.ts';
import { Empty, Loading, Money, Notice, Proof, Section, Table, cx, useLoad } from './ui.tsx';

interface Props {
  go: (tab: TabId) => void;
  onMode: (mode: Mode) => void;
}

export function Overview({ go, onMode }: Props) {
  const ov = useLoad(() => api.get<OverviewData>('/api/console/overview'), [], 20_000);
  const mode = ov.data?.mode;
  useEffect(() => {
    if (mode) onMode(mode);
  }, [mode, onMode]);

  const st = useLoad(() => api.get<{ stripe: StripeStatus }>('/api/console/payouts'), [], 60_000);
  const wl = useLoad(() => api.get<{ wallet: WalletStatus }>('/api/console/wallet'), [], 60_000);

  if (!ov.data) return <Loading error={ov.error} onRetry={() => void ov.reload()} />;
  const o = ov.data;
  const t = o.totals;
  const blocking = o.attention.filter(a => a.level === 'error');
  const others = o.attention.filter(a => a.level !== 'error');
  const nothingYet = t.verifiedAllTimeCents === 0;
  const test = o.mode === 'test';
  const quiet = o.daily.every(d => d.verifiedCents + d.attestedCents === 0);

  return (
    <>
      {/* The figure that matters, and exactly what it means. */}
      <section className="grid gap-8 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
        <div>
          <h1 className="text-sm text-mute">{test ? 'Verified test payments' : 'Verified income'}</h1>
          <p className={cx('num mt-1 text-5xl leading-none font-medium tracking-tight sm:text-6xl', nothingYet ? 'text-bone' : test ? 'text-test' : 'text-proof')}>{aud(t.verifiedAllTimeCents)}</p>
          <p className="mt-3 max-w-xl text-sm text-mute">
            {test
              ? 'Test cards and devnet coins that Stripe or the chain confirmed. It proves the plumbing works. None of it is money, and none of it carries over when you switch to live keys.'
              : 'Money that Stripe or the Solana chain has confirmed reached you, after refunds. It is the only kind of money this console counts. Nothing on this page can be typed in, and nothing is a projection.'}
          </p>
          <dl className="mt-6 grid max-w-xl grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4">
            <Stat label="Last 7 days" cents={t.verified7dCents} />
            <Stat label="Last 30 days" cents={t.verified30dCents} />
            <Stat label="Owed to you" cents={t.receivableCents} note={`${t.openInvoices} open invoice${t.openInvoices === 1 ? '' : 's'}`} />
            <Stat label="Attested by you" cents={t.attestedAllTimeCents} note="bank payments you recorded" tone="gold" />
          </dl>
        </div>

        <div>
          {blocking.length > 0 ? (
            <div>
              <h2 className="text-sm text-alarm">Blocking payments right now</h2>
              <ul className="mt-2 space-y-2">
                {blocking.map((a, i) => (
                  <li key={i}>
                    <button onClick={() => a.tab && go(a.tab as TabId)} className="w-full rounded-md border-l-2 border-alarm bg-panel px-3 py-2 text-left text-sm text-bone hover:bg-deck">
                      {a.text}
                      {a.tab && <span className="ml-2 text-mute underline">Fix</span>}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ) : nothingYet ? (
            <Notice tone="ok">Everything needed to take a payment is switched on. Issue an invoice or list a product, send the link, and the first verified dollar will appear here.</Notice>
          ) : null}
          {others.length > 0 && (
            <ul className={cx('space-y-1.5 text-sm', blocking.length > 0 && 'mt-4')}>
              {others.map((a, i) => (
                <li key={i} className="flex gap-2">
                  <span aria-hidden className={a.level === 'warn' ? 'text-gold' : 'text-dim'}>
                    {a.level === 'warn' ? '▲' : '•'}
                  </span>
                  <button className="text-left text-mute hover:text-bone" onClick={() => a.tab && go(a.tab as TabId)}>
                    {a.text}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      <Section title="Last 30 days" aside={quiet ? undefined : <span>verified per day{t.attestedAllTimeCents > 0 ? ', attested in gold' : ''}</span>}>
        {quiet ? <p className="text-sm text-dim">No payments in the last 30 days.</p> : <DailyBars days={o.daily} test={test} />}
      </Section>

      <Section title="Where the money is" aside={<button className="underline" onClick={() => go('payouts')}>Payout details</button>}>
        <div className="grid gap-6 md:grid-cols-3">
          <Place
            title="Stripe"
            lines={
              !st.data
                ? [['', 'Loading…']]
                : !st.data.stripe.configured
                  ? [['', 'Not connected']]
                  : [
                      ['Available', st.data.stripe.availableCents === null ? '—' : aud(st.data.stripe.availableCents)],
                      ['On its way', st.data.stripe.pendingCents === null ? '—' : aud(st.data.stripe.pendingCents)],
                      ['Pays out to', st.data.stripe.payoutDestination ?? (st.data.stripe.chargesEnabled === null ? 'not readable with this key' : 'no bank account attached')],
                    ]
            }
            warn={st.data?.stripe.configured && st.data.stripe.reachable && st.data.stripe.payoutsEnabled === false ? 'Payouts are disabled on this Stripe account.' : null}
          />
          <Place
            title="Your Solana wallet"
            lines={
              !wl.data
                ? [['', 'Loading…']]
                : !wl.data.wallet.configured
                  ? [['', 'No wallet configured']]
                  : [
                      ['SOL', wl.data.wallet.sol === null ? '—' : wl.data.wallet.sol.toFixed(5)],
                      ['USDC', wl.data.wallet.usdc === null ? '—' : wl.data.wallet.usdc.toFixed(2)],
                      ['Worth about', wl.data.wallet.audValueCents === null ? '—' : aud(wl.data.wallet.audValueCents)],
                    ]
            }
            warn={wl.data?.wallet.configured && !wl.data.wallet.proven ? 'Control of this wallet has not been proven yet.' : (wl.data?.wallet.error ?? null)}
            foot="Read live from the chain. This app holds no key and cannot move it."
          />
          <Place
            title="Bank transfers"
            lines={[
              ['Recorded by you', aud(t.attestedAllTimeCents)],
              ['Shown on invoices', o.rails.bank.enabled ? 'Yes' : 'No'],
            ]}
            foot="The app cannot see your bank. These are payments you checked yourself."
          />
        </div>
      </Section>

      <Section title="Recent payments" aside={<button className="underline" onClick={() => go('receive')}>All payments</button>}>
        {o.recentPayments.length === 0 ? (
          <Empty title="No payments yet">When a customer pays an invoice or buys a product, it appears here with a link to the proof.</Empty>
        ) : (
          <Table head={['When', 'For', 'From', <span className="block text-right">Amount</span>, 'Proof']}>
            {o.recentPayments.map(p => (
              <tr key={p.id}>
                <td className="whitespace-nowrap text-mute">{dateTime(p.occurredAt)}</td>
                <td>{p.label ?? '—'}</td>
                <td className="max-w-[220px] truncate text-mute">{p.payer ?? '—'}</td>
                <td className="text-right">
                  <Money cents={p.amountCents - p.refundedCents} />
                </td>
                <td className="whitespace-nowrap">
                  <Proof payment={p} />
                  {p.proofUrl && (
                    <a href={p.proofUrl} target="_blank" rel="noreferrer noopener" className="ml-2 inline-flex items-center gap-1 text-mute underline hover:text-bone">
                      view <ExternalLink className="h-3 w-3" aria-hidden />
                    </a>
                  )}
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Section>

      <Section title="This month's plan" aside={<span>a budget on verified income — not balances</span>}>
        <div className="grid gap-x-8 gap-y-3 sm:grid-cols-2 lg:grid-cols-4">
          {o.allocation.map(a => (
            <div key={a.key} className="border-l border-rule-strong pl-3">
              <p className="text-sm text-mute">{a.label}</p>
              <p className="num text-xl">{aud(a.cents)}</p>
              <p className="num text-xs text-dim">{a.pct}%</p>
            </div>
          ))}
        </div>
        <p className="mt-3 max-w-2xl text-xs text-dim">
          The 30% treasury rule applied to this month's verified income. It tells you how to split what actually arrived. Change the percentages under Ops.
        </p>
      </Section>
    </>
  );
}

function Stat({ label, cents, note, tone }: { label: string; cents: number; note?: string; tone?: 'gold' }) {
  return (
    <div>
      <dt className="text-[13px] text-mute">{label}</dt>
      <dd className={cx('num text-lg', tone === 'gold' && cents > 0 && 'text-gold')}>{aud(cents)}</dd>
      {note && <dd className="text-xs text-dim">{note}</dd>}
    </div>
  );
}

function Place({ title, lines, warn, foot }: { title: string; lines: Array<[string, string]>; warn?: string | null; foot?: string }) {
  return (
    <div>
      <h3 className="text-sm font-medium">{title}</h3>
      <dl className="mt-2 space-y-1 text-sm">
        {lines.map(([k, v], i) => (
          <div key={i} className="flex justify-between gap-4">
            <dt className="text-mute">{k}</dt>
            <dd className={cx('text-right', /^[$\d−-]/.test(v) && 'num')}>{v}</dd>
          </div>
        ))}
      </dl>
      {warn && <p className="mt-2 text-xs text-alarm">{warn}</p>}
      {foot && <p className="mt-2 text-xs text-dim">{foot}</p>}
    </div>
  );
}

function DailyBars({ days, test }: { days: OverviewData['daily']; test: boolean }) {
  const max = Math.max(1, ...days.map(d => d.verifiedCents + d.attestedCents));
  const W = 30;
  const H = 96;
  return (
    <div>
      <svg viewBox={`0 0 ${days.length * W} ${H + 4}`} className="h-28 w-full" preserveAspectRatio="none" role="img" aria-label="Verified income per day for the last 30 days">
        <line x1="0" x2={days.length * W} y1={H + 1} y2={H + 1} stroke="var(--color-rule-strong)" strokeWidth="1" vectorEffect="non-scaling-stroke" />
        {days.map((d, i) => {
          const v = (d.verifiedCents / max) * H;
          const a = (d.attestedCents / max) * H;
          return (
            <g key={d.day}>
              <title>{`${d.day}: ${aud(d.verifiedCents)} verified${d.attestedCents ? `, ${aud(d.attestedCents)} attested` : ''}`}</title>
              <rect x={i * W + 4} width={W - 8} y={0} height={H} fill="transparent" />
              {v > 0 && <rect x={i * W + 4} width={W - 8} y={H - v} height={v} fill={test ? 'var(--color-test)' : 'var(--color-proof)'} />}
              {a > 0 && <rect x={i * W + 4} width={W - 8} y={H - v - a} height={a} fill="var(--color-gold)" />}
            </g>
          );
        })}
      </svg>
      <div className="num mt-1 flex justify-between text-xs text-dim">
        <span>{days[0]?.day}</span>
        <span>tallest day {aud(max)}</span>
        <span>{days[days.length - 1]?.day}</span>
      </div>
    </div>
  );
}
