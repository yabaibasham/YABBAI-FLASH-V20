import { useState } from 'react';
import { ExternalLink, Plus, Sparkles } from 'lucide-react';
import { api } from '../lib/api.ts';
import { aud, dateTime } from '../lib/format.ts';
import type { Order, Product } from '../../shared/types.ts';
import { Button, CopyButton, Dialog, Empty, Field, Input, Loading, Money, Notice, Section, Select, Table, Textarea, cx, useAction, useLoad } from './ui.tsx';

const STATUS_WORD = { draft: 'Draft', listed: 'On sale', archived: 'Archived' } as const;
const ORDER_WORD = { pending: 'Not paid', paid: 'Paid and delivered', refunded: 'Refunded', expired: 'Expired' } as const;

export function Store() {
  const products = useLoad(() => api.get<{ products: Product[] }>('/api/console/products'), [], 30_000);
  const orders = useLoad(() => api.get<{ orders: Order[] }>('/api/console/orders'), [], 30_000);
  const site = useLoad(() => api.get<{ pinned: { publicBaseUrl: string } }>('/api/console/settings'), []);
  const [editing, setEditing] = useState<Product | 'new' | null>(null);
  const act = useAction();

  const baseUrl = site.data?.pinned.publicBaseUrl ?? window.location.origin;
  if (!products.data) return <Loading error={products.error} onRetry={() => void products.reload()} />;
  const list = products.data.products;

  const setStatus = (p: Product, status: Product['status']) =>
    void act.run(async () => {
      await api.post(`/api/console/products/${p.id}/status`, { status });
      await products.reload(true);
    });

  return (
    <>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Store</h1>
          <p className="mt-1 max-w-2xl text-sm text-mute">
            Digital products with their own checkout page. A product cannot go on sale until the real thing the buyer receives is attached, and the buyer only gets it after their payment is
            verified.
          </p>
        </div>
        <Button variant="primary" onClick={() => setEditing('new')}>
          <Plus className="h-4 w-4" aria-hidden /> New product
        </Button>
      </div>
      {act.error && <Notice tone="error">{act.error}</Notice>}

      <Section title="Products">
        {list.length === 0 ? (
          <Empty title="Nothing in the store yet" action={<Button variant="primary" onClick={() => setEditing('new')}>Add a product</Button>}>
            Start with something you have already built and can hand over as a link or as text: a template pack, a prompt library, a setup guide.
          </Empty>
        ) : (
          <ul className="divide-y divide-rule/70">
            {list.map(p => {
              const link = `${baseUrl}/p/${p.slug}`;
              return (
                <li key={p.id} className="grid gap-x-6 gap-y-2 py-4 md:grid-cols-[minmax(0,1fr)_auto]">
                  <div className="min-w-0">
                    <p className="flex flex-wrap items-baseline gap-x-3">
                      <span className="font-medium">{p.title}</span>
                      <span className="num">{aud(p.priceCents)}</span>
                      <span className={cx('text-sm', p.status === 'listed' ? 'text-bone' : 'text-mute')}>
                        {p.status === 'listed' && <span aria-hidden>● </span>}
                        {STATUS_WORD[p.status]}
                      </span>
                    </p>
                    <p className="mt-1 line-clamp-2 max-w-2xl text-sm text-mute">{p.description}</p>
                    <p className="mt-1.5 text-[13px] text-dim">
                      {p.soldCount} sold · {aud(p.revenueCents)} verified ·{' '}
                      {p.hasDeliverable ? (
                        <span>deliverable attached ({p.deliverableKind === 'link' ? 'link' : 'text'})</span>
                      ) : (
                        <span className="text-gold">no deliverable yet — cannot go on sale</span>
                      )}
                    </p>
                    {p.status === 'listed' && (
                      <div className="mt-2 flex flex-wrap items-center gap-2">
                        <code className="num min-w-0 truncate rounded border border-rule-strong bg-ink px-2 py-1 text-[13px]">{link}</code>
                        <CopyButton text={link} label="Copy link" />
                        <a href={link} target="_blank" rel="noreferrer noopener" className="inline-flex items-center gap-1 text-sm text-mute underline hover:text-bone">
                          View page <ExternalLink className="h-3 w-3" aria-hidden />
                        </a>
                      </div>
                    )}
                  </div>
                  <div className="flex flex-wrap items-start gap-2 md:justify-end">
                    <Button small onClick={() => setEditing(p)}>
                      Edit
                    </Button>
                    {p.status !== 'listed' && (
                      <Button small variant="primary" busy={act.busy} disabled={!p.hasDeliverable} title={p.hasDeliverable ? undefined : 'Attach the deliverable first'} onClick={() => setStatus(p, 'listed')}>
                        Put on sale
                      </Button>
                    )}
                    {p.status === 'listed' && (
                      <Button small busy={act.busy} onClick={() => setStatus(p, 'draft')}>
                        Take off sale
                      </Button>
                    )}
                    {p.status !== 'archived' && (
                      <Button small variant="ghost" busy={act.busy} onClick={() => setStatus(p, 'archived')}>
                        Archive
                      </Button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Section>

      <Section title="Orders" aside={<span>paid and refunded only</span>}>
        {!orders.data ? (
          <Loading error={orders.error} onRetry={() => void orders.reload()} />
        ) : orders.data.orders.length === 0 ? (
          <Empty title="No sales yet">An order shows up here once a buyer's payment has been verified. Abandoned checkouts are not listed.</Empty>
        ) : (
          <Table head={['Paid', 'Product', <span className="block text-right">Price</span>, 'Buyer', 'Status']}>
            {orders.data.orders.map(o => (
              <tr key={o.id}>
                <td className="whitespace-nowrap text-mute">{o.paidAt ? dateTime(o.paidAt) : '—'}</td>
                <td>{o.productTitle}</td>
                <td className="text-right">
                  <Money cents={o.priceCents} />
                </td>
                <td className="max-w-[220px] truncate text-mute">{o.customerEmail ?? '—'}</td>
                <td className={o.status === 'paid' ? (o.livemode ? 'text-proof' : 'text-test') : 'text-mute'}>
                  {ORDER_WORD[o.status]}
                  {o.status === 'paid' && !o.livemode ? ' (test)' : ''}
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Section>

      {editing && (
        <ProductEditor
          product={editing === 'new' ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            void products.reload(true);
          }}
        />
      )}
    </>
  );
}

const lines = (text: string) =>
  text
    .split('\n')
    .map(s => s.trim())
    .filter(Boolean);

function ProductEditor({ product, onClose, onSaved }: { product: Product | null; onClose: () => void; onSaved: () => void }) {
  const [title, setTitle] = useState(product?.title ?? '');
  const [description, setDescription] = useState(product?.description ?? '');
  const [price, setPrice] = useState(product ? (product.priceCents / 100).toFixed(2) : '');
  const [ships, setShips] = useState((product?.ships ?? []).join('\n'));
  const [doesNotShip, setDoesNotShip] = useState((product?.doesNotShip ?? []).join('\n'));
  const [kind, setKind] = useState<'link' | 'text'>(product?.deliverableKind ?? 'link');
  const [value, setValue] = useState(product?.deliverableValue ?? '');
  const save = useAction();
  const scope = useAction();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const payload = {
      title,
      description,
      priceDollars: price,
      ships: lines(ships).slice(0, 8),
      doesNotShip: lines(doesNotShip).slice(0, 8),
      deliverableKind: value.trim() ? kind : null,
      deliverableValue: value,
    };
    const out = await save.run(() => (product ? api.put(`/api/console/products/${product.id}`, payload) : api.post('/api/console/products', payload)));
    if (out) onSaved();
  }

  return (
    <Dialog title={product ? `Edit ${product.title}` : 'New product'} onClose={onClose} wide>
      <form onSubmit={submit} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-[minmax(0,1fr)_9rem]">
          <Field label="Name">
            <Input required minLength={2} maxLength={120} value={title} onChange={e => setTitle(e.target.value)} />
          </Field>
          <Field label="Price (AUD)">
            <Input required inputMode="decimal" placeholder="0.00" className="num" value={price} onChange={e => setPrice(e.target.value.replace(/[^0-9.]/g, ''))} />
          </Field>
        </div>
        <Field label="Description" hint="Shown on the product page. Say plainly what it is.">
          <Textarea required maxLength={2000} value={description} onChange={e => setDescription(e.target.value)} />
        </Field>

        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="What the buyer gets" hint="One per line, up to 8.">
            <Textarea value={ships} onChange={e => setShips(e.target.value)} className="min-h-28" />
          </Field>
          <Field label="What is not included" hint="One per line. Saying this up front prevents refund requests.">
            <Textarea value={doesNotShip} onChange={e => setDoesNotShip(e.target.value)} className="min-h-28" />
          </Field>
        </div>
        {product && (
          <div className="flex flex-wrap items-center gap-3">
            <Button
              small
              busy={scope.busy}
              onClick={() =>
                void scope.run(async () => {
                  const out = await api.post<{ scope: { ships: string[]; doesNotShip: string[] } }>(`/api/console/ai/products/${product.id}/scope`);
                  setShips(out.scope.ships.join('\n'));
                  setDoesNotShip(out.scope.doesNotShip.join('\n'));
                })
              }
            >
              <Sparkles className="h-3.5 w-3.5" aria-hidden /> Draft these two lists from the saved description
            </Button>
            <span className="text-xs text-dim">A draft for you to correct. Nothing is saved until you press Save.</span>
          </div>
        )}
        {scope.error && <Notice tone="error">{scope.error}</Notice>}

        <fieldset className="rounded-md border border-rule-strong p-4">
          <legend className="px-1 text-sm">The deliverable</legend>
          <p className="mb-3 text-sm text-mute">The actual thing the buyer receives. It is kept on the server and revealed on their order page only once payment is verified in full.</p>
          <div className="grid gap-4 sm:grid-cols-[11rem_minmax(0,1fr)]">
            <Field label="Delivered as">
              <Select value={kind} onChange={e => setKind(e.target.value as 'link' | 'text')}>
                <option value="link">A download link</option>
                <option value="text">Text shown on the page</option>
              </Select>
            </Field>
            <Field label={kind === 'link' ? 'Link' : 'Content'} hint={kind === 'link' ? 'A private https link to the file or folder.' : 'Licence keys, instructions or the content itself.'}>
              {kind === 'link' ? (
                <Input type="url" placeholder="https://" maxLength={4000} value={value} onChange={e => setValue(e.target.value)} />
              ) : (
                <Textarea maxLength={4000} value={value} onChange={e => setValue(e.target.value)} className="min-h-28" />
              )}
            </Field>
          </div>
        </fieldset>

        {save.error && <Notice tone="error">{save.error}</Notice>}
        <div className="flex justify-end gap-2">
          <Button onClick={onClose}>Cancel</Button>
          <Button type="submit" variant="primary" busy={save.busy}>
            Save
          </Button>
        </div>
      </form>
    </Dialog>
  );
}
