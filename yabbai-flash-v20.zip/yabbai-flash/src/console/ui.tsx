import { useCallback, useEffect, useRef, useState } from 'react';
import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode, SelectHTMLAttributes, TextareaHTMLAttributes } from 'react';
import { Check, Copy, Loader2, X } from 'lucide-react';
import { messageOf } from '../lib/api.ts';
import { aud } from '../lib/format.ts';
import type { Invoice, InvoiceStatus, Payment } from '../../shared/types.ts';

export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

// ── data loading ──────────────────────────────────────────────────────────
export function useLoad<T>(loader: () => Promise<T>, deps: unknown[] = [], refreshMs = 0) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const alive = useRef(true);
  const fn = useRef(loader);
  fn.current = loader;

  const reload = useCallback(async (quiet = false) => {
    if (!quiet) setLoading(true);
    try {
      const out = await fn.current();
      if (!alive.current) return;
      setData(out);
      setError(null);
    } catch (err) {
      if (alive.current) setError(messageOf(err));
    } finally {
      if (alive.current) setLoading(false);
    }
  }, []);

  useEffect(() => {
    alive.current = true;
    void reload();
    let timer: number | undefined;
    if (refreshMs > 0) {
      timer = window.setInterval(() => {
        if (document.visibilityState === 'visible') void reload(true);
      }, refreshMs);
    }
    return () => {
      alive.current = false;
      if (timer) window.clearInterval(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  return { data, error, loading, reload };
}

/** Run an action with busy + error state. */
export function useAction() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const run = useCallback(async <T,>(fn: () => Promise<T>): Promise<T | undefined> => {
    setBusy(true);
    setError(null);
    try {
      return await fn();
    } catch (err) {
      setError(messageOf(err));
      return undefined;
    } finally {
      setBusy(false);
    }
  }, []);
  return { busy, error, run, clear: () => setError(null) };
}

// ── buttons & inputs ──────────────────────────────────────────────────────
type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
const VARIANT: Record<Variant, string> = {
  primary: 'bg-gold text-ink font-semibold hover:brightness-110 disabled:opacity-40',
  secondary: 'border border-rule-strong text-bone hover:border-mute disabled:opacity-40',
  ghost: 'text-mute hover:text-bone disabled:opacity-40',
  danger: 'border border-alarm/60 text-alarm hover:bg-alarm/10 disabled:opacity-40',
};

export function Button({
  variant = 'secondary',
  busy,
  small,
  className,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; busy?: boolean; small?: boolean }) {
  return (
    <button
      type="button"
      {...rest}
      disabled={rest.disabled || busy}
      className={cx(
        'inline-flex items-center justify-center gap-2 rounded-md whitespace-nowrap transition-[filter,border-color,color,background-color]',
        small ? 'px-2.5 py-1 text-[13px]' : 'px-3.5 py-2 text-sm',
        VARIANT[variant],
        className
      )}
    >
      {busy && <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />}
      {children}
    </button>
  );
}

const FIELD = 'w-full rounded-md border border-rule-strong bg-ink px-3 py-2 text-sm text-bone placeholder:text-dim focus:border-gold focus:outline-none';

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={cx(FIELD, props.className)} />;
}
export function Textarea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={cx(FIELD, 'min-h-24 resize-y', props.className)} />;
}
export function Select(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={cx(FIELD, props.className)} />;
}

export function Field({ label, hint, children, className }: { label: string; hint?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <label className={cx('block', className)}>
      <span className="mb-1 block text-[13px] text-mute">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-dim">{hint}</span>}
    </label>
  );
}

// ── text atoms ────────────────────────────────────────────────────────────
export function Money({ cents, className, sign }: { cents: number; className?: string; sign?: boolean }) {
  return <span className={cx('num', className)}>{aud(cents, { sign })}</span>;
}

const STATUS_TONE: Record<InvoiceStatus, string> = {
  paid: 'text-proof',
  part: 'text-gold',
  overdue: 'text-alarm',
  open: 'text-bone',
  draft: 'text-mute',
  void: 'text-dim line-through',
};
const STATUS_WORD: Record<InvoiceStatus, string> = { paid: 'Paid', part: 'Part paid', overdue: 'Overdue', open: 'Awaiting payment', draft: 'Draft', void: 'Void' };

/**
 * Green is reserved for live money a processor confirmed. An invoice settled
 * partly on your own say-so reads gold; anything in test mode reads purple.
 */
export function InvoiceStatusText({ invoice }: { invoice: Pick<Invoice, 'status' | 'attestedPaidCents' | 'livemode'> }) {
  const { status } = invoice;
  if (status === 'paid' && invoice.attestedPaidCents > 0) {
    return (
      <span className="text-gold" title="Settled with a bank payment you recorded yourself.">
        Paid (attested)
      </span>
    );
  }
  if (status === 'paid' && !invoice.livemode) return <span className="text-test">Paid (test)</span>;
  return <span className={STATUS_TONE[status]}>{STATUS_WORD[status]}</span>;
}

/** How a payment is proven. The single most important label in the app. */
export function Proof({ payment }: { payment: Pick<Payment, 'rail' | 'verified' | 'disputed' | 'refundedCents' | 'amountCents' | 'livemode'> }) {
  if (payment.disputed) return <span className="text-alarm">Disputed</span>;
  if (payment.refundedCents >= payment.amountCents) return <span className="text-dim">Refunded</span>;
  if (payment.rail === 'attested') {
    return (
      <span className="text-gold" title="You recorded this yourself. No processor has confirmed it.">
        ◇ Attested by you
      </span>
    );
  }
  const who = payment.rail === 'stripe' ? 'Stripe' : 'On-chain';
  if (!payment.livemode) {
    return (
      <span className="text-test" title="A test payment. No real money moved.">
        ✓ {who} (test)
      </span>
    );
  }
  return (
    <span className="text-proof" title={payment.rail === 'stripe' ? 'Confirmed by Stripe' : 'Confirmed on the Solana chain'}>
      ✓ {who}
    </span>
  );
}

export function Notice({ tone = 'info', children, className }: { tone?: 'info' | 'ok' | 'warn' | 'error' | 'test'; children: ReactNode; className?: string }) {
  const tones = {
    info: 'border-rule-strong text-mute',
    ok: 'border-proof/40 text-proof',
    warn: 'border-gold/50 text-gold',
    error: 'border-alarm/60 text-alarm',
    test: 'border-test/50 text-test',
  };
  return (
    <div role={tone === 'error' ? 'alert' : 'status'} className={cx('rounded-md border-l-2 bg-panel px-3 py-2 text-sm', tones[tone], className)}>
      {children}
    </div>
  );
}

export function Section({ title, aside, children, className }: { title: string; aside?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={cx('border-t border-rule pt-5', className)}>
      <div className="mb-3 flex flex-wrap items-baseline justify-between gap-x-4 gap-y-2">
        <h2 className="text-base font-semibold text-bone">{title}</h2>
        {aside && <div className="flex flex-wrap items-center gap-2 text-sm text-mute">{aside}</div>}
      </div>
      {children}
    </section>
  );
}

export function Empty({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="rounded-md border border-dashed border-rule-strong px-5 py-8 text-center">
      <p className="font-medium text-bone">{title}</p>
      {children && <p className="mx-auto mt-1 max-w-xl text-sm text-mute">{children}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Loading({ error, onRetry }: { error?: string | null; onRetry?: () => void }) {
  if (error) {
    return (
      <Notice tone="error">
        {error}{' '}
        {onRetry && (
          <button className="underline" onClick={onRetry}>
            Try again
          </button>
        )}
      </Notice>
    );
  }
  return <p className="py-6 text-sm text-dim">Loading…</p>;
}

export function CopyButton({ text, label = 'Copy', small = true, variant = 'secondary' }: { text: string; label?: string; small?: boolean; variant?: Variant }) {
  const [done, setDone] = useState(false);
  return (
    <Button
      small={small}
      variant={variant}
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setDone(true);
          window.setTimeout(() => setDone(false), 1800);
        } catch {
          window.prompt('Copy this:', text);
        }
      }}
    >
      {done ? <Check className="h-3.5 w-3.5 text-proof" aria-hidden /> : <Copy className="h-3.5 w-3.5" aria-hidden />}
      {done ? 'Copied' : label}
    </Button>
  );
}

// ── dialog ────────────────────────────────────────────────────────────────
export function Dialog({ title, onClose, children, wide }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    const first = ref.current?.querySelector<HTMLElement>('input, textarea, select, button[data-autofocus]');
    first?.focus();
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/70 p-4 sm:items-center" onMouseDown={e => e.target === e.currentTarget && onClose()}>
      <div ref={ref} role="dialog" aria-modal="true" aria-label={title} className={cx('settle w-full rounded-lg border border-rule-strong bg-deck shadow-2xl', wide ? 'max-w-3xl' : 'max-w-lg')}>
        <div className="flex items-center justify-between border-b border-rule px-5 py-3">
          <h3 className="font-semibold">{title}</h3>
          <button aria-label="Close" onClick={onClose} className="rounded p-1 text-mute hover:text-bone">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="px-5 py-4">{children}</div>
      </div>
    </div>
  );
}

/** A plain data table with hairline rows. */
export function Table({ head, children, className }: { head: ReactNode[]; children: ReactNode; className?: string }) {
  return (
    <div className={cx('overflow-x-auto', className)}>
      <table className="w-full min-w-[560px] border-collapse text-sm">
        <thead>
          <tr className="text-left text-[13px] text-mute">
            {head.map((h, i) => (
              <th key={i} className="border-b border-rule px-2 py-2 font-normal first:pl-0 last:pr-0">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="[&_td]:border-b [&_td]:border-rule/70 [&_td]:px-2 [&_td]:py-2.5 [&_td]:align-top [&_td:first-child]:pl-0 [&_td:last-child]:pr-0">{children}</tbody>
      </table>
    </div>
  );
}

export function StateDot({ state }: { state: 'ok' | 'warn' | 'error' | 'off' }) {
  const c = { ok: 'bg-proof', warn: 'bg-gold', error: 'bg-alarm', off: 'bg-dim' }[state];
  return <span aria-hidden className={cx('mt-[7px] inline-block h-2 w-2 shrink-0 rounded-full', c)} />;
}
