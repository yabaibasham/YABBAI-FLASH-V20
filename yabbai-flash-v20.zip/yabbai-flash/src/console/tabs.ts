export const TABS = [
  { id: 'overview', label: 'Overview' },
  { id: 'receive', label: 'Receive' },
  { id: 'store', label: 'Store' },
  { id: 'pipeline', label: 'Pipeline' },
  { id: 'brain', label: 'Brain' },
  { id: 'network', label: 'Network' },
  { id: 'payouts', label: 'Payouts' },
  { id: 'markets', label: 'Markets' },
  { id: 'ops', label: 'Ops' },
] as const;

export type TabId = (typeof TABS)[number]['id'];
