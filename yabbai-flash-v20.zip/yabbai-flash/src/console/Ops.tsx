import { useState } from 'react';
import { Sparkles } from 'lucide-react';
import { api } from '../lib/api.ts';
import { ago, dateTime } from '../lib/format.ts';
import type { AuditEntry, HealthCheck, Mode } from '../../shared/types.ts';
import { Button, Field, Input, Loading, Notice, Section, StateDot, Table, cx, useAction, useLoad } from './ui.tsx';

interface Job {
  id: string;
  name: string;
  does: string;
  everySec: number;
  needs: string | null;
  lastRunAt: number | null;
  lastResult: string | null;
  lastError: string | null;
  running: boolean;
}
interface Settings {
  allocation: { keepPct: number; reservePct: number; reinvestPct: number };
  pinned: {
    solanaAddress: string | null;
    brandName: string;
    abn: string | null;
    gstRegistered: boolean;
    supportEmail: string | null;
    publicBaseUrl: string;
    timeZone: string;
  };
}

const every = (sec: number) => (sec < 120 ? `${sec}s` : sec < 7200 ? `${Math.round(sec / 60)} min` : `${Math.round(sec / 3600)} h`);

export function Ops({ onSignedOut }: { onSignedOut: () => Promise<void> }) {
  return (
    <>
      <div>
        <h1 className="text-2xl font-semibold">Ops</h1>
        <p className="mt-1 max-w-2xl text-sm text-mute">What is switched on, what still needs doing before money can arrive, and a record of everything that has happened.</p>
      </div>
      <Checklist />
      <AutopilotPanel />
      <Brain />
      <Allocation />
      <AuditLog />
      <Section title="Sessions">
        <SignOutAll onSignedOut={onSignedOut} />
      </Section>
    </>
  );
}

// ── go-live checklist ───────────────────────────────────────────────────────
function Checklist() {
  const h = useLoad(() => api.get<{ checks: HealthCheck[]; mode: Mode }>('/api/console/health'), [], 60_000);
  if (!h.data) {
    return (
      <Section title="Go-live checklist">
        <Loading error={h.error} onRetry={() => void h.reload()} />
      </Section>
    );
  }
  const { checks } = h.data;
  const errors = checks.filter(c => c.state === 'error').length;
  const warns = checks.filter(c => c.state === 'warn').length;
  return (
    <Section
      title="Go-live checklist"
      aside={
        <span className={errors ? 'text-alarm' : warns ? 'text-gold' : 'text-proof'}>
          {errors ? `${errors} blocking` : warns ? `${warns} to tidy up` : 'all clear'}
        </span>
      }
    >
      <ul className="divide-y divide-rule/70">
        {checks.map(c => (
          <li key={c.id} className="flex gap-3 py-2.5">
            <StateDot state={c.state} />
            <div className="min-w-0 flex-1">
              <p className="flex flex-wrap items-baseline gap-x-3">
                <span className="font-medium">{c.label}</span>
                <span className={cx('text-[13px]', c.state === 'ok' ? 'text-proof' : c.state === 'warn' ? 'text-gold' : c.state === 'error' ? 'text-alarm' : 'text-dim')}>
                  {c.state === 'ok' ? 'Ready' : c.state === 'warn' ? 'Works, with a risk' : c.state === 'error' ? 'Needs fixing' : 'Off'}
                </span>
              </p>
              <p className="text-sm break-words text-mute">{c.detail}</p>
              {c.fix && <p className="mt-0.5 text-sm break-words text-bone">To fix: {c.fix}</p>}
            </div>
          </li>
        ))}
      </ul>
      <p className="mt-3 max-w-2xl text-xs text-dim">
        Everything marked with a setting name in capitals is changed in your hosting provider's environment variables, then the app is restarted. Keys and destinations are deliberately not
        editable from inside the console.
      </p>
    </Section>
  );
}

// ── autopilot ───────────────────────────────────────────────────────────────
function AutopilotPanel() {
  const a = useLoad(() => api.get<{ on: boolean; jobs: Job[] }>('/api/console/autopilot'), [], 20_000);
  const act = useAction();
  if (!a.data) {
    return (
      <Section title="Autopilot">
        <Loading error={a.error} onRetry={() => void a.reload()} />
      </Section>
    );
  }
  const { on, jobs } = a.data;
  const post = (path: string, body: unknown) =>
    void act.run(async () => {
      await api.post(path, body);
      await a.reload(true);
    });
  return (
    <Section
      title="Autopilot"
      aside={
        <>
          <span className={on ? 'text-proof' : 'text-gold'}>{on ? 'Running' : 'Paused'}</span>
          <Button small busy={act.busy} onClick={() => post('/api/console/autopilot', { on: !on })}>
            {on ? 'Pause' : 'Resume'}
          </Button>
        </>
      }
    >
      <p className="mb-3 max-w-2xl text-sm text-mute">
        Six jobs run on the server whether or not this page is open. They check for payments, score real enquiries, write drafts and ask each watched link whether it still answers. None of them
        can create a payment without proof, and none of them sends a message. The council is not one of them: it sits only when you ask.
      </p>
      {act.error && <Notice tone="error" className="mb-3">{act.error}</Notice>}
      <Table head={['Job', 'What it does', 'Every', 'Last run', '']}>
        {jobs.map(j => (
          <tr key={j.id}>
            <td className="font-medium whitespace-nowrap">{j.name}</td>
            <td className="max-w-md text-mute">
              {j.does}
              {(j.lastError || j.lastResult) && <span className={cx('mt-0.5 block text-[13px]', j.lastError ? 'text-alarm' : 'text-dim')}>{j.lastError ? `Failed: ${j.lastError}` : j.lastResult}</span>}
            </td>
            <td className="num whitespace-nowrap text-mute">{every(j.everySec)}</td>
            <td className="whitespace-nowrap text-mute">{j.running ? 'running…' : j.lastRunAt ? ago(j.lastRunAt) : 'not yet'}</td>
            <td className="text-right">
              <Button small busy={act.busy} onClick={() => post('/api/console/autopilot/run', { id: j.id })}>
                Run now
              </Button>
            </td>
          </tr>
        ))}
      </Table>
    </Section>
  );
}

// ── AI ──────────────────────────────────────────────────────────────────────
function Brain() {
  const ai = useLoad(() => api.get<{ enabled: boolean; provider: string; lastError: string | null; lastOkAt: number | null; dailyCap: number }>('/api/console/ai'), []);
  const [text, setText] = useState<string | null>(null);
  const [question, setQuestion] = useState('');
  const act = useAction();
  if (!ai.data) {
    return (
      <Section title="AI brain">
        <Loading error={ai.error} onRetry={() => void ai.reload()} />
      </Section>
    );
  }
  const d = ai.data;
  return (
    <Section title="AI brain" aside={<span>{d.enabled ? `${d.provider} · up to ${d.dailyCap} calls a day` : 'off'}</span>}>
      {!d.enabled ? (
        <p className="max-w-2xl text-sm text-mute">
          No AI provider is configured, so scoring and drafting are unavailable. Everything to do with payments works without it. To switch it on, set <code className="num">GEMINI_API_KEY</code>
          , or <code className="num">LLM_BASE_URL</code> and <code className="num">LLM_MODEL</code> for another provider.
        </p>
      ) : (
        <div className="space-y-4">
          <p className="max-w-2xl text-sm text-mute">
            The AI reads a summary of your verified records and writes words: a brief, an answer, a draft. It has no tools. It cannot record a payment, change a setting, send an email or move
            money. For a decision worth more than one point of view, put it to the council under Brain.
          </p>
          <div className="flex flex-wrap gap-2">
            <Button
              busy={act.busy}
              onClick={() =>
                void act.run(async () => {
                  setText((await api.post<{ text: string }>('/api/console/ai/brief')).text);
                  void ai.reload(true);
                })
              }
            >
              <Sparkles className="h-3.5 w-3.5" aria-hidden /> Write today's brief
            </Button>
          </div>
          <form
            className="flex flex-wrap items-end gap-2"
            onSubmit={e => {
              e.preventDefault();
              void act.run(async () => {
                setText((await api.post<{ text: string }>('/api/console/ai/ask', { question })).text);
                void ai.reload(true);
              });
            }}
          >
            <Field label="Ask about the business" className="min-w-0 flex-1">
              <Input required minLength={2} maxLength={500} value={question} onChange={e => setQuestion(e.target.value)} placeholder="What should I chase first this week?" />
            </Field>
            <Button type="submit" busy={act.busy}>
              Ask
            </Button>
          </form>
          {act.error && <Notice tone="error">{act.error}</Notice>}
          {d.lastError && !act.error && <Notice tone="warn">The last AI call failed: {d.lastError}</Notice>}
          {text && <pre className="max-w-3xl rounded-md border border-rule-strong bg-panel p-4 font-sans text-sm whitespace-pre-wrap">{text}</pre>}
        </div>
      )}
    </Section>
  );
}

// ── allocation + pinned settings ────────────────────────────────────────────
function Allocation() {
  const s = useLoad(() => api.get<Settings>('/api/console/settings'), []);
  const [form, setForm] = useState<{ keepPct: string; reservePct: string; reinvestPct: string } | null>(null);
  const [saved, setSaved] = useState(false);
  const act = useAction();
  if (!s.data) {
    return (
      <Section title="Settings">
        <Loading error={s.error} onRetry={() => void s.reload()} />
      </Section>
    );
  }
  const a = s.data.allocation;
  const f = form ?? { keepPct: String(a.keepPct), reservePct: String(a.reservePct), reinvestPct: String(a.reinvestPct) };
  const p = s.data.pinned;
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setSaved(false);
    setForm({ ...f, [k]: e.target.value.replace(/[^0-9]/g, '').slice(0, 3) });
  };
  const keep = Math.min(100, Number(f.keepPct) || 0);
  const reserve = ((100 - keep) * Math.min(100, Number(f.reservePct) || 0)) / 100;
  const reinvest = ((100 - keep - reserve) * Math.min(100, Number(f.reinvestPct) || 0)) / 100;
  const pay = 100 - keep - reserve - reinvest;

  return (
    <>
      <Section title="Monthly plan split">
        <p className="mb-4 max-w-2xl text-sm text-mute">
          How the Overview divides each month's verified income into a budget. It is a plan for you to follow by hand. Changing it moves no money.
        </p>
        <form
          className="grid max-w-2xl gap-4 sm:grid-cols-3"
          onSubmit={e => {
            e.preventDefault();
            void act.run(async () => {
              await api.put('/api/console/settings/allocation', { keepPct: Number(f.keepPct), reservePct: Number(f.reservePct), reinvestPct: Number(f.reinvestPct) });
              setSaved(true);
              setForm(null);
              await s.reload(true);
            });
          }}
        >
          <Field label="Treasury, kept (%)" hint="Of everything verified.">
            <Input inputMode="numeric" className="num" value={f.keepPct} onChange={set('keepPct')} />
          </Field>
          <Field label="Reserve (%)" hint="Of what is left after treasury.">
            <Input inputMode="numeric" className="num" value={f.reservePct} onChange={set('reservePct')} />
          </Field>
          <Field label="Reinvest (%)" hint="Of what is left after reserve.">
            <Input inputMode="numeric" className="num" value={f.reinvestPct} onChange={set('reinvestPct')} />
          </Field>
          <p className="num text-sm text-mute sm:col-span-3">
            Of every $100 verified: ${keep.toFixed(0)} treasury · ${reserve.toFixed(0)} reserve · ${reinvest.toFixed(0)} reinvest · ${pay.toFixed(0)} pay yourself
          </p>
          <div className="flex items-center gap-3 sm:col-span-3">
            <Button type="submit" busy={act.busy} disabled={!form}>
              Save split
            </Button>
            {saved && <span className="text-sm text-proof">Saved.</span>}
            {act.error && <span className="text-sm text-alarm">{act.error}</span>}
          </div>
        </form>
      </Section>

      <Section title="Pinned by the hosting environment" aside={<span>read-only here</span>}>
        <dl className="grid max-w-3xl gap-x-10 gap-y-2 text-sm sm:grid-cols-2">
          <Pin k="Business name" v={p.brandName} />
          <Pin k="Support email" v={p.supportEmail} />
          <Pin k="ABN" v={p.abn} mono />
          <Pin k="GST" v={p.gstRegistered ? 'Registered — invoices can add 10%' : 'Not registered — never charged'} />
          <Pin k="Customer-facing address" v={p.publicBaseUrl} mono />
          <Pin k="Business time zone" v={p.timeZone} />
          <Pin k="Solana receiving wallet" v={p.solanaAddress} mono wide />
        </dl>
      </Section>
    </>
  );
}

function Pin({ k, v, mono, wide }: { k: string; v: string | null; mono?: boolean; wide?: boolean }) {
  return (
    <div className={cx('flex flex-wrap justify-between gap-x-4 border-b border-rule/70 py-1', wide && 'sm:col-span-2')}>
      <dt className="text-mute">{k}</dt>
      <dd className={cx('min-w-0 text-right break-all', mono && 'num', !v && 'text-dim')}>{v ?? 'not set'}</dd>
    </div>
  );
}

// ── audit log ───────────────────────────────────────────────────────────────
const ACTION_WORD: Record<string, string> = {
  'auth.login': 'Signed in',
  'auth.logout': 'Signed out',
  'auth.logout_all': 'Signed out everywhere',
  'auth.login_failed': 'Failed sign-in attempt',
  'auth.stepup_failed': 'Failed password confirmation',
  'payment.verified': 'Payment verified',
  'payment.attested': 'Bank payment attested',
  'payment.refunded': 'Refund recorded',
  'payment.rejected': 'Payment rejected',
  'payment.dispute_created': 'Dispute opened',
  'payment.dispute_closed': 'Dispute closed',
  'payment.dispute_funds_withdrawn': 'Dispute funds withdrawn',
  'payment.dispute_funds_reinstated': 'Dispute funds returned',
  'checkout.create_failed': 'Checkout could not start',
  'payout.paid': 'Stripe payout reached your bank',
  'payout.failed': 'Stripe payout failed',
  'webhook.bad_signature': 'Webhook with a bad signature refused',
  'webhook.wrong_mode': 'Webhook from the wrong mode refused',
  'invoice.created': 'Invoice drafted',
  'invoice.updated': 'Draft invoice edited',
  'invoice.opened': 'Invoice issued',
  'invoice.voided': 'Invoice voided',
  'product.created': 'Product created',
  'product.updated': 'Product edited',
  'product.listed': 'Product put on sale',
  'product.draft': 'Product taken off sale',
  'product.archived': 'Product archived',
  'lead.created': 'Lead added',
  'lead.stage': 'Lead moved',
  'lead.deleted': 'Lead deleted',
  'wallet.proven': 'Wallet control proven',
  'wallet.proof_failed': 'Wallet proof failed',
  'intake.received': 'Enquiry received',
  'settings.allocation': 'Plan split changed',
  'autopilot.on': 'Autopilot resumed',
  'autopilot.off': 'Autopilot paused',
  'council.convened': 'Council convened',
  'council.finished': 'Council reached a verdict',
  'council.failed': 'Council session did not finish',
  'council.ruled': 'You ruled on a verdict',
  'lesson.proposed': 'Council suggested a lesson',
  'lesson.added': 'Lesson added',
  'lesson.approved': 'Suggested lesson kept',
  'lesson.dismissed': 'Suggested lesson dismissed',
  'lesson.retired': 'Lesson retired',
  'network.added': 'Link added',
  'network.changed': 'Link changed',
  'network.removed': 'Link removed',
  'network.imported': 'Links imported',
};

function summarise(detail: Record<string, unknown>): string {
  const parts: string[] = [];
  for (const [k, v] of Object.entries(detail)) {
    if (v === null || v === undefined || typeof v === 'object') continue;
    const text = k.endsWith('Cents') && typeof v === 'number' ? `${k.replace(/Cents$/, '')} $${(v / 100).toFixed(2)}` : `${k} ${String(v)}`;
    parts.push(text.length > 60 ? `${text.slice(0, 57)}…` : text);
  }
  return parts.slice(0, 4).join(' · ');
}

function AuditLog() {
  const [entries, setEntries] = useState<AuditEntry[] | null>(null);
  const [more, setMore] = useState(true);
  const first = useLoad(async () => {
    const out = await api.get<{ entries: AuditEntry[] }>('/api/console/audit');
    setEntries(out.entries);
    setMore(out.entries.length === 100);
    return out;
  }, []);
  const [verdict, setVerdict] = useState<{ ok: boolean; entries: number; brokenAtSeq: number | null; headHash: string } | null>(null);
  const act = useAction();

  return (
    <Section
      title="Audit log"
      aside={
        <Button
          small
          busy={act.busy}
          onClick={() =>
            void act.run(async () => {
              setVerdict(await api.get('/api/console/audit/verify'));
            })
          }
        >
          Verify the chain
        </Button>
      }
    >
      <p className="mb-3 max-w-2xl text-sm text-mute">
        Every sign-in, payment, invoice change and setting change is written here. Each entry carries a fingerprint of the one before it, and the database refuses edits and deletions, so a
        quiet change to history shows up as a broken chain.
      </p>
      {verdict &&
        (verdict.ok ? (
          <Notice tone="ok" className="mb-3">
            All {verdict.entries} entries check out. Latest fingerprint <span className="num">{verdict.headHash.slice(0, 16)}…</span>
          </Notice>
        ) : (
          <Notice tone="error" className="mb-3">
            The chain is broken at entry #{verdict.brokenAtSeq}. Something altered the log outside this app. Treat the database as compromised: rotate every key and password.
          </Notice>
        ))}
      {act.error && <Notice tone="error" className="mb-3">{act.error}</Notice>}
      {!entries ? (
        <Loading error={first.error} onRetry={() => void first.reload()} />
      ) : (
        <>
          <Table head={['#', 'When', 'Who', 'What', 'Detail']}>
            {entries.map(e => (
              <tr key={e.seq}>
                <td className="num text-dim">{e.seq}</td>
                <td className="whitespace-nowrap text-mute">{dateTime(e.at)}</td>
                <td className={cx('whitespace-nowrap', e.actor === 'director' ? 'text-bone' : 'text-mute')}>{e.actor}</td>
                <td className={cx('whitespace-nowrap', /failed|dispute_created|rejected|bad_signature|wrong_mode/.test(e.action) && 'text-alarm')}>{ACTION_WORD[e.action] ?? e.action}</td>
                <td className="max-w-md truncate text-[13px] text-dim" title={JSON.stringify(e.detail)}>
                  {summarise(e.detail)}
                </td>
              </tr>
            ))}
          </Table>
          {more && entries.length > 0 && (
            <Button
              small
              className="mt-3"
              busy={act.busy}
              onClick={() =>
                void act.run(async () => {
                  const out = await api.get<{ entries: AuditEntry[] }>(`/api/console/audit?before=${entries[entries.length - 1].seq}`);
                  setEntries([...entries, ...out.entries]);
                  setMore(out.entries.length === 100);
                })
              }
            >
              Load older entries
            </Button>
          )}
        </>
      )}
    </Section>
  );
}

function SignOutAll({ onSignedOut }: { onSignedOut: () => Promise<void> }) {
  const act = useAction();
  return (
    <div className="flex flex-wrap items-center gap-3">
      <Button
        variant="danger"
        busy={act.busy}
        onClick={() =>
          void act.run(async () => {
            await api.post('/api/auth/logout-all');
            await onSignedOut();
          })
        }
      >
        Sign out on every device
      </Button>
      <p className="max-w-xl text-sm text-mute">Use this if you signed in somewhere you do not trust. It ends every session, including this one. To change the password itself, run setup again and update the hosting environment.</p>
      {act.error && <Notice tone="error">{act.error}</Notice>}
    </div>
  );
}
