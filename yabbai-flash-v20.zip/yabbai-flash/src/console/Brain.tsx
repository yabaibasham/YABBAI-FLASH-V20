import { useEffect, useRef, useState } from 'react';
import { api, messageOf } from '../lib/api.ts';
import { ago, dateTime } from '../lib/format.ts';
import type { CouncilDecision, CouncilOpinion, CouncilSession, Lesson, Mode, RoutePlan, SeatId, SeatInfo } from '../../shared/types.ts';
import { Button, Empty, Field, Input, Loading, Notice, Section, Select, Table, Textarea, cx, useAction, useLoad } from './ui.tsx';

interface BrainView {
  mode: Mode;
  ai: { enabled: boolean; provider: string; budgetLeft: number; dailyCap: number; lastError: string | null };
  seats: SeatInfo[];
  limits: { minSeats: number; maxSeats: number; maxActiveLessons: number };
  running: string | null;
  sessions: CouncilSession[];
  lessons: Lesson[];
}
interface SessionView {
  session: CouncilSession;
  opinions: CouncilOpinion[];
  lesson: Lesson | null;
}

const RULING_WORD: Record<CouncilDecision, string> = { accepted: 'Accepted', rejected: 'Rejected', noted: 'Noted' };
const OUTCOME: Record<CouncilSession['status'], string> = { running: 'in session…', done: 'verdict reached', failed: 'did not finish' };

export function Brain() {
  const b = useLoad(() => api.get<BrainView>('/api/console/brain'), [], 30_000);
  const [openId, setOpenId] = useState<string | null>(null);
  const running = b.data?.running ?? null;
  useEffect(() => {
    // Arriving while the council is sitting: show that session rather than an idle page.
    if (running) setOpenId(id => id ?? running);
  }, [running]);

  if (!b.data) return <Loading error={b.error} onRetry={() => void b.reload()} />;
  const view = b.data;
  const nameOf = (id: string) => view.seats.find(s => s.id === id)?.name ?? id;

  return (
    <>
      <div>
        <h1 className="text-2xl font-semibold">Brain</h1>
        <p className="mt-1 max-w-2xl text-sm text-mute">
          One question, several points of view. Eight seats each read a different part of your records, and {view.limits.minSeats} to {view.limits.maxSeats} sit at a time. They answer separately, the
          Skeptic checks what they wrote against the records, and one verdict comes back for you to rule on. The council has no tools: it cannot record a payment, send a message or change a
          setting. Only you can.
        </p>
      </div>

      {!view.ai.enabled && (
        <Notice tone="warn">
          No AI provider is configured, so the council cannot sit. Set <code className="num">GEMINI_API_KEY</code>, or <code className="num">LLM_BASE_URL</code> and{' '}
          <code className="num">LLM_MODEL</code> for another provider, then restart. You can still see who would be seated for a question.
        </Notice>
      )}
      {view.ai.enabled && view.ai.lastError && <Notice tone="warn">The last AI call failed: {view.ai.lastError}</Notice>}

      <Convene
        view={view}
        onStarted={id => {
          setOpenId(id);
          void b.reload(true);
        }}
      />

      {openId && <SessionPanel key={openId} id={openId} seats={view.seats} onChanged={() => void b.reload(true)} onClose={() => setOpenId(null)} />}

      <Lessons view={view} nameOf={nameOf} onChanged={() => void b.reload(true)} />

      <Section title="The eight seats" aside={<span>each sees only its own records</span>}>
        <Table head={['Seat', 'Judges', 'Is handed', <span className="block text-right">Sat in</span>]}>
          {view.seats.map(s => (
            <tr key={s.id}>
              <td className="font-medium whitespace-nowrap">
                {s.name}
                {s.always && <span className="ml-2 text-[13px] font-normal text-gold">every session</span>}
              </td>
              <td className="max-w-xs text-mute">{s.lens.replace(/^You (judge one thing: |add no plan\. )/, '').replace(/^./, c => c.toUpperCase())}</td>
              <td className="max-w-md text-[13px] text-dim">{s.sees}</td>
              <td className="num text-right text-mute">{s.sessions}</td>
            </tr>
          ))}
        </Table>
        <p className="mt-3 max-w-3xl text-xs text-dim">
          Seats are kept apart on purpose. A seat that cannot see another seat's records cannot simply repeat its answer, so when two of them agree it means something — and it still is not
          proof, which is why the Skeptic checks every session against the records.
        </p>
      </Section>

      <Section title="Past sessions">
        {view.sessions.length === 0 ? (
          <Empty title="The council has not sat yet">Ask a question above. Each session is kept here with what every seat wrote and how you ruled.</Empty>
        ) : (
          <Table head={['When', 'Question', 'Seats', 'Outcome', 'Your ruling', '']}>
            {view.sessions.map(s => (
              <tr key={s.id} className={cx(s.id === openId && 'bg-panel')}>
                <td className="whitespace-nowrap text-mute">{dateTime(s.createdAt)}</td>
                <td className="max-w-sm">{s.question}</td>
                <td className="text-[13px] text-dim">{s.seats.map(nameOf).join(' · ')}</td>
                <td className={cx('whitespace-nowrap', s.status === 'failed' ? 'text-alarm' : 'text-mute')}>{OUTCOME[s.status]}</td>
                <td className={cx('whitespace-nowrap', s.decision === 'accepted' ? 'text-gold' : 'text-mute')}>{s.decision ? RULING_WORD[s.decision] : s.status === 'done' ? 'not yet' : '—'}</td>
                <td className="text-right">
                  <Button small onClick={() => setOpenId(s.id)}>
                    Open
                  </Button>
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Section>
    </>
  );
}

// ── convene ─────────────────────────────────────────────────────────────────
function Convene({ view, onStarted }: { view: BrainView; onStarted: (id: string) => void }) {
  const [question, setQuestion] = useState('');
  const [manual, setManual] = useState(false);
  const [chosen, setChosen] = useState<SeatId[]>([]);
  const [plan, setPlan] = useState<RoutePlan | null>(null);
  const [planError, setPlanError] = useState<string | null>(null);
  const turn = useRef(0);
  const act = useAction();

  const domain = view.seats.filter(s => !s.always);
  const min = view.limits.minSeats - 1;
  const max = view.limits.maxSeats - 1;
  const q = question.trim();
  const manualOk = !manual || (chosen.length >= min && chosen.length <= max);
  const key = `${q}|${manual ? chosen.join(',') : 'router'}`;

  useEffect(() => {
    // Ask the server who would sit. It costs nothing: the router is rules, not a model.
    const mine = ++turn.current;
    if (q.length < 8 || !manualOk) {
      setPlan(null);
      setPlanError(null);
      return;
    }
    const timer = window.setTimeout(() => {
      api
        .post<RoutePlan>('/api/console/brain/route', manual ? { question: q, seats: chosen } : { question: q })
        .then(p => {
          if (turn.current === mine) {
            setPlan(p);
            setPlanError(null);
          }
        })
        .catch(err => {
          if (turn.current === mine) {
            setPlan(null);
            setPlanError(messageOf(err));
          }
        });
    }, 450);
    return () => window.clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, manualOk]);

  const nameOf = (id: string) => view.seats.find(s => s.id === id)?.name ?? id;
  const tooDear = plan !== null && view.ai.enabled && plan.calls > view.ai.budgetLeft;
  const busy = view.running !== null;

  return (
    <Section title="Ask the council" aside={view.ai.enabled ? <span>{`${view.ai.provider} · ${view.ai.budgetLeft} of ${view.ai.dailyCap} AI calls left today`}</span> : <span>AI off</span>}>
      <form
        className="max-w-3xl space-y-4"
        onSubmit={e => {
          e.preventDefault();
          void act.run(async () => {
            const out = await api.post<SessionView>('/api/console/brain/sessions', manual ? { question: q, seats: chosen } : { question: q });
            setQuestion('');
            setPlan(null);
            onStarted(out.session.id);
          });
        }}
      >
        <Field label="Your question" hint="Ask about a decision, not a lookup. The seats answer from your records as they stand right now.">
          <Textarea required minLength={8} maxLength={500} rows={2} className="min-h-16" value={question} onChange={e => setQuestion(e.target.value)} placeholder="Which overdue invoice should I chase first, and how hard?" />
        </Field>

        <fieldset className="space-y-2">
          <legend className="mb-1 text-[13px] text-mute">Who sits</legend>
          <label className="flex items-center gap-2 text-sm">
            <input type="radio" name="who" checked={!manual} onChange={() => setManual(false)} className="accent-[var(--color-gold)]" />
            Let the router choose from the question and the records
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="radio" name="who" checked={manual} onChange={() => setManual(true)} className="accent-[var(--color-gold)]" />
            I will choose {min} to {max} seats
          </label>
          {manual && (
            <div className="flex flex-wrap gap-x-5 gap-y-1.5 pt-1 pl-6">
              {domain.map(s => {
                const on = chosen.includes(s.id);
                return (
                  <label key={s.id} className={cx('flex items-center gap-2 text-sm', !on && chosen.length >= max && 'text-dim')} title={s.sees}>
                    <input
                      type="checkbox"
                      checked={on}
                      disabled={!on && chosen.length >= max}
                      onChange={() => setChosen(on ? chosen.filter(x => x !== s.id) : [...chosen, s.id])}
                      className="accent-[var(--color-gold)]"
                    />
                    {s.name}
                  </label>
                );
              })}
              <span className="text-sm text-dim">+ Skeptic, always</span>
            </div>
          )}
        </fieldset>

        {plan && (
          <div className="rounded-md border border-rule-strong bg-panel px-3 py-2.5 text-sm">
            <p className="text-mute">
              Would seat {plan.picks.length}, for {plan.calls} AI calls (one each, plus one for the verdict):
            </p>
            <ul className="mt-1.5 space-y-0.5">
              {plan.picks.map(p => (
                <li key={p.seat}>
                  <span className="font-medium text-bone">{nameOf(p.seat)}</span> <span className="text-dim">— {p.reason}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
        {manual && !manualOk && <p className="text-sm text-dim">Choose {min} to {max} seats to see what a session would cost.</p>}
        {planError && <Notice tone="error">{planError}</Notice>}
        {tooDear && <Notice tone="warn">That needs {plan!.calls} AI calls and only {view.ai.budgetLeft} are left today, so the session would not start. The count resets at midnight.</Notice>}
        {act.error && <Notice tone="error">{act.error}</Notice>}

        <div className="flex flex-wrap items-center gap-3">
          <Button type="submit" variant="primary" busy={act.busy} disabled={!view.ai.enabled || busy || q.length < 8 || !manualOk || tooDear}>
            Convene the council
          </Button>
          {busy && <span className="text-sm text-gold">The council is in session. One at a time.</span>}
        </div>
      </form>
    </Section>
  );
}

// ── one session ─────────────────────────────────────────────────────────────
function SessionPanel({ id, seats, onChanged, onClose }: { id: string; seats: SeatInfo[]; onChanged: () => void; onClose: () => void }) {
  const [view, setView] = useState<SessionView | null>(null);
  const [error, setError] = useState<string | null>(null);
  const status = view?.session.status ?? null;
  const changed = useRef(onChanged);
  changed.current = onChanged;

  const load = async () => {
    try {
      setView(await api.get<SessionView>(`/api/console/brain/sessions/${id}`));
      setError(null);
    } catch (err) {
      setError(messageOf(err));
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);
  useEffect(() => {
    // While the seats are answering, look again every second and a half.
    if (status !== 'running') return;
    const timer = window.setInterval(() => void load(), 1500);
    return () => {
      window.clearInterval(timer);
      changed.current(); // the session just closed: refresh the budget, the history and any suggested lesson
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  if (!view) {
    return (
      <Section title="Session">
        <Loading error={error} onRetry={() => void load()} />
      </Section>
    );
  }
  const { session, opinions, lesson } = view;
  const nameOf = (seat: string) => seats.find(s => s.id === seat)?.name ?? seat;
  const domain = opinions.filter(o => o.seat !== 'skeptic');
  const skeptic = opinions.find(o => o.seat === 'skeptic');

  return (
    <Section
      title={session.status === 'running' ? 'In session' : 'Session'}
      aside={
        <>
          <span>
            {dateTime(session.createdAt)} · seated by {session.pickedBy === 'router' ? 'the router' : 'you'}
          </span>
          {!session.livemode && <span className="text-test">built on test-mode records</span>}
          <Button small variant="ghost" onClick={onClose}>
            Close
          </Button>
        </>
      }
    >
      <div className="settle grid gap-6 lg:grid-cols-[220px_minmax(0,1fr)]">
        <SeatRing seats={seats} opinions={opinions} status={session.status} />
        <div className="min-w-0 space-y-4">
          <p className="text-lg leading-snug text-bone">{session.question}</p>

          <div className="grid gap-3 md:grid-cols-2">
            {domain.map(o => (
              <OpinionCard key={o.seat} name={nameOf(o.seat)} opinion={o} />
            ))}
          </div>
          {skeptic && <OpinionCard name="Skeptic" opinion={skeptic} skeptic />}

          {session.status === 'running' && <p className="text-sm text-mute">The verdict is written once every seat has answered.</p>}
          {session.status === 'failed' && <Notice tone="error">{session.error ?? 'This session did not finish.'} What the seats managed to write is kept above.</Notice>}
          {session.status === 'done' && (
            <div className="rounded-md border border-gold/40 bg-panel p-4">
              <h3 className="text-[13px] tracking-wide text-gold uppercase">Verdict</h3>
              <pre className="mt-2 font-sans text-sm whitespace-pre-wrap text-bone">{session.verdict}</pre>
              <p className="mt-3 border-t border-rule pt-2 text-xs text-dim">
                Words only. Nothing above has been carried out, whatever it says: the council cannot act. If it tells you to do something, that is for you to do in the other tabs.
              </p>
            </div>
          )}

          {session.status === 'done' && <Ruling session={session} onSaved={s => setView({ ...view, session: s })} onChanged={onChanged} />}
          {lesson && lesson.status === 'proposed' && <SuggestedLesson lesson={lesson} onDone={() => void load().then(onChanged)} />}
        </div>
      </div>
    </Section>
  );
}

function OpinionCard({ name, opinion, skeptic }: { name: string; opinion: CouncilOpinion; skeptic?: boolean }) {
  const edge = opinion.status === 'failed' ? 'border-alarm/70' : opinion.status === 'thinking' ? 'border-gold' : opinion.status === 'done' ? (skeptic ? 'border-gold/60' : 'border-rule-strong') : 'border-rule';
  return (
    <article className={cx('rounded-md border-l-2 bg-panel px-3 py-2.5', edge)}>
      <header className="flex flex-wrap items-baseline justify-between gap-x-3">
        <h3 className="font-medium">{name}</h3>
        <span className={cx('text-[13px]', opinion.status === 'failed' ? 'text-alarm' : opinion.status === 'thinking' ? 'text-gold' : 'text-dim')}>
          {opinion.status === 'waiting' && 'waiting'}
          {opinion.status === 'thinking' && (
            <>
              <span aria-hidden className="pulse-dot mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-gold align-middle" />
              answering
            </>
          )}
          {opinion.status === 'done' && (skeptic ? 'checked the others' : 'answered')}
          {opinion.status === 'failed' && 'did not answer'}
        </span>
      </header>
      <p className="mt-0.5 text-[13px] text-dim">{skeptic ? 'Sits at every session.' : `Seated because ${opinion.reason}.`}</p>
      {opinion.body && <pre className="mt-2 font-sans text-sm whitespace-pre-wrap text-bone">{opinion.body}</pre>}
      {opinion.status === 'failed' && opinion.error && <p className="mt-2 text-sm break-words text-alarm">{opinion.error}</p>}
    </article>
  );
}

/**
 * The council as a picture: eight seats around one verdict. Lit seats are the
 * ones sitting at this session. It shows state the cards beside it already say
 * in words, so it is hidden from screen readers.
 */
function SeatRing({ seats, opinions, status }: { seats: SeatInfo[]; opinions: CouncilOpinion[]; status: CouncilSession['status'] }) {
  const c = 110;
  const r = 82;
  return (
    <svg viewBox="0 0 220 220" aria-hidden className="mx-auto w-full max-w-[220px] self-start">
      <circle cx={c} cy={c} r={r} className="fill-none stroke-rule" strokeDasharray="2 5" />
      {seats.map((s, i) => {
        const a = ((-90 + i * 45) * Math.PI) / 180;
        const x = c + r * Math.cos(a);
        const y = c + r * Math.sin(a);
        const o = opinions.find(op => op.seat === s.id);
        const st = o?.status;
        const lit = st === 'done' || st === 'thinking';
        return (
          <g key={s.id}>
            {o && <line x1={c} y1={c} x2={x} y2={y} className={cx(st === 'failed' ? 'stroke-alarm/50' : lit ? 'stroke-gold/50' : 'stroke-rule-strong')} strokeWidth={1} />}
            <circle
              cx={x}
              cy={y}
              r={15}
              strokeWidth={1.5}
              className={cx(
                st === 'thinking' && 'pulse-dot',
                !o ? 'fill-ink stroke-rule' : st === 'failed' ? 'fill-ink stroke-alarm' : lit ? 'fill-panel stroke-gold' : 'fill-panel stroke-rule-strong'
              )}
            />
            <text x={x} y={y + 3.5} textAnchor="middle" className={cx('num text-[10px]', !o ? 'fill-dim' : st === 'failed' ? 'fill-alarm' : lit ? 'fill-gold' : 'fill-mute')}>
              {s.name.slice(0, 2)}
            </text>
          </g>
        );
      })}
      <circle cx={c} cy={c} r={24} strokeWidth={1.5} className={cx(status === 'running' && 'pulse-dot', status === 'failed' ? 'fill-ink stroke-alarm' : status === 'done' ? 'fill-panel stroke-gold' : 'fill-ink stroke-rule-strong')} />
      <text x={c} y={c + 3.5} textAnchor="middle" className={cx('text-[9px] tracking-wide uppercase', status === 'failed' ? 'fill-alarm' : status === 'done' ? 'fill-gold' : 'fill-mute')}>
        {status === 'done' ? 'verdict' : status === 'failed' ? 'none' : 'sitting'}
      </text>
    </svg>
  );
}

function Ruling({ session, onSaved, onChanged }: { session: CouncilSession; onSaved: (s: CouncilSession) => void; onChanged: () => void }) {
  const [note, setNote] = useState(session.decisionNote ?? '');
  const act = useAction();
  const rule = (ruling: CouncilDecision) =>
    void act.run(async () => {
      const out = await api.post<{ session: CouncilSession }>(`/api/console/brain/sessions/${session.id}/rule`, { ruling, note: note.trim() || undefined });
      onSaved(out.session);
      onChanged();
    });
  return (
    <div className="space-y-2">
      <p className="text-sm text-mute">
        {session.decision ? (
          <>
            You ruled: <span className={session.decision === 'accepted' ? 'text-gold' : 'text-bone'}>{RULING_WORD[session.decision]}</span>
            {session.decidedAt ? ` · ${ago(session.decidedAt)}` : ''}. You can change it.
          </>
        ) : (
          'Your ruling. It carries out nothing — it is kept, and later verdicts are told how you ruled.'
        )}
      </p>
      <div className="flex flex-wrap items-end gap-2">
        <Field label="Why (optional)" className="min-w-[14rem] flex-1">
          <Input maxLength={400} value={note} onChange={e => setNote(e.target.value)} placeholder="I never discount a retainer." />
        </Field>
        <Button busy={act.busy} onClick={() => rule('accepted')}>
          Accept
        </Button>
        <Button busy={act.busy} onClick={() => rule('rejected')}>
          Reject
        </Button>
        <Button variant="ghost" busy={act.busy} onClick={() => rule('noted')}>
          Just note it
        </Button>
      </div>
      {act.error && <Notice tone="error">{act.error}</Notice>}
    </div>
  );
}

function SuggestedLesson({ lesson, onDone }: { lesson: Lesson; onDone: () => void }) {
  const [text, setText] = useState(lesson.text);
  const act = useAction();
  return (
    <div className="rounded-md border border-dashed border-rule-strong px-3 py-3">
      <p className="text-sm text-mute">
        The council suggests keeping this as a lesson. Until you keep it, it is only a suggestion: no seat is told it. Keeping it asks for your password, because every later session will
        be handed it.
      </p>
      <div className="mt-2 flex flex-wrap items-end gap-2">
        <Field label="Suggested lesson — reword it if you like" className="min-w-[14rem] flex-1">
          <Input maxLength={240} value={text} onChange={e => setText(e.target.value)} />
        </Field>
        <Button
          busy={act.busy}
          disabled={text.trim().length < 8}
          onClick={() =>
            void act.run(async () => {
              await api.post(`/api/console/brain/lessons/${lesson.id}/approve`, { text: text.trim() });
              onDone();
            })
          }
        >
          Keep this lesson
        </Button>
        <Button
          variant="ghost"
          busy={act.busy}
          onClick={() =>
            void act.run(async () => {
              await api.post(`/api/console/brain/lessons/${lesson.id}/dismiss`);
              onDone();
            })
          }
        >
          Dismiss
        </Button>
      </div>
      {act.error && <Notice tone="error" className="mt-2">{act.error}</Notice>}
    </div>
  );
}

// ── lessons ─────────────────────────────────────────────────────────────────
function Lessons({ view, nameOf, onChanged }: { view: BrainView; nameOf: (id: string) => string; onChanged: () => void }) {
  const [text, setText] = useState('');
  const [seat, setSeat] = useState('all');
  const act = useAction();
  const active = view.lessons.filter(l => l.status === 'active');
  const proposed = view.lessons.filter(l => l.status === 'proposed');
  const full = active.length >= view.limits.maxActiveLessons;
  const post = (path: string, body: unknown = {}) =>
    void act.run(async () => {
      await api.post(path, body);
      onChanged();
    });

  return (
    <Section title="Lessons" aside={<span>{`${active.length} of ${view.limits.maxActiveLessons} active`}</span>}>
      <p className="mb-3 max-w-2xl text-sm text-mute">
        How the council grows. A lesson is one standing note handed to the seats at every session. The council may suggest one; only you can make it active, and that asks for your
        password. The number is capped on purpose: better notes, not a longer and longer list.
      </p>

      {proposed.length > 0 && (
        <ul className="mb-4 space-y-2">
          {proposed.map(l => (
            <li key={l.id} className="flex flex-wrap items-center gap-x-3 gap-y-1.5 rounded-md border border-dashed border-rule-strong px-3 py-2 text-sm">
              <span className="text-[13px] text-dim">Suggested</span>
              <span className="min-w-[14rem] flex-1 break-words">{l.text}</span>
              <Button small busy={act.busy} disabled={full} onClick={() => post(`/api/console/brain/lessons/${l.id}/approve`)}>
                Keep
              </Button>
              <Button small variant="ghost" busy={act.busy} onClick={() => post(`/api/console/brain/lessons/${l.id}/dismiss`)}>
                Dismiss
              </Button>
            </li>
          ))}
        </ul>
      )}

      {active.length === 0 ? (
        <p className="text-sm text-dim">No lessons yet. Every session starts from the records and nothing else.</p>
      ) : (
        <ul className="divide-y divide-rule/70">
          {active.map(l => (
            <li key={l.id} className="flex flex-wrap items-center gap-x-3 gap-y-1 py-2 text-sm">
              <span className="min-w-[14rem] flex-1 break-words">{l.text}</span>
              <span className="text-[13px] text-dim">
                {l.seat === 'all' ? 'every seat' : `${nameOf(l.seat)} only`} · {l.source === 'council' ? 'suggested by the council, kept by you' : 'written by you'}
              </span>
              <Button small variant="ghost" busy={act.busy} onClick={() => post(`/api/console/brain/lessons/${l.id}/retire`)}>
                Retire
              </Button>
            </li>
          ))}
        </ul>
      )}

      <form
        className="mt-4 flex max-w-3xl flex-wrap items-end gap-2"
        onSubmit={e => {
          e.preventDefault();
          void act.run(async () => {
            await api.post('/api/console/brain/lessons', { text: text.trim(), seat });
            setText('');
            onChanged();
          });
        }}
      >
        <Field label="Add a lesson" className="min-w-[14rem] flex-1">
          <Input required minLength={8} maxLength={240} value={text} onChange={e => setText(e.target.value)} placeholder="Quote every price without GST." />
        </Field>
        <Field label="For">
          <Select value={seat} onChange={e => setSeat(e.target.value)}>
            <option value="all">Every seat</option>
            {view.seats.map(s => (
              <option key={s.id} value={s.id}>
                {s.name} only
              </option>
            ))}
          </Select>
        </Field>
        <Button type="submit" busy={act.busy} disabled={full || text.trim().length < 8}>
          Add
        </Button>
      </form>
      {full && <p className="mt-2 text-sm text-gold">All {view.limits.maxActiveLessons} places are taken. Retire a lesson to make room for another.</p>}
      {act.error && <Notice tone="error" className="mt-2">{act.error}</Notice>}
    </Section>
  );
}
