import { useCallback, useEffect, useRef, useState } from 'react';
import { Lock, TerminalSquare } from 'lucide-react';
import { api, messageOf, onStepUpRequired, onUnauthenticated } from '../lib/api.ts';
import type { AuthState, Mode } from '../../shared/types.ts';
import { Button, Dialog, Field, Input, Notice, cx } from './ui.tsx';
import { Brain } from './Brain.tsx';
import { Markets } from './Markets.tsx';
import { Network } from './Network.tsx';
import { Ops } from './Ops.tsx';
import { Overview } from './Overview.tsx';
import { Payouts } from './Payouts.tsx';
import { Pipeline } from './Pipeline.tsx';
import { Receive } from './Receive.tsx';
import { Store } from './Store.tsx';
import { Terminal } from './Terminal.tsx';
import { TABS } from './tabs.ts';
import type { TabId } from './tabs.ts';

function tabFromHash(): TabId {
  const h = window.location.hash.replace(/^#\/?/, '');
  return (TABS.find(t => t.id === h)?.id ?? 'overview') as TabId;
}

export default function ConsoleApp() {
  const [auth, setAuth] = useState<AuthState | null>(null);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      setAuth(await api.get<AuthState>('/api/auth/me'));
      setError(null);
    } catch (err) {
      setError(messageOf(err));
    }
  }, []);

  useEffect(() => {
    void refresh();
    onUnauthenticated(() => void refresh());
    return () => onUnauthenticated(null);
  }, [refresh]);

  if (error && !auth) {
    return (
      <Centered>
        <Notice tone="error">{error}</Notice>
        <Button className="mt-4" onClick={() => void refresh()}>
          Try again
        </Button>
      </Centered>
    );
  }
  if (!auth) return null;
  if (!auth.configured) return <SetupNeeded problems={auth.problems} />;
  if (!auth.authenticated) return <SignIn totp={auth.totpRequired} onDone={refresh} />;
  return <Shell auth={auth} onSignedOut={refresh} />;
}

function Centered({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center p-6">
      <div className="w-full max-w-md">{children}</div>
    </div>
  );
}

function Brand({ sub }: { sub?: string }) {
  return (
    <div className="flex items-center gap-2.5">
      <span aria-hidden className="grid h-7 w-7 place-items-center rounded border border-gold/50 text-gold">
        ◆
      </span>
      <span className="font-semibold tracking-wide">YABBAI FLASH</span>
      {sub && <span className="text-sm text-dim">{sub}</span>}
    </div>
  );
}

function SetupNeeded({ problems }: { problems: string[] }) {
  return (
    <Centered>
      <Brand />
      <h1 className="mt-8 text-2xl font-semibold">The console is locked until a password is set</h1>
      <p className="mt-3 text-mute">
        There is no default or factory password. Nobody can sign in — including you — until the server has one.
      </p>
      <ol className="mt-5 list-decimal space-y-2 pl-5 text-sm text-bone">
        <li>
          On your computer, in the project folder, run <code className="num text-gold">npm run setup</code>. It asks for a password and prints two lines.
        </li>
        <li>
          Add those lines (<code className="num">DIRECTOR_PASSWORD_HASH</code> and <code className="num">TOTP_SECRET</code>) to your host's environment variables or secrets panel.
        </li>
        <li>Restart the app and reload this page.</li>
      </ol>
      {problems.map((p, i) => (
        <Notice key={i} tone="warn" className="mt-4">
          {p}
        </Notice>
      ))}
    </Centered>
  );
}

function SignIn({ totp, onDone }: { totp: boolean; onDone: () => Promise<void> }) {
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.post('/api/auth/login', { password, ...(totp ? { totp: code } : {}) });
      await onDone();
    } catch (err) {
      setError(messageOf(err));
      setCode('');
    } finally {
      setBusy(false);
    }
  }

  return (
    <Centered>
      <Brand />
      <h1 className="mt-8 text-2xl font-semibold">Sign in</h1>
      <form onSubmit={submit} className="mt-5 space-y-4">
        <Field label="Director password">
          <Input type="password" autoComplete="current-password" autoFocus required value={password} onChange={e => setPassword(e.target.value)} />
        </Field>
        {totp && (
          <Field label="Authenticator code" hint="The 6-digit code from your authenticator app.">
            <Input inputMode="numeric" autoComplete="one-time-code" pattern="[0-9 ]{6,7}" maxLength={7} required value={code} onChange={e => setCode(e.target.value)} className="num tracking-[0.3em]" />
          </Field>
        )}
        {error && <Notice tone="error">{error}</Notice>}
        <Button type="submit" variant="primary" busy={busy} className="w-full">
          Sign in
        </Button>
      </form>
      <p className="mt-6 text-xs text-dim">Sessions last 12 hours and end after 2 hours of inactivity. Repeated wrong attempts lock sign-in.</p>
    </Centered>
  );
}

/** Asks for the password again before a sensitive action. Resolves true once confirmed. */
function StepUpDialog({ totp, onResult }: { totp: boolean; onResult: (ok: boolean) => void }) {
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  return (
    <Dialog title="Confirm it's you" onClose={() => onResult(false)}>
      <p className="mb-4 text-sm text-mute">
        This action changes how money is recorded or received, where a link points, or what the council is told at every session, so it needs your password again. The confirmation lasts 5
        minutes.
      </p>
      <form
        className="space-y-4"
        onSubmit={async e => {
          e.preventDefault();
          setBusy(true);
          setError(null);
          try {
            await api.post('/api/auth/stepup', { password, ...(totp ? { totp: code } : {}) });
            onResult(true);
          } catch (err) {
            setError(messageOf(err));
          } finally {
            setBusy(false);
          }
        }}
      >
        <Field label="Director password">
          <Input type="password" autoComplete="current-password" required value={password} onChange={e => setPassword(e.target.value)} />
        </Field>
        {totp && (
          <Field label="Authenticator code" hint="Use a fresh code — each one works once.">
            <Input inputMode="numeric" autoComplete="one-time-code" maxLength={7} required value={code} onChange={e => setCode(e.target.value)} className="num tracking-[0.3em]" />
          </Field>
        )}
        {error && <Notice tone="error">{error}</Notice>}
        <div className="flex justify-end gap-2">
          <Button onClick={() => onResult(false)}>Cancel</Button>
          <Button type="submit" variant="primary" busy={busy}>
            Confirm
          </Button>
        </div>
      </form>
    </Dialog>
  );
}

function Shell({ auth, onSignedOut }: { auth: AuthState; onSignedOut: () => Promise<void> }) {
  const [tab, setTab] = useState<TabId>(tabFromHash);
  const [mode, setMode] = useState<Mode | null>(null);
  const [terminal, setTerminal] = useState(false);
  const [stepUp, setStepUp] = useState(false);
  const stepUpResolve = useRef<((ok: boolean) => void) | null>(null);

  useEffect(() => {
    // The mode badge must be right on every tab, not only after Overview has loaded.
    api
      .get<{ mode: Mode }>('/api/public/site')
      .then(s => setMode(s.mode))
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    const onHash = () => setTab(tabFromHash());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  useEffect(() => {
    onStepUpRequired(
      () =>
        new Promise<boolean>(resolve => {
          stepUpResolve.current = resolve;
          setStepUp(true);
        })
    );
    return () => onStepUpRequired(null);
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (e.key === '`' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(t?.tagName ?? '')) {
        e.preventDefault();
        setTerminal(v => !v);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const go = useCallback((id: TabId) => {
    window.location.hash = `/${id}`;
    setTab(id);
    window.scrollTo({ top: 0 });
  }, []);

  async function signOut() {
    try {
      await api.post('/api/auth/logout');
    } finally {
      await onSignedOut();
    }
  }

  return (
    <div className="min-h-screen">
      {mode === 'test' && (
        <div className="bg-test/15 px-4 py-1.5 text-center text-[13px] text-test">Test mode. Payments here use test cards or devnet coins — none of it is real money.</div>
      )}
      <header className="sticky top-0 z-40 border-b border-rule bg-ink/95 backdrop-blur">
        <div className="mx-auto flex max-w-[1280px] flex-wrap items-center gap-x-6 gap-y-1.5 px-5 py-2.5">
          <Brand />
          <nav aria-label="Console sections" className="order-last -mx-1 flex w-full gap-1 overflow-x-auto md:order-none md:mx-0 md:w-auto md:flex-1">
            {TABS.map(t => (
              <button
                key={t.id}
                onClick={() => go(t.id)}
                aria-current={tab === t.id ? 'page' : undefined}
                className={cx('rounded px-3 py-1.5 text-sm whitespace-nowrap', tab === t.id ? 'bg-panel text-gold' : 'text-mute hover:text-bone')}
              >
                {t.label}
              </button>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-1.5">
            {mode && <span className={cx('num text-xs', mode === 'live' ? 'text-proof' : 'text-test')}>{mode === 'live' ? '● LIVE' : '● TEST'}</span>}
            <button title="Terminal (press `)" aria-label="Open terminal" onClick={() => setTerminal(v => !v)} className="rounded p-1.5 text-mute hover:text-bone">
              <TerminalSquare className="h-4 w-4" />
            </button>
            <button title="Sign out" aria-label="Sign out" onClick={() => void signOut()} className="rounded p-1.5 text-mute hover:text-bone">
              <Lock className="h-4 w-4" />
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1280px] space-y-8 px-5 py-7 pb-24">
        {tab === 'overview' && <Overview go={go} onMode={setMode} />}
        {tab === 'receive' && <Receive />}
        {tab === 'store' && <Store />}
        {tab === 'pipeline' && <Pipeline />}
        {tab === 'brain' && <Brain />}
        {tab === 'network' && <Network />}
        {tab === 'payouts' && <Payouts />}
        {tab === 'markets' && <Markets />}
        {tab === 'ops' && <Ops onSignedOut={onSignedOut} />}
      </main>

      {terminal && <Terminal onClose={() => setTerminal(false)} go={go} onSignOut={() => void signOut()} />}
      {stepUp && (
        <StepUpDialog
          totp={auth.totpRequired}
          onResult={ok => {
            setStepUp(false);
            stepUpResolve.current?.(ok);
            stepUpResolve.current = null;
          }}
        />
      )}
    </div>
  );
}
