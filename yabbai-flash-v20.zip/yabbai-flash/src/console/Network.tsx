import { useState } from 'react';
import { ExternalLink } from 'lucide-react';
import { api } from '../lib/api.ts';
import { ago } from '../lib/format.ts';
import type { LinkKind, NetworkLink } from '../../shared/types.ts';
import { Button, Dialog, Empty, Field, Input, Loading, Notice, Section, Select, Table, Textarea, cx, useAction, useLoad } from './ui.tsx';

interface NetworkView {
  links: NetworkLink[];
  realms: string[];
  kinds: LinkKind[];
  sweptAt: number | null;
  limits: { maxLinks: number; maxImport: number };
}

const KIND_WORD: Record<LinkKind, string> = { app: 'App', site: 'Site', dashboard: 'Dashboard', artifact: 'Claude artifact', doc: 'Document', repo: 'Code', tool: 'Tool' };

/** Only ever render a real web address as something clickable. The server refuses anything else; this is the second lock. */
const isWeb = (url: string) => /^https?:\/\//i.test(url);

export function Network() {
  const n = useLoad(() => api.get<NetworkView>('/api/console/network'), [], 60_000);
  const [editing, setEditing] = useState<NetworkLink | 'new' | null>(null);
  const [importing, setImporting] = useState(false);
  const [checked, setChecked] = useState<string | null>(null);
  const act = useAction();

  if (!n.data) return <Loading error={n.error} onRetry={() => void n.reload()} />;
  const { links, realms, sweptAt, limits, kinds } = n.data;
  const watched = links.filter(l => l.watch);
  const stopped = watched.filter(l => l.state === 'down' || l.state === 'error');

  return (
    <>
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Network</h1>
          <p className="mt-1 max-w-2xl text-sm text-mute">
            Every other app, site and document the business runs on, in one place. These are links and nothing more: whatever a linked page shows — a balance, a profit, a counter — is not read,
            counted or repeated here. The only money this console counts is on the Overview. Ask for a link to be watched and the sentinel knocks on its server every 15 minutes and tells you
            whether it answered.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => setImporting(true)}>Import a list</Button>
          <Button variant="primary" onClick={() => setEditing('new')}>
            Add a link
          </Button>
        </div>
      </div>

      {act.error && <Notice tone="error">{act.error}</Notice>}

      {links.length === 0 ? (
        <Empty
          title="No links yet"
          action={
            <Button variant="primary" onClick={() => setEditing('new')}>
              Add the first link
            </Button>
          }
        >
          Add your other apps, sites, dashboards and documents, grouped into realms such as “Agency”, “Products” or “Crypto watch”. Nothing is listed until you list it.
        </Empty>
      ) : (
        <>
          <Section
            title="Watch"
            aside={
              <>
                <span>
                  {watched.length === 0 ? 'no links are being watched' : `${watched.length} watched · last round ${sweptAt ? ago(sweptAt) : 'not yet run'}`}
                  {checked ? ` · ${checked}` : ''}
                </span>
                <Button
                  small
                  busy={act.busy}
                  disabled={watched.length === 0}
                  onClick={() =>
                    void act.run(async () => {
                      const out = await api.post<{ result: string | null; error: string | null }>('/api/console/network/check');
                      setChecked(out.error ?? out.result);
                      await n.reload(true);
                    })
                  }
                >
                  Knock now
                </Button>
              </>
            }
          >
            {stopped.length > 0 ? (
              <Notice tone="warn">
                Not answering: {stopped.map(l => l.name).join(', ')}. This console only watches them — fix each one where it is hosted.
              </Notice>
            ) : (
              <p className="max-w-2xl text-sm text-mute">
                {watched.length === 0
                  ? 'Tick “Watch” on a link to have its server checked. Private pages and Claude artifacts are better left unwatched: they answer the same whether or not they work.'
                  : 'Every watched link answered at the last round. “Answered” means a server replied — not that the app behind it works, and not that any figure on it is true.'}
              </p>
            )}
          </Section>

          {realms.map(realm => (
            <Section key={realm} title={realm} aside={<span>{links.filter(l => l.realm === realm).length} linked</span>}>
              <Table head={['Name', 'Kind', 'Address', 'Last answer', '']}>
                {links
                  .filter(l => l.realm === realm)
                  .map(l => (
                    <tr key={l.id}>
                      <td className="w-[38%]">
                        {isWeb(l.url) ? (
                          <a href={l.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-baseline gap-1.5 font-medium text-bone underline decoration-rule-strong underline-offset-4 hover:decoration-gold">
                            {l.name}
                            <ExternalLink className="h-3 w-3 shrink-0 self-center text-dim" aria-hidden />
                          </a>
                        ) : (
                          <span className="font-medium">{l.name}</span>
                        )}
                        {l.note && <span className="mt-0.5 block text-[13px] text-dim">{l.note}</span>}
                      </td>
                      <td className="w-[14%] whitespace-nowrap text-mute">{KIND_WORD[l.kind]}</td>
                      <td className="num w-[23%] max-w-[240px] truncate text-[13px] text-mute" title={l.url}>
                        {l.host}
                      </td>
                      <td className="w-[15%] whitespace-nowrap">
                        <Answer link={l} />
                      </td>
                      <td className="text-right whitespace-nowrap">
                        <Button small variant="ghost" onClick={() => setEditing(l)}>
                          Edit
                        </Button>
                        <Button
                          small
                          variant="ghost"
                          busy={act.busy}
                          onClick={() => {
                            if (!window.confirm(`Remove “${l.name}” from the network? The app itself is not touched.`)) return;
                            void act.run(async () => {
                              await api.del(`/api/console/network/${l.id}`);
                              await n.reload(true);
                            });
                          }}
                        >
                          Remove
                        </Button>
                      </td>
                    </tr>
                  ))}
              </Table>
            </Section>
          ))}
          <p className="max-w-3xl text-xs text-dim">
            {links.length} of {limits.maxLinks} links. Adding a link or changing where one points asks for your password, so a browser left signed in cannot quietly repoint something you
            trust. Removing one never does.
          </p>
        </>
      )}

      {editing && (
        <LinkDialog
          link={editing === 'new' ? null : editing}
          realms={realms}
          kinds={kinds}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            void n.reload(true);
          }}
        />
      )}
      {importing && (
        <ImportDialog
          max={limits.maxImport}
          onClose={() => setImporting(false)}
          onDone={() => {
            void n.reload(true);
          }}
        />
      )}
    </>
  );
}

function Answer({ link }: { link: NetworkLink }) {
  if (link.state === 'off') return <span className="text-dim">{link.watchable ? 'not watched' : 'cannot be watched'}</span>;
  if (link.state === 'unknown') return <span className="text-mute">not knocked on yet</span>;
  const when = link.lastCheckedAt ? ` · ${ago(link.lastCheckedAt)}` : '';
  // Deliberately not green: green on this console means verified money, and an answering server proves nothing of the kind.
  return (
    <span className={cx('inline-flex items-start gap-2', link.state === 'up' ? 'text-mute' : 'text-alarm')}>
      <span aria-hidden className={cx('mt-[7px] inline-block h-2 w-2 shrink-0 rounded-full', link.state === 'up' ? 'bg-bone' : 'bg-alarm')} />
      <span>
        {link.state === 'down' ? (link.lastError ?? 'no answer') : `answered ${link.lastStatus}`}
        <span className="text-dim">{when}</span>
      </span>
    </span>
  );
}

function LinkDialog({ link, realms, kinds, onClose, onSaved }: { link: NetworkLink | null; realms: string[]; kinds: LinkKind[]; onClose: () => void; onSaved: () => void }) {
  const [f, setF] = useState({
    name: link?.name ?? '',
    url: link?.url ?? '',
    realm: link?.realm ?? realms[0] ?? '',
    kind: (link?.kind ?? 'app') as LinkKind,
    note: link?.note ?? '',
    watch: link?.watch ?? false,
  });
  const act = useAction();
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF({ ...f, [k]: v });

  return (
    <Dialog title={link ? `Edit “${link.name}”` : 'Add a link'} onClose={onClose}>
      <form
        className="space-y-4"
        onSubmit={e => {
          e.preventDefault();
          void act.run(async () => {
            const body = { name: f.name.trim(), url: f.url.trim(), realm: f.realm.trim(), kind: f.kind, note: f.note.trim() || undefined, watch: f.watch };
            if (link) await api.put(`/api/console/network/${link.id}`, body);
            else await api.post('/api/console/network', body);
            onSaved();
          });
        }}
      >
        <Field label="Name">
          <Input required maxLength={80} value={f.name} onChange={e => set('name', e.target.value)} placeholder="Agency site" />
        </Field>
        <Field label="Address" hint="Must start with https://. Plain http is accepted only for an app on this computer, such as http://127.0.0.1:7860.">
          <Input required type="url" maxLength={500} className="num" value={f.url} onChange={e => set('url', e.target.value)} placeholder="https://" />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Realm" hint="The group it sits in.">
            <Input required maxLength={40} list="network-realms" value={f.realm} onChange={e => set('realm', e.target.value)} placeholder="Agency" />
            <datalist id="network-realms">
              {realms.map(r => (
                <option key={r} value={r} />
              ))}
            </datalist>
          </Field>
          <Field label="Kind">
            <Select value={f.kind} onChange={e => set('kind', e.target.value as LinkKind)}>
              {kinds.map(k => (
                <option key={k} value={k}>
                  {KIND_WORD[k]}
                </option>
              ))}
            </Select>
          </Field>
        </div>
        <Field label="Note (optional)" hint="What it is, in your words. Do not put a password or a key here.">
          <Input maxLength={240} value={f.note} onChange={e => set('note', e.target.value)} />
        </Field>
        <label className="flex items-start gap-2 text-sm">
          <input type="checkbox" checked={f.watch} onChange={e => set('watch', e.target.checked)} className="mt-1 accent-[var(--color-gold)]" />
          <span>
            Watch it
            <span className="block text-xs text-dim">One HEAD request every 15 minutes, to a public https address only. It reads no page and follows no redirect.</span>
          </span>
        </label>
        {act.error && <Notice tone="error">{act.error}</Notice>}
        <div className="flex justify-end gap-2">
          <Button onClick={onClose}>Cancel</Button>
          <Button type="submit" variant="primary" busy={act.busy}>
            {link ? 'Save' : 'Add link'}
          </Button>
        </div>
      </form>
    </Dialog>
  );
}

const SAMPLE = `[
  { "name": "Agency site", "url": "https://example.com", "realm": "Agency", "kind": "site", "watch": true },
  { "name": "Money map", "url": "https://example.com/doc", "realm": "Library", "kind": "doc", "note": "Planning notes" }
]`;

function ImportDialog({ max, onClose, onDone }: { max: number; onClose: () => void; onDone: () => void }) {
  const [text, setText] = useState('');
  const [result, setResult] = useState<{ added: number; skipped: number } | null>(null);
  const [parseError, setParseError] = useState<string | null>(null);
  const act = useAction();

  return (
    <Dialog title="Import a list of links" onClose={onClose} wide>
      <form
        className="space-y-4"
        onSubmit={e => {
          e.preventDefault();
          setResult(null);
          let parsed: unknown;
          try {
            parsed = JSON.parse(text);
          } catch {
            setParseError('That is not valid JSON. It should be a list in square brackets, like the example.');
            return;
          }
          setParseError(null);
          const list = Array.isArray(parsed) ? parsed : (parsed as { links?: unknown } | null)?.links;
          void act.run(async () => {
            setResult(await api.post<{ added: number; skipped: number }>('/api/console/network/import', { links: list }));
            onDone();
          });
        }}
      >
        <p className="text-sm text-mute">
          Paste a JSON list of up to {max} links. Each needs a name, an address, a realm and a kind; a note and “watch” are optional. Every row is checked before anything is saved, so one
          bad row means nothing is imported. Addresses already in the network are skipped, never overwritten.
        </p>
        <Field label="List">
          <Textarea required rows={10} spellCheck={false} className="num min-h-52 text-[13px]" value={text} onChange={e => setText(e.target.value)} placeholder={SAMPLE} />
        </Field>
        {parseError && <Notice tone="error">{parseError}</Notice>}
        {act.error && <Notice tone="error">{act.error}</Notice>}
        {result && (
          <Notice tone="info">
            {result.added} added{result.skipped ? `, ${result.skipped} skipped because the address was already there` : ''}.
          </Notice>
        )}
        <div className="flex justify-end gap-2">
          <Button onClick={onClose}>{result ? 'Done' : 'Cancel'}</Button>
          <Button type="submit" variant="primary" busy={act.busy} disabled={text.trim().length < 2}>
            Import
          </Button>
        </div>
      </form>
    </Dialog>
  );
}
