import { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { ExternalLink, RefreshCw } from 'lucide-react';
import { api } from '../lib/api.ts';
import { ago, aud, chunkAddress, countdown, shortDate } from '../lib/format.ts';
import type { RailState, StripeStatus, WalletStatus } from '../../shared/types.ts';
import { Button, CopyButton, Loading, Notice, Section, Table, cx, useAction, useLoad } from './ui.tsx';

interface WalletInfo {
  wallet: WalletStatus;
  rail: RailState;
  accepts: { sol: boolean; usdc: boolean };
}
interface Pinned {
  pinned: { bank: { payId: string | null; bsb: string | null; accountLast4: string | null; accountName: string | null } };
}

export function Payouts() {
  const st = useLoad(() => api.get<{ stripe: StripeStatus; webhookUrl: string }>('/api/console/payouts'), [], 60_000);
  const wl = useLoad(() => api.get<WalletInfo>('/api/console/wallet'), [], 60_000);
  const settings = useLoad(() => api.get<Pinned>('/api/console/settings'), []);
  const refresh = useAction();

  return (
    <>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Payouts</h1>
          <p className="mt-1 max-w-2xl text-sm text-mute">
            Where your money goes after a customer pays. This app never holds funds and has no button that moves them: card money is paid out to your bank by Stripe, and crypto goes straight
            from the customer's wallet into yours.
          </p>
        </div>
        <Button
          busy={refresh.busy}
          onClick={() =>
            void refresh.run(async () => {
              await Promise.all([api.get('/api/console/payouts?refresh=1'), api.get('/api/console/wallet?refresh=1')]);
              await Promise.all([st.reload(true), wl.reload(true)]);
            })
          }
        >
          <RefreshCw className="h-3.5 w-3.5" aria-hidden /> Refresh from Stripe and the chain
        </Button>
      </div>
      {refresh.error && <Notice tone="error">{refresh.error}</Notice>}

      <Section title="Card payments → your bank" aside={st.data && <span>checked {ago(st.data.stripe.fetchedAt)}</span>}>
        {!st.data ? <Loading error={st.error} onRetry={() => void st.reload()} /> : <StripePanel s={st.data.stripe} webhookUrl={st.data.webhookUrl} />}
      </Section>

      <Section title="Crypto → your Solana wallet" aside={wl.data && <span>checked {ago(wl.data.wallet.fetchedAt)}</span>}>
        {!wl.data ? <Loading error={wl.error} onRetry={() => void wl.reload()} /> : <WalletPanel info={wl.data} onChanged={() => void wl.reload(true)} />}
      </Section>

      <Section title="Bank transfer details shown on invoices">
        {!settings.data ? (
          <Loading error={settings.error} onRetry={() => void settings.reload()} />
        ) : (
          <BankPanel bank={settings.data.pinned.bank} />
        )}
      </Section>
    </>
  );
}

// ── Stripe ──────────────────────────────────────────────────────────────────
const REQUIREMENTS: Array<[RegExp, string]> = [
  [/^external_account/, 'Add the bank account Stripe should pay out to'],
  [/tos_acceptance/, "Accept Stripe's terms of service"],
  [/verification\.(additional_)?document/, 'Upload a photo of your ID'],
  [/business_profile\.url/, 'Add your business website or social profile'],
  [/business_profile\.support_phone/, 'Add a customer support phone number'],
  [/business_profile\.mcc/, 'Choose your industry'],
  [/business_profile\.product_description/, 'Describe what you sell'],
  [/business_type/, 'Choose your business type'],
  [/\.dob\./, 'Add your date of birth'],
  [/\.address\./, 'Add your address'],
  [/\.(first|last)_name/, 'Add your legal name'],
  [/id_number|tax_id/, 'Add your ABN or tax ID'],
  [/\.email/, 'Add your email address'],
  [/\.phone/, 'Add your phone number'],
];

function plainRequirements(keys: string[]): string[] {
  const out = new Set<string>();
  for (const key of keys) out.add(REQUIREMENTS.find(([re]) => re.test(key))?.[1] ?? key.replace(/[._]/g, ' '));
  return [...out];
}

function StripePanel({ s, webhookUrl }: { s: StripeStatus; webhookUrl: string }) {
  if (!s.configured) {
    return (
      <Notice tone="warn">
        Stripe is not connected, so customers cannot pay by card. Create a restricted API key in your Stripe Dashboard and set <code className="num">STRIPE_SECRET_KEY</code> in your hosting
        environment. The Ops tab has the full checklist.
      </Notice>
    );
  }
  const ready = s.chargesEnabled === true && s.payoutsEnabled === true;
  // The key may be barred from reading the account. That is "unknown", not "disabled".
  const unknown = s.reachable && s.chargesEnabled === null;
  const todo = plainRequirements(s.requirementsDue);
  return (
    <div className="space-y-5">
      {!s.reachable && <Notice tone="error">Stripe could not be reached: {s.error ?? 'unknown error'}</Notice>}
      {unknown && (
        <Notice tone="warn">
          Stripe answered, but this key is not allowed to read whether the account is activated{s.error ? ` (${s.error})` : ''}. Card checkout still works if the account is active. Confirm
          activation and the payout bank account in the Stripe Dashboard, or add the permission named in that message to the key.
        </Notice>
      )}
      {s.reachable && !ready && !unknown && (
        <div className="rounded-md border-l-2 border-alarm bg-panel px-4 py-3">
          <p className="font-medium text-alarm">This Stripe account cannot {s.chargesEnabled ? 'pay out to your bank' : 'take payments'} yet.</p>
          <p className="mt-1 max-w-2xl text-sm text-mute">
            Stripe will not move a cent until it has verified who you are and knows which bank account to pay. Finish these in the Stripe Dashboard — they are identity and banking details, so
            only you can enter them.
          </p>
          {todo.length > 0 && (
            <ul className="mt-3 list-disc space-y-1 pl-5 text-sm">
              {todo.map(t => (
                <li key={t}>{t}</li>
              ))}
            </ul>
          )}
          <a href="https://dashboard.stripe.com/" target="_blank" rel="noreferrer noopener" className="mt-3 inline-flex items-center gap-1 text-sm underline">
            Open the Stripe Dashboard <ExternalLink className="h-3 w-3" aria-hidden />
          </a>
        </div>
      )}
      {s.reachable && ready && <Notice tone="ok">Stripe can take card payments and pay them out to your bank.</Notice>}

      <dl className="grid gap-x-8 gap-y-4 sm:grid-cols-2 lg:grid-cols-4">
        <Fact label="Mode" value={s.mode === 'live' ? 'Live' : 'Test'} tone={s.mode === 'live' ? 'proof' : 'test'} />
        <Fact label="Available to pay out" value={s.availableCents === null ? '—' : aud(s.availableCents)} mono />
        <Fact label="On its way (pending)" value={s.pendingCents === null ? '—' : aud(s.pendingCents)} mono />
        <Fact
          label="Pays out to"
          value={s.payoutDestination ?? (unknown || !s.reachable ? 'Not readable with this key' : 'No bank account attached')}
          tone={s.payoutDestination || unknown || !s.reachable ? undefined : 'alarm'}
          note={s.payoutSchedule ?? undefined}
        />
      </dl>
      <p className="max-w-2xl text-xs text-dim">
        These two figures are read from Stripe a moment ago. They are Stripe's balance, not income: the same money is already counted once, as verified income, on the Overview.
      </p>

      <div>
        <h3 className="mb-2 text-sm font-medium">Payouts to your bank</h3>
        {s.payouts.length === 0 ? (
          <p className="text-sm text-dim">Stripe has not sent any payouts yet. The first one usually takes longer while Stripe verifies the account.</p>
        ) : (
          <Table head={['Arrives', <span className="block text-right">Amount</span>, 'Status', 'Speed']}>
            {s.payouts.map(p => (
              <tr key={p.id}>
                <td className="whitespace-nowrap text-mute">{shortDate(p.arrivalDate)}</td>
                <td className="num text-right">{aud(p.amountCents)}</td>
                <td className={cx(p.status === 'paid' && 'text-proof', p.status === 'failed' && 'text-alarm')}>
                  {p.status.replace(/_/g, ' ')}
                  {p.failureMessage && <span className="block text-xs text-alarm">{p.failureMessage}</span>}
                </td>
                <td className="text-mute">{p.method}</td>
              </tr>
            ))}
          </Table>
        )}
      </div>

      <div>
        <h3 className="mb-1 text-sm font-medium">Webhook address</h3>
        <p className="mb-2 max-w-2xl text-sm text-mute">
          Stripe calls this address the instant a customer pays. Add it in Stripe under Developers → Webhooks, then set the signing secret it gives you as{' '}
          <code className="num">STRIPE_WEBHOOK_SECRET</code>.
        </p>
        <div className="flex flex-wrap items-center gap-2">
          <code className="num min-w-0 truncate rounded border border-rule-strong bg-ink px-3 py-2 text-sm">{webhookUrl}</code>
          <CopyButton text={webhookUrl} />
        </div>
      </div>
    </div>
  );
}

function Fact({ label, value, note, mono, tone }: { label: string; value: string; note?: string; mono?: boolean; tone?: 'proof' | 'test' | 'alarm' }) {
  return (
    <div>
      <dt className="text-[13px] text-mute">{label}</dt>
      <dd className={cx('text-lg', mono && 'num', tone === 'proof' && 'text-proof', tone === 'test' && 'text-test', tone === 'alarm' && 'text-alarm')}>{value}</dd>
      {note && <dd className="text-xs text-dim">{note}</dd>}
    </div>
  );
}

// ── Solana wallet ───────────────────────────────────────────────────────────
function Address({ value }: { value: string }) {
  return (
    <p className="num flex flex-wrap gap-x-2 gap-y-1 text-lg leading-tight" aria-label={`Wallet address ${value}`}>
      {chunkAddress(value).map((part, i) => (
        <span key={i} className={i % 2 === 0 ? 'text-bone' : 'text-gold'}>
          {part}
        </span>
      ))}
    </p>
  );
}

function WalletPanel({ info, onChanged }: { info: WalletInfo; onChanged: () => void }) {
  const { wallet: w, rail, accepts } = info;
  if (!w.configured || !w.address) {
    return (
      <Notice tone="warn">
        No receiving wallet is set. Put your Solana address in <code className="num">SOLANA_RECEIVE_ADDRESS</code> in your hosting environment. It can only be set there, never from this
        console.
      </Notice>
    );
  }
  if (!w.addressValid) {
    return <Notice tone="error">The configured address is not a valid Solana address. Copy it again from your wallet and update SOLANA_RECEIVE_ADDRESS.</Notice>;
  }
  const proofWord = w.proofMethod === 'signature' ? 'a signed message' : w.proofMethod === 'onchain' ? 'a signed transaction' : null;
  return (
    <div className="space-y-5">
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
        <div>
          <p className="mb-2 text-[13px] text-mute">Every crypto payment is sent to this address</p>
          <Address value={w.address} />
          <div className="mt-3 flex flex-wrap items-center gap-3 text-sm">
            <CopyButton text={w.address} label="Copy address" />
            {w.explorerUrl && (
              <a href={w.explorerUrl} target="_blank" rel="noreferrer noopener" className="inline-flex items-center gap-1 text-mute underline hover:text-bone">
                View on Solscan <ExternalLink className="h-3 w-3" aria-hidden />
              </a>
            )}
            <span className="text-dim">{w.cluster === 'mainnet-beta' ? 'Mainnet' : w.cluster}</span>
          </div>
          <p className="mt-3 max-w-xl text-xs text-dim">
            Compare every group with your wallet app, not just the first and last. Scammers send dust from look-alike addresses that share the same opening and closing characters, hoping
            you copy theirs from your history. The address is pinned in the hosting environment, and nobody — including a signed-in attacker — can change it from here.
          </p>
        </div>
        <dl className="space-y-1.5 text-sm">
          <Row k="SOL in wallet" v={w.sol === null ? '—' : w.sol.toFixed(5)} />
          <Row k="USDC in wallet" v={w.usdc === null ? '—' : w.usdc.toFixed(2)} />
          <Row k="Worth about" v={w.audValueCents === null ? '—' : aud(w.audValueCents)} />
          <Row k="Customers can pay in" v={[accepts.sol && 'SOL', accepts.usdc && 'USDC'].filter(Boolean).join(' and ') || 'nothing'} />
          {w.error && <p className="pt-1 text-xs text-alarm">Chain lookup failed: {w.error}</p>}
          <p className="pt-1 text-xs text-dim">Read live from the chain. It includes anything already in the wallet, so it is not an income figure.</p>
        </dl>
      </div>

      {w.proven && proofWord && (
        <Notice tone="ok">
          You proved you control this wallet with {proofWord}
          {w.provenAt ? ` on ${shortDate(w.provenAt)}` : ''}. {rail.enabled ? 'Customers are offered crypto on pay pages.' : ''}
        </Notice>
      )}
      {w.proofMethod === 'override' && (
        <Notice tone="warn">
          This address is being used without proof because SOLANA_ADDRESS_UNPROVEN_OK is set. If a single character is wrong, payments are gone for good. Prove control below and remove that
          setting.
        </Notice>
      )}
      {!rail.enabled && rail.reason && <Notice tone={w.proven ? 'warn' : 'info'}>Crypto payments are off: {rail.reason}</Notice>}

      {(!w.proven || w.proofMethod === 'override') && <ProveWallet address={w.address} onProven={onChanged} />}
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-4">
      <dt className="text-mute">{k}</dt>
      <dd className="num text-right">{v}</dd>
    </div>
  );
}

interface InjectedWallet {
  publicKey?: { toString(): string } | null;
  connect(): Promise<unknown>;
  signMessage(message: Uint8Array, display?: string): Promise<{ signature: Uint8Array } | Uint8Array>;
}

function findWallets(): Array<{ name: string; provider: InjectedWallet }> {
  const w = window as unknown as Record<string, any>;
  const out: Array<{ name: string; provider: InjectedWallet }> = [];
  if (w.phantom?.solana?.isPhantom) out.push({ name: 'Phantom', provider: w.phantom.solana });
  if (w.solflare?.isSolflare) out.push({ name: 'Solflare', provider: w.solflare });
  if (w.backpack?.isBackpack) out.push({ name: 'Backpack', provider: w.backpack });
  if (out.length === 0 && typeof w.solana?.signMessage === 'function') out.push({ name: 'your browser wallet', provider: w.solana });
  return out;
}

function toBase64(bytes: Uint8Array): string {
  let s = '';
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s);
}

function ProveWallet({ address, onProven }: { address: string; onProven: () => void }) {
  const [wallets, setWallets] = useState(findWallets);
  const sign = useAction();
  const chain = useAction();
  const [mismatch, setMismatch] = useState<string | null>(null);
  const [proof, setProof] = useState<{ url: string; expiresAt: number; qr: string } | null>(null);
  const [now, setNow] = useState(Date.now());
  const done = useRef(false);
  const notify = useRef(onProven);
  notify.current = onProven;

  // Wallet extensions inject themselves a moment after the page loads.
  useEffect(() => {
    const t = window.setTimeout(() => setWallets(findWallets()), 800);
    return () => window.clearTimeout(t);
  }, []);

  // While a proof QR is on screen, ask the server whether the chain has seen it.
  useEffect(() => {
    if (!proof) return;
    done.current = false;
    const tick = window.setInterval(() => setNow(Date.now()), 1000);
    const poll = window.setInterval(async () => {
      if (done.current || Date.now() > proof.expiresAt) return;
      try {
        const out = await api.post<{ proven: boolean }>('/api/console/wallet/onchain-check');
        if (out.proven && !done.current) {
          done.current = true;
          setProof(null);
          notify.current();
        }
      } catch {
        /* keep polling; the next tick reports the same thing */
      }
    }, 6000);
    return () => {
      window.clearInterval(tick);
      window.clearInterval(poll);
    };
  }, [proof]);

  async function signWith(provider: InjectedWallet) {
    setMismatch(null);
    await sign.run(async () => {
      await provider.connect();
      const connected = provider.publicKey?.toString() ?? '';
      if (connected !== address) {
        setMismatch(connected);
        return;
      }
      const ch = await api.post<{ message: string }>('/api/console/wallet/challenge');
      const out = await provider.signMessage(new TextEncoder().encode(ch.message), 'utf8');
      const signature = out instanceof Uint8Array ? out : out.signature;
      await api.post('/api/console/wallet/verify', { signature: toBase64(signature) });
      onProven();
    });
  }

  return (
    <div className="rounded-md border border-gold/40 bg-panel p-4">
      <h3 className="font-medium text-gold">Prove this wallet is yours</h3>
      <p className="mt-1 max-w-2xl text-sm text-mute">
        One character wrong in an address and every payment goes to a stranger, permanently. So before any customer is shown this address, the app needs proof that you hold its key. Both ways
        below are done once. Neither gives this app any ability to spend from the wallet.
      </p>

      <div className="mt-4 grid gap-6 md:grid-cols-2">
        <div>
          <h4 className="text-sm font-medium">Sign a message (free)</h4>
          <p className="mt-1 text-sm text-mute">Open this page in the browser where your wallet extension lives, or inside your wallet app's built-in browser.</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {wallets.length === 0 ? (
              <p className="text-sm text-dim">No Solana wallet was found in this browser. Use the other option, or reopen this page where Phantom or Solflare is installed.</p>
            ) : (
              wallets.map(w => (
                <Button key={w.name} variant="primary" busy={sign.busy} onClick={() => void signWith(w.provider)}>
                  Sign with {w.name}
                </Button>
              ))
            )}
          </div>
          {mismatch !== null && (
            <Notice tone="error" className="mt-3">
              {mismatch ? (
                <>
                  The wallet you connected is <span className="num break-all">{mismatch}</span>, which is not the configured address. Switch to the right account in your wallet. If the connected
                  one is actually yours, then SOLANA_RECEIVE_ADDRESS is wrong and needs fixing in your hosting settings.
                </>
              ) : (
                'The wallet did not share its address. Unlock it and try again.'
              )}
            </Notice>
          )}
          {sign.error && (
            <Notice tone="error" className="mt-3">
              {sign.error}
            </Notice>
          )}
        </div>

        <div>
          <h4 className="text-sm font-medium">Or approve a tiny transfer to yourself</h4>
          <p className="mt-1 text-sm text-mute">
            Works from a phone or with a hardware wallet. You send 0.000001 SOL from the wallet to itself, so the only cost is the network fee — a fraction of a cent.
          </p>
          {!proof ? (
            <Button
              className="mt-3"
              busy={chain.busy}
              onClick={() =>
                void chain.run(async () => {
                  const out = await api.post<{ url: string; expiresAt: number }>('/api/console/wallet/onchain-proof');
                  const qr = await QRCode.toDataURL(out.url, { margin: 1, width: 440, errorCorrectionLevel: 'M' });
                  setProof({ url: out.url, expiresAt: out.expiresAt, qr });
                })
              }
            >
              Show the QR code
            </Button>
          ) : (
            <div className="mt-3 flex flex-wrap items-start gap-4">
              <img src={proof.qr} alt="QR code for the wallet proof transfer" width={176} height={176} className="rounded bg-white p-1" />
              <div className="min-w-0 flex-1 text-sm">
                <p>Scan with the wallet that holds the address above and approve.</p>
                <p className="mt-2 flex items-center gap-2 text-mute">
                  <span aria-hidden className="pulse-dot inline-block h-2 w-2 rounded-full bg-gold" />
                  {now > proof.expiresAt ? 'This code expired.' : `Watching the chain · ${countdown(proof.expiresAt - now)} left`}
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <CopyButton text={proof.url} label="Copy as link" />
                  <Button small variant="ghost" onClick={() => setProof(null)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          )}
          {chain.error && (
            <Notice tone="error" className="mt-3">
              {chain.error}
            </Notice>
          )}
        </div>
      </div>
    </div>
  );
}

// ── bank ────────────────────────────────────────────────────────────────────
function BankPanel({ bank }: { bank: Pinned['pinned']['bank'] }) {
  const has = bank.payId || (bank.bsb && bank.accountLast4);
  if (!has) {
    return (
      <p className="max-w-2xl text-sm text-mute">
        None. Invoices do not offer bank transfer. To add it, set <code className="num">BANK_PAYID</code>, or <code className="num">BANK_BSB</code>, <code className="num">BANK_ACCOUNT_NUMBER</code>{' '}
        and <code className="num">BANK_ACCOUNT_NAME</code>, in your hosting environment.
      </p>
    );
  }
  return (
    <div className="grid gap-6 md:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)]">
      <dl className="space-y-1.5 text-sm">
        {bank.payId && <Row k="PayID" v={bank.payId} />}
        {bank.accountName && <Row k="Account name" v={bank.accountName} />}
        {bank.bsb && <Row k="BSB" v={bank.bsb} />}
        {bank.accountLast4 && <Row k="Account number" v={`••••${bank.accountLast4}`} />}
      </dl>
      <p className="max-w-xl text-sm text-mute">
        Customers see these on an invoice, with the invoice number as the reference. They are pinned in the hosting environment so a break-in to this console cannot redirect a customer's
        transfer. The app cannot see your bank, so a transfer only shows up when you record it yourself under Receive, labelled as attested.
      </p>
    </div>
  );
}
