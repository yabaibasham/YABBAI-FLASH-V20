import { useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { api, messageOf } from '../lib/api.ts';
import { aud, dateTime } from '../lib/format.ts';
import type { CouncilOpinion, CouncilSession, HealthCheck, Invoice, Lead, Lesson, NetworkLink, Overview, Payment, SeatInfo } from '../../shared/types.ts';
import { TABS } from './tabs.ts';
import type { TabId } from './tabs.ts';
import { cx } from './ui.tsx';

type Tone = 'in' | 'out' | 'ok' | 'warn' | 'err';
interface Line {
  tone: Tone;
  text: string;
}

const HELP = [
  'status          verified income, what is owed, which payment methods are on',
  'health          the go-live checklist',
  'invoices        invoices still waiting for money',
  'payments        the last ten ledger entries and how each is proven',
  'leads           how many leads sit in each stage',
  'check           ask Stripe and the chain for new payments right now',
  'verify          re-check the audit log fingerprints',
  'brief           AI summary of where things stand',
  'ask <question>  ask the AI about your records',
  'council <q>     put a question to the council: several seats, one verdict (words only)',
  'lessons         the standing notes the council is handed',
  'network         linked apps by realm, and what each last answered',
  'go <section>    overview, receive, store, pipeline, brain, network, payouts, markets, ops',
  'clear · close · logout',
];

/** Commands the old app had. They invented money, so they are gone on purpose. */
const RETIRED = new Set(['sale', 'credit', 'fund', 'deposit', 'inject', 'mint', 'withdraw', 'payout', 'sweep', 'transfer', 'send', 'trade', 'settle']);

const PROOF: Record<Payment['rail'], string> = { stripe: 'Stripe ✓', solana: 'on-chain ✓', attested: 'attested by you' };

export function Terminal({ onClose, go, onSignOut }: { onClose: () => void; go: (id: TabId) => void; onSignOut: () => void }) {
  const [lines, setLines] = useState<Line[]>([{ tone: 'out', text: 'Read-only console. Type "help" for commands.' }]);
  const [value, setValue] = useState('');
  const [busy, setBusy] = useState(false);
  const [history, setHistory] = useState<string[]>([]);
  const [cursor, setCursor] = useState(-1);
  const log = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => {
    input.current?.focus();
  }, []);
  useEffect(() => {
    // Scroll the log itself; scrollIntoView would drag the whole page along.
    if (log.current) log.current.scrollTop = log.current.scrollHeight;
  }, [lines]);

  const print = (tone: Tone, ...text: string[]) => setLines(l => [...l, ...text.map(t => ({ tone, text: t }))].slice(-400));

  async function run(raw: string) {
    const line = raw.trim();
    if (!line) return;
    print('in', `> ${line}`);
    setHistory(h => [line, ...h.filter(x => x !== line)].slice(0, 50));
    setCursor(-1);
    const [cmd, ...rest] = line.split(/\s+/);
    const arg = rest.join(' ');
    const name = cmd.toLowerCase();

    if (RETIRED.has(name)) {
      print('warn', `"${name}" does not exist any more. Nothing typed here can add, move or withdraw money.`, 'Income appears only when Stripe or the Solana chain confirms a customer paid.');
      return;
    }

    setBusy(true);
    try {
      switch (name) {
        case 'help':
        case '?':
          print('out', ...HELP);
          break;
        case 'clear':
          setLines([]);
          break;
        case 'close':
        case 'exit':
          onClose();
          break;
        case 'logout':
          onSignOut();
          break;
        case 'go': {
          const tab = TABS.find(t => t.id === arg.toLowerCase());
          if (!tab) print('err', `No section called "${arg}". Try: ${TABS.map(t => t.id).join(', ')}`);
          else {
            go(tab.id);
            print('ok', `Opened ${tab.label}.`);
          }
          break;
        }
        case 'status': {
          const o = await api.get<Overview>('/api/console/overview');
          const t = o.totals;
          print(
            'out',
            `mode             ${o.mode.toUpperCase()}`,
            `verified income  ${aud(t.verifiedAllTimeCents)} all time · ${aud(t.verified30dCents)} in 30 days · ${aud(t.verified7dCents)} in 7 days`,
            `attested by you  ${aud(t.attestedAllTimeCents)}`,
            `owed to you      ${aud(t.receivableCents)} across ${t.openInvoices} open invoice${t.openInvoices === 1 ? '' : 's'}`,
            `card             ${o.rails.stripe.enabled ? 'on' : `off — ${o.rails.stripe.reason}`}`,
            `crypto           ${o.rails.solana.enabled ? 'on' : `off — ${o.rails.solana.reason}`}`,
            `bank transfer    ${o.rails.bank.enabled ? 'on' : 'off'}`
          );
          break;
        }
        case 'health': {
          const h = await api.get<{ checks: HealthCheck[] }>('/api/console/health');
          for (const c of h.checks) print(c.state === 'ok' ? 'ok' : c.state === 'error' ? 'err' : c.state === 'warn' ? 'warn' : 'out', `${c.state.toUpperCase().padEnd(5)} ${c.label} — ${c.detail}`);
          break;
        }
        case 'invoices': {
          const d = await api.get<{ invoices: Invoice[] }>('/api/console/invoices');
          const open = d.invoices.filter(i => i.storedStatus === 'open' && i.outstandingCents > 0);
          if (open.length === 0) print('out', 'No invoices are waiting for payment.');
          for (const i of open) print(i.status === 'overdue' ? 'warn' : 'out', `${i.number}  ${aud(i.outstandingCents).padStart(12)}  due ${i.dueDate}  ${i.clientName}${i.status === 'overdue' ? '  OVERDUE' : ''}`);
          break;
        }
        case 'payments': {
          const d = await api.get<{ payments: Payment[] }>('/api/console/payments');
          if (d.payments.length === 0) print('out', 'The ledger is empty. No payment has been verified yet.');
          for (const p of d.payments.slice(0, 10)) print(p.verified ? 'ok' : 'warn', `${dateTime(p.occurredAt).padEnd(18)} ${aud(p.amountCents).padStart(12)}  ${PROOF[p.rail].padEnd(16)} ${p.label ?? ''}`);
          break;
        }
        case 'leads': {
          const d = await api.get<{ leads: Lead[]; stages: string[] }>('/api/console/leads');
          if (d.leads.length === 0) print('out', 'No leads yet.');
          else print('out', d.stages.map(s => `${s} ${d.leads.filter(l => l.stage === s).length}`).join(' · '));
          break;
        }
        case 'check': {
          const out = await api.post<{ result: string | null; error: string | null }>('/api/console/reconcile');
          print(out.error ? 'err' : 'ok', out.error ?? out.result ?? 'Checked.');
          break;
        }
        case 'verify': {
          const v = await api.get<{ ok: boolean; entries: number; brokenAtSeq: number | null }>('/api/console/audit/verify');
          print(v.ok ? 'ok' : 'err', v.ok ? `Audit log intact: ${v.entries} entries.` : `Audit log BROKEN at entry #${v.brokenAtSeq}.`);
          break;
        }
        case 'brief':
          print('out', ...(await api.post<{ text: string }>('/api/console/ai/brief')).text.split('\n'));
          break;
        case 'ask':
          if (arg.length < 2) print('err', 'Usage: ask <your question>');
          else print('out', ...(await api.post<{ text: string }>('/api/console/ai/ask', { question: arg })).text.split('\n'));
          break;
        case 'council': {
          if (arg.length < 8) {
            print('err', 'Usage: council <your question, in a sentence>');
            break;
          }
          const started = await api.post<{ session: CouncilSession; opinions: CouncilOpinion[] }>('/api/console/brain/sessions', { question: arg });
          const names = Object.fromEntries((await api.get<{ seats: SeatInfo[] }>('/api/console/brain')).seats.map(s => [s.id, s.name]));
          print('out', `Seated: ${started.opinions.map(o => names[o.seat] ?? o.seat).join(', ')}. Waiting for them to answer…`);
          let view = started;
          // Up to four minutes; a slow local model can take a while over five answers.
          for (let i = 0; i < 160 && view.session.status === 'running'; i++) {
            await new Promise(r => window.setTimeout(r, 1500));
            view = await api.get<{ session: CouncilSession; opinions: CouncilOpinion[] }>(`/api/console/brain/sessions/${started.session.id}`);
          }
          for (const o of view.opinions) {
            print(o.status === 'failed' ? 'err' : 'in', `— ${names[o.seat] ?? o.seat}${o.status === 'failed' ? ` did not answer: ${o.error ?? ''}` : ''}`);
            if (o.body) print('out', ...o.body.split('\n'));
          }
          if (view.session.status === 'done') print('warn', ...(view.session.verdict ?? '').split('\n'), 'Words only: nothing has been carried out. Rule on it under Brain.');
          else if (view.session.status === 'failed') print('err', view.session.error ?? 'The session did not finish.');
          else print('warn', 'Still in session. Open Brain to watch it finish.');
          break;
        }
        case 'lessons': {
          const d = await api.get<{ lessons: Lesson[] }>('/api/console/brain');
          const active = d.lessons.filter(l => l.status === 'active');
          const waiting = d.lessons.filter(l => l.status === 'proposed').length;
          if (active.length === 0) print('out', 'No lessons. Every session starts from the records alone.');
          for (const l of active) print('out', `• ${l.text}${l.seat === 'all' ? '' : `  (${l.seat} only)`}`);
          if (waiting) print('warn', `${waiting} suggested by the council and waiting for you under Brain.`);
          break;
        }
        case 'network': {
          const d = await api.get<{ links: NetworkLink[]; realms: string[] }>('/api/console/network');
          if (d.links.length === 0) print('out', 'No links yet. Add them under Network.');
          for (const realm of d.realms) {
            print('in', realm);
            for (const l of d.links.filter(x => x.realm === realm)) {
              const answer = l.state === 'off' ? 'not watched' : l.state === 'unknown' ? 'not knocked on yet' : l.state === 'down' ? 'NO ANSWER' : `answered ${l.lastStatus}`;
              print(l.state === 'down' || l.state === 'error' ? 'err' : 'out', `  ${l.name.padEnd(34).slice(0, 34)} ${l.host.padEnd(30).slice(0, 30)} ${answer}`);
            }
          }
          break;
        }
        default:
          print('err', `Unknown command "${cmd}". Type "help".`);
      }
    } catch (err) {
      print('err', messageOf(err));
    } finally {
      setBusy(false);
    }
  }

  const tone: Record<Tone, string> = { in: 'text-gold', out: 'text-bone', ok: 'text-proof', warn: 'text-gold', err: 'text-alarm' };

  return (
    <div className="fixed inset-x-0 bottom-0 z-40 border-t border-rule-strong bg-deck shadow-[0_-12px_40px_rgba(0,0,0,0.6)]" role="region" aria-label="Terminal">
      <div className="mx-auto max-w-[1280px] px-5">
        <div className="flex items-center justify-between py-2">
          <p className="text-[13px] text-mute">Terminal · reads your records, cannot change money</p>
          <button aria-label="Close terminal" onClick={onClose} className="rounded p-1 text-mute hover:text-bone">
            <X className="h-4 w-4" />
          </button>
        </div>
        <div ref={log} className="num h-56 overflow-y-auto text-[13px] leading-relaxed" aria-live="polite" onClick={() => input.current?.focus()}>
          {lines.map((l, i) => (
            <div key={i} className={cx('whitespace-pre-wrap', tone[l.tone])}>
              {l.text || ' '}
            </div>
          ))}
        </div>
        <form
          className="flex items-center gap-2 border-t border-rule py-2"
          onSubmit={e => {
            e.preventDefault();
            if (busy) return;
            const v = value;
            setValue('');
            void run(v);
          }}
        >
          <span aria-hidden className="num text-gold">
            &gt;
          </span>
          <input
            ref={input}
            aria-label="Command"
            value={value}
            readOnly={busy}
            spellCheck={false}
            autoCapitalize="off"
            autoComplete="off"
            onChange={e => setValue(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'ArrowUp' && history.length) {
                e.preventDefault();
                const next = Math.min(cursor + 1, history.length - 1);
                setCursor(next);
                setValue(history[next]);
              } else if (e.key === 'ArrowDown') {
                e.preventDefault();
                const next = cursor - 1;
                setCursor(Math.max(next, -1));
                setValue(next >= 0 ? history[next] : '');
              } else if (e.key === 'Escape') onClose();
            }}
            className="num w-full bg-transparent text-[13px] text-bone outline-none placeholder:text-dim"
            placeholder={busy ? 'working…' : 'help'}
          />
        </form>
      </div>
    </div>
  );
}
