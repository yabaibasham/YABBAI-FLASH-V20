import { useMemo, useState } from 'react';
import { ExternalLink, Plus, RefreshCw, Trash2 } from 'lucide-react';
import { api } from '../lib/api.ts';
import { aud, dateTime, isoDay } from '../lib/format.ts';
import type { Draft, Invoice, Payment } from '../../shared/types.ts';
import { Button, CopyButton, Dialog, Empty, Field, Input, InvoiceStatusText, Loading, Money, Notice, Proof, Section, Table, Textarea, useAction, useLoad } from './ui.tsx';

interface InvoiceList {
  invoices: Invoice[];
  gstRegistered: boolean;
}
interface Suggestion {
  date: string;
  amountCents: number;
  description: string;
  invoiceId: string | null;
  invoiceNumber: string | null;
  reference: string;
  reason: string;
}
interface AttestPrefill {
  amountDollars: string;
  reference: string;
  date: string;
}

export function Receive() {
  const list = useLoad(() => api.get<InvoiceList>('/api/console/invoices'), [], 30_000);
  const pays = useLoad(() => api.get<{ payments: Payment[] }>('/api/console/payments'), [], 30_000);
  const site = useLoad(() => api.get<{ pinned: { publicBaseUrl: string } }>('/api/console/settings'), []);
  const [editing, setEditing] = useState<Invoice | 'new' | null>(null);
  const [viewing, setViewing] = useState<string | null>(null);
  const [attesting, setAttesting] = useState<{ invoice: Invoice; prefill?: AttestPrefill } | null>(null);
  const [checked, setChecked] = useState<string | null>(null);
  const recheck = useAction();

  const baseUrl = site.data?.pinned.publicBaseUrl ?? window.location.origin;
  const refresh = () => {
    void list.reload(true);
    void pays.reload(true);
  };

  if (!list.data) return <Loading error={list.error} onRetry={() => void list.reload()} />;
  const { invoices, gstRegistered } = list.data;

  return (
    <>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Receive</h1>
          <p className="mt-1 max-w-2xl text-sm text-mute">
            Send a customer a pay link. The invoice turns paid only when Stripe or the Solana chain confirms the money — there is no button here that marks one paid.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            busy={recheck.busy}
            onClick={() =>
              void recheck.run(async () => {
                const out = await api.post<{ result: string | null; error: string | null }>('/api/console/reconcile');
                setChecked(out.error ? `Check failed: ${out.error}` : (out.result ?? 'Checked.'));
                refresh();
              })
            }
          >
            <RefreshCw className="h-3.5 w-3.5" aria-hidden /> Check for payments now
          </Button>
          <Button variant="primary" onClick={() => setEditing('new')}>
            <Plus className="h-4 w-4" aria-hidden /> New invoice
          </Button>
        </div>
      </div>
      {(recheck.error || checked) && <Notice tone={recheck.error ? 'error' : 'info'}>{recheck.error ?? checked}</Notice>}

      <Section title="Invoices">
        {invoices.length === 0 ? (
          <Empty title="No invoices yet" action={<Button variant="primary" onClick={() => setEditing('new')}>Create the first invoice</Button>}>
            Write up what you did and what it costs, issue it, and send the customer the link. They can pay by card, in SOL or USDC, or by bank transfer — whichever you have switched on.
          </Empty>
        ) : (
          <Table head={['Invoice', 'Client', <span className="block text-right">Total</span>, <span className="block text-right">Owing</span>, 'Due', 'Status', '']}>
            {invoices.map(inv => (
              <tr key={inv.id}>
                <td className="num whitespace-nowrap">{inv.number}</td>
                <td className="max-w-[240px] truncate">{inv.clientName}</td>
                <td className="text-right">
                  <Money cents={inv.totalCents} />
                </td>
                <td className="text-right">
                  {inv.storedStatus === 'open' ? <Money cents={inv.outstandingCents} className={inv.outstandingCents === 0 ? 'text-dim' : undefined} /> : <span className="text-dim">—</span>}
                </td>
                <td className="whitespace-nowrap text-mute">{isoDay(inv.dueDate)}</td>
                <td className="whitespace-nowrap">
                  <InvoiceStatusText invoice={inv} />
                </td>
                <td className="text-right whitespace-nowrap">
                  <Button small aria-label={`View ${inv.number}`} onClick={() => setViewing(inv.id)}>
                    View
                  </Button>
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Section>

      <StatementHelper invoices={invoices} onRecord={(invoice, prefill) => setAttesting({ invoice, prefill })} />

      <Section title="Payments ledger" aside={<span>append-only — a payment can be refunded by Stripe, never edited here</span>}>
        {!pays.data ? (
          <Loading error={pays.error} onRetry={() => void pays.reload()} />
        ) : pays.data.payments.length === 0 ? (
          <Empty title="The ledger is empty">Every payment lands here with the proof that it happened: a Stripe payment ID, a Solana transaction, or your own attestation for a bank transfer.</Empty>
        ) : (
          <Table head={['When', 'For', 'From', <span className="block text-right">Amount</span>, <span className="block text-right">Refunded</span>, 'Proof']}>
            {pays.data.payments.map(p => (
              <tr key={p.id}>
                <td className="whitespace-nowrap text-mute">{dateTime(p.occurredAt)}</td>
                <td className="max-w-[260px] truncate">{p.label ?? '—'}</td>
                <td className="max-w-[200px] truncate text-mute">{p.payer ?? '—'}</td>
                <td className="text-right">
                  <Money cents={p.amountCents} />
                </td>
                <td className="text-right">{p.refundedCents > 0 ? <Money cents={-p.refundedCents} className="text-alarm" /> : <span className="text-dim">—</span>}</td>
                <td className="whitespace-nowrap">
                  <Proof payment={p} />
                  {p.proofUrl && (
                    <a href={p.proofUrl} target="_blank" rel="noreferrer noopener" className="ml-2 inline-flex items-center gap-1 text-mute underline hover:text-bone">
                      view <ExternalLink className="h-3 w-3" aria-hidden />
                    </a>
                  )}
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Section>

      {editing && (
        <InvoiceEditor
          invoice={editing === 'new' ? null : editing}
          gstRegistered={gstRegistered}
          onClose={() => setEditing(null)}
          onSaved={inv => {
            setEditing(null);
            setViewing(inv.id);
            refresh();
          }}
        />
      )}
      {viewing && (
        <InvoiceDetail
          id={viewing}
          baseUrl={baseUrl}
          onClose={() => setViewing(null)}
          onChanged={refresh}
          onEdit={inv => {
            setViewing(null);
            setEditing(inv);
          }}
          onAttest={invoice => {
            setViewing(null);
            setAttesting({ invoice });
          }}
        />
      )}
      {attesting && (
        <AttestDialog
          invoice={attesting.invoice}
          prefill={attesting.prefill}
          onClose={() => setAttesting(null)}
          onDone={() => {
            const id = attesting.invoice.id;
            setAttesting(null);
            setViewing(id);
            refresh();
          }}
        />
      )}
    </>
  );
}

// ── create / edit ───────────────────────────────────────────────────────────
interface Row {
  desc: string;
  qty: string;
  unit: string;
}

function toCents(text: string): number {
  const n = Number(text.trim());
  return Number.isFinite(n) ? Math.round(n * 100) : 0;
}

function InvoiceEditor({ invoice, gstRegistered, onClose, onSaved }: { invoice: Invoice | null; gstRegistered: boolean; onClose: () => void; onSaved: (inv: Invoice) => void }) {
  const [clientName, setClientName] = useState(invoice?.clientName ?? '');
  const [clientEmail, setClientEmail] = useState(invoice?.clientEmail ?? '');
  const [rows, setRows] = useState<Row[]>(
    invoice?.items.length ? invoice.items.map(i => ({ desc: i.desc, qty: String(i.qty), unit: (i.unitCents / 100).toFixed(2) })) : [{ desc: '', qty: '1', unit: '' }]
  );
  const [discount, setDiscount] = useState(invoice && invoice.discountCents > 0 ? (invoice.discountCents / 100).toFixed(2) : '');
  const [chargeGst, setChargeGst] = useState(invoice ? invoice.taxCents > 0 : gstRegistered);
  const [dueDate, setDueDate] = useState(invoice?.dueDate ?? '');
  const [note, setNote] = useState(invoice?.note ?? '');
  const save = useAction();

  const preview = useMemo(() => {
    const subtotal = rows.reduce((sum, r) => sum + (Number.parseInt(r.qty, 10) || 0) * toCents(r.unit), 0);
    const disc = Math.min(Math.max(0, toCents(discount)), subtotal);
    const tax = chargeGst && gstRegistered ? Math.round((subtotal - disc) / 10) : 0;
    return { subtotal, disc, tax, total: subtotal - disc + tax };
  }, [rows, discount, chargeGst, gstRegistered]);

  const setRow = (i: number, patch: Partial<Row>) => setRows(rs => rs.map((r, j) => (j === i ? { ...r, ...patch } : r)));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const payload = {
      clientName,
      clientEmail,
      items: rows.filter(r => r.desc.trim() !== '').map(r => ({ desc: r.desc, qty: Number.parseInt(r.qty, 10), unitDollars: r.unit })),
      discountDollars: discount,
      chargeGst: chargeGst && gstRegistered,
      dueDate,
      note,
    };
    const out = await save.run(() =>
      invoice ? api.put<{ invoice: Invoice }>(`/api/console/invoices/${invoice.id}`, payload) : api.post<{ invoice: Invoice }>('/api/console/invoices', payload)
    );
    if (out) onSaved(out.invoice);
  }

  return (
    <Dialog title={invoice ? `Edit ${invoice.number}` : 'New invoice'} onClose={onClose} wide>
      <form onSubmit={submit} className="space-y-5">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Client name">
            <Input required maxLength={120} value={clientName} onChange={e => setClientName(e.target.value)} />
          </Field>
          <Field label="Client email" hint="Optional. Pre-fills the card checkout.">
            <Input type="email" maxLength={254} value={clientEmail} onChange={e => setClientEmail(e.target.value)} />
          </Field>
        </div>

        <fieldset>
          <legend className="mb-2 text-[13px] text-mute">What you are charging for</legend>
          <div className="space-y-2">
            {rows.map((r, i) => (
              <div key={i} className="grid grid-cols-[minmax(0,1fr)_4.5rem_7rem_2rem] gap-2">
                <Input aria-label={`Line ${i + 1} description`} placeholder="Description" maxLength={200} value={r.desc} onChange={e => setRow(i, { desc: e.target.value })} />
                <Input aria-label={`Line ${i + 1} quantity`} inputMode="numeric" className="num text-right" value={r.qty} onChange={e => setRow(i, { qty: e.target.value.replace(/[^0-9]/g, '') })} />
                <Input aria-label={`Line ${i + 1} unit price in dollars`} inputMode="decimal" placeholder="0.00" className="num text-right" value={r.unit} onChange={e => setRow(i, { unit: e.target.value.replace(/[^0-9.]/g, '') })} />
                <button type="button" aria-label={`Remove line ${i + 1}`} disabled={rows.length === 1} onClick={() => setRows(rs => rs.filter((_, j) => j !== i))} className="grid place-items-center rounded text-dim hover:text-alarm disabled:opacity-30">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
          <Button small className="mt-2" onClick={() => setRows(rs => [...rs, { desc: '', qty: '1', unit: '' }])} disabled={rows.length >= 50}>
            <Plus className="h-3.5 w-3.5" aria-hidden /> Add a line
          </Button>
        </fieldset>

        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Discount ($)">
            <Input inputMode="decimal" placeholder="0.00" className="num" value={discount} onChange={e => setDiscount(e.target.value.replace(/[^0-9.]/g, ''))} />
          </Field>
          <Field label="Due date" hint="Blank means 7 days from today.">
            <Input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} />
          </Field>
          <div className="text-sm">
            <span className="mb-1 block text-[13px] text-mute">GST</span>
            {gstRegistered ? (
              <label className="flex items-center gap-2 py-2">
                <input type="checkbox" checked={chargeGst} onChange={e => setChargeGst(e.target.checked)} className="h-4 w-4 accent-[var(--color-gold)]" />
                Add 10% GST
              </label>
            ) : (
              <p className="py-2 text-xs text-dim">Not charged. The server only allows GST once you are registered and GST_REGISTERED is set.</p>
            )}
          </div>
        </div>

        <Field label="Note on the invoice" hint="Optional. Shown to the customer.">
          <Textarea maxLength={1000} value={note} onChange={e => setNote(e.target.value)} className="min-h-16" />
        </Field>

        <dl className="ml-auto max-w-xs space-y-1 text-sm">
          <Line k="Subtotal" v={aud(preview.subtotal)} />
          {preview.disc > 0 && <Line k="Discount" v={aud(-preview.disc)} />}
          {preview.tax > 0 && <Line k="GST 10%" v={aud(preview.tax)} />}
          <div className="flex justify-between border-t border-rule pt-1.5 text-base">
            <dt>Total</dt>
            <dd className="num">{aud(preview.total)} AUD</dd>
          </div>
        </dl>

        {save.error && <Notice tone="error">{save.error}</Notice>}
        <div className="flex items-center justify-between gap-3">
          <p className="text-xs text-dim">Saved as a draft. Nothing is sent and the pay link stays dead until you issue it.</p>
          <div className="flex gap-2">
            <Button onClick={onClose}>Cancel</Button>
            <Button type="submit" variant="primary" busy={save.busy}>
              Save draft
            </Button>
          </div>
        </div>
      </form>
    </Dialog>
  );
}

function Line({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-6">
      <dt className="text-mute">{k}</dt>
      <dd className="num">{v}</dd>
    </div>
  );
}

// ── detail ──────────────────────────────────────────────────────────────────
function InvoiceDetail({
  id,
  baseUrl,
  onClose,
  onChanged,
  onEdit,
  onAttest,
}: {
  id: string;
  baseUrl: string;
  onClose: () => void;
  onChanged: () => void;
  onEdit: (inv: Invoice) => void;
  onAttest: (inv: Invoice) => void;
}) {
  const d = useLoad(() => api.get<{ invoice: Invoice; payments: Payment[] }>(`/api/console/invoices/${id}`), [id], 15_000);
  const act = useAction();
  const [reminder, setReminder] = useState<Draft | null>(null);
  const [confirmVoid, setConfirmVoid] = useState(false);

  if (!d.data) {
    return (
      <Dialog title="Invoice" onClose={onClose} wide>
        <Loading error={d.error} onRetry={() => void d.reload()} />
      </Dialog>
    );
  }
  const { invoice: inv, payments } = d.data;
  const link = `${baseUrl}/pay/${inv.token}`;
  const owing = inv.storedStatus === 'open' && inv.outstandingCents > 0;
  const after = async () => {
    await d.reload(true);
    onChanged();
  };

  return (
    <Dialog title={`${inv.number} · ${inv.clientName}`} onClose={onClose} wide>
      <div className="space-y-5">
        <div className="flex flex-wrap items-baseline justify-between gap-3">
          <p className="text-lg">
            <InvoiceStatusText invoice={inv} />
            <span className="ml-3 text-sm text-mute">due {isoDay(inv.dueDate)}</span>
          </p>
          <p className="num text-2xl">{aud(inv.totalCents)}</p>
        </div>

        <table className="w-full text-sm">
          <tbody>
            {inv.items.map((it, i) => (
              <tr key={i} className="border-b border-rule/70">
                <td className="py-1.5 pr-3">{it.desc}</td>
                <td className="num py-1.5 pr-3 text-right text-mute">
                  {it.qty} × {aud(it.unitCents)}
                </td>
                <td className="num py-1.5 text-right">{aud(it.qty * it.unitCents)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <dl className="ml-auto max-w-xs space-y-1 text-sm">
          {inv.discountCents > 0 && <Line k="Discount" v={aud(-inv.discountCents)} />}
          {inv.taxCents > 0 && <Line k="GST 10%" v={aud(inv.taxCents)} />}
          {inv.storedStatus !== 'draft' && (
            <>
              <Line k="Verified payments" v={aud(inv.verifiedPaidCents)} />
              {inv.attestedPaidCents > 0 && <Line k="Attested by you" v={aud(inv.attestedPaidCents)} />}
              <div className="flex justify-between border-t border-rule pt-1.5">
                <dt>Still owing</dt>
                <dd className="num">{aud(inv.outstandingCents)}</dd>
              </div>
            </>
          )}
        </dl>

        {inv.storedStatus === 'draft' && (
          <Notice>This is a draft. The customer cannot see it, and it has no pay link until you issue it.</Notice>
        )}
        {inv.storedStatus === 'open' && (
          <div>
            <p className="mb-1 text-[13px] text-mute">Pay link — send this to the customer</p>
            <div className="flex flex-wrap items-center gap-2">
              <code className="num min-w-0 flex-1 truncate rounded border border-rule-strong bg-ink px-3 py-2 text-sm">{link}</code>
              <CopyButton text={link} label="Copy link" />
              <a href={link} target="_blank" rel="noreferrer noopener" className="inline-flex items-center gap-1 text-sm text-mute underline hover:text-bone">
                Preview <ExternalLink className="h-3 w-3" aria-hidden />
              </a>
            </div>
          </div>
        )}

        {payments.length > 0 && (
          <div>
            <p className="mb-1 text-[13px] text-mute">Payments on this invoice</p>
            <ul className="divide-y divide-rule/70 text-sm">
              {payments.map(p => (
                <li key={p.id} className="flex flex-wrap items-center justify-between gap-3 py-1.5">
                  <span className="text-mute">{dateTime(p.occurredAt)}</span>
                  <span className="num">{aud(p.amountCents)}</span>
                  <span>
                    <Proof payment={p} />
                    {p.proofUrl && (
                      <a href={p.proofUrl} target="_blank" rel="noreferrer noopener" className="ml-2 text-mute underline hover:text-bone">
                        view
                      </a>
                    )}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {reminder && (
          <div className="rounded-md border border-rule-strong bg-ink p-3">
            <div className="mb-2 flex items-center justify-between gap-2">
              <p className="text-[13px] text-mute">Reminder draft — nothing has been sent. Copy it into your own email.</p>
              <CopyButton text={reminder.body} />
            </div>
            <pre className="font-sans text-sm whitespace-pre-wrap text-bone">{reminder.body}</pre>
          </div>
        )}

        {act.error && <Notice tone="error">{act.error}</Notice>}

        <div className="flex flex-wrap justify-between gap-2 border-t border-rule pt-4">
          <div className="flex flex-wrap gap-2">
            {inv.storedStatus !== 'void' && inv.paidCents === 0 && (
              confirmVoid ? (
                <>
                  <Button variant="danger" busy={act.busy} onClick={() => void act.run(async () => { await api.post(`/api/console/invoices/${inv.id}/void`); setConfirmVoid(false); await after(); })}>
                    Yes, void {inv.number}
                  </Button>
                  <Button onClick={() => setConfirmVoid(false)}>Keep it</Button>
                </>
              ) : (
                <Button variant="ghost" onClick={() => setConfirmVoid(true)}>
                  Void invoice
                </Button>
              )
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {inv.storedStatus === 'draft' && (
              <>
                <Button onClick={() => onEdit(inv)}>Edit</Button>
                <Button variant="primary" busy={act.busy} onClick={() => void act.run(async () => { await api.post(`/api/console/invoices/${inv.id}/open`); await after(); })}>
                  Issue invoice
                </Button>
              </>
            )}
            {owing && (
              <>
                <Button busy={act.busy} onClick={() => void act.run(async () => { const out = await api.post<{ draft: Draft }>(`/api/console/ai/invoices/${inv.id}/followup`); setReminder(out.draft); })}>
                  Draft a reminder
                </Button>
                <Button onClick={() => onAttest(inv)}>Record a bank payment</Button>
              </>
            )}
          </div>
        </div>
      </div>
    </Dialog>
  );
}

// ── attest a bank payment ───────────────────────────────────────────────────
function AttestDialog({ invoice, prefill, onClose, onDone }: { invoice: Invoice; prefill?: AttestPrefill; onClose: () => void; onDone: () => void }) {
  const [amount, setAmount] = useState(prefill?.amountDollars ?? (invoice.outstandingCents / 100).toFixed(2));
  const [reference, setReference] = useState(prefill?.reference ?? '');
  const [date, setDate] = useState(prefill?.date ?? '');
  const [note, setNote] = useState('');
  const [seen, setSeen] = useState(false);
  const act = useAction();
  const [duplicate, setDuplicate] = useState(false);

  return (
    <Dialog title={`Record a bank payment on ${invoice.number}`} onClose={onClose}>
      <form
        className="space-y-4"
        onSubmit={async e => {
          e.preventDefault();
          const out = await act.run(() => api.post<{ duplicate: boolean }>(`/api/console/invoices/${invoice.id}/attest`, { amountDollars: amount, reference, note, date }));
          if (!out) return;
          if (out.duplicate) setDuplicate(true);
          else onDone();
        }}
      >
        <Notice tone="warn">
          This app cannot see your bank account. You are stating that you looked at your bank and the money is there. It is recorded as <strong>attested by you</strong>, shown in gold, and never
          counted as verified income.
        </Notice>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Amount that arrived ($)" hint={`${aud(invoice.outstandingCents)} is owing.`}>
            <Input required inputMode="decimal" className="num" value={amount} onChange={e => setAmount(e.target.value.replace(/[^0-9.]/g, ''))} />
          </Field>
          <Field label="Date it arrived" hint="Blank means today.">
            <Input type="date" value={date} onChange={e => setDate(e.target.value)} />
          </Field>
        </div>
        <Field label="Bank reference" hint="The receipt or transaction reference from your bank. The same reference can only be recorded once.">
          <Input required minLength={4} maxLength={120} value={reference} onChange={e => setReference(e.target.value)} />
        </Field>
        <Field label="Note">
          <Input maxLength={300} value={note} onChange={e => setNote(e.target.value)} />
        </Field>
        <label className="flex items-start gap-2 text-sm">
          <input type="checkbox" required checked={seen} onChange={e => setSeen(e.target.checked)} className="mt-1 h-4 w-4 accent-[var(--color-gold)]" />
          I have checked my bank and this money has arrived.
        </label>
        {duplicate && <Notice tone="warn">That bank reference is already recorded on this invoice, so nothing was added.</Notice>}
        {act.error && <Notice tone="error">{act.error}</Notice>}
        <div className="flex justify-end gap-2">
          <Button onClick={onClose}>Cancel</Button>
          <Button type="submit" variant="primary" busy={act.busy}>
            Record as attested
          </Button>
        </div>
      </form>
    </Dialog>
  );
}

// ── bank statement helper ───────────────────────────────────────────────────
function StatementHelper({ invoices, onRecord }: { invoices: Invoice[]; onRecord: (invoice: Invoice, prefill: AttestPrefill) => void }) {
  const [open, setOpen] = useState(false);
  const [csv, setCsv] = useState('');
  const [rows, setRows] = useState<Suggestion[] | null>(null);
  const act = useAction();

  return (
    <Section
      title="Match a bank statement"
      aside={
        <Button small aria-expanded={open} onClick={() => setOpen(v => !v)}>
          {open ? 'Hide' : 'Show'}
        </Button>
      }
    >
      <p className="max-w-2xl text-sm text-mute">
        Paste a CSV export from your bank and the app points out credits that mention an open invoice number. It only suggests. Each one still has to be recorded by you, one at a time, as an
        attested payment.
      </p>
      {open && (
        <div className="mt-4 space-y-3">
          <Textarea aria-label="Bank statement CSV" placeholder="Paste the CSV text here" value={csv} onChange={e => setCsv(e.target.value)} className="num min-h-32 text-xs" />
          <div className="flex flex-wrap items-center gap-3">
            <Button
              busy={act.busy}
              disabled={csv.trim() === ''}
              onClick={() =>
                void act.run(async () => {
                  const out = await api.post<{ suggestions: Suggestion[] }>('/api/console/statements/suggest', { csv });
                  setRows(out.suggestions);
                })
              }
            >
              Find matching credits
            </Button>
            <label className="text-sm text-mute">
              or choose a file{' '}
              <input
                type="file"
                accept=".csv,text/csv,text/plain"
                className="text-xs"
                onChange={async e => {
                  const f = e.target.files?.[0];
                  if (f) setCsv((await f.text()).slice(0, 1_400_000));
                }}
              />
            </label>
          </div>
          {act.error && <Notice tone="error">{act.error}</Notice>}
          {rows && rows.length === 0 && <Notice>No incoming credits were found in that statement.</Notice>}
          {rows && rows.length > 0 && (
            <Table head={['Date', <span className="block text-right">Credit</span>, 'Description', 'Suggestion', '']}>
              {rows.map((r, i) => {
                const inv = r.invoiceId ? invoices.find(x => x.id === r.invoiceId) : undefined;
                const fits = inv && inv.storedStatus === 'open' && r.amountCents <= inv.outstandingCents;
                return (
                  <tr key={i}>
                    <td className="num whitespace-nowrap text-mute">{r.date}</td>
                    <td className="text-right">
                      <Money cents={r.amountCents} />
                    </td>
                    <td className="max-w-[280px] truncate">{r.description}</td>
                    <td className={inv ? 'text-bone' : 'text-dim'}>{r.reason}</td>
                    <td className="text-right whitespace-nowrap">
                      {inv && fits && (
                        <Button small onClick={() => onRecord(inv, { amountDollars: (r.amountCents / 100).toFixed(2), reference: r.reference, date: r.date })}>
                          Record on {inv.number}
                        </Button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </Table>
          )}
        </div>
      )}
    </Section>
  );
}
