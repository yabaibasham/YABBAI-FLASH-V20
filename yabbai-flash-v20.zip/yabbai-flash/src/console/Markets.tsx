import { api } from '../lib/api.ts';
import { ago } from '../lib/format.ts';
import type { MarketRow } from '../../shared/types.ts';
import { Loading, Notice, Section, Table, cx, useLoad } from './ui.tsx';

interface Snapshot {
  rows: MarketRow[];
  venuesUp: Record<string, boolean>;
  fetchedAt: number;
  fees: Record<string, number>;
}

const price = (n: number) => (n >= 1000 ? n.toLocaleString('en-AU', { maximumFractionDigits: 0 }) : n >= 1 ? n.toFixed(2) : n.toFixed(4));
const bps = (n: number) => `${n > 0 ? '+' : n < 0 ? '−' : ''}${Math.abs(n).toFixed(1)}`;

export function Markets() {
  const m = useLoad(() => api.get<Snapshot>('/api/console/markets'), [], 20_000);
  if (!m.data) return <Loading error={m.error} onRetry={() => void m.reload()} />;
  const { rows, venuesUp, fees, fetchedAt } = m.data;
  const venues = Object.keys(venuesUp);
  const anyUp = venues.some(v => venuesUp[v]);
  const best = rows.filter(r => r.netBps !== null).sort((a, b) => (b.netBps ?? 0) - (a.netBps ?? 0))[0];

  return (
    <>
      <div>
        <h1 className="text-2xl font-semibold">Markets</h1>
        <p className="mt-1 max-w-2xl text-sm text-mute">
          A watch screen and nothing more. It reads public order books and shows the gap between exchanges after each side's taker fee. It places no trades, holds no exchange keys, and adds
          nothing to your income figures — only money a customer or an exchange actually pays you can do that.
        </p>
      </div>

      {!anyUp && <Notice tone="warn">None of the exchanges answered just now. Prices are left blank rather than guessed.</Notice>}

      <Section title="Cross-exchange spread, USD pairs" aside={<span>updated {ago(fetchedAt)}</span>}>
        <Table head={['Asset', ...venues.map(v => <span className="block text-right">{v} bid / ask</span>), 'Cheapest buy → dearest sell', <span className="block text-right">Gap</span>, <span className="block text-right">After fees</span>]}>
          {rows.map(r => (
            <tr key={r.symbol}>
              <td className="font-medium">{r.symbol}</td>
              {venues.map(v => {
                const q = r.venues.find(x => x.venue === v);
                return (
                  <td key={v} className="num text-right whitespace-nowrap">
                    {q ? (
                      <>
                        {price(q.bid)} <span className="text-dim">/</span> {price(q.ask)}
                      </>
                    ) : (
                      <span className="text-dim">—</span>
                    )}
                  </td>
                );
              })}
              <td className="whitespace-nowrap text-mute">{r.bestBuy && r.bestSell ? `${r.bestBuy.venue} → ${r.bestSell.venue}` : '—'}</td>
              <td className="num text-right text-mute">{r.grossBps === null ? '—' : bps(r.grossBps)}</td>
              <td className={cx('num text-right', r.netBps === null ? 'text-dim' : r.netBps > 0 ? 'text-proof' : 'text-mute')}>{r.netBps === null ? '—' : bps(r.netBps)}</td>
            </tr>
          ))}
        </Table>
        <p className="mt-3 max-w-3xl text-xs text-dim">
          Figures are basis points (100 = 1%). "After fees" subtracts the entry-tier taker fee on both legs:{' '}
          {Object.entries(fees)
            .map(([v, f]) => `${v} ${(f / 100).toFixed(2)}%`)
            .join(', ')}
          . It still leaves out withdrawal fees, transfer time, slippage and the USD/USDT difference on Binance, all of which make the real number worse.
        </p>
      </Section>

      <Section title="Reading this honestly">
        <div className="max-w-2xl space-y-3 text-sm text-mute">
          <p>
            {best && best.netBps !== null && best.netBps > 0
              ? `Right now ${best.symbol} shows ${bps(best.netBps)} basis points after fees. A gap like that usually closes in seconds and is taken by firms with capital already sitting on both exchanges.`
              : 'Right now every route is negative after fees, which is the normal state of these markets for a retail account.'}
          </p>
          <p>
            The old version of this screen rolled a random number for each "trade" and added the result to a profit counter. None of that was ever money. If you trade for real, the income shows
            up where the money lands — your exchange and your bank — and belongs in your own records and tax return, not here.
          </p>
        </div>
      </Section>
    </>
  );
}
