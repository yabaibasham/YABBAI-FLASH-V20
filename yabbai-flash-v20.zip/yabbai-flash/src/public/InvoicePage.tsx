import { useCallback, useEffect, useRef, useState } from 'react';
import { aud, isoDay, shortDate } from '../lib/format.ts';
import type { CryptoAsset, InvoiceStatus, PublicInvoiceView, PublicQuote } from '../../shared/types.ts';
import { Alert, CopyText, CryptoPay, Frame, Missing, PButton, Unreachable, api, isMissing, messageOf, usePoll } from './parts.tsx';

interface Status {
  status: InvoiceStatus;
  paidCents: number;
  outstandingCents: number;
  chain: 'none' | 'seen' | 'paid';
}

export function InvoicePage({ token }: { token: string }) {
  const base = `/api/public/invoice/${encodeURIComponent(token)}`;
  const [inv, setInv] = useState<PublicInvoiceView | null>(null);
  const shown = useRef(inv);
  shown.current = inv;
  const [fatal, setFatal] = useState<'missing' | 'unreachable' | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [chain, setChain] = useState<Status['chain']>('none');
  const [watching, setWatching] = useState(false);
  // Set when Stripe sends the customer back here after checkout.
  const [sessionId, setSessionId] = useState(() => new URLSearchParams(window.location.search).get('session_id'));

  const load = useCallback(async (): Promise<boolean> => {
    try {
      setInv(await api.get<PublicInvoiceView>(base));
      return true;
    } catch (err) {
      setFatal(isMissing(err) ? 'missing' : 'unreachable');
      return false;
    }
  }, [base]);

  const check = useCallback(async () => {
    try {
      const s = await api.get<Status>(`${base}/status${sessionId ? `?session_id=${encodeURIComponent(sessionId)}` : ''}`);
      setChain(s.chain);
      const cur = shown.current;
      if (cur && (cur.status !== s.status || cur.paidCents !== s.paidCents)) void load();
      if (s.status === 'paid' && sessionId) {
        window.history.replaceState(null, '', window.location.pathname);
        setSessionId(null);
      }
    } catch {
      /* a failed poll is retried on the next tick */
    }
  }, [base, sessionId, load]);

  useEffect(() => {
    // One check on arrival catches a payment that landed while the page was closed.
    void load().then(ok => (ok ? check() : undefined));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const payable = !!inv && (inv.status === 'open' || inv.status === 'part' || inv.status === 'overdue') && inv.outstandingCents > 0;
  // Quick while a payment is in flight, slow otherwise.
  usePoll(check, payable, watching || sessionId ? 4000 : 20_000);

  if (fatal === 'unreachable') return <Unreachable />;
  if (fatal) return <Missing title="This payment link is not valid">Check the link with whoever sent it to you. Links are long, so make sure none of it was cut off.</Missing>;
  if (!inv) return null;

  const assets: CryptoAsset[] = [...(inv.rails.usdc ? (['USDC'] as const) : []), ...(inv.rails.sol ? (['SOL'] as const) : [])];
  const anyRail = inv.rails.card || assets.length > 0 || !!inv.rails.bank;
  const isTaxInvoice = inv.gstRegistered && inv.taxCents > 0;

  async function payByCard() {
    setBusy(true);
    setError(null);
    try {
      const out = await api.post<{ url: string }>(`${base}/checkout`);
      window.location.assign(out.url);
    } catch (err) {
      setError(messageOf(err));
      setBusy(false);
    }
  }

  return (
    <Frame brand={inv.brandName} mode={inv.mode} support={inv.supportEmail}>
      <div className="grid gap-8 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
        {/* The document */}
        <article className="order-2 rounded-lg border border-paper-rule bg-sheet p-6 sm:p-8 lg:order-1">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h1 className="text-2xl font-semibold tracking-tight">{isTaxInvoice ? 'Tax invoice' : 'Invoice'}</h1>
              <p className="num mt-1 text-paper-mute">{inv.number}</p>
            </div>
            <dl className="text-right text-sm">
              {inv.issuedAt && (
                <div>
                  <dt className="inline text-paper-mute">Issued </dt>
                  <dd className="inline">{shortDate(inv.issuedAt)}</dd>
                </div>
              )}
              <div>
                <dt className="inline text-paper-mute">Due </dt>
                <dd className="inline">{isoDay(inv.dueDate)}</dd>
              </div>
            </dl>
          </div>

          <div className="mt-6 grid gap-4 text-sm sm:grid-cols-2">
            <div>
              <p className="text-paper-mute">From</p>
              <p className="font-medium">{inv.brandName}</p>
              {inv.abn && <p className="num text-paper-mute">ABN {inv.abn}</p>}
            </div>
            <div>
              <p className="text-paper-mute">Billed to</p>
              <p className="font-medium">{inv.clientName}</p>
            </div>
          </div>

          <table className="mt-6 w-full text-sm">
            <thead>
              <tr className="border-b border-navy text-left">
                <th className="py-2 font-medium">Description</th>
                <th className="py-2 pl-3 text-right font-medium">Qty</th>
                <th className="py-2 pl-3 text-right font-medium">Price</th>
                <th className="py-2 pl-3 text-right font-medium">Amount</th>
              </tr>
            </thead>
            <tbody>
              {inv.items.map((it, i) => (
                <tr key={i} className="border-b border-paper-rule align-top">
                  <td className="py-2 pr-3">{it.desc}</td>
                  <td className="num py-2 pl-3 text-right">{it.qty}</td>
                  <td className="num py-2 pl-3 text-right whitespace-nowrap">{aud(it.unitCents)}</td>
                  <td className="num py-2 pl-3 text-right whitespace-nowrap">{aud(it.qty * it.unitCents)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <dl className="mt-4 ml-auto max-w-xs space-y-1 text-sm">
            <Sum k="Subtotal" v={aud(inv.subtotalCents)} />
            {inv.discountCents > 0 && <Sum k="Discount" v={aud(-inv.discountCents)} />}
            {inv.taxCents > 0 && <Sum k="GST (10%)" v={aud(inv.taxCents)} />}
            <div className="flex justify-between border-t border-navy pt-1.5 text-base font-medium">
              <dt>Total (AUD)</dt>
              <dd className="num">{aud(inv.totalCents)}</dd>
            </div>
            {inv.paidCents > 0 && <Sum k="Paid" v={aud(-inv.paidCents)} />}
            {inv.paidCents > 0 && inv.outstandingCents > 0 && <Sum k="Still owing" v={aud(inv.outstandingCents)} />}
          </dl>

          {inv.note && <p className="mt-6 border-t border-paper-rule pt-4 text-sm whitespace-pre-wrap text-paper-mute">{inv.note}</p>}
          {!inv.gstRegistered && <p className="mt-4 text-xs text-paper-mute">No GST has been charged on this invoice.</p>}
        </article>

        {/* The action */}
        <aside className="order-1 lg:order-2">
          <div className="lg:sticky lg:top-6">
            {inv.status === 'paid' ? (
              <div className="settle rounded-lg border border-paid bg-[#e9f7f0] p-6">
                <p className="text-sm text-paid">Paid in full</p>
                <p className="num mt-1 text-4xl font-medium text-paid">{aud(inv.totalCents)}</p>
                <p className="mt-3 text-sm">Thank you. This page is your receipt — save the link or print it for your records.</p>
                <button type="button" className="mt-3 text-sm underline" onClick={() => window.print()}>
                  Print receipt
                </button>
              </div>
            ) : inv.status === 'void' ? (
              <div className="rounded-lg border border-paper-rule bg-sheet p-6">
                <p className="text-lg font-medium">This invoice was cancelled</p>
                <p className="mt-2 text-sm text-paper-mute">Nothing is owing on it. Please do not send a payment.</p>
              </div>
            ) : (
              <div className="rounded-lg border border-paper-rule bg-sheet p-6">
                <p className="text-sm text-paper-mute">
                  {inv.paidCents > 0 ? 'Still owing' : 'Amount due'}
                  {inv.status === 'overdue' && <span className="ml-2 text-[#8f1a2c]">overdue since {isoDay(inv.dueDate)}</span>}
                </p>
                <p className="num mt-1 text-4xl font-medium tracking-tight">{aud(inv.outstandingCents)}</p>
                <p className="num text-xs text-paper-mute">Australian dollars</p>

                {sessionId && (
                  <div className="mt-4">
                    <Alert tone="info">Confirming your card payment with Stripe. This takes a few seconds.</Alert>
                  </div>
                )}

                <div className="mt-5 space-y-3">
                  {inv.rails.card && (
                    <PButton busy={busy} onClick={() => void payByCard()}>
                      Pay {aud(inv.outstandingCents)} by card
                    </PButton>
                  )}
                  {assets.length > 0 && (
                    <CryptoPay
                      assets={assets}
                      support={inv.supportEmail}
                      seen={chain === 'seen'}
                      getQuote={async asset => {
                        const q = await api.post<PublicQuote>(`${base}/quote`, { asset });
                        setWatching(true);
                        return q;
                      }}
                    />
                  )}
                  {error && <Alert>{error}</Alert>}
                  {!anyRail && (
                    <Alert tone="info">
                      Online payment is not switched on for this invoice yet.
                      {inv.supportEmail ? (
                        <>
                          {' '}
                          Email <a className="underline" href={`mailto:${inv.supportEmail}`}>{inv.supportEmail}</a> to arrange payment.
                        </>
                      ) : (
                        ' Contact the sender to arrange payment.'
                      )}
                    </Alert>
                  )}
                </div>

                {inv.rails.bank && (
                  <details className="mt-5 border-t border-paper-rule pt-4 text-sm" open={!inv.rails.card && assets.length === 0}>
                    <summary className="cursor-pointer font-medium">Pay by bank transfer</summary>
                    <dl className="mt-3 space-y-1.5">
                      {inv.rails.bank.payId && <Bank k="PayID" v={inv.rails.bank.payId} />}
                      {inv.rails.bank.accountName && <Bank k="Account name" v={inv.rails.bank.accountName} />}
                      {inv.rails.bank.bsb && <Bank k="BSB" v={inv.rails.bank.bsb} />}
                      {inv.rails.bank.accountNumber && <Bank k="Account number" v={inv.rails.bank.accountNumber} />}
                      <Bank k="Reference" v={inv.rails.bank.reference} />
                      <Bank k="Amount" v={aud(inv.outstandingCents)} />
                    </dl>
                    <p className="mt-3 text-xs text-paper-mute">
                      Use the reference exactly so the payment can be matched. Bank transfers are checked by a person, so this page updates after {inv.brandName} confirms it — usually within
                      one business day.
                    </p>
                  </details>
                )}
              </div>
            )}
          </div>
        </aside>
      </div>
    </Frame>
  );
}

function Sum({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-6">
      <dt className="text-paper-mute">{k}</dt>
      <dd className="num">{v}</dd>
    </div>
  );
}

function Bank({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex items-baseline justify-between gap-4">
      <dt className="text-paper-mute">{k}</dt>
      <dd className="flex items-baseline gap-3">
        <span className="num">{v}</span>
        <CopyText text={v} label="Copy" />
      </dd>
    </div>
  );
}
