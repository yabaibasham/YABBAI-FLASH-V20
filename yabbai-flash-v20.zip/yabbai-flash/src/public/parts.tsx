import { useEffect, useRef, useState } from 'react';
import type { ButtonHTMLAttributes, ReactNode } from 'react';
import QRCode from 'qrcode';
import { ApiError, api, messageOf } from '../lib/api.ts';
import { aud, chunkAddress, countdown } from '../lib/format.ts';
import type { CryptoAsset, Mode, PublicQuote } from '../../shared/types.ts';

export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

/** The page every customer sees: quiet paper, the seller's name, and who actually handles the money. */
export function Frame({ brand, mode, children, support, payments = true }: { brand: string; mode?: Mode; support?: string | null; payments?: boolean; children: ReactNode }) {
  return (
    <div className="min-h-screen">
      {mode === 'test' && payments && <div className="bg-[#efe7ff] px-4 py-2 text-center text-sm text-[#4b2ba3]">Test mode — this page takes test payments only. No real money moves.</div>}
      <header className="border-b border-paper-rule bg-sheet">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-5 py-4">
          <p className="text-lg font-semibold tracking-tight">{brand}</p>
          {support && (
            <a href={`mailto:${support}`} className="text-sm text-paper-mute underline">
              {support}
            </a>
          )}
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-5 py-8">{children}</main>
      {payments && (
        <footer className="mx-auto max-w-5xl px-5 pb-10 text-xs text-paper-mute">
          Card payments are handled by Stripe on Stripe's own page; {brand} never sees your card number. Crypto payments go directly from your wallet to {brand}'s wallet.
        </footer>
      )}
    </div>
  );
}

export function PButton({ tone = 'primary', busy, className, children, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { tone?: 'primary' | 'plain'; busy?: boolean }) {
  return (
    <button
      type="button"
      {...rest}
      disabled={rest.disabled || busy}
      className={cx(
        'inline-flex w-full items-center justify-center gap-2 rounded-md px-4 py-3 text-[15px] font-medium transition-colors disabled:opacity-50',
        tone === 'primary' ? 'bg-navy text-white hover:bg-[#1a2740]' : 'border border-paper-rule bg-sheet text-navy hover:border-navy',
        className
      )}
    >
      {busy ? 'One moment…' : children}
    </button>
  );
}

export function Alert({ tone = 'error', children }: { tone?: 'error' | 'info' | 'ok'; children: ReactNode }) {
  const tones = { error: 'border-[#c0263d] bg-[#fdf0f2] text-[#8f1a2c]', info: 'border-paper-rule bg-sheet text-paper-mute', ok: 'border-paid bg-[#e9f7f0] text-paid' };
  return (
    <div role={tone === 'error' ? 'alert' : 'status'} className={cx('rounded-md border-l-4 px-3 py-2 text-sm', tones[tone])}>
      {children}
    </div>
  );
}

/** Shown when a page could not be loaded for a reason other than "no such link". */
export function Unreachable() {
  return (
    <div className="flex min-h-screen items-center justify-center p-6">
      <div className="max-w-md text-center">
        <h1 className="text-2xl font-semibold">This page could not be loaded</h1>
        <p className="mt-3 text-paper-mute">That is a connection or server problem, not a problem with your link. Nothing has been charged.</p>
        <button type="button" className="mt-5 rounded-md bg-navy px-4 py-2.5 font-medium text-white" onClick={() => window.location.reload()}>
          Try again
        </button>
      </div>
    </div>
  );
}

/** 404 means the link is wrong; anything else means we could not check. */
export function isMissing(err: unknown): boolean {
  return err instanceof ApiError && err.status === 404;
}

export function Missing({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center p-6">
      <div className="max-w-md text-center">
        <h1 className="text-2xl font-semibold">{title}</h1>
        {children && <p className="mt-3 text-paper-mute">{children}</p>}
      </div>
    </div>
  );
}

/** Call `fn` every `ms` while `active`. Skips ticks when the tab is hidden. */
export function usePoll(fn: () => Promise<void> | void, active: boolean, ms: number) {
  const ref = useRef(fn);
  ref.current = fn;
  useEffect(() => {
    if (!active) return;
    const t = window.setInterval(() => {
      if (document.visibilityState === 'visible') void ref.current();
    }, ms);
    return () => window.clearInterval(t);
  }, [active, ms]);
}

export function useNow(active: boolean): number {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!active) return;
    const t = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(t);
  }, [active]);
  return now;
}

export function CopyText({ text, label }: { text: string; label: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      className="text-sm underline"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setDone(true);
          window.setTimeout(() => setDone(false), 1800);
        } catch {
          window.prompt('Copy this:', text);
        }
      }}
    >
      {done ? 'Copied' : label}
    </button>
  );
}

/**
 * Pay-with-crypto panel. Fetches a quote from the server (which decides the
 * amount and the destination), draws the Solana Pay QR, and waits. Whether the
 * payment "arrived" is never decided here — the parent polls the server.
 */
export function CryptoPay({
  assets,
  getQuote,
  seen,
  support,
  initial,
}: {
  assets: CryptoAsset[];
  getQuote: (asset: CryptoAsset) => Promise<PublicQuote>;
  /** True once the server has seen the transfer on the network but it is not final yet. */
  seen: boolean;
  support: string | null;
  initial?: PublicQuote | null;
}) {
  const [quote, setQuote] = useState<PublicQuote | null>(initial ?? null);
  const [qr, setQr] = useState<string | null>(null);
  const [busy, setBusy] = useState<CryptoAsset | null>(null);
  const [error, setError] = useState<string | null>(null);
  const now = useNow(!!quote);

  useEffect(() => {
    let alive = true;
    setQr(null);
    if (quote) {
      QRCode.toDataURL(quote.url, { margin: 1, width: 480, errorCorrectionLevel: 'M' })
        .then(url => alive && setQr(url))
        .catch(() => alive && setQr(null));
    }
    return () => {
      alive = false;
    };
  }, [quote]);

  async function start(asset: CryptoAsset) {
    setBusy(asset);
    setError(null);
    try {
      setQuote(await getQuote(asset));
    } catch (err) {
      setError(messageOf(err));
    } finally {
      setBusy(null);
    }
  }

  if (!quote) {
    return (
      <div className="space-y-2">
        {assets.map(a => (
          <PButton key={a} tone="plain" busy={busy === a} disabled={busy !== null} onClick={() => void start(a)}>
            Pay with {a}
            <span className="text-paper-mute">on Solana</span>
          </PButton>
        ))}
        {error && <Alert>{error}</Alert>}
      </div>
    );
  }

  const left = quote.expiresAt - now;
  const expired = left <= 0;
  return (
    <div className="rounded-md border border-paper-rule bg-sheet p-4">
      <div className="flex items-baseline justify-between gap-3">
        <p className="text-sm text-paper-mute">Send exactly</p>
        <button type="button" className="text-sm text-paper-mute underline" onClick={() => setQuote(null)}>
          Change method
        </button>
      </div>
      <p className="num mt-1 text-2xl font-medium break-all">
        {quote.amount} {quote.asset}
      </p>
      <p className="num text-xs text-paper-mute">
        = {aud(quote.audCents)} AUD at ${quote.audPerUnit.toFixed(quote.asset === 'USDC' ? 4 : 2)} per {quote.asset}
        {quote.cluster !== 'mainnet-beta' ? ` · ${quote.cluster}` : ''}
      </p>

      {seen ? (
        <Alert tone="ok">Your payment has reached the network. Waiting for it to become final — usually under 30 seconds. Keep this page open.</Alert>
      ) : expired ? (
        <div className="mt-4 space-y-3">
          <Alert tone="info">This price expired because exchange rates move. Nothing was charged. Get a fresh one to continue.</Alert>
          <PButton tone="plain" busy={busy !== null} onClick={() => void start(quote.asset)}>
            Get a new price
          </PButton>
        </div>
      ) : (
        <>
          <div className="mt-4 flex justify-center">
            {qr ? <img src={qr} alt={`QR code to pay ${quote.amount} ${quote.asset}`} width={208} height={208} className="rounded border border-paper-rule" /> : <div className="h-52 w-52 rounded border border-paper-rule" />}
          </div>
          <p className="mt-3 text-center text-sm">Scan with Phantom, Solflare or another Solana wallet.</p>
          <a href={quote.url} className="mt-2 block rounded-md bg-navy px-4 py-3 text-center text-[15px] font-medium text-white hover:bg-[#1a2740]">
            Open in my wallet app
          </a>
          <p className="mt-3 flex items-center justify-center gap-2 text-sm text-paper-mute">
            <span aria-hidden className="pulse-dot inline-block h-2 w-2 rounded-full bg-navy" />
            Waiting for payment · price held for {countdown(left)}
          </p>

          <details className="mt-4 text-sm">
            <summary className="cursor-pointer text-paper-mute underline">Details and paying by hand</summary>
            <div className="mt-2 space-y-2">
              <p className="text-paper-mute">Recipient wallet</p>
              <p className="num flex flex-wrap gap-x-2 text-[13px]">
                {chunkAddress(quote.recipient).map((part, i) => (
                  <span key={i}>{part}</span>
                ))}
              </p>
              <CopyText text={quote.recipient} label="Copy address" />
              <p className="text-paper-mute">
                Use the QR code or the button above if you can. They attach a reference that matches the payment to you automatically. A plain transfer or an exchange withdrawal has no
                reference, so it still reaches {support ? 'us' : 'the seller'} but has to be matched by hand
                {support ? (
                  <>
                    {' '}
                    — email <a href={`mailto:${support}`} className="underline">{support}</a> with the transaction link.
                  </>
                ) : (
                  '.'
                )}
              </p>
            </div>
          </details>
        </>
      )}
      {error && (
        <div className="mt-3">
          <Alert>{error}</Alert>
        </div>
      )}
    </div>
  );
}

export { api, messageOf };
