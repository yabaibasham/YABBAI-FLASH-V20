import { useEffect, useState } from 'react';
import type { Mode } from '../../shared/types.ts';
import { Alert, Frame, PButton, api, messageOf } from './parts.tsx';

interface Site {
  brandName: string;
  mode: Mode;
  supportEmail: string | null;
}

const FIELD = 'mt-1 w-full rounded-md border border-paper-rule bg-sheet px-3 py-2.5 text-[15px] text-navy placeholder:text-paper-mute/70 focus:border-navy focus:outline-none';

export function IntakePage() {
  const [site, setSite] = useState<Site | null>(null);
  const [f, setF] = useState({ name: '', company: '', email: '', phone: '', sector: '', message: '', website: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    api
      .get<Site>('/api/public/site')
      .then(setSite)
      .catch(() => setSite({ brandName: 'Enquiries', mode: 'live', supportEmail: null }));
  }, []);

  if (!site) return null;
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => setF(v => ({ ...v, [k]: e.target.value }));

  return (
    <Frame brand={site.brandName} mode={site.mode} support={site.supportEmail} payments={false}>
      <div className="mx-auto max-w-xl">
        {sent ? (
          <div className="settle rounded-lg border border-paid bg-[#e9f7f0] p-6">
            <h1 className="text-2xl font-semibold text-paid">Got it — thank you</h1>
            <p className="mt-2">Your message is with {site.brandName}. A person reads every enquiry and will reply using the contact details you left.</p>
          </div>
        ) : (
          <>
            <h1 className="text-3xl font-semibold tracking-tight">Tell us what you need</h1>
            <p className="mt-2 text-paper-mute">A few lines is plenty. Say what is taking up your time or costing you customers, and how best to reach you.</p>
            <form
              className="mt-6 space-y-4"
              onSubmit={async e => {
                e.preventDefault();
                setBusy(true);
                setError(null);
                try {
                  await api.post('/api/public/intake', f);
                  setSent(true);
                } catch (err) {
                  setError(messageOf(err));
                } finally {
                  setBusy(false);
                }
              }}
            >
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block text-sm">
                  Your name
                  <input required maxLength={120} autoComplete="name" value={f.name} onChange={set('name')} className={FIELD} />
                </label>
                <label className="block text-sm">
                  Business <span className="text-paper-mute">(optional)</span>
                  <input maxLength={160} autoComplete="organization" value={f.company} onChange={set('company')} className={FIELD} />
                </label>
                <label className="block text-sm">
                  Email
                  <input type="email" maxLength={254} autoComplete="email" value={f.email} onChange={set('email')} className={FIELD} />
                </label>
                <label className="block text-sm">
                  Phone
                  <input type="tel" maxLength={40} autoComplete="tel" value={f.phone} onChange={set('phone')} className={FIELD} />
                </label>
              </div>
              <p className="-mt-2 text-xs text-paper-mute">Leave an email address or a phone number — at least one.</p>
              <label className="block text-sm">
                Industry <span className="text-paper-mute">(optional)</span>
                <input maxLength={80} value={f.sector} onChange={set('sector')} className={FIELD} />
              </label>
              <label className="block text-sm">
                What do you need help with?
                <textarea required maxLength={2000} rows={6} value={f.message} onChange={set('message')} className={FIELD} />
              </label>
              {/* Bots fill every field they find. People never see this one. */}
              <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
                <label>
                  Website
                  <input tabIndex={-1} autoComplete="off" value={f.website} onChange={set('website')} />
                </label>
              </div>
              {error && <Alert>{error}</Alert>}
              <PButton type="submit" busy={busy}>
                Send enquiry
              </PButton>
              <p className="text-xs text-paper-mute">Your details are used only to reply to this enquiry.</p>
            </form>
          </>
        )}
      </div>
    </Frame>
  );
}
