import { IntakePage } from './IntakePage.tsx';
import { InvoicePage } from './InvoicePage.tsx';
import { Missing } from './parts.tsx';
import { OrderPage, ProductPage } from './ProductPage.tsx';

const ID = '([A-Za-z0-9_-]{1,80})';

/** Customer-facing pages. No login, no console code, no stored state. */
export default function PublicApp({ path }: { path: string }) {
  const pay = new RegExp(`^/pay/${ID}/?$`).exec(path);
  if (pay) return <InvoicePage token={pay[1]} />;
  const product = new RegExp(`^/p/${ID}/?$`).exec(path);
  if (product) return <ProductPage slug={product[1]} />;
  const order = new RegExp(`^/order/${ID}/?$`).exec(path);
  if (order) return <OrderPage token={order[1]} />;
  if (/^\/intake\/?$/.test(path)) return <IntakePage />;
  return <Missing title="Page not found">This address does not lead anywhere. Check the link you were given.</Missing>;
}
