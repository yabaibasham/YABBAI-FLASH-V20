import { useCallback, useEffect, useRef, useState } from 'react';
import { aud } from '../lib/format.ts';
import type { CryptoAsset, PublicOrderView, PublicProductView, PublicQuote } from '../../shared/types.ts';
import { Alert, CopyText, CryptoPay, Frame, Missing, PButton, Unreachable, api, isMissing, messageOf, usePoll } from './parts.tsx';

type OrderView = PublicOrderView & { chain: 'none' | 'seen' | 'paid' };

// ── /p/:slug ────────────────────────────────────────────────────────────────
export function ProductPage({ slug }: { slug: string }) {
  const base = `/api/public/product/${encodeURIComponent(slug)}`;
  const [p, setP] = useState<PublicProductView | null>(null);
  const [fatal, setFatal] = useState<'missing' | 'unreachable' | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // Once a crypto payment code exists, the buyer is moved to their order page.
  const [handoff, setHandoff] = useState<{ token: string; quote: PublicQuote } | null>(null);

  useEffect(() => {
    api
      .get<PublicProductView>(base)
      .then(setP)
      .catch(err => setFatal(isMissing(err) ? 'missing' : 'unreachable'));
  }, [base]);

  if (handoff) return <OrderPage token={handoff.token} initialQuote={handoff.quote} />;
  if (fatal === 'unreachable') return <Unreachable />;
  if (fatal) return <Missing title="This product is not available">It may have been taken off sale. Check the link with whoever shared it.</Missing>;
  if (!p) return null;

  const assets: CryptoAsset[] = [...(p.rails.usdc ? (['USDC'] as const) : []), ...(p.rails.sol ? (['SOL'] as const) : [])];

  async function buyByCard() {
    setBusy(true);
    setError(null);
    try {
      const out = await api.post<{ url: string }>(`${base}/checkout`);
      window.location.assign(out.url);
    } catch (err) {
      setError(messageOf(err));
      setBusy(false);
    }
  }

  return (
    <Frame brand={p.brandName} mode={p.mode} support={p.supportEmail}>
      <div className="grid gap-10 lg:grid-cols-[minmax(0,1.4fr)_minmax(0,1fr)]">
        <article>
          <h1 className="text-4xl leading-tight font-semibold tracking-tight">{p.title}</h1>
          <p className="mt-4 max-w-prose text-[17px] leading-relaxed whitespace-pre-wrap">{p.description}</p>

          {p.ships.length > 0 && (
            <section className="mt-8">
              <h2 className="text-lg font-semibold">What you get</h2>
              <ul className="mt-3 space-y-2">
                {p.ships.map((s, i) => (
                  <li key={i} className="flex gap-3">
                    <span aria-hidden className="mt-[3px] text-paid">
                      ✓
                    </span>
                    <span>{s}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}
          {p.doesNotShip.length > 0 && (
            <section className="mt-8">
              <h2 className="text-lg font-semibold">What is not included</h2>
              <ul className="mt-3 space-y-2 text-paper-mute">
                {p.doesNotShip.map((s, i) => (
                  <li key={i} className="flex gap-3">
                    <span aria-hidden className="mt-[3px]">
                      –
                    </span>
                    <span>{s}</span>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </article>

        <aside>
          <div className="rounded-lg border border-paper-rule bg-sheet p-6 lg:sticky lg:top-6">
            <p className="num text-4xl font-medium tracking-tight">{aud(p.priceCents)}</p>
            <p className="text-xs text-paper-mute">Australian dollars, one-off{p.gstRegistered ? ', GST included' : ''}</p>
            <div className="mt-5 space-y-3">
              {p.rails.card && (
                <PButton busy={busy} onClick={() => void buyByCard()}>
                  Buy now with card
                </PButton>
              )}
              {assets.length > 0 && (
                <CryptoPay
                  assets={assets}
                  support={p.supportEmail}
                  seen={false}
                  getQuote={async asset => {
                    const out = await api.post<{ quote: PublicQuote; orderToken: string }>(`${base}/quote`, { asset });
                    // The order page address is the buyer's key to the download, so put it in the address bar straight away.
                    window.history.replaceState(null, '', `/order/${out.orderToken}`);
                    setHandoff({ token: out.orderToken, quote: out.quote });
                    return out.quote;
                  }}
                />
              )}
              {!p.rails.card && assets.length === 0 && <Alert tone="info">Checkout is not switched on for this product yet. Please check back soon.</Alert>}
              {error && <Alert>{error}</Alert>}
            </div>
            <p className="mt-4 text-xs text-paper-mute">Delivered on screen the moment your payment is confirmed. You get a private page to come back to.</p>
          </div>
        </aside>
      </div>
    </Frame>
  );
}

// ── /order/:token ───────────────────────────────────────────────────────────
export function OrderPage({ token, initialQuote }: { token: string; initialQuote?: PublicQuote }) {
  const [o, setO] = useState<OrderView | null>(null);
  const [fatal, setFatal] = useState<'missing' | 'unreachable' | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sessionId, setSessionId] = useState(() => new URLSearchParams(window.location.search).get('session_id'));
  const [watching, setWatching] = useState(!!initialQuote);
  const loaded = useRef(false);

  const load = useCallback(async () => {
    try {
      const view = await api.get<OrderView>(`/api/public/order/${encodeURIComponent(token)}${sessionId ? `?session_id=${encodeURIComponent(sessionId)}` : ''}`);
      loaded.current = true;
      setO(view);
      if (view.status === 'paid' && sessionId) {
        window.history.replaceState(null, '', window.location.pathname);
        setSessionId(null);
      }
    } catch (err) {
      // A failed refresh of a page that already loaded is just retried on the next tick.
      if (isMissing(err)) setFatal('missing');
      else if (!loaded.current) setFatal('unreachable');
    }
  }, [token, sessionId]);

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  usePoll(load, !!o && o.status === 'pending', watching || sessionId ? 4000 : 20_000);

  if (fatal === 'unreachable') return <Unreachable />;
  if (fatal) return <Missing title="This order link is not valid">Check that you copied the whole address.</Missing>;
  if (!o) return null;

  const productBase = o.productSlug ? `/api/public/product/${encodeURIComponent(o.productSlug)}` : null;
  const assets: CryptoAsset[] = [...(o.rails.usdc ? (['USDC'] as const) : []), ...(o.rails.sol ? (['SOL'] as const) : [])];

  return (
    <Frame brand={o.brandName} mode={o.mode} support={o.supportEmail}>
      <div className="mx-auto max-w-xl">
        <p className="text-sm text-paper-mute">Your order</p>
        <h1 className="text-3xl font-semibold tracking-tight">{o.productTitle}</h1>
        <p className="num mt-1 text-paper-mute">{aud(o.priceCents)} AUD</p>

        {o.status === 'paid' && o.deliverable && (
          <div className="settle mt-6 rounded-lg border border-paid bg-[#e9f7f0] p-6">
            <p className="font-medium text-paid">Payment confirmed. Here is your purchase.</p>
            {o.deliverable.kind === 'link' ? (
              <div className="mt-4">
                <a href={o.deliverable.value} target="_blank" rel="noreferrer noopener" className="block rounded-md bg-navy px-4 py-3 text-center font-medium text-white hover:bg-[#1a2740]">
                  Open your download
                </a>
                <p className="num mt-3 text-xs break-all text-paper-mute">{o.deliverable.value}</p>
              </div>
            ) : (
              <div className="mt-4">
                <pre className="num max-h-96 overflow-auto rounded border border-paper-rule bg-sheet p-3 text-sm whitespace-pre-wrap text-navy">{o.deliverable.value}</pre>
                <div className="mt-2">
                  <CopyText text={o.deliverable.value} label="Copy all" />
                </div>
              </div>
            )}
            <p className="mt-4 text-sm">Bookmark this page. Its address is your receipt and your way back to the purchase.</p>
          </div>
        )}

        {o.status === 'paid' && !o.deliverable && (
          <div className="mt-6">
            <Alert tone="info">
              Your payment is confirmed, but the delivery is not available on this page right now.
              {o.supportEmail ? ` Email ${o.supportEmail} and quote this page's address.` : ' Contact the seller and quote this page\'s address.'}
            </Alert>
          </div>
        )}

        {o.status === 'refunded' && (
          <div className="mt-6">
            <Alert tone="info">This order was refunded, so the purchase is no longer available here.</Alert>
          </div>
        )}

        {o.status === 'expired' && (
          <div className="mt-6 space-y-3">
            <Alert tone="info">This order was never paid and has expired. Nothing was charged.</Alert>
          </div>
        )}

        {o.status === 'pending' && (
          <div className="mt-6 rounded-lg border border-paper-rule bg-sheet p-6">
            {sessionId ? (
              <Alert tone="info">Confirming your card payment with Stripe. This takes a few seconds.</Alert>
            ) : (
              <p className="text-sm">
                <strong>Waiting for payment.</strong> Keep this page: your purchase appears here as soon as the payment is confirmed. If you close it, come back to this same address.
              </p>
            )}
            <div className="mt-4 space-y-3">
              {assets.length > 0 && productBase && (
                <CryptoPay
                  assets={assets}
                  support={o.supportEmail}
                  seen={o.chain === 'seen'}
                  initial={initialQuote}
                  getQuote={async asset => {
                    const out = await api.post<{ quote: PublicQuote }>(`${productBase}/quote`, { asset, orderToken: token });
                    setWatching(true);
                    return out.quote;
                  }}
                />
              )}
              {o.rails.card && productBase && !sessionId && (
                <PButton
                  tone={assets.length > 0 ? 'plain' : 'primary'}
                  busy={busy}
                  onClick={async () => {
                    setBusy(true);
                    setError(null);
                    try {
                      const out = await api.post<{ url: string }>(`${productBase}/checkout`, { orderToken: token });
                      window.location.assign(out.url);
                    } catch (err) {
                      setError(messageOf(err));
                      setBusy(false);
                    }
                  }}
                >
                  Pay {aud(o.priceCents)} by card
                </PButton>
              )}
              {!productBase && !sessionId && <Alert tone="info">This product is no longer on sale, so this order cannot be paid.</Alert>}
              {productBase && !o.rails.card && assets.length === 0 && !sessionId && <Alert tone="info">Checkout is switched off at the moment. Please try again later.</Alert>}
              {error && <Alert>{error}</Alert>}
            </div>
          </div>
        )}
      </div>
    </Frame>
  );
}
